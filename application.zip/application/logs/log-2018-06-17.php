<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-17 00:00:01 --> Helper loaded: url_helper
INFO - 2018-06-17 00:00:01 --> Helper loaded: notification_helper
INFO - 2018-06-17 00:00:01 --> Helper loaded: settings_helper
INFO - 2018-06-17 00:00:01 --> Helper loaded: permission_helper
INFO - 2018-06-17 00:00:01 --> Helper loaded: users_helper
INFO - 2018-06-17 00:00:01 --> Database Driver Class Initialized
DEBUG - 2018-06-17 00:00:01 --> Session: Initialization under CLI aborted.
INFO - 2018-06-17 00:00:01 --> Helper loaded: form_helper
INFO - 2018-06-17 00:00:01 --> Form Validation Class Initialized
INFO - 2018-06-17 00:00:01 --> Controller Class Initialized
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 00:00:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 00:00:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Final output sent to browser
DEBUG - 2018-06-17 00:00:01 --> Total execution time: 0.0933
INFO - 2018-06-17 00:00:01 --> Helper loaded: url_helper
INFO - 2018-06-17 00:00:01 --> Helper loaded: notification_helper
INFO - 2018-06-17 00:00:01 --> Helper loaded: settings_helper
INFO - 2018-06-17 00:00:01 --> Helper loaded: permission_helper
INFO - 2018-06-17 00:00:01 --> Helper loaded: users_helper
INFO - 2018-06-17 00:00:01 --> Database Driver Class Initialized
DEBUG - 2018-06-17 00:00:01 --> Session: Initialization under CLI aborted.
INFO - 2018-06-17 00:00:01 --> Helper loaded: form_helper
INFO - 2018-06-17 00:00:01 --> Form Validation Class Initialized
INFO - 2018-06-17 00:00:01 --> Controller Class Initialized
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 00:00:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 00:00:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:01 --> Model Class Initialized
INFO - 2018-06-17 00:00:02 --> Model Class Initialized
INFO - 2018-06-17 00:00:02 --> Model Class Initialized
INFO - 2018-06-17 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 00:00:02 --> Model Class Initialized
INFO - 2018-06-17 00:00:02 --> Final output sent to browser
DEBUG - 2018-06-17 00:00:02 --> Total execution time: 0.0699
INFO - 2018-06-17 14:50:15 --> Config Class Initialized
INFO - 2018-06-17 14:50:15 --> Hooks Class Initialized
INFO - 2018-06-17 14:50:15 --> Config Class Initialized
INFO - 2018-06-17 14:50:15 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:15 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:15 --> Utf8 Class Initialized
DEBUG - 2018-06-17 14:50:15 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:15 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:15 --> URI Class Initialized
INFO - 2018-06-17 14:50:15 --> URI Class Initialized
INFO - 2018-06-17 14:50:15 --> Router Class Initialized
INFO - 2018-06-17 14:50:15 --> Router Class Initialized
INFO - 2018-06-17 14:50:15 --> Output Class Initialized
INFO - 2018-06-17 14:50:15 --> Output Class Initialized
INFO - 2018-06-17 14:50:15 --> Security Class Initialized
INFO - 2018-06-17 14:50:15 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:15 --> Input Class Initialized
DEBUG - 2018-06-17 14:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:15 --> Input Class Initialized
INFO - 2018-06-17 14:50:15 --> Language Class Initialized
INFO - 2018-06-17 14:50:15 --> Language Class Initialized
INFO - 2018-06-17 14:50:15 --> Language Class Initialized
INFO - 2018-06-17 14:50:15 --> Config Class Initialized
INFO - 2018-06-17 14:50:15 --> Loader Class Initialized
INFO - 2018-06-17 14:50:15 --> Language Class Initialized
INFO - 2018-06-17 14:50:15 --> Config Class Initialized
INFO - 2018-06-17 14:50:15 --> Loader Class Initialized
INFO - 2018-06-17 20:20:15 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:15 --> Database Driver Class Initialized
INFO - 2018-06-17 20:20:15 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-17 20:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:15 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:15 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:15 --> Controller Class Initialized
INFO - 2018-06-17 20:20:15 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:15 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:15 --> Controller Class Initialized
INFO - 2018-06-17 20:20:15 --> Model Class Initialized
INFO - 2018-06-17 20:20:15 --> Model Class Initialized
INFO - 2018-06-17 20:20:15 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:20:15 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 20:20:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:15 --> Model Class Initialized
INFO - 2018-06-17 20:20:15 --> Model Class Initialized
INFO - 2018-06-17 20:20:15 --> Model Class Initialized
INFO - 2018-06-17 20:20:15 --> Model Class Initialized
INFO - 2018-06-17 20:20:15 --> Model Class Initialized
INFO - 2018-06-17 20:20:15 --> Model Class Initialized
INFO - 2018-06-17 20:20:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:16 --> Total execution time: 0.6080
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:16 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:16 --> Total execution time: 0.6314
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:16 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:16 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:16 --> URI Class Initialized
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:16 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:16 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:16 --> Router Class Initialized
INFO - 2018-06-17 14:50:16 --> URI Class Initialized
INFO - 2018-06-17 14:50:16 --> Output Class Initialized
INFO - 2018-06-17 14:50:16 --> Router Class Initialized
INFO - 2018-06-17 14:50:16 --> Security Class Initialized
INFO - 2018-06-17 14:50:16 --> Output Class Initialized
DEBUG - 2018-06-17 14:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:16 --> Input Class Initialized
INFO - 2018-06-17 14:50:16 --> Security Class Initialized
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
DEBUG - 2018-06-17 14:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:16 --> Input Class Initialized
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Loader Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: url_helper
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Loader Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:16 --> Database Driver Class Initialized
INFO - 2018-06-17 20:20:16 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:16 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:16 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:16 --> Controller Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:16 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:16 --> Controller Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 20:20:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:16 --> Total execution time: 0.1575
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:16 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:16 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:16 --> URI Class Initialized
INFO - 2018-06-17 14:50:16 --> Router Class Initialized
INFO - 2018-06-17 14:50:16 --> Output Class Initialized
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Hooks Class Initialized
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Hooks Class Initialized
INFO - 2018-06-17 14:50:16 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:16 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:16 --> Utf8 Class Initialized
DEBUG - 2018-06-17 14:50:16 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:16 --> Utf8 Class Initialized
DEBUG - 2018-06-17 14:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:16 --> Input Class Initialized
INFO - 2018-06-17 14:50:16 --> URI Class Initialized
INFO - 2018-06-17 14:50:16 --> URI Class Initialized
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
INFO - 2018-06-17 14:50:16 --> Router Class Initialized
INFO - 2018-06-17 14:50:16 --> Output Class Initialized
INFO - 2018-06-17 14:50:16 --> Security Class Initialized
INFO - 2018-06-17 14:50:16 --> Router Class Initialized
DEBUG - 2018-06-17 14:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:16 --> Input Class Initialized
INFO - 2018-06-17 14:50:16 --> Output Class Initialized
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
INFO - 2018-06-17 14:50:16 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:16 --> Input Class Initialized
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Loader Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: url_helper
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Loader Class Initialized
INFO - 2018-06-17 14:50:16 --> Language Class Initialized
INFO - 2018-06-17 14:50:16 --> Config Class Initialized
INFO - 2018-06-17 14:50:16 --> Loader Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:16 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:16 --> Database Driver Class Initialized
INFO - 2018-06-17 20:20:16 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:16 --> Database Driver Class Initialized
INFO - 2018-06-17 20:20:16 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:16 --> Total execution time: 0.2717
DEBUG - 2018-06-17 20:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:16 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:16 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:16 --> Controller Class Initialized
DEBUG - 2018-06-17 20:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:16 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:16 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:16 --> Controller Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:16 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:16 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:16 --> Controller Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
DEBUG - 2018-06-17 20:20:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:20:16 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:16 --> Total execution time: 0.1522
DEBUG - 2018-06-17 20:20:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:16 --> Model Class Initialized
INFO - 2018-06-17 20:20:16 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:16 --> Total execution time: 0.1379
INFO - 2018-06-17 20:20:16 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:16 --> Total execution time: 0.1586
INFO - 2018-06-17 14:50:17 --> Config Class Initialized
INFO - 2018-06-17 14:50:17 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:17 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:17 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:17 --> URI Class Initialized
INFO - 2018-06-17 14:50:17 --> Router Class Initialized
INFO - 2018-06-17 14:50:17 --> Output Class Initialized
INFO - 2018-06-17 14:50:17 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:17 --> Input Class Initialized
INFO - 2018-06-17 14:50:17 --> Language Class Initialized
INFO - 2018-06-17 14:50:17 --> Language Class Initialized
INFO - 2018-06-17 14:50:17 --> Config Class Initialized
INFO - 2018-06-17 14:50:17 --> Loader Class Initialized
INFO - 2018-06-17 20:20:17 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:17 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:17 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:17 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:17 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:17 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:17 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:17 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:17 --> Controller Class Initialized
INFO - 2018-06-17 20:20:17 --> Model Class Initialized
INFO - 2018-06-17 20:20:17 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:17 --> Model Class Initialized
INFO - 2018-06-17 20:20:17 --> Model Class Initialized
INFO - 2018-06-17 20:20:17 --> Model Class Initialized
INFO - 2018-06-17 20:20:17 --> Model Class Initialized
INFO - 2018-06-17 20:20:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:17 --> Model Class Initialized
INFO - 2018-06-17 20:20:17 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:17 --> Total execution time: 0.1062
INFO - 2018-06-17 14:50:18 --> Config Class Initialized
INFO - 2018-06-17 14:50:18 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:18 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:18 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:18 --> URI Class Initialized
INFO - 2018-06-17 14:50:18 --> Router Class Initialized
INFO - 2018-06-17 14:50:18 --> Output Class Initialized
INFO - 2018-06-17 14:50:18 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:18 --> Input Class Initialized
INFO - 2018-06-17 14:50:18 --> Language Class Initialized
INFO - 2018-06-17 14:50:18 --> Language Class Initialized
INFO - 2018-06-17 14:50:18 --> Config Class Initialized
INFO - 2018-06-17 14:50:18 --> Loader Class Initialized
INFO - 2018-06-17 20:20:18 --> Helper loaded: url_helper
INFO - 2018-06-17 14:50:18 --> Config Class Initialized
INFO - 2018-06-17 14:50:18 --> Hooks Class Initialized
INFO - 2018-06-17 20:20:18 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:18 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:18 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:18 --> Helper loaded: users_helper
DEBUG - 2018-06-17 14:50:18 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:18 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:18 --> URI Class Initialized
INFO - 2018-06-17 14:50:18 --> Router Class Initialized
INFO - 2018-06-17 14:50:18 --> Output Class Initialized
INFO - 2018-06-17 20:20:18 --> Database Driver Class Initialized
INFO - 2018-06-17 14:50:18 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:18 --> Input Class Initialized
INFO - 2018-06-17 14:50:18 --> Language Class Initialized
DEBUG - 2018-06-17 20:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:18 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:18 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:18 --> Controller Class Initialized
INFO - 2018-06-17 14:50:18 --> Language Class Initialized
INFO - 2018-06-17 14:50:18 --> Config Class Initialized
INFO - 2018-06-17 14:50:18 --> Loader Class Initialized
INFO - 2018-06-17 20:20:18 --> Model Class Initialized
INFO - 2018-06-17 20:20:18 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:18 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:20:18 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:18 --> Helper loaded: settings_helper
DEBUG - 2018-06-17 20:20:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:18 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:18 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 14:50:18 --> Config Class Initialized
INFO - 2018-06-17 14:50:18 --> Hooks Class Initialized
INFO - 2018-06-17 20:20:18 --> Model Class Initialized
INFO - 2018-06-17 20:20:18 --> Model Class Initialized
INFO - 2018-06-17 20:20:18 --> Model Class Initialized
INFO - 2018-06-17 20:20:18 --> Model Class Initialized
INFO - 2018-06-17 20:20:18 --> Model Class Initialized
INFO - 2018-06-17 20:20:18 --> Model Class Initialized
INFO - 2018-06-17 20:20:18 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-17 14:50:18 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:18 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:18 --> URI Class Initialized
INFO - 2018-06-17 20:20:18 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:18 --> Total execution time: 0.1159
INFO - 2018-06-17 14:50:18 --> Router Class Initialized
INFO - 2018-06-17 20:20:18 --> Database Driver Class Initialized
INFO - 2018-06-17 14:50:18 --> Output Class Initialized
INFO - 2018-06-17 14:50:18 --> Security Class Initialized
DEBUG - 2018-06-17 20:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 14:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:19 --> Input Class Initialized
INFO - 2018-06-17 14:50:19 --> Language Class Initialized
INFO - 2018-06-17 20:20:19 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:19 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:19 --> Controller Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 14:50:19 --> Language Class Initialized
INFO - 2018-06-17 14:50:19 --> Config Class Initialized
INFO - 2018-06-17 14:50:19 --> Loader Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Database Driver Class Initialized
INFO - 2018-06-17 20:20:19 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:19 --> Total execution time: 0.1318
DEBUG - 2018-06-17 20:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:19 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:19 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:19 --> Controller Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Model Class Initialized
INFO - 2018-06-17 20:20:19 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:19 --> Total execution time: 0.1576
INFO - 2018-06-17 14:50:22 --> Config Class Initialized
INFO - 2018-06-17 14:50:22 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:22 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:22 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:22 --> URI Class Initialized
INFO - 2018-06-17 14:50:22 --> Router Class Initialized
INFO - 2018-06-17 14:50:22 --> Output Class Initialized
INFO - 2018-06-17 14:50:22 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:22 --> Input Class Initialized
INFO - 2018-06-17 14:50:22 --> Language Class Initialized
INFO - 2018-06-17 14:50:22 --> Language Class Initialized
INFO - 2018-06-17 14:50:22 --> Config Class Initialized
INFO - 2018-06-17 14:50:22 --> Loader Class Initialized
INFO - 2018-06-17 20:20:22 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:22 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:22 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:22 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:22 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:22 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:22 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:22 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:22 --> Controller Class Initialized
INFO - 2018-06-17 20:20:22 --> Model Class Initialized
INFO - 2018-06-17 20:20:22 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:22 --> Model Class Initialized
INFO - 2018-06-17 20:20:22 --> Model Class Initialized
INFO - 2018-06-17 20:20:22 --> Model Class Initialized
INFO - 2018-06-17 20:20:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:22 --> Model Class Initialized
INFO - 2018-06-17 20:20:22 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:22 --> Total execution time: 0.1019
INFO - 2018-06-17 14:50:33 --> Config Class Initialized
INFO - 2018-06-17 14:50:33 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:33 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:33 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:33 --> URI Class Initialized
INFO - 2018-06-17 14:50:33 --> Router Class Initialized
INFO - 2018-06-17 14:50:33 --> Output Class Initialized
INFO - 2018-06-17 14:50:33 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:33 --> Input Class Initialized
INFO - 2018-06-17 14:50:33 --> Language Class Initialized
INFO - 2018-06-17 14:50:33 --> Language Class Initialized
INFO - 2018-06-17 14:50:33 --> Config Class Initialized
INFO - 2018-06-17 14:50:33 --> Loader Class Initialized
INFO - 2018-06-17 20:20:33 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:33 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:33 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:33 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:33 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:33 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:33 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:33 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:33 --> Controller Class Initialized
INFO - 2018-06-17 20:20:33 --> Model Class Initialized
INFO - 2018-06-17 20:20:33 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:33 --> Model Class Initialized
INFO - 2018-06-17 20:20:33 --> Model Class Initialized
INFO - 2018-06-17 20:20:33 --> Model Class Initialized
INFO - 2018-06-17 20:20:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:33 --> Model Class Initialized
INFO - 2018-06-17 20:20:33 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:33 --> Total execution time: 0.1316
INFO - 2018-06-17 14:50:37 --> Config Class Initialized
INFO - 2018-06-17 14:50:37 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:37 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:37 --> URI Class Initialized
INFO - 2018-06-17 14:50:37 --> Router Class Initialized
INFO - 2018-06-17 14:50:37 --> Output Class Initialized
INFO - 2018-06-17 14:50:37 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:37 --> Input Class Initialized
INFO - 2018-06-17 14:50:37 --> Language Class Initialized
INFO - 2018-06-17 14:50:37 --> Language Class Initialized
INFO - 2018-06-17 14:50:37 --> Config Class Initialized
INFO - 2018-06-17 14:50:37 --> Loader Class Initialized
INFO - 2018-06-17 20:20:37 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:37 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:37 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:37 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:37 --> Controller Class Initialized
INFO - 2018-06-17 20:20:37 --> Model Class Initialized
INFO - 2018-06-17 20:20:37 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:37 --> Model Class Initialized
INFO - 2018-06-17 20:20:37 --> Model Class Initialized
INFO - 2018-06-17 20:20:37 --> Model Class Initialized
INFO - 2018-06-17 20:20:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:37 --> Model Class Initialized
INFO - 2018-06-17 20:20:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:37 --> Total execution time: 0.1082
INFO - 2018-06-17 14:50:40 --> Config Class Initialized
INFO - 2018-06-17 14:50:40 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:40 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:40 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:40 --> URI Class Initialized
INFO - 2018-06-17 14:50:40 --> Router Class Initialized
INFO - 2018-06-17 14:50:40 --> Output Class Initialized
INFO - 2018-06-17 14:50:40 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:40 --> Input Class Initialized
INFO - 2018-06-17 14:50:40 --> Language Class Initialized
INFO - 2018-06-17 14:50:40 --> Language Class Initialized
INFO - 2018-06-17 14:50:40 --> Config Class Initialized
INFO - 2018-06-17 14:50:40 --> Loader Class Initialized
INFO - 2018-06-17 20:20:40 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:40 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:40 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:40 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:40 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:40 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:40 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:40 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:40 --> Controller Class Initialized
INFO - 2018-06-17 20:20:40 --> Model Class Initialized
INFO - 2018-06-17 20:20:40 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:40 --> Model Class Initialized
INFO - 2018-06-17 20:20:40 --> Model Class Initialized
INFO - 2018-06-17 20:20:40 --> Model Class Initialized
INFO - 2018-06-17 20:20:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:40 --> Model Class Initialized
INFO - 2018-06-17 20:20:40 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:40 --> Total execution time: 0.1126
INFO - 2018-06-17 14:50:47 --> Config Class Initialized
INFO - 2018-06-17 14:50:47 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:47 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:47 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:47 --> URI Class Initialized
INFO - 2018-06-17 14:50:47 --> Router Class Initialized
INFO - 2018-06-17 14:50:47 --> Output Class Initialized
INFO - 2018-06-17 14:50:47 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:47 --> Input Class Initialized
INFO - 2018-06-17 14:50:47 --> Language Class Initialized
INFO - 2018-06-17 14:50:47 --> Language Class Initialized
INFO - 2018-06-17 14:50:47 --> Config Class Initialized
INFO - 2018-06-17 14:50:47 --> Loader Class Initialized
INFO - 2018-06-17 20:20:47 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:47 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:47 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:47 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:47 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:47 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:47 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:47 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:47 --> Controller Class Initialized
INFO - 2018-06-17 20:20:47 --> Model Class Initialized
INFO - 2018-06-17 20:20:47 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:47 --> Model Class Initialized
INFO - 2018-06-17 20:20:47 --> Model Class Initialized
INFO - 2018-06-17 20:20:47 --> Model Class Initialized
INFO - 2018-06-17 20:20:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:47 --> Model Class Initialized
INFO - 2018-06-17 20:20:47 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:47 --> Total execution time: 0.1030
INFO - 2018-06-17 14:50:50 --> Config Class Initialized
INFO - 2018-06-17 14:50:50 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:50 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:50 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:50 --> URI Class Initialized
INFO - 2018-06-17 14:50:50 --> Router Class Initialized
INFO - 2018-06-17 14:50:50 --> Output Class Initialized
INFO - 2018-06-17 14:50:50 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:50 --> Input Class Initialized
INFO - 2018-06-17 14:50:50 --> Language Class Initialized
INFO - 2018-06-17 14:50:50 --> Language Class Initialized
INFO - 2018-06-17 14:50:50 --> Config Class Initialized
INFO - 2018-06-17 14:50:50 --> Loader Class Initialized
INFO - 2018-06-17 20:20:50 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:50 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:50 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:50 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:50 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:50 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:50 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:50 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:50 --> Controller Class Initialized
INFO - 2018-06-17 20:20:50 --> Model Class Initialized
INFO - 2018-06-17 20:20:50 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:50 --> Model Class Initialized
INFO - 2018-06-17 20:20:50 --> Model Class Initialized
INFO - 2018-06-17 20:20:50 --> Model Class Initialized
INFO - 2018-06-17 20:20:50 --> Model Class Initialized
INFO - 2018-06-17 20:20:50 --> Model Class Initialized
INFO - 2018-06-17 20:20:50 --> Model Class Initialized
INFO - 2018-06-17 20:20:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:50 --> Model Class Initialized
INFO - 2018-06-17 20:20:50 --> Model Class Initialized
ERROR - 2018-06-17 20:20:50 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-17 20:20:50 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:50 --> Total execution time: 0.1398
INFO - 2018-06-17 14:50:53 --> Config Class Initialized
INFO - 2018-06-17 14:50:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:53 --> URI Class Initialized
INFO - 2018-06-17 14:50:53 --> Router Class Initialized
INFO - 2018-06-17 14:50:53 --> Output Class Initialized
INFO - 2018-06-17 14:50:53 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:53 --> Input Class Initialized
INFO - 2018-06-17 14:50:53 --> Language Class Initialized
INFO - 2018-06-17 14:50:53 --> Language Class Initialized
INFO - 2018-06-17 14:50:53 --> Config Class Initialized
INFO - 2018-06-17 14:50:53 --> Loader Class Initialized
INFO - 2018-06-17 20:20:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:53 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:53 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:53 --> Controller Class Initialized
INFO - 2018-06-17 20:20:53 --> Model Class Initialized
INFO - 2018-06-17 20:20:53 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:53 --> Model Class Initialized
INFO - 2018-06-17 20:20:53 --> Model Class Initialized
INFO - 2018-06-17 20:20:53 --> Model Class Initialized
INFO - 2018-06-17 20:20:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:53 --> Model Class Initialized
INFO - 2018-06-17 20:20:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:53 --> Total execution time: 0.1079
INFO - 2018-06-17 14:50:55 --> Config Class Initialized
INFO - 2018-06-17 14:50:55 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:55 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:55 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:55 --> URI Class Initialized
INFO - 2018-06-17 14:50:55 --> Router Class Initialized
INFO - 2018-06-17 14:50:55 --> Output Class Initialized
INFO - 2018-06-17 14:50:55 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:55 --> Input Class Initialized
INFO - 2018-06-17 14:50:55 --> Language Class Initialized
INFO - 2018-06-17 14:50:55 --> Language Class Initialized
INFO - 2018-06-17 14:50:55 --> Config Class Initialized
INFO - 2018-06-17 14:50:55 --> Loader Class Initialized
INFO - 2018-06-17 20:20:55 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:55 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:55 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:55 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:55 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:55 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:55 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:55 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:55 --> Controller Class Initialized
INFO - 2018-06-17 20:20:55 --> Model Class Initialized
INFO - 2018-06-17 20:20:55 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:55 --> Model Class Initialized
INFO - 2018-06-17 20:20:55 --> Model Class Initialized
INFO - 2018-06-17 20:20:55 --> Model Class Initialized
INFO - 2018-06-17 20:20:55 --> Model Class Initialized
INFO - 2018-06-17 20:20:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:55 --> Model Class Initialized
INFO - 2018-06-17 20:20:55 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:55 --> Total execution time: 0.1110
INFO - 2018-06-17 14:50:55 --> Config Class Initialized
INFO - 2018-06-17 14:50:55 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:55 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:55 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:55 --> URI Class Initialized
INFO - 2018-06-17 14:50:55 --> Router Class Initialized
INFO - 2018-06-17 14:50:55 --> Output Class Initialized
INFO - 2018-06-17 14:50:55 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:55 --> Input Class Initialized
INFO - 2018-06-17 14:50:55 --> Language Class Initialized
INFO - 2018-06-17 14:50:55 --> Language Class Initialized
INFO - 2018-06-17 14:50:55 --> Config Class Initialized
INFO - 2018-06-17 14:50:55 --> Loader Class Initialized
INFO - 2018-06-17 20:20:55 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:55 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:55 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:55 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:55 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:56 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:56 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:56 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:56 --> Controller Class Initialized
INFO - 2018-06-17 20:20:56 --> Model Class Initialized
INFO - 2018-06-17 20:20:56 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:56 --> Model Class Initialized
INFO - 2018-06-17 20:20:56 --> Model Class Initialized
INFO - 2018-06-17 20:20:56 --> Model Class Initialized
INFO - 2018-06-17 20:20:56 --> Model Class Initialized
INFO - 2018-06-17 20:20:56 --> Model Class Initialized
INFO - 2018-06-17 20:20:56 --> Model Class Initialized
INFO - 2018-06-17 20:20:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:56 --> Model Class Initialized
INFO - 2018-06-17 20:20:56 --> Model Class Initialized
ERROR - 2018-06-17 20:20:56 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-17 20:20:56 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:56 --> Total execution time: 0.1190
INFO - 2018-06-17 14:50:59 --> Config Class Initialized
INFO - 2018-06-17 14:50:59 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:50:59 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:50:59 --> Utf8 Class Initialized
INFO - 2018-06-17 14:50:59 --> URI Class Initialized
INFO - 2018-06-17 14:50:59 --> Router Class Initialized
INFO - 2018-06-17 14:50:59 --> Output Class Initialized
INFO - 2018-06-17 14:50:59 --> Security Class Initialized
DEBUG - 2018-06-17 14:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:50:59 --> Input Class Initialized
INFO - 2018-06-17 14:50:59 --> Language Class Initialized
INFO - 2018-06-17 14:50:59 --> Language Class Initialized
INFO - 2018-06-17 14:50:59 --> Config Class Initialized
INFO - 2018-06-17 14:50:59 --> Loader Class Initialized
INFO - 2018-06-17 20:20:59 --> Helper loaded: url_helper
INFO - 2018-06-17 20:20:59 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:20:59 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:20:59 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:20:59 --> Helper loaded: users_helper
INFO - 2018-06-17 20:20:59 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:20:59 --> Helper loaded: form_helper
INFO - 2018-06-17 20:20:59 --> Form Validation Class Initialized
INFO - 2018-06-17 20:20:59 --> Controller Class Initialized
INFO - 2018-06-17 20:20:59 --> Model Class Initialized
INFO - 2018-06-17 20:20:59 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:20:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:20:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:20:59 --> Model Class Initialized
INFO - 2018-06-17 20:20:59 --> Model Class Initialized
INFO - 2018-06-17 20:20:59 --> Model Class Initialized
INFO - 2018-06-17 20:20:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:20:59 --> Model Class Initialized
INFO - 2018-06-17 20:20:59 --> Final output sent to browser
DEBUG - 2018-06-17 20:20:59 --> Total execution time: 0.1049
INFO - 2018-06-17 14:51:01 --> Config Class Initialized
INFO - 2018-06-17 14:51:01 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:01 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:01 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:01 --> URI Class Initialized
INFO - 2018-06-17 14:51:01 --> Router Class Initialized
INFO - 2018-06-17 14:51:01 --> Output Class Initialized
INFO - 2018-06-17 14:51:01 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:01 --> Input Class Initialized
INFO - 2018-06-17 14:51:01 --> Language Class Initialized
INFO - 2018-06-17 14:51:01 --> Language Class Initialized
INFO - 2018-06-17 14:51:01 --> Config Class Initialized
INFO - 2018-06-17 14:51:01 --> Loader Class Initialized
INFO - 2018-06-17 20:21:01 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:01 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:01 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:01 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:01 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:01 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:01 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:01 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:01 --> Controller Class Initialized
INFO - 2018-06-17 20:21:01 --> Model Class Initialized
INFO - 2018-06-17 20:21:01 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:01 --> Model Class Initialized
INFO - 2018-06-17 20:21:01 --> Model Class Initialized
INFO - 2018-06-17 20:21:01 --> Model Class Initialized
INFO - 2018-06-17 20:21:01 --> Model Class Initialized
INFO - 2018-06-17 20:21:01 --> Model Class Initialized
INFO - 2018-06-17 20:21:01 --> Model Class Initialized
INFO - 2018-06-17 20:21:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:01 --> Model Class Initialized
INFO - 2018-06-17 20:21:01 --> Model Class Initialized
ERROR - 2018-06-17 20:21:01 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-17 20:21:01 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:01 --> Total execution time: 0.1269
INFO - 2018-06-17 14:51:01 --> Config Class Initialized
INFO - 2018-06-17 14:51:01 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:01 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:01 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:01 --> URI Class Initialized
INFO - 2018-06-17 14:51:01 --> Router Class Initialized
INFO - 2018-06-17 14:51:01 --> Output Class Initialized
INFO - 2018-06-17 14:51:01 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:01 --> Input Class Initialized
INFO - 2018-06-17 14:51:02 --> Language Class Initialized
INFO - 2018-06-17 14:51:02 --> Language Class Initialized
INFO - 2018-06-17 14:51:02 --> Config Class Initialized
INFO - 2018-06-17 14:51:02 --> Loader Class Initialized
INFO - 2018-06-17 20:21:02 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:02 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:02 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:02 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:02 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:02 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:02 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:02 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:02 --> Controller Class Initialized
INFO - 2018-06-17 20:21:02 --> Model Class Initialized
INFO - 2018-06-17 20:21:02 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:02 --> Model Class Initialized
INFO - 2018-06-17 20:21:02 --> Model Class Initialized
INFO - 2018-06-17 20:21:02 --> Model Class Initialized
INFO - 2018-06-17 20:21:02 --> Model Class Initialized
INFO - 2018-06-17 20:21:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:02 --> Model Class Initialized
INFO - 2018-06-17 20:21:02 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:02 --> Total execution time: 0.1001
INFO - 2018-06-17 14:51:06 --> Config Class Initialized
INFO - 2018-06-17 14:51:06 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:06 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:06 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:06 --> URI Class Initialized
INFO - 2018-06-17 14:51:06 --> Router Class Initialized
INFO - 2018-06-17 14:51:06 --> Output Class Initialized
INFO - 2018-06-17 14:51:06 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:06 --> Input Class Initialized
INFO - 2018-06-17 14:51:06 --> Language Class Initialized
INFO - 2018-06-17 14:51:06 --> Language Class Initialized
INFO - 2018-06-17 14:51:06 --> Config Class Initialized
INFO - 2018-06-17 14:51:06 --> Loader Class Initialized
INFO - 2018-06-17 20:21:06 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:06 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:06 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:06 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:06 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:06 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:06 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:06 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:06 --> Controller Class Initialized
INFO - 2018-06-17 20:21:06 --> Model Class Initialized
INFO - 2018-06-17 20:21:06 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:06 --> Model Class Initialized
INFO - 2018-06-17 20:21:06 --> Model Class Initialized
INFO - 2018-06-17 20:21:06 --> Model Class Initialized
INFO - 2018-06-17 20:21:06 --> Model Class Initialized
INFO - 2018-06-17 20:21:06 --> Model Class Initialized
INFO - 2018-06-17 20:21:06 --> Model Class Initialized
INFO - 2018-06-17 20:21:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:06 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:06 --> Total execution time: 0.1096
INFO - 2018-06-17 14:51:10 --> Config Class Initialized
INFO - 2018-06-17 14:51:10 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:10 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:10 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:10 --> URI Class Initialized
INFO - 2018-06-17 14:51:10 --> Router Class Initialized
INFO - 2018-06-17 14:51:10 --> Output Class Initialized
INFO - 2018-06-17 14:51:10 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:10 --> Input Class Initialized
INFO - 2018-06-17 14:51:10 --> Language Class Initialized
INFO - 2018-06-17 14:51:10 --> Language Class Initialized
INFO - 2018-06-17 14:51:10 --> Config Class Initialized
INFO - 2018-06-17 14:51:10 --> Loader Class Initialized
INFO - 2018-06-17 20:21:10 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:10 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:10 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:10 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:10 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:10 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:10 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:10 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:10 --> Controller Class Initialized
INFO - 2018-06-17 20:21:10 --> Model Class Initialized
INFO - 2018-06-17 20:21:10 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:10 --> Model Class Initialized
INFO - 2018-06-17 20:21:10 --> Model Class Initialized
INFO - 2018-06-17 20:21:10 --> Model Class Initialized
INFO - 2018-06-17 20:21:10 --> Model Class Initialized
INFO - 2018-06-17 20:21:10 --> Model Class Initialized
INFO - 2018-06-17 20:21:10 --> Model Class Initialized
INFO - 2018-06-17 20:21:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:10 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:10 --> Total execution time: 0.1079
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:11 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:11 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:11 --> URI Class Initialized
INFO - 2018-06-17 14:51:11 --> Router Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Hooks Class Initialized
INFO - 2018-06-17 14:51:11 --> Output Class Initialized
DEBUG - 2018-06-17 14:51:11 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:11 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:11 --> URI Class Initialized
INFO - 2018-06-17 14:51:11 --> Security Class Initialized
INFO - 2018-06-17 14:51:11 --> Router Class Initialized
DEBUG - 2018-06-17 14:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:11 --> Input Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Output Class Initialized
INFO - 2018-06-17 14:51:11 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:11 --> Input Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Loader Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: users_helper
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Loader Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:11 --> Database Driver Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:11 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:11 --> Utf8 Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 14:51:11 --> URI Class Initialized
INFO - 2018-06-17 20:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:11 --> Database Driver Class Initialized
INFO - 2018-06-17 14:51:11 --> Router Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:11 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:11 --> Controller Class Initialized
INFO - 2018-06-17 14:51:11 --> Output Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:51:11 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:11 --> Input Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:11 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:11 --> Controller Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Hooks Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:11 --> Total execution time: 0.1031
INFO - 2018-06-17 20:21:11 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 14:51:11 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:11 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:11 --> URI Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Loader Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 14:51:11 --> Router Class Initialized
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:11 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: notification_helper
INFO - 2018-06-17 14:51:11 --> Output Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:11 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:11 --> Total execution time: 0.1085
INFO - 2018-06-17 20:21:11 --> Helper loaded: users_helper
INFO - 2018-06-17 14:51:11 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:11 --> Input Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 20:21:11 --> Database Driver Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:11 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 14:51:11 --> Loader Class Initialized
INFO - 2018-06-17 14:51:11 --> Utf8 Class Initialized
INFO - 2018-06-17 20:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:51:11 --> URI Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: users_helper
INFO - 2018-06-17 14:51:11 --> Router Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Hooks Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:11 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:11 --> Controller Class Initialized
INFO - 2018-06-17 14:51:11 --> Output Class Initialized
DEBUG - 2018-06-17 14:51:11 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:11 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:11 --> Security Class Initialized
INFO - 2018-06-17 14:51:11 --> URI Class Initialized
DEBUG - 2018-06-17 14:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:11 --> Input Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Router Class Initialized
INFO - 2018-06-17 14:51:11 --> Output Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 14:51:11 --> Security Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:21:11 --> Database Driver Class Initialized
DEBUG - 2018-06-17 14:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:11 --> Input Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-06-17 20:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Loader Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:11 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:11 --> Controller Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:11 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Loader Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: users_helper
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Hooks Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 14:51:11 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:11 --> Utf8 Class Initialized
INFO - 2018-06-17 20:21:11 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 14:51:11 --> URI Class Initialized
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 14:51:11 --> Router Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Database Driver Class Initialized
INFO - 2018-06-17 20:21:11 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:11 --> Total execution time: 0.1398
INFO - 2018-06-17 14:51:11 --> Output Class Initialized
INFO - 2018-06-17 14:51:11 --> Security Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:11 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:11 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:11 --> Controller Class Initialized
DEBUG - 2018-06-17 14:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:11 --> Input Class Initialized
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 20:21:11 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:11 --> Total execution time: 0.1777
INFO - 2018-06-17 20:21:11 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:11 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:11 --> Controller Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-17 20:21:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 14:51:11 --> Language Class Initialized
INFO - 2018-06-17 14:51:11 --> Config Class Initialized
INFO - 2018-06-17 14:51:11 --> Loader Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Final output sent to browser
INFO - 2018-06-17 20:21:11 --> Helper loaded: url_helper
DEBUG - 2018-06-17 20:21:11 --> Total execution time: 0.1193
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:11 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:11 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:11 --> Total execution time: 0.1412
INFO - 2018-06-17 20:21:11 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:11 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:11 --> Controller Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:11 --> Model Class Initialized
INFO - 2018-06-17 20:21:11 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:11 --> Total execution time: 0.1219
INFO - 2018-06-17 14:51:14 --> Config Class Initialized
INFO - 2018-06-17 14:51:14 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:14 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:14 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:14 --> URI Class Initialized
INFO - 2018-06-17 14:51:14 --> Config Class Initialized
INFO - 2018-06-17 14:51:14 --> Hooks Class Initialized
INFO - 2018-06-17 14:51:14 --> Router Class Initialized
DEBUG - 2018-06-17 14:51:14 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:14 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:14 --> Output Class Initialized
INFO - 2018-06-17 14:51:14 --> URI Class Initialized
INFO - 2018-06-17 14:51:14 --> Security Class Initialized
INFO - 2018-06-17 14:51:14 --> Router Class Initialized
DEBUG - 2018-06-17 14:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:14 --> Input Class Initialized
INFO - 2018-06-17 14:51:14 --> Language Class Initialized
INFO - 2018-06-17 14:51:14 --> Output Class Initialized
INFO - 2018-06-17 14:51:14 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:14 --> Input Class Initialized
INFO - 2018-06-17 14:51:14 --> Language Class Initialized
INFO - 2018-06-17 14:51:14 --> Language Class Initialized
INFO - 2018-06-17 14:51:14 --> Config Class Initialized
INFO - 2018-06-17 14:51:14 --> Loader Class Initialized
INFO - 2018-06-17 20:21:14 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:14 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:14 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:14 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:14 --> Helper loaded: users_helper
INFO - 2018-06-17 14:51:14 --> Language Class Initialized
INFO - 2018-06-17 14:51:14 --> Config Class Initialized
INFO - 2018-06-17 14:51:14 --> Loader Class Initialized
INFO - 2018-06-17 20:21:14 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:14 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:14 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:14 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:14 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:14 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:14 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:14 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:14 --> Controller Class Initialized
INFO - 2018-06-17 20:21:14 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:14 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:14 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:14 --> Controller Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:14 --> Model Class Initialized
INFO - 2018-06-17 20:21:14 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:14 --> Total execution time: 0.1555
INFO - 2018-06-17 20:21:14 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:14 --> Total execution time: 0.1660
INFO - 2018-06-17 14:51:17 --> Config Class Initialized
INFO - 2018-06-17 14:51:17 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:17 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:17 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:17 --> URI Class Initialized
INFO - 2018-06-17 14:51:17 --> Router Class Initialized
INFO - 2018-06-17 14:51:17 --> Output Class Initialized
INFO - 2018-06-17 14:51:17 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:17 --> Input Class Initialized
INFO - 2018-06-17 14:51:18 --> Language Class Initialized
INFO - 2018-06-17 14:51:18 --> Language Class Initialized
INFO - 2018-06-17 14:51:18 --> Config Class Initialized
INFO - 2018-06-17 14:51:18 --> Loader Class Initialized
INFO - 2018-06-17 20:21:18 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:18 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:18 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:18 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:18 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:18 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:18 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:18 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:18 --> Controller Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:18 --> Model Class Initialized
INFO - 2018-06-17 20:21:18 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:18 --> Total execution time: 0.2205
INFO - 2018-06-17 14:51:36 --> Config Class Initialized
INFO - 2018-06-17 14:51:36 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:36 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:36 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:36 --> URI Class Initialized
INFO - 2018-06-17 14:51:36 --> Router Class Initialized
INFO - 2018-06-17 14:51:36 --> Output Class Initialized
INFO - 2018-06-17 14:51:36 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:36 --> Input Class Initialized
INFO - 2018-06-17 14:51:36 --> Language Class Initialized
INFO - 2018-06-17 14:51:36 --> Language Class Initialized
INFO - 2018-06-17 14:51:36 --> Config Class Initialized
INFO - 2018-06-17 14:51:36 --> Loader Class Initialized
INFO - 2018-06-17 20:21:36 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:36 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:36 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:36 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:36 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:36 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:36 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:36 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:36 --> Controller Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Model Class Initialized
INFO - 2018-06-17 20:21:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:36 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:36 --> Total execution time: 0.1266
INFO - 2018-06-17 14:51:38 --> Config Class Initialized
INFO - 2018-06-17 14:51:38 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:38 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:38 --> URI Class Initialized
INFO - 2018-06-17 14:51:38 --> Router Class Initialized
INFO - 2018-06-17 14:51:38 --> Output Class Initialized
INFO - 2018-06-17 14:51:38 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:38 --> Input Class Initialized
INFO - 2018-06-17 14:51:38 --> Language Class Initialized
INFO - 2018-06-17 14:51:38 --> Language Class Initialized
INFO - 2018-06-17 14:51:38 --> Config Class Initialized
INFO - 2018-06-17 14:51:38 --> Loader Class Initialized
INFO - 2018-06-17 20:21:38 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:38 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:38 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:38 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:38 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:38 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:38 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:38 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:38 --> Controller Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Model Class Initialized
INFO - 2018-06-17 20:21:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:38 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:38 --> Total execution time: 0.1265
INFO - 2018-06-17 14:51:45 --> Config Class Initialized
INFO - 2018-06-17 14:51:45 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:45 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:45 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:45 --> URI Class Initialized
INFO - 2018-06-17 14:51:45 --> Router Class Initialized
INFO - 2018-06-17 14:51:45 --> Output Class Initialized
INFO - 2018-06-17 14:51:45 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:45 --> Input Class Initialized
INFO - 2018-06-17 14:51:45 --> Language Class Initialized
INFO - 2018-06-17 14:51:45 --> Language Class Initialized
INFO - 2018-06-17 14:51:45 --> Config Class Initialized
INFO - 2018-06-17 14:51:45 --> Loader Class Initialized
INFO - 2018-06-17 20:21:45 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:45 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:45 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:45 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:45 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:45 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:45 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:45 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:45 --> Controller Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Model Class Initialized
INFO - 2018-06-17 20:21:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:45 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:45 --> Total execution time: 0.1237
INFO - 2018-06-17 14:51:48 --> Config Class Initialized
INFO - 2018-06-17 14:51:48 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:48 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:48 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:48 --> URI Class Initialized
INFO - 2018-06-17 14:51:48 --> Router Class Initialized
INFO - 2018-06-17 14:51:48 --> Output Class Initialized
INFO - 2018-06-17 14:51:48 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:48 --> Input Class Initialized
INFO - 2018-06-17 14:51:48 --> Language Class Initialized
INFO - 2018-06-17 14:51:48 --> Language Class Initialized
INFO - 2018-06-17 14:51:48 --> Config Class Initialized
INFO - 2018-06-17 14:51:48 --> Loader Class Initialized
INFO - 2018-06-17 20:21:48 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:48 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:48 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:48 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:48 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:48 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:48 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:48 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:48 --> Controller Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Model Class Initialized
INFO - 2018-06-17 20:21:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:48 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:48 --> Total execution time: 0.1191
INFO - 2018-06-17 14:51:50 --> Config Class Initialized
INFO - 2018-06-17 14:51:50 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:50 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:50 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:50 --> URI Class Initialized
INFO - 2018-06-17 14:51:50 --> Router Class Initialized
INFO - 2018-06-17 14:51:50 --> Output Class Initialized
INFO - 2018-06-17 14:51:50 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:50 --> Input Class Initialized
INFO - 2018-06-17 14:51:50 --> Language Class Initialized
INFO - 2018-06-17 14:51:50 --> Language Class Initialized
INFO - 2018-06-17 14:51:50 --> Config Class Initialized
INFO - 2018-06-17 14:51:50 --> Loader Class Initialized
INFO - 2018-06-17 20:21:50 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:50 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:50 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:50 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:50 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:50 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:50 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:50 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:50 --> Controller Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:50 --> Model Class Initialized
INFO - 2018-06-17 20:21:50 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:50 --> Total execution time: 0.1645
INFO - 2018-06-17 14:51:52 --> Config Class Initialized
INFO - 2018-06-17 14:51:52 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:52 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:52 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:52 --> URI Class Initialized
INFO - 2018-06-17 14:51:52 --> Router Class Initialized
INFO - 2018-06-17 14:51:52 --> Output Class Initialized
INFO - 2018-06-17 14:51:52 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:52 --> Input Class Initialized
INFO - 2018-06-17 14:51:52 --> Language Class Initialized
INFO - 2018-06-17 14:51:52 --> Language Class Initialized
INFO - 2018-06-17 14:51:52 --> Config Class Initialized
INFO - 2018-06-17 14:51:52 --> Loader Class Initialized
INFO - 2018-06-17 20:21:52 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:52 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:52 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:52 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:52 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:52 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:52 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:52 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:52 --> Controller Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:52 --> Model Class Initialized
INFO - 2018-06-17 20:21:52 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:52 --> Total execution time: 0.1728
INFO - 2018-06-17 14:51:54 --> Config Class Initialized
INFO - 2018-06-17 14:51:54 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:54 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:54 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:54 --> URI Class Initialized
INFO - 2018-06-17 14:51:54 --> Router Class Initialized
INFO - 2018-06-17 14:51:54 --> Output Class Initialized
INFO - 2018-06-17 14:51:54 --> Config Class Initialized
INFO - 2018-06-17 14:51:54 --> Hooks Class Initialized
INFO - 2018-06-17 14:51:54 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:54 --> Input Class Initialized
DEBUG - 2018-06-17 14:51:54 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:54 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:54 --> Language Class Initialized
INFO - 2018-06-17 14:51:54 --> URI Class Initialized
INFO - 2018-06-17 14:51:54 --> Router Class Initialized
INFO - 2018-06-17 14:51:54 --> Output Class Initialized
INFO - 2018-06-17 14:51:54 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:54 --> Input Class Initialized
INFO - 2018-06-17 14:51:54 --> Language Class Initialized
INFO - 2018-06-17 14:51:54 --> Language Class Initialized
INFO - 2018-06-17 14:51:54 --> Config Class Initialized
INFO - 2018-06-17 14:51:54 --> Loader Class Initialized
INFO - 2018-06-17 20:21:54 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: users_helper
INFO - 2018-06-17 14:51:54 --> Language Class Initialized
INFO - 2018-06-17 14:51:54 --> Config Class Initialized
INFO - 2018-06-17 14:51:54 --> Loader Class Initialized
INFO - 2018-06-17 20:21:54 --> Database Driver Class Initialized
INFO - 2018-06-17 20:21:54 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:54 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:54 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:54 --> Controller Class Initialized
INFO - 2018-06-17 20:21:54 --> Database Driver Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:21:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:54 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:54 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:54 --> Controller Class Initialized
INFO - 2018-06-17 20:21:54 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:54 --> Total execution time: 0.1095
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:54 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:54 --> Total execution time: 0.1889
INFO - 2018-06-17 14:51:54 --> Config Class Initialized
INFO - 2018-06-17 14:51:54 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:54 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:54 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:54 --> URI Class Initialized
INFO - 2018-06-17 14:51:54 --> Router Class Initialized
INFO - 2018-06-17 14:51:54 --> Output Class Initialized
INFO - 2018-06-17 14:51:54 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:54 --> Input Class Initialized
INFO - 2018-06-17 14:51:54 --> Language Class Initialized
INFO - 2018-06-17 14:51:54 --> Language Class Initialized
INFO - 2018-06-17 14:51:54 --> Config Class Initialized
INFO - 2018-06-17 14:51:54 --> Loader Class Initialized
INFO - 2018-06-17 20:21:54 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:54 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:54 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:54 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:54 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:54 --> Controller Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Model Class Initialized
INFO - 2018-06-17 20:21:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:54 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:54 --> Total execution time: 0.1340
INFO - 2018-06-17 14:51:56 --> Config Class Initialized
INFO - 2018-06-17 14:51:56 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:51:56 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:56 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:56 --> URI Class Initialized
INFO - 2018-06-17 14:51:56 --> Config Class Initialized
INFO - 2018-06-17 14:51:56 --> Hooks Class Initialized
INFO - 2018-06-17 14:51:56 --> Router Class Initialized
DEBUG - 2018-06-17 14:51:56 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:51:56 --> Utf8 Class Initialized
INFO - 2018-06-17 14:51:56 --> Output Class Initialized
INFO - 2018-06-17 14:51:56 --> URI Class Initialized
INFO - 2018-06-17 14:51:56 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:56 --> Input Class Initialized
INFO - 2018-06-17 14:51:56 --> Router Class Initialized
INFO - 2018-06-17 14:51:56 --> Language Class Initialized
INFO - 2018-06-17 14:51:56 --> Output Class Initialized
INFO - 2018-06-17 14:51:56 --> Security Class Initialized
DEBUG - 2018-06-17 14:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:51:56 --> Input Class Initialized
INFO - 2018-06-17 14:51:56 --> Language Class Initialized
INFO - 2018-06-17 14:51:56 --> Language Class Initialized
INFO - 2018-06-17 14:51:56 --> Config Class Initialized
INFO - 2018-06-17 14:51:56 --> Loader Class Initialized
INFO - 2018-06-17 20:21:56 --> Helper loaded: url_helper
INFO - 2018-06-17 14:51:56 --> Language Class Initialized
INFO - 2018-06-17 14:51:56 --> Config Class Initialized
INFO - 2018-06-17 14:51:56 --> Loader Class Initialized
INFO - 2018-06-17 20:21:56 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:56 --> Helper loaded: url_helper
INFO - 2018-06-17 20:21:56 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:56 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:56 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:21:56 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:56 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:21:56 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:21:56 --> Helper loaded: users_helper
INFO - 2018-06-17 20:21:56 --> Database Driver Class Initialized
INFO - 2018-06-17 20:21:56 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:21:56 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:56 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:56 --> Controller Class Initialized
INFO - 2018-06-17 20:21:56 --> Helper loaded: form_helper
INFO - 2018-06-17 20:21:56 --> Form Validation Class Initialized
INFO - 2018-06-17 20:21:56 --> Controller Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:21:56 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:21:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 20:21:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:21:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:21:56 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:56 --> Total execution time: 0.1206
INFO - 2018-06-17 20:21:56 --> Model Class Initialized
INFO - 2018-06-17 20:21:56 --> Final output sent to browser
DEBUG - 2018-06-17 20:21:56 --> Total execution time: 0.1484
INFO - 2018-06-17 14:52:04 --> Config Class Initialized
INFO - 2018-06-17 14:52:04 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:04 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:04 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:04 --> URI Class Initialized
INFO - 2018-06-17 14:52:04 --> Router Class Initialized
INFO - 2018-06-17 14:52:04 --> Output Class Initialized
INFO - 2018-06-17 14:52:04 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:04 --> Input Class Initialized
INFO - 2018-06-17 14:52:04 --> Language Class Initialized
INFO - 2018-06-17 14:52:04 --> Language Class Initialized
INFO - 2018-06-17 14:52:04 --> Config Class Initialized
INFO - 2018-06-17 14:52:04 --> Loader Class Initialized
INFO - 2018-06-17 20:22:04 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:04 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:04 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:04 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:04 --> Controller Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 14:52:04 --> Config Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 14:52:04 --> Hooks Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-17 14:52:04 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:04 --> Utf8 Class Initialized
INFO - 2018-06-17 20:22:04 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:04 --> Total execution time: 0.1119
INFO - 2018-06-17 14:52:04 --> URI Class Initialized
INFO - 2018-06-17 14:52:04 --> Router Class Initialized
INFO - 2018-06-17 14:52:04 --> Output Class Initialized
INFO - 2018-06-17 14:52:04 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:04 --> Input Class Initialized
INFO - 2018-06-17 14:52:04 --> Config Class Initialized
INFO - 2018-06-17 14:52:04 --> Hooks Class Initialized
INFO - 2018-06-17 14:52:04 --> Language Class Initialized
DEBUG - 2018-06-17 14:52:04 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:04 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:04 --> URI Class Initialized
INFO - 2018-06-17 14:52:04 --> Router Class Initialized
INFO - 2018-06-17 14:52:04 --> Output Class Initialized
INFO - 2018-06-17 14:52:04 --> Language Class Initialized
INFO - 2018-06-17 14:52:04 --> Config Class Initialized
INFO - 2018-06-17 14:52:04 --> Loader Class Initialized
INFO - 2018-06-17 14:52:04 --> Security Class Initialized
INFO - 2018-06-17 20:22:04 --> Helper loaded: url_helper
DEBUG - 2018-06-17 14:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:04 --> Input Class Initialized
INFO - 2018-06-17 20:22:04 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:52:04 --> Language Class Initialized
INFO - 2018-06-17 20:22:04 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:04 --> Database Driver Class Initialized
INFO - 2018-06-17 14:52:04 --> Language Class Initialized
INFO - 2018-06-17 14:52:04 --> Config Class Initialized
INFO - 2018-06-17 14:52:04 --> Loader Class Initialized
DEBUG - 2018-06-17 20:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:04 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:04 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:04 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:04 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:04 --> Controller Class Initialized
INFO - 2018-06-17 20:22:04 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:04 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:04 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:04 --> Controller Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 20:22:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Model Class Initialized
INFO - 2018-06-17 20:22:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:04 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:04 --> Total execution time: 0.1361
INFO - 2018-06-17 20:22:04 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:04 --> Total execution time: 0.1147
INFO - 2018-06-17 14:52:05 --> Config Class Initialized
INFO - 2018-06-17 14:52:05 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:05 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:05 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:05 --> URI Class Initialized
INFO - 2018-06-17 14:52:05 --> Router Class Initialized
INFO - 2018-06-17 14:52:05 --> Output Class Initialized
INFO - 2018-06-17 14:52:05 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:05 --> Input Class Initialized
INFO - 2018-06-17 14:52:05 --> Language Class Initialized
INFO - 2018-06-17 14:52:05 --> Language Class Initialized
INFO - 2018-06-17 14:52:05 --> Config Class Initialized
INFO - 2018-06-17 14:52:05 --> Loader Class Initialized
INFO - 2018-06-17 20:22:05 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: users_helper
INFO - 2018-06-17 14:52:05 --> Config Class Initialized
INFO - 2018-06-17 14:52:05 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:05 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:05 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:05 --> URI Class Initialized
INFO - 2018-06-17 20:22:05 --> Database Driver Class Initialized
INFO - 2018-06-17 14:52:05 --> Router Class Initialized
INFO - 2018-06-17 14:52:05 --> Output Class Initialized
DEBUG - 2018-06-17 20:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:52:05 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:05 --> Input Class Initialized
INFO - 2018-06-17 14:52:05 --> Language Class Initialized
INFO - 2018-06-17 20:22:05 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:05 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:05 --> Controller Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 14:52:05 --> Language Class Initialized
INFO - 2018-06-17 14:52:05 --> Config Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 14:52:05 --> Loader Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:05 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:05 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:05 --> Total execution time: 0.1094
INFO - 2018-06-17 14:52:05 --> Config Class Initialized
INFO - 2018-06-17 14:52:05 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:05 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:05 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:05 --> URI Class Initialized
INFO - 2018-06-17 20:22:05 --> Database Driver Class Initialized
INFO - 2018-06-17 14:52:05 --> Router Class Initialized
DEBUG - 2018-06-17 20:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:52:05 --> Output Class Initialized
INFO - 2018-06-17 14:52:05 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:05 --> Input Class Initialized
INFO - 2018-06-17 20:22:05 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:05 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:05 --> Controller Class Initialized
INFO - 2018-06-17 14:52:05 --> Language Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 14:52:05 --> Language Class Initialized
INFO - 2018-06-17 14:52:05 --> Config Class Initialized
INFO - 2018-06-17 14:52:05 --> Loader Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:05 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:05 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:05 --> Total execution time: 0.1501
INFO - 2018-06-17 20:22:05 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:05 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:05 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:05 --> Controller Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:05 --> Model Class Initialized
INFO - 2018-06-17 20:22:05 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:05 --> Total execution time: 0.1443
INFO - 2018-06-17 14:52:09 --> Config Class Initialized
INFO - 2018-06-17 14:52:09 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:09 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:09 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:09 --> URI Class Initialized
INFO - 2018-06-17 14:52:09 --> Router Class Initialized
INFO - 2018-06-17 14:52:09 --> Output Class Initialized
INFO - 2018-06-17 14:52:09 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:09 --> Input Class Initialized
INFO - 2018-06-17 14:52:09 --> Language Class Initialized
INFO - 2018-06-17 14:52:09 --> Config Class Initialized
INFO - 2018-06-17 14:52:09 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:09 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:09 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:09 --> URI Class Initialized
INFO - 2018-06-17 14:52:09 --> Language Class Initialized
INFO - 2018-06-17 14:52:09 --> Config Class Initialized
INFO - 2018-06-17 14:52:09 --> Loader Class Initialized
INFO - 2018-06-17 14:52:09 --> Router Class Initialized
INFO - 2018-06-17 20:22:09 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:09 --> Helper loaded: notification_helper
INFO - 2018-06-17 14:52:09 --> Output Class Initialized
INFO - 2018-06-17 20:22:09 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:52:09 --> Security Class Initialized
INFO - 2018-06-17 20:22:09 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:09 --> Helper loaded: users_helper
DEBUG - 2018-06-17 14:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:09 --> Input Class Initialized
INFO - 2018-06-17 14:52:09 --> Language Class Initialized
INFO - 2018-06-17 20:22:09 --> Database Driver Class Initialized
INFO - 2018-06-17 14:52:09 --> Language Class Initialized
INFO - 2018-06-17 14:52:09 --> Config Class Initialized
INFO - 2018-06-17 14:52:09 --> Loader Class Initialized
DEBUG - 2018-06-17 20:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:09 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:09 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:09 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:09 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:09 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:09 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:09 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:09 --> Controller Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:22:09 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:09 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-06-17 20:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:09 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:09 --> Controller Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:09 --> Model Class Initialized
INFO - 2018-06-17 20:22:09 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:09 --> Total execution time: 0.1484
INFO - 2018-06-17 20:22:09 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:09 --> Total execution time: 0.1322
INFO - 2018-06-17 14:52:12 --> Config Class Initialized
INFO - 2018-06-17 14:52:12 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:12 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:12 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:12 --> URI Class Initialized
INFO - 2018-06-17 14:52:12 --> Router Class Initialized
INFO - 2018-06-17 14:52:12 --> Output Class Initialized
INFO - 2018-06-17 14:52:12 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:12 --> Input Class Initialized
INFO - 2018-06-17 14:52:12 --> Language Class Initialized
INFO - 2018-06-17 14:52:12 --> Language Class Initialized
INFO - 2018-06-17 14:52:12 --> Config Class Initialized
INFO - 2018-06-17 14:52:12 --> Loader Class Initialized
INFO - 2018-06-17 20:22:12 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:12 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:12 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:12 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:12 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:12 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:12 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:12 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:12 --> Controller Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:12 --> Model Class Initialized
INFO - 2018-06-17 20:22:12 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:12 --> Total execution time: 0.1344
INFO - 2018-06-17 14:52:27 --> Config Class Initialized
INFO - 2018-06-17 14:52:27 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:27 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:27 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:27 --> URI Class Initialized
INFO - 2018-06-17 14:52:27 --> Router Class Initialized
INFO - 2018-06-17 14:52:27 --> Output Class Initialized
INFO - 2018-06-17 14:52:27 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:27 --> Input Class Initialized
INFO - 2018-06-17 14:52:27 --> Language Class Initialized
INFO - 2018-06-17 14:52:27 --> Language Class Initialized
INFO - 2018-06-17 14:52:27 --> Config Class Initialized
INFO - 2018-06-17 14:52:27 --> Loader Class Initialized
INFO - 2018-06-17 20:22:27 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:27 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:27 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:27 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:27 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:27 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:27 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:27 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:27 --> Controller Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Model Class Initialized
INFO - 2018-06-17 20:22:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:27 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:27 --> Total execution time: 0.1527
INFO - 2018-06-17 14:52:29 --> Config Class Initialized
INFO - 2018-06-17 14:52:29 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:29 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:29 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:29 --> URI Class Initialized
INFO - 2018-06-17 14:52:29 --> Router Class Initialized
INFO - 2018-06-17 14:52:29 --> Output Class Initialized
INFO - 2018-06-17 14:52:29 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:29 --> Input Class Initialized
INFO - 2018-06-17 14:52:29 --> Language Class Initialized
INFO - 2018-06-17 14:52:29 --> Language Class Initialized
INFO - 2018-06-17 14:52:29 --> Config Class Initialized
INFO - 2018-06-17 14:52:29 --> Loader Class Initialized
INFO - 2018-06-17 20:22:29 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:29 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:29 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:29 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:29 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:29 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:29 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:29 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:29 --> Controller Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:29 --> Model Class Initialized
INFO - 2018-06-17 20:22:29 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:29 --> Total execution time: 0.1159
INFO - 2018-06-17 14:52:31 --> Config Class Initialized
INFO - 2018-06-17 14:52:31 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:31 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:31 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:31 --> URI Class Initialized
INFO - 2018-06-17 14:52:31 --> Router Class Initialized
INFO - 2018-06-17 14:52:31 --> Output Class Initialized
INFO - 2018-06-17 14:52:31 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:31 --> Input Class Initialized
INFO - 2018-06-17 14:52:31 --> Language Class Initialized
INFO - 2018-06-17 14:52:31 --> Language Class Initialized
INFO - 2018-06-17 14:52:31 --> Config Class Initialized
INFO - 2018-06-17 14:52:31 --> Loader Class Initialized
INFO - 2018-06-17 20:22:31 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:31 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:31 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:31 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:31 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:31 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:31 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:31 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:31 --> Controller Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:31 --> Model Class Initialized
INFO - 2018-06-17 20:22:31 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:31 --> Total execution time: 0.1342
INFO - 2018-06-17 14:52:33 --> Config Class Initialized
INFO - 2018-06-17 14:52:33 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:33 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:33 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:33 --> URI Class Initialized
INFO - 2018-06-17 14:52:33 --> Router Class Initialized
INFO - 2018-06-17 14:52:33 --> Output Class Initialized
INFO - 2018-06-17 14:52:33 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:33 --> Input Class Initialized
INFO - 2018-06-17 14:52:33 --> Language Class Initialized
INFO - 2018-06-17 14:52:33 --> Language Class Initialized
INFO - 2018-06-17 14:52:33 --> Config Class Initialized
INFO - 2018-06-17 14:52:33 --> Loader Class Initialized
INFO - 2018-06-17 20:22:33 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:33 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:33 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:33 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:33 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:33 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:33 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:33 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:33 --> Controller Class Initialized
INFO - 2018-06-17 20:22:33 --> Model Class Initialized
INFO - 2018-06-17 20:22:33 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:33 --> Model Class Initialized
INFO - 2018-06-17 20:22:33 --> Model Class Initialized
INFO - 2018-06-17 20:22:33 --> Model Class Initialized
INFO - 2018-06-17 20:22:33 --> Model Class Initialized
INFO - 2018-06-17 20:22:33 --> Model Class Initialized
INFO - 2018-06-17 20:22:33 --> Model Class Initialized
INFO - 2018-06-17 20:22:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:33 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:33 --> Total execution time: 0.1193
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:37 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:37 --> URI Class Initialized
INFO - 2018-06-17 14:52:37 --> Router Class Initialized
INFO - 2018-06-17 14:52:37 --> Output Class Initialized
INFO - 2018-06-17 14:52:37 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:37 --> Input Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Loader Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:37 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:37 --> Controller Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:37 --> Total execution time: 0.1142
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:37 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:37 --> URI Class Initialized
INFO - 2018-06-17 14:52:37 --> Router Class Initialized
INFO - 2018-06-17 14:52:37 --> Output Class Initialized
INFO - 2018-06-17 14:52:37 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:37 --> Input Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Loader Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Hooks Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: url_helper
DEBUG - 2018-06-17 14:52:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:37 --> Utf8 Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: permission_helper
INFO - 2018-06-17 14:52:37 --> URI Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Hooks Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: users_helper
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:37 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:37 --> Router Class Initialized
INFO - 2018-06-17 14:52:37 --> URI Class Initialized
DEBUG - 2018-06-17 14:52:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:37 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:37 --> Router Class Initialized
INFO - 2018-06-17 14:52:37 --> Output Class Initialized
INFO - 2018-06-17 14:52:37 --> URI Class Initialized
INFO - 2018-06-17 14:52:37 --> Output Class Initialized
INFO - 2018-06-17 14:52:37 --> Security Class Initialized
INFO - 2018-06-17 14:52:37 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:37 --> Input Class Initialized
DEBUG - 2018-06-17 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Input Class Initialized
INFO - 2018-06-17 14:52:37 --> Router Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Hooks Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Output Class Initialized
DEBUG - 2018-06-17 14:52:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:37 --> Utf8 Class Initialized
INFO - 2018-06-17 20:22:37 --> Database Driver Class Initialized
INFO - 2018-06-17 14:52:37 --> Security Class Initialized
INFO - 2018-06-17 14:52:37 --> URI Class Initialized
DEBUG - 2018-06-17 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:37 --> Input Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Loader Class Initialized
DEBUG - 2018-06-17 20:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 14:52:37 --> Router Class Initialized
INFO - 2018-06-17 20:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:37 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: users_helper
INFO - 2018-06-17 14:52:37 --> Output Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Loader Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: url_helper
INFO - 2018-06-17 14:52:37 --> Security Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:37 --> Controller Class Initialized
DEBUG - 2018-06-17 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:37 --> Input Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: users_helper
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Hooks Class Initialized
INFO - 2018-06-17 20:22:37 --> Database Driver Class Initialized
DEBUG - 2018-06-17 14:52:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:37 --> Utf8 Class Initialized
DEBUG - 2018-06-17 20:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> URI Class Initialized
INFO - 2018-06-17 14:52:37 --> Loader Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: url_helper
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Hooks Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:37 --> Controller Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:52:37 --> Router Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 14:52:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:37 --> Utf8 Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: users_helper
INFO - 2018-06-17 14:52:37 --> URI Class Initialized
INFO - 2018-06-17 20:22:37 --> Database Driver Class Initialized
INFO - 2018-06-17 14:52:37 --> Output Class Initialized
DEBUG - 2018-06-17 20:22:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 14:52:37 --> Router Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 14:52:37 --> Output Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 14:52:37 --> Security Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
DEBUG - 2018-06-17 20:22:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 14:52:37 --> Security Class Initialized
DEBUG - 2018-06-17 20:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-06-17 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 14:52:37 --> Input Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
DEBUG - 2018-06-17 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:37 --> Input Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Loader Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:37 --> Controller Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Loader Class Initialized
INFO - 2018-06-17 20:22:37 --> Database Driver Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:37 --> Controller Class Initialized
INFO - 2018-06-17 14:52:37 --> Language Class Initialized
INFO - 2018-06-17 14:52:37 --> Config Class Initialized
INFO - 2018-06-17 14:52:37 --> Loader Class Initialized
INFO - 2018-06-17 20:22:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:37 --> Total execution time: 0.1684
INFO - 2018-06-17 20:22:37 --> Database Driver Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 20:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:37 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:37 --> Controller Class Initialized
INFO - 2018-06-17 20:22:37 --> Database Driver Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:22:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:37 --> Total execution time: 0.1767
INFO - 2018-06-17 20:22:37 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-06-17 20:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-17 20:22:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:37 --> Total execution time: 0.2483
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
DEBUG - 2018-06-17 20:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:37 --> Total execution time: 0.1134
INFO - 2018-06-17 20:22:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:37 --> Total execution time: 0.2000
INFO - 2018-06-17 20:22:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:37 --> Controller Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:37 --> Controller Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:37 --> Total execution time: 0.1616
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:37 --> Model Class Initialized
INFO - 2018-06-17 20:22:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:37 --> Total execution time: 0.2190
INFO - 2018-06-17 14:52:41 --> Config Class Initialized
INFO - 2018-06-17 14:52:41 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:41 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:41 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:41 --> URI Class Initialized
INFO - 2018-06-17 14:52:41 --> Router Class Initialized
INFO - 2018-06-17 14:52:41 --> Output Class Initialized
INFO - 2018-06-17 14:52:41 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:41 --> Input Class Initialized
INFO - 2018-06-17 14:52:41 --> Language Class Initialized
INFO - 2018-06-17 14:52:41 --> Language Class Initialized
INFO - 2018-06-17 14:52:41 --> Config Class Initialized
INFO - 2018-06-17 14:52:41 --> Loader Class Initialized
INFO - 2018-06-17 20:22:41 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:41 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:41 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:41 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:41 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:41 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:41 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:41 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:41 --> Controller Class Initialized
INFO - 2018-06-17 20:22:41 --> Model Class Initialized
INFO - 2018-06-17 20:22:41 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:41 --> Model Class Initialized
INFO - 2018-06-17 20:22:41 --> Model Class Initialized
INFO - 2018-06-17 20:22:41 --> Model Class Initialized
INFO - 2018-06-17 20:22:41 --> Model Class Initialized
INFO - 2018-06-17 20:22:41 --> Model Class Initialized
INFO - 2018-06-17 20:22:41 --> Model Class Initialized
INFO - 2018-06-17 20:22:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:41 --> Model Class Initialized
INFO - 2018-06-17 20:22:41 --> Model Class Initialized
ERROR - 2018-06-17 20:22:41 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
ERROR - 2018-06-17 20:22:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 825
INFO - 2018-06-17 20:22:41 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:41 --> Total execution time: 0.1214
INFO - 2018-06-17 14:52:42 --> Config Class Initialized
INFO - 2018-06-17 14:52:42 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:42 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:42 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:42 --> URI Class Initialized
INFO - 2018-06-17 14:52:42 --> Router Class Initialized
INFO - 2018-06-17 14:52:42 --> Output Class Initialized
INFO - 2018-06-17 14:52:42 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:42 --> Input Class Initialized
INFO - 2018-06-17 14:52:42 --> Language Class Initialized
INFO - 2018-06-17 14:52:42 --> Config Class Initialized
INFO - 2018-06-17 14:52:42 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:42 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:42 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:42 --> URI Class Initialized
INFO - 2018-06-17 14:52:42 --> Router Class Initialized
INFO - 2018-06-17 14:52:42 --> Output Class Initialized
INFO - 2018-06-17 14:52:42 --> Language Class Initialized
INFO - 2018-06-17 14:52:42 --> Config Class Initialized
INFO - 2018-06-17 14:52:42 --> Loader Class Initialized
INFO - 2018-06-17 14:52:42 --> Security Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: url_helper
INFO - 2018-06-17 14:52:42 --> Config Class Initialized
INFO - 2018-06-17 14:52:42 --> Hooks Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:42 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:42 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 14:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:42 --> Input Class Initialized
INFO - 2018-06-17 14:52:42 --> Language Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: users_helper
DEBUG - 2018-06-17 14:52:42 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:42 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:42 --> URI Class Initialized
INFO - 2018-06-17 14:52:42 --> Router Class Initialized
INFO - 2018-06-17 14:52:42 --> Output Class Initialized
INFO - 2018-06-17 20:22:42 --> Database Driver Class Initialized
INFO - 2018-06-17 14:52:42 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:42 --> Input Class Initialized
INFO - 2018-06-17 14:52:42 --> Language Class Initialized
INFO - 2018-06-17 14:52:42 --> Language Class Initialized
INFO - 2018-06-17 14:52:42 --> Config Class Initialized
INFO - 2018-06-17 14:52:42 --> Loader Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:42 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:42 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:42 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:42 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:42 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:42 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:42 --> Controller Class Initialized
INFO - 2018-06-17 14:52:42 --> Language Class Initialized
INFO - 2018-06-17 14:52:42 --> Config Class Initialized
INFO - 2018-06-17 14:52:42 --> Loader Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:42 --> Database Driver Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:42 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:42 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:42 --> Helper loaded: users_helper
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:22:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:42 --> Controller Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Database Driver Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:22:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:42 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:42 --> Controller Class Initialized
INFO - 2018-06-17 20:22:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:42 --> Total execution time: 0.1168
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:42 --> Model Class Initialized
INFO - 2018-06-17 20:22:42 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:42 --> Total execution time: 0.1548
INFO - 2018-06-17 20:22:42 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:42 --> Total execution time: 0.1170
INFO - 2018-06-17 14:52:59 --> Config Class Initialized
INFO - 2018-06-17 14:52:59 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:59 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:59 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:59 --> URI Class Initialized
INFO - 2018-06-17 14:52:59 --> Router Class Initialized
INFO - 2018-06-17 14:52:59 --> Output Class Initialized
INFO - 2018-06-17 14:52:59 --> Security Class Initialized
DEBUG - 2018-06-17 14:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:59 --> Input Class Initialized
INFO - 2018-06-17 14:52:59 --> Language Class Initialized
INFO - 2018-06-17 14:52:59 --> Config Class Initialized
INFO - 2018-06-17 14:52:59 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:52:59 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:52:59 --> Utf8 Class Initialized
INFO - 2018-06-17 14:52:59 --> URI Class Initialized
INFO - 2018-06-17 14:52:59 --> Router Class Initialized
INFO - 2018-06-17 14:52:59 --> Language Class Initialized
INFO - 2018-06-17 14:52:59 --> Config Class Initialized
INFO - 2018-06-17 14:52:59 --> Loader Class Initialized
INFO - 2018-06-17 20:22:59 --> Helper loaded: url_helper
INFO - 2018-06-17 14:52:59 --> Output Class Initialized
INFO - 2018-06-17 20:22:59 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:59 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:52:59 --> Security Class Initialized
INFO - 2018-06-17 20:22:59 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 14:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:52:59 --> Input Class Initialized
INFO - 2018-06-17 20:22:59 --> Helper loaded: users_helper
INFO - 2018-06-17 14:52:59 --> Language Class Initialized
INFO - 2018-06-17 14:52:59 --> Language Class Initialized
INFO - 2018-06-17 14:52:59 --> Config Class Initialized
INFO - 2018-06-17 14:52:59 --> Loader Class Initialized
INFO - 2018-06-17 20:22:59 --> Helper loaded: url_helper
INFO - 2018-06-17 20:22:59 --> Database Driver Class Initialized
INFO - 2018-06-17 20:22:59 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:22:59 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:22:59 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:22:59 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:59 --> Database Driver Class Initialized
INFO - 2018-06-17 20:22:59 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:59 --> Form Validation Class Initialized
DEBUG - 2018-06-17 20:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:22:59 --> Controller Class Initialized
INFO - 2018-06-17 20:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:22:59 --> Helper loaded: form_helper
INFO - 2018-06-17 20:22:59 --> Form Validation Class Initialized
INFO - 2018-06-17 20:22:59 --> Controller Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:22:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
DEBUG - 2018-06-17 20:22:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:22:59 --> Model Class Initialized
INFO - 2018-06-17 20:22:59 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:59 --> Total execution time: 0.1866
INFO - 2018-06-17 20:22:59 --> Final output sent to browser
DEBUG - 2018-06-17 20:22:59 --> Total execution time: 0.1420
INFO - 2018-06-17 14:53:01 --> Config Class Initialized
INFO - 2018-06-17 14:53:01 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:01 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:01 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:01 --> URI Class Initialized
INFO - 2018-06-17 14:53:01 --> Router Class Initialized
INFO - 2018-06-17 14:53:01 --> Output Class Initialized
INFO - 2018-06-17 14:53:01 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:01 --> Input Class Initialized
INFO - 2018-06-17 14:53:01 --> Language Class Initialized
INFO - 2018-06-17 14:53:01 --> Language Class Initialized
INFO - 2018-06-17 14:53:01 --> Config Class Initialized
INFO - 2018-06-17 14:53:01 --> Loader Class Initialized
INFO - 2018-06-17 20:23:01 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:01 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:01 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:01 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:01 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:01 --> Database Driver Class Initialized
INFO - 2018-06-17 14:53:01 --> Config Class Initialized
INFO - 2018-06-17 14:53:01 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:01 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:01 --> Utf8 Class Initialized
DEBUG - 2018-06-17 20:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:53:01 --> URI Class Initialized
INFO - 2018-06-17 20:23:01 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:01 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:01 --> Controller Class Initialized
INFO - 2018-06-17 14:53:01 --> Router Class Initialized
INFO - 2018-06-17 14:53:01 --> Output Class Initialized
INFO - 2018-06-17 20:23:01 --> Model Class Initialized
INFO - 2018-06-17 14:53:01 --> Security Class Initialized
INFO - 2018-06-17 20:23:01 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:01 --> Model Class Initialized
INFO - 2018-06-17 20:23:01 --> Model Class Initialized
DEBUG - 2018-06-17 14:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:01 --> Input Class Initialized
INFO - 2018-06-17 20:23:01 --> Model Class Initialized
INFO - 2018-06-17 20:23:01 --> Model Class Initialized
INFO - 2018-06-17 14:53:01 --> Language Class Initialized
INFO - 2018-06-17 20:23:01 --> Model Class Initialized
INFO - 2018-06-17 20:23:01 --> Model Class Initialized
INFO - 2018-06-17 20:23:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:01 --> Model Class Initialized
INFO - 2018-06-17 20:23:01 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:01 --> Total execution time: 0.1545
INFO - 2018-06-17 14:53:01 --> Language Class Initialized
INFO - 2018-06-17 14:53:01 --> Config Class Initialized
INFO - 2018-06-17 14:53:01 --> Loader Class Initialized
INFO - 2018-06-17 20:23:01 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:01 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:01 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:01 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:01 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:01 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:01 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:01 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:01 --> Controller Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:02 --> Total execution time: 0.1688
INFO - 2018-06-17 14:53:02 --> Config Class Initialized
INFO - 2018-06-17 14:53:02 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:02 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:02 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:02 --> URI Class Initialized
INFO - 2018-06-17 14:53:02 --> Router Class Initialized
INFO - 2018-06-17 14:53:02 --> Output Class Initialized
INFO - 2018-06-17 14:53:02 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:02 --> Input Class Initialized
INFO - 2018-06-17 14:53:02 --> Language Class Initialized
INFO - 2018-06-17 14:53:02 --> Language Class Initialized
INFO - 2018-06-17 14:53:02 --> Config Class Initialized
INFO - 2018-06-17 14:53:02 --> Loader Class Initialized
INFO - 2018-06-17 20:23:02 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:02 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:02 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:02 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:02 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:02 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:02 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:02 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:02 --> Controller Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:02 --> Model Class Initialized
INFO - 2018-06-17 20:23:02 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:02 --> Total execution time: 0.1450
INFO - 2018-06-17 14:53:04 --> Config Class Initialized
INFO - 2018-06-17 14:53:04 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:04 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:04 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:04 --> URI Class Initialized
INFO - 2018-06-17 14:53:04 --> Router Class Initialized
INFO - 2018-06-17 14:53:04 --> Output Class Initialized
INFO - 2018-06-17 14:53:04 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:04 --> Input Class Initialized
INFO - 2018-06-17 14:53:04 --> Language Class Initialized
INFO - 2018-06-17 14:53:04 --> Config Class Initialized
INFO - 2018-06-17 14:53:04 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:04 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:04 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:04 --> URI Class Initialized
INFO - 2018-06-17 14:53:04 --> Router Class Initialized
INFO - 2018-06-17 14:53:04 --> Language Class Initialized
INFO - 2018-06-17 14:53:04 --> Config Class Initialized
INFO - 2018-06-17 14:53:04 --> Loader Class Initialized
INFO - 2018-06-17 14:53:04 --> Output Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:04 --> Helper loaded: notification_helper
INFO - 2018-06-17 14:53:04 --> Security Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:04 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 14:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 20:23:04 --> Helper loaded: users_helper
INFO - 2018-06-17 14:53:04 --> Input Class Initialized
INFO - 2018-06-17 14:53:04 --> Language Class Initialized
INFO - 2018-06-17 20:23:04 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:53:04 --> Language Class Initialized
INFO - 2018-06-17 14:53:04 --> Config Class Initialized
INFO - 2018-06-17 14:53:04 --> Loader Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:04 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:04 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:04 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:04 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:04 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:04 --> Controller Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: users_helper
INFO - 2018-06-17 14:53:04 --> Config Class Initialized
INFO - 2018-06-17 14:53:04 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:04 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:04 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:04 --> URI Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:53:04 --> Router Class Initialized
DEBUG - 2018-06-17 20:23:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Database Driver Class Initialized
INFO - 2018-06-17 14:53:04 --> Output Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 14:53:04 --> Security Class Initialized
INFO - 2018-06-17 20:23:04 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:04 --> Total execution time: 0.1083
DEBUG - 2018-06-17 20:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 14:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:04 --> Input Class Initialized
INFO - 2018-06-17 14:53:04 --> Language Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:04 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:04 --> Controller Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 14:53:04 --> Language Class Initialized
INFO - 2018-06-17 14:53:04 --> Config Class Initialized
INFO - 2018-06-17 14:53:04 --> Loader Class Initialized
INFO - 2018-06-17 20:23:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:04 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:04 --> Total execution time: 0.1437
INFO - 2018-06-17 20:23:04 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:04 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:04 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:04 --> Controller Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Model Class Initialized
INFO - 2018-06-17 20:23:04 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:04 --> Total execution time: 0.1504
INFO - 2018-06-17 14:53:06 --> Config Class Initialized
INFO - 2018-06-17 14:53:06 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:06 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:06 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:06 --> URI Class Initialized
INFO - 2018-06-17 14:53:06 --> Router Class Initialized
INFO - 2018-06-17 14:53:06 --> Output Class Initialized
INFO - 2018-06-17 14:53:06 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:06 --> Input Class Initialized
INFO - 2018-06-17 14:53:06 --> Language Class Initialized
INFO - 2018-06-17 14:53:06 --> Config Class Initialized
INFO - 2018-06-17 14:53:06 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:06 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:06 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:06 --> URI Class Initialized
INFO - 2018-06-17 14:53:06 --> Language Class Initialized
INFO - 2018-06-17 14:53:06 --> Config Class Initialized
INFO - 2018-06-17 14:53:06 --> Loader Class Initialized
INFO - 2018-06-17 14:53:06 --> Router Class Initialized
INFO - 2018-06-17 20:23:06 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:06 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:06 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:53:06 --> Output Class Initialized
INFO - 2018-06-17 20:23:06 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:06 --> Helper loaded: users_helper
INFO - 2018-06-17 14:53:06 --> Security Class Initialized
INFO - 2018-06-17 20:23:06 --> Database Driver Class Initialized
DEBUG - 2018-06-17 14:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:06 --> Input Class Initialized
INFO - 2018-06-17 14:53:06 --> Language Class Initialized
DEBUG - 2018-06-17 20:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:06 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:06 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:06 --> Controller Class Initialized
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:53:06 --> Language Class Initialized
INFO - 2018-06-17 14:53:06 --> Config Class Initialized
INFO - 2018-06-17 14:53:06 --> Loader Class Initialized
DEBUG - 2018-06-17 20:23:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:06 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:06 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:06 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:06 --> Total execution time: 0.1067
INFO - 2018-06-17 20:23:06 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:06 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:06 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:06 --> Controller Class Initialized
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Model Class Initialized
INFO - 2018-06-17 20:23:06 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:06 --> Total execution time: 0.1294
INFO - 2018-06-17 14:53:08 --> Config Class Initialized
INFO - 2018-06-17 14:53:08 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:08 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:08 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:08 --> URI Class Initialized
INFO - 2018-06-17 14:53:08 --> Router Class Initialized
INFO - 2018-06-17 14:53:08 --> Output Class Initialized
INFO - 2018-06-17 14:53:08 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:08 --> Input Class Initialized
INFO - 2018-06-17 14:53:08 --> Language Class Initialized
INFO - 2018-06-17 14:53:08 --> Language Class Initialized
INFO - 2018-06-17 14:53:08 --> Config Class Initialized
INFO - 2018-06-17 14:53:08 --> Loader Class Initialized
INFO - 2018-06-17 20:23:08 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: permission_helper
INFO - 2018-06-17 14:53:08 --> Config Class Initialized
INFO - 2018-06-17 14:53:08 --> Hooks Class Initialized
INFO - 2018-06-17 20:23:08 --> Helper loaded: users_helper
DEBUG - 2018-06-17 14:53:08 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:08 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:08 --> URI Class Initialized
INFO - 2018-06-17 14:53:08 --> Config Class Initialized
INFO - 2018-06-17 14:53:08 --> Hooks Class Initialized
INFO - 2018-06-17 14:53:08 --> Router Class Initialized
INFO - 2018-06-17 14:53:08 --> Output Class Initialized
DEBUG - 2018-06-17 14:53:08 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:08 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:08 --> Security Class Initialized
INFO - 2018-06-17 14:53:08 --> URI Class Initialized
DEBUG - 2018-06-17 14:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:08 --> Input Class Initialized
INFO - 2018-06-17 14:53:08 --> Language Class Initialized
INFO - 2018-06-17 14:53:08 --> Router Class Initialized
INFO - 2018-06-17 14:53:08 --> Output Class Initialized
INFO - 2018-06-17 14:53:08 --> Security Class Initialized
INFO - 2018-06-17 14:53:08 --> Language Class Initialized
INFO - 2018-06-17 14:53:08 --> Config Class Initialized
INFO - 2018-06-17 14:53:08 --> Loader Class Initialized
DEBUG - 2018-06-17 14:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:08 --> Input Class Initialized
INFO - 2018-06-17 14:53:08 --> Language Class Initialized
INFO - 2018-06-17 20:23:08 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:08 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:08 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:53:08 --> Language Class Initialized
INFO - 2018-06-17 14:53:08 --> Config Class Initialized
INFO - 2018-06-17 20:23:08 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:08 --> Form Validation Class Initialized
INFO - 2018-06-17 14:53:08 --> Loader Class Initialized
INFO - 2018-06-17 20:23:08 --> Controller Class Initialized
INFO - 2018-06-17 20:23:08 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:08 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:08 --> Controller Class Initialized
INFO - 2018-06-17 20:23:08 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:08 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
DEBUG - 2018-06-17 20:23:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:08 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:23:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
DEBUG - 2018-06-17 20:23:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:08 --> Total execution time: 0.0990
INFO - 2018-06-17 20:23:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:08 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:08 --> Total execution time: 0.1490
INFO - 2018-06-17 20:23:08 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:08 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:08 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:08 --> Controller Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Model Class Initialized
INFO - 2018-06-17 20:23:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:08 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:08 --> Total execution time: 0.1381
INFO - 2018-06-17 14:53:12 --> Config Class Initialized
INFO - 2018-06-17 14:53:12 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:12 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:12 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:12 --> URI Class Initialized
INFO - 2018-06-17 14:53:12 --> Router Class Initialized
INFO - 2018-06-17 14:53:12 --> Config Class Initialized
INFO - 2018-06-17 14:53:12 --> Hooks Class Initialized
INFO - 2018-06-17 14:53:12 --> Output Class Initialized
DEBUG - 2018-06-17 14:53:12 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:12 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:12 --> Config Class Initialized
INFO - 2018-06-17 14:53:12 --> Hooks Class Initialized
INFO - 2018-06-17 14:53:12 --> Security Class Initialized
INFO - 2018-06-17 14:53:12 --> URI Class Initialized
DEBUG - 2018-06-17 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:12 --> Input Class Initialized
INFO - 2018-06-17 14:53:12 --> Language Class Initialized
DEBUG - 2018-06-17 14:53:12 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:12 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:12 --> URI Class Initialized
INFO - 2018-06-17 14:53:12 --> Router Class Initialized
INFO - 2018-06-17 14:53:12 --> Output Class Initialized
INFO - 2018-06-17 14:53:12 --> Router Class Initialized
INFO - 2018-06-17 14:53:12 --> Security Class Initialized
INFO - 2018-06-17 14:53:12 --> Output Class Initialized
DEBUG - 2018-06-17 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:12 --> Input Class Initialized
INFO - 2018-06-17 14:53:12 --> Security Class Initialized
INFO - 2018-06-17 14:53:12 --> Language Class Initialized
DEBUG - 2018-06-17 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:12 --> Input Class Initialized
INFO - 2018-06-17 14:53:12 --> Language Class Initialized
INFO - 2018-06-17 14:53:12 --> Language Class Initialized
INFO - 2018-06-17 14:53:12 --> Config Class Initialized
INFO - 2018-06-17 14:53:12 --> Loader Class Initialized
INFO - 2018-06-17 20:23:12 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: users_helper
INFO - 2018-06-17 14:53:12 --> Language Class Initialized
INFO - 2018-06-17 14:53:12 --> Config Class Initialized
INFO - 2018-06-17 14:53:12 --> Loader Class Initialized
INFO - 2018-06-17 20:23:12 --> Helper loaded: url_helper
INFO - 2018-06-17 14:53:12 --> Language Class Initialized
INFO - 2018-06-17 14:53:12 --> Config Class Initialized
INFO - 2018-06-17 14:53:12 --> Loader Class Initialized
INFO - 2018-06-17 20:23:12 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:12 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:12 --> Database Driver Class Initialized
INFO - 2018-06-17 20:23:12 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:12 --> Database Driver Class Initialized
INFO - 2018-06-17 20:23:12 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:12 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:12 --> Controller Class Initialized
INFO - 2018-06-17 20:23:12 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
DEBUG - 2018-06-17 20:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:12 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:23:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:23:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:12 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:12 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:12 --> Controller Class Initialized
INFO - 2018-06-17 20:23:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:12 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:12 --> Controller Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:12 --> Total execution time: 0.1135
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:23:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-17 20:23:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:12 --> Total execution time: 0.1139
INFO - 2018-06-17 20:23:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:12 --> Model Class Initialized
INFO - 2018-06-17 20:23:12 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:12 --> Total execution time: 0.1571
INFO - 2018-06-17 14:53:17 --> Config Class Initialized
INFO - 2018-06-17 14:53:17 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:17 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:17 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:17 --> URI Class Initialized
INFO - 2018-06-17 14:53:17 --> Router Class Initialized
INFO - 2018-06-17 14:53:17 --> Output Class Initialized
INFO - 2018-06-17 14:53:17 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:17 --> Input Class Initialized
INFO - 2018-06-17 14:53:17 --> Language Class Initialized
INFO - 2018-06-17 14:53:17 --> Language Class Initialized
INFO - 2018-06-17 14:53:17 --> Config Class Initialized
INFO - 2018-06-17 14:53:17 --> Loader Class Initialized
INFO - 2018-06-17 20:23:17 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:17 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:17 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:17 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:17 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:17 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:17 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:17 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:17 --> Controller Class Initialized
INFO - 2018-06-17 20:23:17 --> Model Class Initialized
INFO - 2018-06-17 20:23:17 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:17 --> Model Class Initialized
INFO - 2018-06-17 20:23:17 --> Model Class Initialized
INFO - 2018-06-17 20:23:17 --> Model Class Initialized
INFO - 2018-06-17 20:23:17 --> Model Class Initialized
INFO - 2018-06-17 20:23:17 --> Model Class Initialized
INFO - 2018-06-17 20:23:17 --> Model Class Initialized
INFO - 2018-06-17 20:23:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:17 --> Model Class Initialized
INFO - 2018-06-17 20:23:17 --> Model Class Initialized
ERROR - 2018-06-17 20:23:17 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-17 20:23:17 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:17 --> Total execution time: 0.1267
INFO - 2018-06-17 14:53:19 --> Config Class Initialized
INFO - 2018-06-17 14:53:19 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:19 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:19 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:19 --> URI Class Initialized
INFO - 2018-06-17 14:53:19 --> Router Class Initialized
INFO - 2018-06-17 14:53:19 --> Output Class Initialized
INFO - 2018-06-17 14:53:19 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:19 --> Input Class Initialized
INFO - 2018-06-17 14:53:19 --> Language Class Initialized
INFO - 2018-06-17 14:53:19 --> Language Class Initialized
INFO - 2018-06-17 14:53:19 --> Config Class Initialized
INFO - 2018-06-17 14:53:19 --> Loader Class Initialized
INFO - 2018-06-17 20:23:19 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:19 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:19 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:19 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:19 --> Controller Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:19 --> Total execution time: 0.1144
INFO - 2018-06-17 14:53:19 --> Config Class Initialized
INFO - 2018-06-17 14:53:19 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:19 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:19 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:19 --> URI Class Initialized
INFO - 2018-06-17 14:53:19 --> Router Class Initialized
INFO - 2018-06-17 14:53:19 --> Output Class Initialized
INFO - 2018-06-17 14:53:19 --> Config Class Initialized
INFO - 2018-06-17 14:53:19 --> Hooks Class Initialized
INFO - 2018-06-17 14:53:19 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:19 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:19 --> Utf8 Class Initialized
DEBUG - 2018-06-17 14:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:19 --> Input Class Initialized
INFO - 2018-06-17 14:53:19 --> Language Class Initialized
INFO - 2018-06-17 14:53:19 --> URI Class Initialized
INFO - 2018-06-17 14:53:19 --> Router Class Initialized
INFO - 2018-06-17 14:53:19 --> Output Class Initialized
INFO - 2018-06-17 14:53:19 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:19 --> Input Class Initialized
INFO - 2018-06-17 14:53:19 --> Language Class Initialized
INFO - 2018-06-17 14:53:19 --> Language Class Initialized
INFO - 2018-06-17 14:53:19 --> Config Class Initialized
INFO - 2018-06-17 14:53:19 --> Loader Class Initialized
INFO - 2018-06-17 20:23:19 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: users_helper
INFO - 2018-06-17 14:53:19 --> Language Class Initialized
INFO - 2018-06-17 14:53:19 --> Config Class Initialized
INFO - 2018-06-17 14:53:19 --> Loader Class Initialized
INFO - 2018-06-17 20:23:19 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:19 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:19 --> Database Driver Class Initialized
INFO - 2018-06-17 20:23:19 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:19 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:19 --> Controller Class Initialized
DEBUG - 2018-06-17 20:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:23:19 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:19 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:19 --> Controller Class Initialized
DEBUG - 2018-06-17 20:23:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:23:19 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:19 --> Total execution time: 0.1084
DEBUG - 2018-06-17 20:23:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:19 --> Model Class Initialized
INFO - 2018-06-17 20:23:19 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:19 --> Total execution time: 0.1368
INFO - 2018-06-17 14:53:22 --> Config Class Initialized
INFO - 2018-06-17 14:53:22 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:22 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:22 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:22 --> URI Class Initialized
INFO - 2018-06-17 14:53:22 --> Router Class Initialized
INFO - 2018-06-17 14:53:22 --> Output Class Initialized
INFO - 2018-06-17 14:53:22 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:22 --> Input Class Initialized
INFO - 2018-06-17 14:53:22 --> Language Class Initialized
INFO - 2018-06-17 14:53:22 --> Config Class Initialized
INFO - 2018-06-17 14:53:22 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:22 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:22 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:22 --> URI Class Initialized
INFO - 2018-06-17 14:53:22 --> Language Class Initialized
INFO - 2018-06-17 14:53:22 --> Config Class Initialized
INFO - 2018-06-17 14:53:22 --> Loader Class Initialized
INFO - 2018-06-17 20:23:22 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:22 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:22 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:53:22 --> Router Class Initialized
INFO - 2018-06-17 20:23:22 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:22 --> Helper loaded: users_helper
INFO - 2018-06-17 14:53:22 --> Output Class Initialized
INFO - 2018-06-17 14:53:22 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:22 --> Input Class Initialized
INFO - 2018-06-17 14:53:22 --> Language Class Initialized
INFO - 2018-06-17 20:23:22 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:22 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:22 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:22 --> Controller Class Initialized
INFO - 2018-06-17 14:53:22 --> Language Class Initialized
INFO - 2018-06-17 14:53:22 --> Config Class Initialized
INFO - 2018-06-17 14:53:22 --> Loader Class Initialized
INFO - 2018-06-17 20:23:22 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:22 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:22 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:22 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:23:22 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:23:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:22 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:22 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:22 --> Controller Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:23:22 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:22 --> Total execution time: 0.1507
DEBUG - 2018-06-17 20:23:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:22 --> Model Class Initialized
INFO - 2018-06-17 20:23:22 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:22 --> Total execution time: 0.1684
INFO - 2018-06-17 14:53:27 --> Config Class Initialized
INFO - 2018-06-17 14:53:27 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:27 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:27 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:27 --> URI Class Initialized
INFO - 2018-06-17 14:53:27 --> Router Class Initialized
INFO - 2018-06-17 14:53:27 --> Output Class Initialized
INFO - 2018-06-17 14:53:27 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:27 --> Input Class Initialized
INFO - 2018-06-17 14:53:27 --> Language Class Initialized
INFO - 2018-06-17 14:53:27 --> Language Class Initialized
INFO - 2018-06-17 14:53:27 --> Config Class Initialized
INFO - 2018-06-17 14:53:27 --> Loader Class Initialized
INFO - 2018-06-17 20:23:27 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:27 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:27 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:27 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:27 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:27 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:27 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:27 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:27 --> Controller Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:27 --> Model Class Initialized
INFO - 2018-06-17 20:23:27 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:27 --> Total execution time: 0.1443
INFO - 2018-06-17 14:53:36 --> Config Class Initialized
INFO - 2018-06-17 14:53:36 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:36 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:36 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:36 --> URI Class Initialized
INFO - 2018-06-17 14:53:36 --> Router Class Initialized
INFO - 2018-06-17 14:53:36 --> Output Class Initialized
INFO - 2018-06-17 14:53:36 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:36 --> Input Class Initialized
INFO - 2018-06-17 14:53:36 --> Language Class Initialized
INFO - 2018-06-17 14:53:36 --> Language Class Initialized
INFO - 2018-06-17 14:53:36 --> Config Class Initialized
INFO - 2018-06-17 14:53:36 --> Loader Class Initialized
INFO - 2018-06-17 20:23:36 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:36 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:36 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:36 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:36 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:36 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:36 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:36 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:36 --> Controller Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Model Class Initialized
INFO - 2018-06-17 20:23:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:37 --> Total execution time: 0.1362
INFO - 2018-06-17 14:53:40 --> Config Class Initialized
INFO - 2018-06-17 14:53:40 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:40 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:40 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:40 --> URI Class Initialized
INFO - 2018-06-17 14:53:40 --> Router Class Initialized
INFO - 2018-06-17 14:53:40 --> Output Class Initialized
INFO - 2018-06-17 14:53:40 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:40 --> Input Class Initialized
INFO - 2018-06-17 14:53:40 --> Language Class Initialized
INFO - 2018-06-17 14:53:40 --> Language Class Initialized
INFO - 2018-06-17 14:53:40 --> Config Class Initialized
INFO - 2018-06-17 14:53:40 --> Loader Class Initialized
INFO - 2018-06-17 20:23:40 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:40 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:40 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:40 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:40 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:41 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:41 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:41 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:41 --> Controller Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Model Class Initialized
INFO - 2018-06-17 20:23:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:41 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:41 --> Total execution time: 0.2012
INFO - 2018-06-17 14:53:45 --> Config Class Initialized
INFO - 2018-06-17 14:53:45 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:45 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:45 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:45 --> URI Class Initialized
INFO - 2018-06-17 14:53:45 --> Router Class Initialized
INFO - 2018-06-17 14:53:45 --> Output Class Initialized
INFO - 2018-06-17 14:53:45 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:45 --> Input Class Initialized
INFO - 2018-06-17 14:53:45 --> Language Class Initialized
INFO - 2018-06-17 14:53:45 --> Language Class Initialized
INFO - 2018-06-17 14:53:45 --> Config Class Initialized
INFO - 2018-06-17 14:53:45 --> Loader Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:45 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:45 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:45 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:45 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:45 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:45 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:45 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:45 --> Controller Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:45 --> Total execution time: 0.1138
INFO - 2018-06-17 14:53:45 --> Config Class Initialized
INFO - 2018-06-17 14:53:45 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:45 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:45 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:45 --> URI Class Initialized
INFO - 2018-06-17 14:53:45 --> Router Class Initialized
INFO - 2018-06-17 14:53:45 --> Output Class Initialized
INFO - 2018-06-17 14:53:45 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:45 --> Input Class Initialized
INFO - 2018-06-17 14:53:45 --> Language Class Initialized
INFO - 2018-06-17 14:53:45 --> Language Class Initialized
INFO - 2018-06-17 14:53:45 --> Config Class Initialized
INFO - 2018-06-17 14:53:45 --> Loader Class Initialized
INFO - 2018-06-17 14:53:45 --> Config Class Initialized
INFO - 2018-06-17 14:53:45 --> Hooks Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:45 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:45 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:45 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 14:53:45 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:45 --> Utf8 Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: users_helper
INFO - 2018-06-17 14:53:45 --> URI Class Initialized
INFO - 2018-06-17 14:53:45 --> Router Class Initialized
INFO - 2018-06-17 20:23:45 --> Database Driver Class Initialized
INFO - 2018-06-17 14:53:45 --> Output Class Initialized
INFO - 2018-06-17 14:53:45 --> Security Class Initialized
DEBUG - 2018-06-17 20:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:45 --> Input Class Initialized
INFO - 2018-06-17 14:53:45 --> Language Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:45 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:45 --> Controller Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 14:53:45 --> Language Class Initialized
INFO - 2018-06-17 14:53:45 --> Config Class Initialized
INFO - 2018-06-17 14:53:45 --> Loader Class Initialized
INFO - 2018-06-17 20:23:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:45 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:45 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:45 --> Total execution time: 0.1088
INFO - 2018-06-17 20:23:45 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:45 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:45 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:45 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:45 --> Controller Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:45 --> Model Class Initialized
INFO - 2018-06-17 20:23:45 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:45 --> Total execution time: 0.1719
INFO - 2018-06-17 14:53:54 --> Config Class Initialized
INFO - 2018-06-17 14:53:54 --> Hooks Class Initialized
INFO - 2018-06-17 14:53:54 --> Config Class Initialized
INFO - 2018-06-17 14:53:54 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:54 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:54 --> Utf8 Class Initialized
DEBUG - 2018-06-17 14:53:54 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:54 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:54 --> URI Class Initialized
INFO - 2018-06-17 14:53:54 --> URI Class Initialized
INFO - 2018-06-17 14:53:54 --> Router Class Initialized
INFO - 2018-06-17 14:53:54 --> Router Class Initialized
INFO - 2018-06-17 14:53:54 --> Output Class Initialized
INFO - 2018-06-17 14:53:54 --> Security Class Initialized
INFO - 2018-06-17 14:53:54 --> Output Class Initialized
DEBUG - 2018-06-17 14:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:54 --> Input Class Initialized
INFO - 2018-06-17 14:53:54 --> Security Class Initialized
INFO - 2018-06-17 14:53:54 --> Language Class Initialized
DEBUG - 2018-06-17 14:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:54 --> Input Class Initialized
INFO - 2018-06-17 14:53:54 --> Language Class Initialized
INFO - 2018-06-17 14:53:54 --> Language Class Initialized
INFO - 2018-06-17 14:53:54 --> Config Class Initialized
INFO - 2018-06-17 14:53:54 --> Loader Class Initialized
INFO - 2018-06-17 20:23:54 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:54 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:54 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:54 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:54 --> Helper loaded: users_helper
INFO - 2018-06-17 14:53:54 --> Language Class Initialized
INFO - 2018-06-17 14:53:54 --> Config Class Initialized
INFO - 2018-06-17 14:53:54 --> Loader Class Initialized
INFO - 2018-06-17 20:23:54 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:54 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:54 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:54 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:54 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:54 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:54 --> Database Driver Class Initialized
INFO - 2018-06-17 20:23:54 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:54 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:54 --> Controller Class Initialized
DEBUG - 2018-06-17 20:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:54 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:54 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:54 --> Controller Class Initialized
INFO - 2018-06-17 20:23:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:54 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
DEBUG - 2018-06-17 20:23:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:54 --> Model Class Initialized
INFO - 2018-06-17 20:23:54 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:54 --> Total execution time: 0.1407
INFO - 2018-06-17 20:23:54 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:54 --> Total execution time: 0.1740
INFO - 2018-06-17 14:53:55 --> Config Class Initialized
INFO - 2018-06-17 14:53:55 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:55 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:55 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:55 --> URI Class Initialized
INFO - 2018-06-17 14:53:55 --> Router Class Initialized
INFO - 2018-06-17 14:53:55 --> Output Class Initialized
INFO - 2018-06-17 14:53:55 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:55 --> Input Class Initialized
INFO - 2018-06-17 14:53:55 --> Language Class Initialized
INFO - 2018-06-17 14:53:55 --> Language Class Initialized
INFO - 2018-06-17 14:53:55 --> Config Class Initialized
INFO - 2018-06-17 14:53:55 --> Loader Class Initialized
INFO - 2018-06-17 20:23:55 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:55 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:55 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:55 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:55 --> Helper loaded: users_helper
INFO - 2018-06-17 14:53:55 --> Config Class Initialized
INFO - 2018-06-17 14:53:55 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:55 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:55 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:55 --> URI Class Initialized
INFO - 2018-06-17 14:53:55 --> Router Class Initialized
INFO - 2018-06-17 20:23:55 --> Database Driver Class Initialized
INFO - 2018-06-17 14:53:55 --> Output Class Initialized
INFO - 2018-06-17 14:53:55 --> Security Class Initialized
DEBUG - 2018-06-17 20:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 14:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:55 --> Input Class Initialized
INFO - 2018-06-17 14:53:55 --> Language Class Initialized
INFO - 2018-06-17 20:23:55 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:55 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:55 --> Controller Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:53:55 --> Language Class Initialized
INFO - 2018-06-17 14:53:55 --> Config Class Initialized
INFO - 2018-06-17 14:53:55 --> Loader Class Initialized
DEBUG - 2018-06-17 20:23:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:55 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:55 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:55 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:55 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:55 --> Total execution time: 0.1147
INFO - 2018-06-17 20:23:55 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:55 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:55 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:55 --> Controller Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:55 --> Model Class Initialized
INFO - 2018-06-17 20:23:55 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:55 --> Total execution time: 0.1299
INFO - 2018-06-17 14:53:56 --> Config Class Initialized
INFO - 2018-06-17 14:53:56 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:56 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:56 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:56 --> URI Class Initialized
INFO - 2018-06-17 14:53:56 --> Router Class Initialized
INFO - 2018-06-17 14:53:56 --> Output Class Initialized
INFO - 2018-06-17 14:53:56 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:56 --> Input Class Initialized
INFO - 2018-06-17 14:53:56 --> Language Class Initialized
INFO - 2018-06-17 14:53:56 --> Language Class Initialized
INFO - 2018-06-17 14:53:56 --> Config Class Initialized
INFO - 2018-06-17 14:53:56 --> Loader Class Initialized
INFO - 2018-06-17 20:23:56 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:56 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:56 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:56 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:56 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:56 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:56 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:56 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:56 --> Controller Class Initialized
INFO - 2018-06-17 20:23:56 --> Model Class Initialized
INFO - 2018-06-17 20:23:56 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:56 --> Model Class Initialized
INFO - 2018-06-17 20:23:56 --> Model Class Initialized
INFO - 2018-06-17 20:23:56 --> Model Class Initialized
INFO - 2018-06-17 20:23:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:56 --> Model Class Initialized
INFO - 2018-06-17 20:23:56 --> Model Class Initialized
INFO - 2018-06-17 20:23:56 --> Model Class Initialized
INFO - 2018-06-17 20:23:56 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:56 --> Total execution time: 0.1159
INFO - 2018-06-17 14:53:58 --> Config Class Initialized
INFO - 2018-06-17 14:53:58 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:53:58 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:53:58 --> Utf8 Class Initialized
INFO - 2018-06-17 14:53:58 --> URI Class Initialized
INFO - 2018-06-17 14:53:58 --> Router Class Initialized
INFO - 2018-06-17 14:53:58 --> Output Class Initialized
INFO - 2018-06-17 14:53:58 --> Security Class Initialized
DEBUG - 2018-06-17 14:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:53:58 --> Input Class Initialized
INFO - 2018-06-17 14:53:58 --> Language Class Initialized
INFO - 2018-06-17 14:53:58 --> Language Class Initialized
INFO - 2018-06-17 14:53:58 --> Config Class Initialized
INFO - 2018-06-17 14:53:58 --> Loader Class Initialized
INFO - 2018-06-17 20:23:58 --> Helper loaded: url_helper
INFO - 2018-06-17 20:23:58 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:23:58 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:23:58 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:23:58 --> Helper loaded: users_helper
INFO - 2018-06-17 20:23:58 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:23:58 --> Helper loaded: form_helper
INFO - 2018-06-17 20:23:58 --> Form Validation Class Initialized
INFO - 2018-06-17 20:23:58 --> Controller Class Initialized
INFO - 2018-06-17 20:23:58 --> Model Class Initialized
INFO - 2018-06-17 20:23:58 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:23:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:23:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:23:58 --> Model Class Initialized
INFO - 2018-06-17 20:23:58 --> Model Class Initialized
INFO - 2018-06-17 20:23:58 --> Model Class Initialized
INFO - 2018-06-17 20:23:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:23:58 --> Model Class Initialized
INFO - 2018-06-17 20:23:58 --> Final output sent to browser
DEBUG - 2018-06-17 20:23:58 --> Total execution time: 0.1008
INFO - 2018-06-17 14:54:04 --> Config Class Initialized
INFO - 2018-06-17 14:54:04 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:04 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:04 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:04 --> URI Class Initialized
INFO - 2018-06-17 14:54:04 --> Router Class Initialized
INFO - 2018-06-17 14:54:04 --> Output Class Initialized
INFO - 2018-06-17 14:54:04 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:04 --> Input Class Initialized
INFO - 2018-06-17 14:54:04 --> Language Class Initialized
INFO - 2018-06-17 14:54:04 --> Language Class Initialized
INFO - 2018-06-17 14:54:04 --> Config Class Initialized
INFO - 2018-06-17 14:54:04 --> Loader Class Initialized
INFO - 2018-06-17 20:24:04 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:04 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:04 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:04 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:04 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:04 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:04 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:04 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:04 --> Controller Class Initialized
INFO - 2018-06-17 20:24:04 --> Model Class Initialized
INFO - 2018-06-17 20:24:04 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:04 --> Model Class Initialized
INFO - 2018-06-17 20:24:05 --> Model Class Initialized
INFO - 2018-06-17 20:24:05 --> Model Class Initialized
INFO - 2018-06-17 20:24:05 --> Model Class Initialized
INFO - 2018-06-17 20:24:05 --> Model Class Initialized
INFO - 2018-06-17 20:24:05 --> Model Class Initialized
INFO - 2018-06-17 20:24:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:05 --> Model Class Initialized
INFO - 2018-06-17 20:24:05 --> Model Class Initialized
ERROR - 2018-06-17 20:24:05 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-17 20:24:05 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:05 --> Total execution time: 0.1205
INFO - 2018-06-17 14:54:18 --> Config Class Initialized
INFO - 2018-06-17 14:54:18 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:18 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:18 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:18 --> URI Class Initialized
INFO - 2018-06-17 14:54:18 --> Router Class Initialized
INFO - 2018-06-17 14:54:18 --> Output Class Initialized
INFO - 2018-06-17 14:54:18 --> Security Class Initialized
INFO - 2018-06-17 14:54:18 --> Config Class Initialized
INFO - 2018-06-17 14:54:18 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:18 --> Input Class Initialized
INFO - 2018-06-17 14:54:18 --> Language Class Initialized
DEBUG - 2018-06-17 14:54:18 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:18 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:18 --> URI Class Initialized
INFO - 2018-06-17 14:54:18 --> Router Class Initialized
INFO - 2018-06-17 14:54:18 --> Output Class Initialized
INFO - 2018-06-17 14:54:18 --> Security Class Initialized
INFO - 2018-06-17 14:54:18 --> Language Class Initialized
INFO - 2018-06-17 14:54:18 --> Config Class Initialized
INFO - 2018-06-17 14:54:18 --> Loader Class Initialized
DEBUG - 2018-06-17 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 20:24:18 --> Helper loaded: url_helper
INFO - 2018-06-17 14:54:18 --> Input Class Initialized
INFO - 2018-06-17 20:24:18 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:18 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:54:18 --> Language Class Initialized
INFO - 2018-06-17 20:24:18 --> Helper loaded: permission_helper
INFO - 2018-06-17 14:54:18 --> Config Class Initialized
INFO - 2018-06-17 14:54:18 --> Hooks Class Initialized
INFO - 2018-06-17 20:24:18 --> Helper loaded: users_helper
DEBUG - 2018-06-17 14:54:18 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:18 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:18 --> URI Class Initialized
INFO - 2018-06-17 20:24:18 --> Database Driver Class Initialized
INFO - 2018-06-17 14:54:18 --> Router Class Initialized
INFO - 2018-06-17 14:54:18 --> Language Class Initialized
INFO - 2018-06-17 14:54:18 --> Config Class Initialized
INFO - 2018-06-17 14:54:18 --> Loader Class Initialized
DEBUG - 2018-06-17 20:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:18 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:18 --> Helper loaded: notification_helper
INFO - 2018-06-17 14:54:18 --> Output Class Initialized
INFO - 2018-06-17 20:24:18 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:18 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:18 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:18 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:18 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:18 --> Controller Class Initialized
INFO - 2018-06-17 14:54:18 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:18 --> Input Class Initialized
INFO - 2018-06-17 14:54:18 --> Language Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:24:18 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
DEBUG - 2018-06-17 20:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:18 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:18 --> Controller Class Initialized
INFO - 2018-06-17 14:54:18 --> Language Class Initialized
INFO - 2018-06-17 14:54:18 --> Config Class Initialized
INFO - 2018-06-17 14:54:18 --> Loader Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:24:18 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:18 --> Helper loaded: notification_helper
DEBUG - 2018-06-17 20:24:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:18 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:18 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:18 --> Total execution time: 0.1208
INFO - 2018-06-17 20:24:18 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:18 --> Total execution time: 0.1372
INFO - 2018-06-17 20:24:18 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:18 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:18 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:18 --> Controller Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:18 --> Model Class Initialized
INFO - 2018-06-17 20:24:18 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:18 --> Total execution time: 0.1605
INFO - 2018-06-17 14:54:20 --> Config Class Initialized
INFO - 2018-06-17 14:54:20 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:20 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:20 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:20 --> URI Class Initialized
INFO - 2018-06-17 14:54:20 --> Router Class Initialized
INFO - 2018-06-17 14:54:20 --> Output Class Initialized
INFO - 2018-06-17 14:54:20 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:20 --> Input Class Initialized
INFO - 2018-06-17 14:54:20 --> Language Class Initialized
INFO - 2018-06-17 14:54:20 --> Language Class Initialized
INFO - 2018-06-17 14:54:20 --> Config Class Initialized
INFO - 2018-06-17 14:54:20 --> Loader Class Initialized
INFO - 2018-06-17 20:24:20 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:20 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:20 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:20 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:20 --> Helper loaded: users_helper
INFO - 2018-06-17 14:54:20 --> Config Class Initialized
INFO - 2018-06-17 14:54:20 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:20 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:20 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:20 --> URI Class Initialized
INFO - 2018-06-17 14:54:20 --> Router Class Initialized
INFO - 2018-06-17 20:24:20 --> Database Driver Class Initialized
INFO - 2018-06-17 14:54:20 --> Output Class Initialized
INFO - 2018-06-17 14:54:20 --> Security Class Initialized
DEBUG - 2018-06-17 20:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 14:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:20 --> Input Class Initialized
INFO - 2018-06-17 14:54:20 --> Language Class Initialized
INFO - 2018-06-17 20:24:20 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:20 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:20 --> Controller Class Initialized
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 14:54:20 --> Language Class Initialized
INFO - 2018-06-17 14:54:20 --> Config Class Initialized
INFO - 2018-06-17 14:54:20 --> Loader Class Initialized
INFO - 2018-06-17 20:24:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:20 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:20 --> Model Class Initialized
INFO - 2018-06-17 20:24:20 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:21 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:21 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:21 --> Controller Class Initialized
INFO - 2018-06-17 20:24:21 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:21 --> Total execution time: 0.1534
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:21 --> Model Class Initialized
INFO - 2018-06-17 20:24:21 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:21 --> Total execution time: 0.1814
INFO - 2018-06-17 14:54:22 --> Config Class Initialized
INFO - 2018-06-17 14:54:22 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:22 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:22 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:22 --> URI Class Initialized
INFO - 2018-06-17 14:54:22 --> Config Class Initialized
INFO - 2018-06-17 14:54:22 --> Hooks Class Initialized
INFO - 2018-06-17 14:54:22 --> Router Class Initialized
INFO - 2018-06-17 14:54:22 --> Output Class Initialized
DEBUG - 2018-06-17 14:54:22 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:22 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:22 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:22 --> Input Class Initialized
INFO - 2018-06-17 14:54:22 --> URI Class Initialized
INFO - 2018-06-17 14:54:22 --> Language Class Initialized
INFO - 2018-06-17 14:54:22 --> Config Class Initialized
INFO - 2018-06-17 14:54:22 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:22 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:22 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:22 --> URI Class Initialized
INFO - 2018-06-17 14:54:22 --> Router Class Initialized
INFO - 2018-06-17 14:54:22 --> Router Class Initialized
INFO - 2018-06-17 14:54:22 --> Output Class Initialized
INFO - 2018-06-17 14:54:22 --> Output Class Initialized
INFO - 2018-06-17 14:54:22 --> Security Class Initialized
INFO - 2018-06-17 14:54:22 --> Security Class Initialized
INFO - 2018-06-17 14:54:22 --> Language Class Initialized
INFO - 2018-06-17 14:54:22 --> Config Class Initialized
INFO - 2018-06-17 14:54:22 --> Loader Class Initialized
INFO - 2018-06-17 20:24:22 --> Helper loaded: url_helper
DEBUG - 2018-06-17 14:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:22 --> Input Class Initialized
INFO - 2018-06-17 20:24:22 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 14:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:22 --> Input Class Initialized
INFO - 2018-06-17 14:54:22 --> Language Class Initialized
INFO - 2018-06-17 14:54:22 --> Language Class Initialized
INFO - 2018-06-17 20:24:22 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:22 --> Database Driver Class Initialized
INFO - 2018-06-17 14:54:22 --> Language Class Initialized
INFO - 2018-06-17 14:54:22 --> Config Class Initialized
INFO - 2018-06-17 14:54:22 --> Loader Class Initialized
INFO - 2018-06-17 20:24:22 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: notification_helper
DEBUG - 2018-06-17 20:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:22 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:22 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:22 --> Controller Class Initialized
INFO - 2018-06-17 14:54:22 --> Language Class Initialized
INFO - 2018-06-17 14:54:22 --> Config Class Initialized
INFO - 2018-06-17 14:54:22 --> Loader Class Initialized
INFO - 2018-06-17 20:24:22 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:22 --> Model Class Initialized
INFO - 2018-06-17 20:24:22 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:24:22 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:24:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:22 --> Database Driver Class Initialized
INFO - 2018-06-17 20:24:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:22 --> Model Class Initialized
INFO - 2018-06-17 20:24:22 --> Model Class Initialized
INFO - 2018-06-17 20:24:22 --> Model Class Initialized
INFO - 2018-06-17 20:24:22 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-17 20:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:22 --> Model Class Initialized
INFO - 2018-06-17 20:24:22 --> Model Class Initialized
INFO - 2018-06-17 20:24:22 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:23 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:23 --> Controller Class Initialized
INFO - 2018-06-17 20:24:23 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:23 --> Total execution time: 0.1798
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Database Driver Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
DEBUG - 2018-06-17 20:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:23 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:23 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:23 --> Controller Class Initialized
INFO - 2018-06-17 20:24:23 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:23 --> Total execution time: 0.2028
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Model Class Initialized
INFO - 2018-06-17 20:24:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:23 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:23 --> Total execution time: 0.2521
INFO - 2018-06-17 14:54:24 --> Config Class Initialized
INFO - 2018-06-17 14:54:24 --> Hooks Class Initialized
INFO - 2018-06-17 14:54:24 --> Config Class Initialized
DEBUG - 2018-06-17 14:54:24 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:24 --> Hooks Class Initialized
INFO - 2018-06-17 14:54:24 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:24 --> URI Class Initialized
INFO - 2018-06-17 14:54:24 --> Config Class Initialized
INFO - 2018-06-17 14:54:24 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:24 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:24 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:24 --> URI Class Initialized
DEBUG - 2018-06-17 14:54:24 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:24 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:24 --> URI Class Initialized
INFO - 2018-06-17 14:54:24 --> Router Class Initialized
INFO - 2018-06-17 14:54:24 --> Router Class Initialized
INFO - 2018-06-17 14:54:24 --> Router Class Initialized
INFO - 2018-06-17 14:54:24 --> Output Class Initialized
INFO - 2018-06-17 14:54:24 --> Output Class Initialized
INFO - 2018-06-17 14:54:24 --> Output Class Initialized
INFO - 2018-06-17 14:54:24 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:24 --> Input Class Initialized
INFO - 2018-06-17 14:54:24 --> Security Class Initialized
INFO - 2018-06-17 14:54:24 --> Language Class Initialized
INFO - 2018-06-17 14:54:24 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:24 --> Input Class Initialized
DEBUG - 2018-06-17 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:24 --> Input Class Initialized
INFO - 2018-06-17 14:54:24 --> Language Class Initialized
INFO - 2018-06-17 14:54:24 --> Language Class Initialized
INFO - 2018-06-17 14:54:24 --> Language Class Initialized
INFO - 2018-06-17 14:54:24 --> Config Class Initialized
INFO - 2018-06-17 14:54:24 --> Loader Class Initialized
INFO - 2018-06-17 20:24:24 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: users_helper
INFO - 2018-06-17 14:54:24 --> Language Class Initialized
INFO - 2018-06-17 14:54:24 --> Config Class Initialized
INFO - 2018-06-17 14:54:24 --> Loader Class Initialized
INFO - 2018-06-17 20:24:24 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:24 --> Database Driver Class Initialized
INFO - 2018-06-17 20:24:24 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: permission_helper
INFO - 2018-06-17 14:54:24 --> Language Class Initialized
INFO - 2018-06-17 14:54:24 --> Config Class Initialized
INFO - 2018-06-17 14:54:24 --> Loader Class Initialized
INFO - 2018-06-17 20:24:24 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:24 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:24 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:24 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:24 --> Controller Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:24:24 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
DEBUG - 2018-06-17 20:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Database Driver Class Initialized
INFO - 2018-06-17 20:24:24 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:24 --> Total execution time: 0.1073
DEBUG - 2018-06-17 20:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:24 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:24 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:24 --> Controller Class Initialized
INFO - 2018-06-17 20:24:24 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:24 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:24 --> Controller Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
DEBUG - 2018-06-17 20:24:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:24 --> Model Class Initialized
INFO - 2018-06-17 20:24:24 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:24 --> Total execution time: 0.1814
INFO - 2018-06-17 20:24:24 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:24 --> Total execution time: 0.1969
INFO - 2018-06-17 14:54:26 --> Config Class Initialized
INFO - 2018-06-17 14:54:26 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:26 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:26 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:26 --> URI Class Initialized
INFO - 2018-06-17 14:54:26 --> Router Class Initialized
INFO - 2018-06-17 14:54:26 --> Output Class Initialized
INFO - 2018-06-17 14:54:26 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:26 --> Input Class Initialized
INFO - 2018-06-17 14:54:26 --> Language Class Initialized
INFO - 2018-06-17 14:54:26 --> Language Class Initialized
INFO - 2018-06-17 14:54:26 --> Config Class Initialized
INFO - 2018-06-17 14:54:26 --> Loader Class Initialized
INFO - 2018-06-17 20:24:26 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:26 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:26 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:26 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:26 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:26 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:26 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:26 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:26 --> Controller Class Initialized
INFO - 2018-06-17 20:24:26 --> Model Class Initialized
INFO - 2018-06-17 20:24:26 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:26 --> Model Class Initialized
INFO - 2018-06-17 20:24:26 --> Model Class Initialized
INFO - 2018-06-17 20:24:26 --> Model Class Initialized
INFO - 2018-06-17 20:24:26 --> Model Class Initialized
INFO - 2018-06-17 20:24:26 --> Model Class Initialized
INFO - 2018-06-17 20:24:26 --> Model Class Initialized
INFO - 2018-06-17 20:24:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:26 --> Model Class Initialized
INFO - 2018-06-17 20:24:26 --> Model Class Initialized
INFO - 2018-06-17 20:24:26 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:26 --> Total execution time: 0.1506
INFO - 2018-06-17 14:54:28 --> Config Class Initialized
INFO - 2018-06-17 14:54:28 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:28 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:28 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:28 --> URI Class Initialized
INFO - 2018-06-17 14:54:28 --> Router Class Initialized
INFO - 2018-06-17 14:54:28 --> Output Class Initialized
INFO - 2018-06-17 14:54:28 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:28 --> Input Class Initialized
INFO - 2018-06-17 14:54:28 --> Language Class Initialized
INFO - 2018-06-17 14:54:28 --> Language Class Initialized
INFO - 2018-06-17 14:54:28 --> Config Class Initialized
INFO - 2018-06-17 14:54:28 --> Loader Class Initialized
INFO - 2018-06-17 20:24:28 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:28 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:28 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:28 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:28 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:28 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:28 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:28 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:28 --> Controller Class Initialized
INFO - 2018-06-17 20:24:28 --> Model Class Initialized
INFO - 2018-06-17 20:24:28 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:28 --> Model Class Initialized
INFO - 2018-06-17 20:24:28 --> Model Class Initialized
INFO - 2018-06-17 20:24:28 --> Model Class Initialized
INFO - 2018-06-17 20:24:28 --> Model Class Initialized
INFO - 2018-06-17 20:24:28 --> Model Class Initialized
INFO - 2018-06-17 20:24:28 --> Model Class Initialized
INFO - 2018-06-17 20:24:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:28 --> Model Class Initialized
INFO - 2018-06-17 20:24:28 --> Model Class Initialized
ERROR - 2018-06-17 20:24:28 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-17 20:24:28 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:28 --> Total execution time: 0.1279
INFO - 2018-06-17 14:54:30 --> Config Class Initialized
INFO - 2018-06-17 14:54:30 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:30 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:30 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:30 --> URI Class Initialized
INFO - 2018-06-17 14:54:30 --> Router Class Initialized
INFO - 2018-06-17 14:54:30 --> Output Class Initialized
INFO - 2018-06-17 14:54:30 --> Config Class Initialized
INFO - 2018-06-17 14:54:30 --> Hooks Class Initialized
INFO - 2018-06-17 14:54:30 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:30 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:30 --> Utf8 Class Initialized
DEBUG - 2018-06-17 14:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:30 --> Input Class Initialized
INFO - 2018-06-17 14:54:30 --> Language Class Initialized
INFO - 2018-06-17 14:54:30 --> URI Class Initialized
INFO - 2018-06-17 14:54:30 --> Router Class Initialized
INFO - 2018-06-17 14:54:30 --> Output Class Initialized
INFO - 2018-06-17 14:54:30 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:30 --> Input Class Initialized
INFO - 2018-06-17 14:54:30 --> Language Class Initialized
INFO - 2018-06-17 14:54:30 --> Language Class Initialized
INFO - 2018-06-17 14:54:30 --> Config Class Initialized
INFO - 2018-06-17 14:54:30 --> Loader Class Initialized
INFO - 2018-06-17 20:24:30 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:30 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:30 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:30 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:30 --> Helper loaded: users_helper
INFO - 2018-06-17 14:54:30 --> Language Class Initialized
INFO - 2018-06-17 14:54:30 --> Config Class Initialized
INFO - 2018-06-17 14:54:30 --> Loader Class Initialized
INFO - 2018-06-17 20:24:30 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:30 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:30 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:30 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:30 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:30 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:30 --> Database Driver Class Initialized
INFO - 2018-06-17 20:24:30 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:30 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:30 --> Controller Class Initialized
DEBUG - 2018-06-17 20:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:24:30 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:30 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:30 --> Controller Class Initialized
DEBUG - 2018-06-17 20:24:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:30 --> Total execution time: 0.1144
DEBUG - 2018-06-17 20:24:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:30 --> Model Class Initialized
INFO - 2018-06-17 20:24:30 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:30 --> Total execution time: 0.1445
INFO - 2018-06-17 14:54:31 --> Config Class Initialized
INFO - 2018-06-17 14:54:31 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:31 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:31 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:31 --> URI Class Initialized
INFO - 2018-06-17 14:54:31 --> Router Class Initialized
INFO - 2018-06-17 14:54:31 --> Output Class Initialized
INFO - 2018-06-17 14:54:31 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:31 --> Input Class Initialized
INFO - 2018-06-17 14:54:31 --> Language Class Initialized
INFO - 2018-06-17 14:54:31 --> Language Class Initialized
INFO - 2018-06-17 14:54:31 --> Config Class Initialized
INFO - 2018-06-17 14:54:31 --> Loader Class Initialized
INFO - 2018-06-17 20:24:31 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:31 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:31 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:31 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:31 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:31 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:31 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:31 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:31 --> Controller Class Initialized
INFO - 2018-06-17 20:24:31 --> Model Class Initialized
INFO - 2018-06-17 20:24:31 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:31 --> Model Class Initialized
INFO - 2018-06-17 20:24:31 --> Model Class Initialized
INFO - 2018-06-17 20:24:31 --> Model Class Initialized
INFO - 2018-06-17 20:24:31 --> Model Class Initialized
INFO - 2018-06-17 20:24:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:31 --> Model Class Initialized
INFO - 2018-06-17 20:24:31 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:31 --> Total execution time: 0.1008
INFO - 2018-06-17 14:54:35 --> Config Class Initialized
INFO - 2018-06-17 14:54:35 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:35 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:35 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:35 --> URI Class Initialized
INFO - 2018-06-17 14:54:35 --> Router Class Initialized
INFO - 2018-06-17 14:54:35 --> Output Class Initialized
INFO - 2018-06-17 14:54:35 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:35 --> Input Class Initialized
INFO - 2018-06-17 14:54:35 --> Language Class Initialized
INFO - 2018-06-17 14:54:35 --> Language Class Initialized
INFO - 2018-06-17 14:54:35 --> Config Class Initialized
INFO - 2018-06-17 14:54:35 --> Loader Class Initialized
INFO - 2018-06-17 20:24:35 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:35 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:35 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:35 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:35 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:35 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:35 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:35 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:35 --> Controller Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:35 --> Total execution time: 0.1410
INFO - 2018-06-17 14:54:35 --> Config Class Initialized
INFO - 2018-06-17 14:54:35 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:35 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:35 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:35 --> URI Class Initialized
INFO - 2018-06-17 14:54:35 --> Router Class Initialized
INFO - 2018-06-17 14:54:35 --> Output Class Initialized
INFO - 2018-06-17 14:54:35 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:35 --> Input Class Initialized
INFO - 2018-06-17 14:54:35 --> Language Class Initialized
INFO - 2018-06-17 14:54:35 --> Language Class Initialized
INFO - 2018-06-17 14:54:35 --> Config Class Initialized
INFO - 2018-06-17 14:54:35 --> Loader Class Initialized
INFO - 2018-06-17 20:24:35 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:35 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:35 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:35 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:35 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:35 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:35 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:35 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:35 --> Controller Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Model Class Initialized
INFO - 2018-06-17 20:24:35 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:35 --> Total execution time: 0.1128
INFO - 2018-06-17 14:54:37 --> Config Class Initialized
INFO - 2018-06-17 14:54:37 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:37 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:37 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:37 --> URI Class Initialized
INFO - 2018-06-17 14:54:37 --> Router Class Initialized
INFO - 2018-06-17 14:54:37 --> Output Class Initialized
INFO - 2018-06-17 14:54:37 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:37 --> Input Class Initialized
INFO - 2018-06-17 14:54:37 --> Language Class Initialized
INFO - 2018-06-17 14:54:37 --> Language Class Initialized
INFO - 2018-06-17 14:54:37 --> Config Class Initialized
INFO - 2018-06-17 14:54:37 --> Loader Class Initialized
INFO - 2018-06-17 20:24:37 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:37 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:37 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:37 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:37 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:37 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:37 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:37 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:37 --> Controller Class Initialized
INFO - 2018-06-17 20:24:37 --> Model Class Initialized
INFO - 2018-06-17 20:24:37 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:37 --> Model Class Initialized
INFO - 2018-06-17 20:24:37 --> Model Class Initialized
INFO - 2018-06-17 20:24:37 --> Model Class Initialized
INFO - 2018-06-17 20:24:37 --> Model Class Initialized
INFO - 2018-06-17 20:24:37 --> Model Class Initialized
INFO - 2018-06-17 20:24:37 --> Model Class Initialized
INFO - 2018-06-17 20:24:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:37 --> Model Class Initialized
INFO - 2018-06-17 20:24:37 --> Model Class Initialized
INFO - 2018-06-17 20:24:37 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:37 --> Total execution time: 0.1203
INFO - 2018-06-17 14:54:38 --> Config Class Initialized
INFO - 2018-06-17 14:54:38 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:38 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:38 --> URI Class Initialized
INFO - 2018-06-17 14:54:38 --> Router Class Initialized
INFO - 2018-06-17 14:54:38 --> Output Class Initialized
INFO - 2018-06-17 14:54:38 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:38 --> Input Class Initialized
INFO - 2018-06-17 14:54:38 --> Language Class Initialized
INFO - 2018-06-17 14:54:38 --> Language Class Initialized
INFO - 2018-06-17 14:54:38 --> Config Class Initialized
INFO - 2018-06-17 14:54:38 --> Loader Class Initialized
INFO - 2018-06-17 20:24:38 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:38 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:38 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:38 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:38 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:38 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:38 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:38 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:38 --> Controller Class Initialized
INFO - 2018-06-17 20:24:39 --> Model Class Initialized
INFO - 2018-06-17 20:24:39 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:39 --> Model Class Initialized
INFO - 2018-06-17 20:24:39 --> Model Class Initialized
INFO - 2018-06-17 20:24:39 --> Model Class Initialized
INFO - 2018-06-17 20:24:39 --> Model Class Initialized
INFO - 2018-06-17 20:24:39 --> Model Class Initialized
INFO - 2018-06-17 20:24:39 --> Model Class Initialized
INFO - 2018-06-17 20:24:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:39 --> Model Class Initialized
INFO - 2018-06-17 20:24:39 --> Model Class Initialized
INFO - 2018-06-17 20:24:39 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:39 --> Total execution time: 0.1217
INFO - 2018-06-17 14:54:47 --> Config Class Initialized
INFO - 2018-06-17 14:54:47 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:47 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:47 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:47 --> URI Class Initialized
INFO - 2018-06-17 14:54:47 --> Router Class Initialized
INFO - 2018-06-17 14:54:47 --> Output Class Initialized
INFO - 2018-06-17 14:54:47 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:47 --> Input Class Initialized
INFO - 2018-06-17 14:54:47 --> Language Class Initialized
INFO - 2018-06-17 14:54:47 --> Language Class Initialized
INFO - 2018-06-17 14:54:47 --> Config Class Initialized
INFO - 2018-06-17 14:54:47 --> Loader Class Initialized
INFO - 2018-06-17 20:24:47 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:47 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:47 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:47 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:47 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:47 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:47 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:47 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:47 --> Controller Class Initialized
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Model Class Initialized
INFO - 2018-06-17 20:24:47 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:47 --> Total execution time: 0.2454
INFO - 2018-06-17 14:54:49 --> Config Class Initialized
INFO - 2018-06-17 14:54:49 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:49 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:49 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:49 --> URI Class Initialized
INFO - 2018-06-17 14:54:49 --> Router Class Initialized
INFO - 2018-06-17 14:54:49 --> Output Class Initialized
INFO - 2018-06-17 14:54:49 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:49 --> Input Class Initialized
INFO - 2018-06-17 14:54:49 --> Language Class Initialized
INFO - 2018-06-17 14:54:49 --> Language Class Initialized
INFO - 2018-06-17 14:54:49 --> Config Class Initialized
INFO - 2018-06-17 14:54:49 --> Loader Class Initialized
INFO - 2018-06-17 20:24:49 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:49 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:49 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:49 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:49 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:49 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:49 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:49 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:49 --> Controller Class Initialized
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Model Class Initialized
INFO - 2018-06-17 20:24:49 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:49 --> Total execution time: 0.3593
INFO - 2018-06-17 14:54:50 --> Config Class Initialized
INFO - 2018-06-17 14:54:50 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:50 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:50 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:50 --> URI Class Initialized
INFO - 2018-06-17 14:54:50 --> Router Class Initialized
INFO - 2018-06-17 14:54:50 --> Output Class Initialized
INFO - 2018-06-17 14:54:50 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:50 --> Input Class Initialized
INFO - 2018-06-17 14:54:50 --> Language Class Initialized
INFO - 2018-06-17 14:54:50 --> Language Class Initialized
INFO - 2018-06-17 14:54:50 --> Config Class Initialized
INFO - 2018-06-17 14:54:50 --> Loader Class Initialized
INFO - 2018-06-17 20:24:50 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:50 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:50 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:50 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:50 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:50 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:50 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:50 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:50 --> Controller Class Initialized
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Model Class Initialized
INFO - 2018-06-17 20:24:50 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:50 --> Total execution time: 0.2961
INFO - 2018-06-17 14:54:51 --> Config Class Initialized
INFO - 2018-06-17 14:54:51 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:51 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:51 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:51 --> URI Class Initialized
INFO - 2018-06-17 14:54:51 --> Router Class Initialized
INFO - 2018-06-17 14:54:51 --> Output Class Initialized
INFO - 2018-06-17 14:54:51 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:51 --> Input Class Initialized
INFO - 2018-06-17 14:54:51 --> Language Class Initialized
INFO - 2018-06-17 14:54:51 --> Language Class Initialized
INFO - 2018-06-17 14:54:51 --> Config Class Initialized
INFO - 2018-06-17 14:54:51 --> Loader Class Initialized
INFO - 2018-06-17 20:24:51 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:51 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:51 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:51 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:51 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:51 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:51 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:51 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:51 --> Controller Class Initialized
INFO - 2018-06-17 20:24:51 --> Model Class Initialized
INFO - 2018-06-17 20:24:51 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:51 --> Model Class Initialized
INFO - 2018-06-17 20:24:51 --> Model Class Initialized
INFO - 2018-06-17 20:24:51 --> Model Class Initialized
INFO - 2018-06-17 20:24:51 --> Model Class Initialized
INFO - 2018-06-17 20:24:51 --> Model Class Initialized
INFO - 2018-06-17 20:24:51 --> Model Class Initialized
INFO - 2018-06-17 20:24:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:51 --> Model Class Initialized
INFO - 2018-06-17 20:24:51 --> Model Class Initialized
INFO - 2018-06-17 20:24:51 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:51 --> Total execution time: 0.1216
INFO - 2018-06-17 14:54:52 --> Config Class Initialized
INFO - 2018-06-17 14:54:52 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:52 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:52 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:52 --> URI Class Initialized
INFO - 2018-06-17 14:54:52 --> Router Class Initialized
INFO - 2018-06-17 14:54:52 --> Output Class Initialized
INFO - 2018-06-17 14:54:52 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:52 --> Input Class Initialized
INFO - 2018-06-17 14:54:52 --> Language Class Initialized
INFO - 2018-06-17 14:54:52 --> Language Class Initialized
INFO - 2018-06-17 14:54:52 --> Config Class Initialized
INFO - 2018-06-17 14:54:52 --> Loader Class Initialized
INFO - 2018-06-17 20:24:52 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:52 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:52 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:52 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:52 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:52 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:52 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:52 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:52 --> Controller Class Initialized
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Model Class Initialized
INFO - 2018-06-17 20:24:52 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:52 --> Total execution time: 0.2957
INFO - 2018-06-17 14:54:53 --> Config Class Initialized
INFO - 2018-06-17 14:54:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:53 --> URI Class Initialized
INFO - 2018-06-17 14:54:53 --> Router Class Initialized
INFO - 2018-06-17 14:54:53 --> Output Class Initialized
INFO - 2018-06-17 14:54:53 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:53 --> Input Class Initialized
INFO - 2018-06-17 14:54:53 --> Language Class Initialized
INFO - 2018-06-17 14:54:53 --> Language Class Initialized
INFO - 2018-06-17 14:54:53 --> Config Class Initialized
INFO - 2018-06-17 14:54:53 --> Loader Class Initialized
INFO - 2018-06-17 20:24:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:53 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:53 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:53 --> Controller Class Initialized
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:54 --> Total execution time: 0.1231
INFO - 2018-06-17 14:54:54 --> Config Class Initialized
INFO - 2018-06-17 14:54:54 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:54 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:54 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:54 --> URI Class Initialized
INFO - 2018-06-17 14:54:54 --> Router Class Initialized
INFO - 2018-06-17 14:54:54 --> Output Class Initialized
INFO - 2018-06-17 14:54:54 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:54 --> Input Class Initialized
INFO - 2018-06-17 14:54:54 --> Language Class Initialized
INFO - 2018-06-17 14:54:54 --> Language Class Initialized
INFO - 2018-06-17 14:54:54 --> Config Class Initialized
INFO - 2018-06-17 14:54:54 --> Loader Class Initialized
INFO - 2018-06-17 20:24:54 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:54 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:54 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:54 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:54 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:54 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:54 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:54 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:54 --> Controller Class Initialized
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Model Class Initialized
INFO - 2018-06-17 20:24:54 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:54 --> Total execution time: 0.1093
INFO - 2018-06-17 14:54:57 --> Config Class Initialized
INFO - 2018-06-17 14:54:57 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:57 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:57 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:57 --> URI Class Initialized
INFO - 2018-06-17 14:54:57 --> Router Class Initialized
INFO - 2018-06-17 14:54:57 --> Output Class Initialized
INFO - 2018-06-17 14:54:57 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:57 --> Input Class Initialized
INFO - 2018-06-17 14:54:57 --> Language Class Initialized
INFO - 2018-06-17 14:54:57 --> Language Class Initialized
INFO - 2018-06-17 14:54:57 --> Config Class Initialized
INFO - 2018-06-17 14:54:57 --> Loader Class Initialized
INFO - 2018-06-17 20:24:57 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:57 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:57 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:57 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:57 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:57 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:54:57 --> Config Class Initialized
INFO - 2018-06-17 14:54:57 --> Hooks Class Initialized
INFO - 2018-06-17 20:24:57 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:57 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:57 --> Controller Class Initialized
DEBUG - 2018-06-17 14:54:57 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:57 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:57 --> URI Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:54:57 --> Router Class Initialized
DEBUG - 2018-06-17 20:24:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 14:54:57 --> Output Class Initialized
INFO - 2018-06-17 20:24:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 14:54:57 --> Security Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-17 14:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:57 --> Input Class Initialized
INFO - 2018-06-17 14:54:57 --> Language Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:57 --> Total execution time: 0.1124
INFO - 2018-06-17 14:54:57 --> Language Class Initialized
INFO - 2018-06-17 14:54:57 --> Config Class Initialized
INFO - 2018-06-17 14:54:57 --> Loader Class Initialized
INFO - 2018-06-17 20:24:57 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:57 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:57 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:57 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:57 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:57 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:57 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:57 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:57 --> Controller Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:57 --> Model Class Initialized
INFO - 2018-06-17 20:24:57 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:57 --> Total execution time: 0.1592
INFO - 2018-06-17 14:54:57 --> Config Class Initialized
INFO - 2018-06-17 14:54:57 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:54:57 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:54:57 --> Utf8 Class Initialized
INFO - 2018-06-17 14:54:57 --> URI Class Initialized
INFO - 2018-06-17 14:54:57 --> Router Class Initialized
INFO - 2018-06-17 14:54:57 --> Output Class Initialized
INFO - 2018-06-17 14:54:58 --> Security Class Initialized
DEBUG - 2018-06-17 14:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:54:58 --> Input Class Initialized
INFO - 2018-06-17 14:54:58 --> Language Class Initialized
INFO - 2018-06-17 14:54:58 --> Language Class Initialized
INFO - 2018-06-17 14:54:58 --> Config Class Initialized
INFO - 2018-06-17 14:54:58 --> Loader Class Initialized
INFO - 2018-06-17 20:24:58 --> Helper loaded: url_helper
INFO - 2018-06-17 20:24:58 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:24:58 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:24:58 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:24:58 --> Helper loaded: users_helper
INFO - 2018-06-17 20:24:58 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:24:58 --> Helper loaded: form_helper
INFO - 2018-06-17 20:24:58 --> Form Validation Class Initialized
INFO - 2018-06-17 20:24:58 --> Controller Class Initialized
INFO - 2018-06-17 20:24:58 --> Model Class Initialized
INFO - 2018-06-17 20:24:58 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:24:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:24:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:24:58 --> Model Class Initialized
INFO - 2018-06-17 20:24:58 --> Model Class Initialized
INFO - 2018-06-17 20:24:58 --> Model Class Initialized
INFO - 2018-06-17 20:24:58 --> Model Class Initialized
INFO - 2018-06-17 20:24:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:24:58 --> Model Class Initialized
INFO - 2018-06-17 20:24:58 --> Final output sent to browser
DEBUG - 2018-06-17 20:24:58 --> Total execution time: 0.1269
INFO - 2018-06-17 14:55:09 --> Config Class Initialized
INFO - 2018-06-17 14:55:09 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:09 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:09 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:09 --> URI Class Initialized
INFO - 2018-06-17 14:55:09 --> Router Class Initialized
INFO - 2018-06-17 14:55:09 --> Output Class Initialized
INFO - 2018-06-17 14:55:09 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:09 --> Input Class Initialized
INFO - 2018-06-17 14:55:09 --> Language Class Initialized
INFO - 2018-06-17 14:55:09 --> Language Class Initialized
INFO - 2018-06-17 14:55:09 --> Config Class Initialized
INFO - 2018-06-17 14:55:09 --> Loader Class Initialized
INFO - 2018-06-17 20:25:09 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:09 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:09 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:09 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:09 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:09 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:09 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:09 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:09 --> Controller Class Initialized
INFO - 2018-06-17 20:25:09 --> Model Class Initialized
INFO - 2018-06-17 20:25:09 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:09 --> Model Class Initialized
INFO - 2018-06-17 20:25:09 --> Model Class Initialized
INFO - 2018-06-17 20:25:09 --> Model Class Initialized
INFO - 2018-06-17 20:25:09 --> Model Class Initialized
INFO - 2018-06-17 20:25:09 --> Model Class Initialized
INFO - 2018-06-17 20:25:09 --> Model Class Initialized
INFO - 2018-06-17 20:25:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:09 --> Model Class Initialized
INFO - 2018-06-17 20:25:09 --> Model Class Initialized
INFO - 2018-06-17 20:25:09 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:09 --> Total execution time: 0.1247
INFO - 2018-06-17 14:55:18 --> Config Class Initialized
INFO - 2018-06-17 14:55:18 --> Hooks Class Initialized
INFO - 2018-06-17 14:55:18 --> Config Class Initialized
INFO - 2018-06-17 14:55:18 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:18 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:18 --> Utf8 Class Initialized
DEBUG - 2018-06-17 14:55:18 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:18 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:18 --> URI Class Initialized
INFO - 2018-06-17 14:55:18 --> URI Class Initialized
INFO - 2018-06-17 14:55:18 --> Router Class Initialized
INFO - 2018-06-17 14:55:18 --> Router Class Initialized
INFO - 2018-06-17 14:55:18 --> Output Class Initialized
INFO - 2018-06-17 14:55:18 --> Output Class Initialized
INFO - 2018-06-17 14:55:18 --> Security Class Initialized
INFO - 2018-06-17 14:55:18 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:18 --> Input Class Initialized
INFO - 2018-06-17 14:55:18 --> Language Class Initialized
DEBUG - 2018-06-17 14:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:18 --> Input Class Initialized
INFO - 2018-06-17 14:55:18 --> Language Class Initialized
INFO - 2018-06-17 14:55:18 --> Language Class Initialized
INFO - 2018-06-17 14:55:18 --> Config Class Initialized
INFO - 2018-06-17 14:55:18 --> Loader Class Initialized
INFO - 2018-06-17 20:25:18 --> Helper loaded: url_helper
INFO - 2018-06-17 14:55:18 --> Language Class Initialized
INFO - 2018-06-17 14:55:18 --> Config Class Initialized
INFO - 2018-06-17 14:55:18 --> Loader Class Initialized
INFO - 2018-06-17 20:25:18 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:18 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:18 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:18 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:18 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:18 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:18 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:18 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:18 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:18 --> Database Driver Class Initialized
INFO - 2018-06-17 20:25:18 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:18 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:18 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:18 --> Controller Class Initialized
INFO - 2018-06-17 20:25:18 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:18 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:18 --> Controller Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:25:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
DEBUG - 2018-06-17 20:25:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:18 --> Model Class Initialized
INFO - 2018-06-17 20:25:18 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:18 --> Total execution time: 0.1473
INFO - 2018-06-17 20:25:18 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:18 --> Total execution time: 0.1474
INFO - 2018-06-17 14:55:26 --> Config Class Initialized
INFO - 2018-06-17 14:55:26 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:26 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:26 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:26 --> URI Class Initialized
INFO - 2018-06-17 14:55:26 --> Router Class Initialized
INFO - 2018-06-17 14:55:26 --> Output Class Initialized
INFO - 2018-06-17 14:55:26 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:26 --> Input Class Initialized
INFO - 2018-06-17 14:55:26 --> Language Class Initialized
INFO - 2018-06-17 14:55:26 --> Language Class Initialized
INFO - 2018-06-17 14:55:26 --> Config Class Initialized
INFO - 2018-06-17 14:55:26 --> Loader Class Initialized
INFO - 2018-06-17 20:25:26 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:26 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:26 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:26 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:26 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:26 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:26 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:26 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:26 --> Controller Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Model Class Initialized
INFO - 2018-06-17 20:25:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:26 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:26 --> Total execution time: 0.4483
INFO - 2018-06-17 14:55:28 --> Config Class Initialized
INFO - 2018-06-17 14:55:28 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:28 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:28 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:28 --> URI Class Initialized
INFO - 2018-06-17 14:55:28 --> Router Class Initialized
INFO - 2018-06-17 14:55:28 --> Output Class Initialized
INFO - 2018-06-17 14:55:28 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:28 --> Input Class Initialized
INFO - 2018-06-17 14:55:28 --> Language Class Initialized
INFO - 2018-06-17 14:55:28 --> Language Class Initialized
INFO - 2018-06-17 14:55:28 --> Config Class Initialized
INFO - 2018-06-17 14:55:28 --> Loader Class Initialized
INFO - 2018-06-17 20:25:28 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:28 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:28 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:28 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:28 --> Controller Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:28 --> Total execution time: 0.1133
INFO - 2018-06-17 14:55:28 --> Config Class Initialized
INFO - 2018-06-17 14:55:28 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:28 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:28 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:28 --> URI Class Initialized
INFO - 2018-06-17 14:55:28 --> Router Class Initialized
INFO - 2018-06-17 14:55:28 --> Output Class Initialized
INFO - 2018-06-17 14:55:28 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:28 --> Input Class Initialized
INFO - 2018-06-17 14:55:28 --> Language Class Initialized
INFO - 2018-06-17 14:55:28 --> Language Class Initialized
INFO - 2018-06-17 14:55:28 --> Config Class Initialized
INFO - 2018-06-17 14:55:28 --> Loader Class Initialized
INFO - 2018-06-17 20:25:28 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:28 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:28 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:28 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:28 --> Controller Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:28 --> Total execution time: 0.1025
INFO - 2018-06-17 14:55:28 --> Config Class Initialized
INFO - 2018-06-17 14:55:28 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:28 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:28 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:28 --> URI Class Initialized
INFO - 2018-06-17 14:55:28 --> Router Class Initialized
INFO - 2018-06-17 14:55:28 --> Output Class Initialized
INFO - 2018-06-17 14:55:28 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:28 --> Input Class Initialized
INFO - 2018-06-17 14:55:28 --> Language Class Initialized
INFO - 2018-06-17 14:55:28 --> Language Class Initialized
INFO - 2018-06-17 14:55:28 --> Config Class Initialized
INFO - 2018-06-17 14:55:28 --> Loader Class Initialized
INFO - 2018-06-17 20:25:28 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:28 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:28 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:28 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:28 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:28 --> Controller Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:28 --> Model Class Initialized
INFO - 2018-06-17 20:25:28 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:28 --> Total execution time: 0.1490
INFO - 2018-06-17 14:55:31 --> Config Class Initialized
INFO - 2018-06-17 14:55:31 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:31 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:31 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:31 --> URI Class Initialized
INFO - 2018-06-17 14:55:31 --> Router Class Initialized
INFO - 2018-06-17 14:55:31 --> Output Class Initialized
INFO - 2018-06-17 14:55:31 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:31 --> Input Class Initialized
INFO - 2018-06-17 14:55:31 --> Language Class Initialized
INFO - 2018-06-17 14:55:31 --> Language Class Initialized
INFO - 2018-06-17 14:55:31 --> Config Class Initialized
INFO - 2018-06-17 14:55:31 --> Loader Class Initialized
INFO - 2018-06-17 20:25:31 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:31 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:31 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:31 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:31 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:31 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:31 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:31 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:31 --> Controller Class Initialized
INFO - 2018-06-17 20:25:31 --> Model Class Initialized
INFO - 2018-06-17 20:25:31 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:31 --> Model Class Initialized
INFO - 2018-06-17 20:25:31 --> Model Class Initialized
INFO - 2018-06-17 20:25:31 --> Model Class Initialized
INFO - 2018-06-17 20:25:31 --> Model Class Initialized
INFO - 2018-06-17 20:25:31 --> Model Class Initialized
INFO - 2018-06-17 20:25:31 --> Model Class Initialized
INFO - 2018-06-17 20:25:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:31 --> Model Class Initialized
INFO - 2018-06-17 20:25:31 --> Model Class Initialized
ERROR - 2018-06-17 20:25:31 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
ERROR - 2018-06-17 20:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 825
INFO - 2018-06-17 20:25:31 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:31 --> Total execution time: 0.1266
INFO - 2018-06-17 14:55:33 --> Config Class Initialized
INFO - 2018-06-17 14:55:33 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:33 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:33 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:33 --> URI Class Initialized
INFO - 2018-06-17 14:55:33 --> Router Class Initialized
INFO - 2018-06-17 14:55:33 --> Output Class Initialized
INFO - 2018-06-17 14:55:33 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:33 --> Input Class Initialized
INFO - 2018-06-17 14:55:33 --> Language Class Initialized
INFO - 2018-06-17 14:55:33 --> Config Class Initialized
INFO - 2018-06-17 14:55:33 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:33 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:33 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:33 --> URI Class Initialized
INFO - 2018-06-17 14:55:33 --> Router Class Initialized
INFO - 2018-06-17 14:55:33 --> Output Class Initialized
INFO - 2018-06-17 14:55:33 --> Language Class Initialized
INFO - 2018-06-17 14:55:33 --> Config Class Initialized
INFO - 2018-06-17 14:55:33 --> Loader Class Initialized
INFO - 2018-06-17 14:55:33 --> Security Class Initialized
INFO - 2018-06-17 20:25:33 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: notification_helper
DEBUG - 2018-06-17 14:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:33 --> Input Class Initialized
INFO - 2018-06-17 20:25:33 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:55:33 --> Language Class Initialized
INFO - 2018-06-17 20:25:33 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: users_helper
INFO - 2018-06-17 14:55:33 --> Config Class Initialized
INFO - 2018-06-17 14:55:33 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:33 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:33 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:33 --> URI Class Initialized
INFO - 2018-06-17 14:55:33 --> Language Class Initialized
INFO - 2018-06-17 14:55:33 --> Config Class Initialized
INFO - 2018-06-17 14:55:33 --> Loader Class Initialized
INFO - 2018-06-17 20:25:33 --> Helper loaded: url_helper
INFO - 2018-06-17 14:55:33 --> Router Class Initialized
INFO - 2018-06-17 20:25:33 --> Database Driver Class Initialized
INFO - 2018-06-17 20:25:33 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: users_helper
INFO - 2018-06-17 14:55:33 --> Output Class Initialized
INFO - 2018-06-17 14:55:33 --> Security Class Initialized
DEBUG - 2018-06-17 20:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-06-17 14:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:33 --> Input Class Initialized
INFO - 2018-06-17 20:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:55:33 --> Language Class Initialized
INFO - 2018-06-17 20:25:33 --> Database Driver Class Initialized
INFO - 2018-06-17 14:55:33 --> Language Class Initialized
INFO - 2018-06-17 14:55:33 --> Config Class Initialized
INFO - 2018-06-17 14:55:33 --> Loader Class Initialized
INFO - 2018-06-17 20:25:33 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: form_helper
DEBUG - 2018-06-17 20:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:33 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:33 --> Controller Class Initialized
INFO - 2018-06-17 20:25:33 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:33 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:33 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:33 --> Controller Class Initialized
INFO - 2018-06-17 20:25:33 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:33 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:33 --> Controller Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:25:33 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:25:33 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:33 --> Total execution time: 0.1135
DEBUG - 2018-06-17 20:25:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 20:25:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:33 --> Total execution time: 0.2245
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:33 --> Model Class Initialized
INFO - 2018-06-17 20:25:33 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:33 --> Total execution time: 0.2158
INFO - 2018-06-17 14:55:34 --> Config Class Initialized
INFO - 2018-06-17 14:55:34 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:34 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:34 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:34 --> URI Class Initialized
INFO - 2018-06-17 14:55:34 --> Router Class Initialized
INFO - 2018-06-17 14:55:34 --> Output Class Initialized
INFO - 2018-06-17 14:55:34 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:34 --> Input Class Initialized
INFO - 2018-06-17 14:55:34 --> Config Class Initialized
INFO - 2018-06-17 14:55:34 --> Hooks Class Initialized
INFO - 2018-06-17 14:55:34 --> Language Class Initialized
DEBUG - 2018-06-17 14:55:34 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:34 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:34 --> URI Class Initialized
INFO - 2018-06-17 14:55:34 --> Router Class Initialized
INFO - 2018-06-17 14:55:34 --> Output Class Initialized
INFO - 2018-06-17 14:55:34 --> Security Class Initialized
INFO - 2018-06-17 14:55:34 --> Language Class Initialized
INFO - 2018-06-17 14:55:34 --> Config Class Initialized
INFO - 2018-06-17 14:55:34 --> Loader Class Initialized
INFO - 2018-06-17 20:25:34 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:34 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:34 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:34 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 14:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:34 --> Input Class Initialized
INFO - 2018-06-17 20:25:34 --> Helper loaded: users_helper
INFO - 2018-06-17 14:55:34 --> Language Class Initialized
INFO - 2018-06-17 20:25:34 --> Database Driver Class Initialized
INFO - 2018-06-17 14:55:34 --> Language Class Initialized
INFO - 2018-06-17 14:55:34 --> Config Class Initialized
INFO - 2018-06-17 14:55:34 --> Loader Class Initialized
INFO - 2018-06-17 20:25:34 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:34 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:34 --> Helper loaded: settings_helper
DEBUG - 2018-06-17 20:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:34 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:34 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:34 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:34 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:34 --> Controller Class Initialized
INFO - 2018-06-17 20:25:34 --> Database Driver Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 20:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:34 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:34 --> Controller Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:34 --> Model Class Initialized
INFO - 2018-06-17 20:25:34 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:34 --> Total execution time: 0.1484
INFO - 2018-06-17 20:25:34 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:34 --> Total execution time: 0.1515
INFO - 2018-06-17 14:55:38 --> Config Class Initialized
INFO - 2018-06-17 14:55:38 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:38 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:38 --> URI Class Initialized
INFO - 2018-06-17 14:55:38 --> Config Class Initialized
INFO - 2018-06-17 14:55:38 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:38 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:38 --> Router Class Initialized
INFO - 2018-06-17 14:55:38 --> URI Class Initialized
INFO - 2018-06-17 14:55:38 --> Config Class Initialized
INFO - 2018-06-17 14:55:38 --> Hooks Class Initialized
INFO - 2018-06-17 14:55:38 --> Output Class Initialized
DEBUG - 2018-06-17 14:55:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:38 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:38 --> Security Class Initialized
INFO - 2018-06-17 14:55:38 --> Router Class Initialized
INFO - 2018-06-17 14:55:38 --> URI Class Initialized
DEBUG - 2018-06-17 14:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:38 --> Input Class Initialized
INFO - 2018-06-17 14:55:38 --> Output Class Initialized
INFO - 2018-06-17 14:55:38 --> Language Class Initialized
INFO - 2018-06-17 14:55:38 --> Router Class Initialized
INFO - 2018-06-17 14:55:38 --> Security Class Initialized
INFO - 2018-06-17 14:55:38 --> Output Class Initialized
DEBUG - 2018-06-17 14:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:38 --> Input Class Initialized
INFO - 2018-06-17 14:55:38 --> Language Class Initialized
INFO - 2018-06-17 14:55:38 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:38 --> Input Class Initialized
INFO - 2018-06-17 14:55:38 --> Language Class Initialized
INFO - 2018-06-17 14:55:38 --> Language Class Initialized
INFO - 2018-06-17 14:55:38 --> Config Class Initialized
INFO - 2018-06-17 14:55:38 --> Loader Class Initialized
INFO - 2018-06-17 20:25:38 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: users_helper
INFO - 2018-06-17 14:55:38 --> Language Class Initialized
INFO - 2018-06-17 14:55:38 --> Config Class Initialized
INFO - 2018-06-17 14:55:38 --> Loader Class Initialized
INFO - 2018-06-17 20:25:38 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:55:38 --> Language Class Initialized
INFO - 2018-06-17 14:55:38 --> Config Class Initialized
INFO - 2018-06-17 14:55:38 --> Loader Class Initialized
INFO - 2018-06-17 20:25:38 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:38 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:38 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:38 --> Database Driver Class Initialized
INFO - 2018-06-17 20:25:38 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:38 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:38 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:38 --> Controller Class Initialized
DEBUG - 2018-06-17 20:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:38 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:38 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:38 --> Controller Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:38 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:38 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:25:38 --> Controller Class Initialized
DEBUG - 2018-06-17 20:25:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:38 --> Total execution time: 0.1080
INFO - 2018-06-17 20:25:38 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:38 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-06-17 20:25:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Model Class Initialized
INFO - 2018-06-17 20:25:38 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:38 --> Total execution time: 0.1086
INFO - 2018-06-17 20:25:38 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:38 --> Total execution time: 0.1369
INFO - 2018-06-17 14:55:39 --> Config Class Initialized
INFO - 2018-06-17 14:55:39 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:39 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:39 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:39 --> URI Class Initialized
INFO - 2018-06-17 14:55:39 --> Router Class Initialized
INFO - 2018-06-17 14:55:39 --> Output Class Initialized
INFO - 2018-06-17 14:55:39 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:39 --> Input Class Initialized
INFO - 2018-06-17 14:55:39 --> Language Class Initialized
INFO - 2018-06-17 14:55:39 --> Config Class Initialized
INFO - 2018-06-17 14:55:39 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:39 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:39 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:39 --> URI Class Initialized
INFO - 2018-06-17 14:55:39 --> Language Class Initialized
INFO - 2018-06-17 14:55:39 --> Config Class Initialized
INFO - 2018-06-17 14:55:39 --> Loader Class Initialized
INFO - 2018-06-17 20:25:39 --> Helper loaded: url_helper
INFO - 2018-06-17 14:55:39 --> Router Class Initialized
INFO - 2018-06-17 20:25:39 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:39 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:39 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:39 --> Helper loaded: users_helper
INFO - 2018-06-17 14:55:39 --> Output Class Initialized
INFO - 2018-06-17 14:55:39 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:39 --> Input Class Initialized
INFO - 2018-06-17 14:55:39 --> Language Class Initialized
INFO - 2018-06-17 20:25:39 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:55:39 --> Language Class Initialized
INFO - 2018-06-17 14:55:39 --> Config Class Initialized
INFO - 2018-06-17 14:55:39 --> Loader Class Initialized
INFO - 2018-06-17 20:25:39 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:39 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:39 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:39 --> Controller Class Initialized
INFO - 2018-06-17 20:25:39 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:39 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:39 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:39 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Database Driver Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
DEBUG - 2018-06-17 20:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:39 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:39 --> Controller Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:39 --> Total execution time: 0.1418
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:39 --> Model Class Initialized
INFO - 2018-06-17 20:25:40 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:40 --> Total execution time: 0.1469
INFO - 2018-06-17 14:55:41 --> Config Class Initialized
INFO - 2018-06-17 14:55:41 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:41 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:41 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:41 --> URI Class Initialized
INFO - 2018-06-17 14:55:41 --> Router Class Initialized
INFO - 2018-06-17 14:55:41 --> Output Class Initialized
INFO - 2018-06-17 14:55:41 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:41 --> Input Class Initialized
INFO - 2018-06-17 14:55:41 --> Language Class Initialized
INFO - 2018-06-17 14:55:41 --> Config Class Initialized
INFO - 2018-06-17 14:55:41 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:41 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:41 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:41 --> URI Class Initialized
INFO - 2018-06-17 14:55:41 --> Router Class Initialized
INFO - 2018-06-17 14:55:41 --> Language Class Initialized
INFO - 2018-06-17 14:55:41 --> Config Class Initialized
INFO - 2018-06-17 14:55:41 --> Loader Class Initialized
INFO - 2018-06-17 14:55:41 --> Output Class Initialized
INFO - 2018-06-17 20:25:41 --> Helper loaded: url_helper
INFO - 2018-06-17 14:55:41 --> Security Class Initialized
INFO - 2018-06-17 20:25:41 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:41 --> Helper loaded: settings_helper
DEBUG - 2018-06-17 14:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:41 --> Input Class Initialized
INFO - 2018-06-17 20:25:41 --> Helper loaded: permission_helper
INFO - 2018-06-17 14:55:41 --> Language Class Initialized
INFO - 2018-06-17 20:25:41 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:41 --> Database Driver Class Initialized
INFO - 2018-06-17 14:55:41 --> Language Class Initialized
INFO - 2018-06-17 14:55:41 --> Config Class Initialized
INFO - 2018-06-17 14:55:41 --> Loader Class Initialized
INFO - 2018-06-17 20:25:41 --> Helper loaded: url_helper
DEBUG - 2018-06-17 20:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:41 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:41 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:41 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:41 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:41 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:41 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:41 --> Controller Class Initialized
INFO - 2018-06-17 20:25:41 --> Database Driver Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:55:41 --> Config Class Initialized
INFO - 2018-06-17 14:55:41 --> Hooks Class Initialized
DEBUG - 2018-06-17 20:25:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 20:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:41 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:41 --> Controller Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 14:55:41 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:41 --> Utf8 Class Initialized
INFO - 2018-06-17 20:25:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:41 --> Model Class Initialized
INFO - 2018-06-17 20:25:41 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:41 --> Total execution time: 0.1053
INFO - 2018-06-17 14:55:41 --> URI Class Initialized
INFO - 2018-06-17 20:25:42 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:42 --> Total execution time: 0.1437
INFO - 2018-06-17 14:55:42 --> Router Class Initialized
INFO - 2018-06-17 14:55:42 --> Output Class Initialized
INFO - 2018-06-17 14:55:42 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:42 --> Input Class Initialized
INFO - 2018-06-17 14:55:42 --> Language Class Initialized
INFO - 2018-06-17 14:55:42 --> Language Class Initialized
INFO - 2018-06-17 14:55:42 --> Config Class Initialized
INFO - 2018-06-17 14:55:42 --> Loader Class Initialized
INFO - 2018-06-17 20:25:42 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:42 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:42 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:42 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:42 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:42 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:42 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:42 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:42 --> Controller Class Initialized
INFO - 2018-06-17 20:25:42 --> Model Class Initialized
INFO - 2018-06-17 20:25:42 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:42 --> Model Class Initialized
INFO - 2018-06-17 20:25:42 --> Model Class Initialized
INFO - 2018-06-17 20:25:42 --> Model Class Initialized
INFO - 2018-06-17 20:25:42 --> Model Class Initialized
INFO - 2018-06-17 20:25:42 --> Model Class Initialized
INFO - 2018-06-17 20:25:42 --> Model Class Initialized
INFO - 2018-06-17 20:25:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:42 --> Model Class Initialized
INFO - 2018-06-17 20:25:42 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:42 --> Total execution time: 0.2008
INFO - 2018-06-17 14:55:45 --> Config Class Initialized
INFO - 2018-06-17 14:55:45 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:45 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:45 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:45 --> URI Class Initialized
INFO - 2018-06-17 14:55:45 --> Router Class Initialized
INFO - 2018-06-17 14:55:45 --> Output Class Initialized
INFO - 2018-06-17 14:55:45 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:45 --> Input Class Initialized
INFO - 2018-06-17 14:55:45 --> Language Class Initialized
INFO - 2018-06-17 14:55:45 --> Language Class Initialized
INFO - 2018-06-17 14:55:45 --> Config Class Initialized
INFO - 2018-06-17 14:55:45 --> Loader Class Initialized
INFO - 2018-06-17 20:25:45 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:45 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:45 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:45 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:45 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:45 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:45 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:45 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:45 --> Controller Class Initialized
INFO - 2018-06-17 20:25:45 --> Model Class Initialized
INFO - 2018-06-17 20:25:45 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:45 --> Model Class Initialized
INFO - 2018-06-17 20:25:45 --> Model Class Initialized
INFO - 2018-06-17 20:25:45 --> Model Class Initialized
INFO - 2018-06-17 20:25:45 --> Model Class Initialized
INFO - 2018-06-17 20:25:45 --> Model Class Initialized
INFO - 2018-06-17 20:25:45 --> Model Class Initialized
INFO - 2018-06-17 20:25:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:45 --> Model Class Initialized
INFO - 2018-06-17 20:25:45 --> Model Class Initialized
ERROR - 2018-06-17 20:25:45 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
ERROR - 2018-06-17 20:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 825
INFO - 2018-06-17 20:25:45 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:45 --> Total execution time: 0.1290
INFO - 2018-06-17 14:55:46 --> Config Class Initialized
INFO - 2018-06-17 14:55:46 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:46 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:46 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:46 --> URI Class Initialized
INFO - 2018-06-17 14:55:46 --> Router Class Initialized
INFO - 2018-06-17 14:55:46 --> Output Class Initialized
INFO - 2018-06-17 14:55:46 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:46 --> Input Class Initialized
INFO - 2018-06-17 14:55:46 --> Language Class Initialized
INFO - 2018-06-17 14:55:46 --> Language Class Initialized
INFO - 2018-06-17 14:55:46 --> Config Class Initialized
INFO - 2018-06-17 14:55:46 --> Loader Class Initialized
INFO - 2018-06-17 20:25:46 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:46 --> Database Driver Class Initialized
INFO - 2018-06-17 14:55:46 --> Config Class Initialized
INFO - 2018-06-17 14:55:46 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:46 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:46 --> Utf8 Class Initialized
DEBUG - 2018-06-17 20:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 14:55:46 --> URI Class Initialized
INFO - 2018-06-17 20:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:55:46 --> Router Class Initialized
INFO - 2018-06-17 14:55:46 --> Output Class Initialized
INFO - 2018-06-17 14:55:46 --> Config Class Initialized
INFO - 2018-06-17 14:55:46 --> Hooks Class Initialized
INFO - 2018-06-17 20:25:46 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:46 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:46 --> Controller Class Initialized
INFO - 2018-06-17 14:55:46 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:46 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:46 --> Utf8 Class Initialized
DEBUG - 2018-06-17 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:46 --> Input Class Initialized
INFO - 2018-06-17 14:55:46 --> Language Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 14:55:46 --> URI Class Initialized
INFO - 2018-06-17 20:25:46 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 14:55:46 --> Router Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 14:55:46 --> Language Class Initialized
INFO - 2018-06-17 14:55:46 --> Config Class Initialized
INFO - 2018-06-17 14:55:46 --> Loader Class Initialized
INFO - 2018-06-17 20:25:46 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:46 --> Total execution time: 0.1109
INFO - 2018-06-17 14:55:46 --> Output Class Initialized
INFO - 2018-06-17 20:25:46 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:55:46 --> Security Class Initialized
INFO - 2018-06-17 20:25:46 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: users_helper
DEBUG - 2018-06-17 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:46 --> Input Class Initialized
INFO - 2018-06-17 14:55:46 --> Language Class Initialized
INFO - 2018-06-17 20:25:46 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:46 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:46 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:46 --> Controller Class Initialized
INFO - 2018-06-17 14:55:46 --> Language Class Initialized
INFO - 2018-06-17 14:55:46 --> Config Class Initialized
INFO - 2018-06-17 14:55:46 --> Loader Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:46 --> Helper loaded: settings_helper
DEBUG - 2018-06-17 20:25:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:46 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:46 --> Total execution time: 0.1057
INFO - 2018-06-17 20:25:46 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:46 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:46 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:46 --> Controller Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:46 --> Model Class Initialized
INFO - 2018-06-17 20:25:46 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:46 --> Total execution time: 0.1912
INFO - 2018-06-17 14:55:53 --> Config Class Initialized
INFO - 2018-06-17 14:55:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:53 --> URI Class Initialized
INFO - 2018-06-17 14:55:53 --> Router Class Initialized
INFO - 2018-06-17 14:55:53 --> Output Class Initialized
INFO - 2018-06-17 14:55:53 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:53 --> Input Class Initialized
INFO - 2018-06-17 14:55:53 --> Language Class Initialized
INFO - 2018-06-17 14:55:53 --> Language Class Initialized
INFO - 2018-06-17 14:55:53 --> Config Class Initialized
INFO - 2018-06-17 14:55:53 --> Loader Class Initialized
INFO - 2018-06-17 20:25:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:53 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:53 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:53 --> Controller Class Initialized
INFO - 2018-06-17 20:25:53 --> Model Class Initialized
INFO - 2018-06-17 20:25:53 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:53 --> Model Class Initialized
INFO - 2018-06-17 20:25:53 --> Model Class Initialized
INFO - 2018-06-17 20:25:53 --> Model Class Initialized
INFO - 2018-06-17 20:25:53 --> Model Class Initialized
INFO - 2018-06-17 20:25:53 --> Model Class Initialized
INFO - 2018-06-17 20:25:53 --> Model Class Initialized
INFO - 2018-06-17 20:25:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:53 --> Model Class Initialized
INFO - 2018-06-17 20:25:53 --> Model Class Initialized
ERROR - 2018-06-17 20:25:53 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
ERROR - 2018-06-17 20:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 825
INFO - 2018-06-17 20:25:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:53 --> Total execution time: 0.1207
INFO - 2018-06-17 14:55:55 --> Config Class Initialized
INFO - 2018-06-17 14:55:55 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:55 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:55 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:55 --> URI Class Initialized
INFO - 2018-06-17 14:55:55 --> Router Class Initialized
INFO - 2018-06-17 14:55:55 --> Output Class Initialized
INFO - 2018-06-17 14:55:55 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:55 --> Input Class Initialized
INFO - 2018-06-17 14:55:55 --> Language Class Initialized
INFO - 2018-06-17 14:55:55 --> Language Class Initialized
INFO - 2018-06-17 14:55:55 --> Config Class Initialized
INFO - 2018-06-17 14:55:55 --> Loader Class Initialized
INFO - 2018-06-17 20:25:55 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:55 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:55 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:55 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:55 --> Controller Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:55 --> Total execution time: 0.1180
INFO - 2018-06-17 14:55:55 --> Config Class Initialized
INFO - 2018-06-17 14:55:55 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:55:55 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:55 --> Utf8 Class Initialized
INFO - 2018-06-17 14:55:55 --> URI Class Initialized
INFO - 2018-06-17 14:55:55 --> Router Class Initialized
INFO - 2018-06-17 14:55:55 --> Config Class Initialized
INFO - 2018-06-17 14:55:55 --> Hooks Class Initialized
INFO - 2018-06-17 14:55:55 --> Output Class Initialized
INFO - 2018-06-17 14:55:55 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:55 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:55:55 --> Utf8 Class Initialized
DEBUG - 2018-06-17 14:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:55 --> Input Class Initialized
INFO - 2018-06-17 14:55:55 --> URI Class Initialized
INFO - 2018-06-17 14:55:55 --> Language Class Initialized
INFO - 2018-06-17 14:55:55 --> Router Class Initialized
INFO - 2018-06-17 14:55:55 --> Output Class Initialized
INFO - 2018-06-17 14:55:55 --> Security Class Initialized
DEBUG - 2018-06-17 14:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:55:55 --> Input Class Initialized
INFO - 2018-06-17 14:55:55 --> Language Class Initialized
INFO - 2018-06-17 14:55:55 --> Language Class Initialized
INFO - 2018-06-17 14:55:55 --> Config Class Initialized
INFO - 2018-06-17 14:55:55 --> Loader Class Initialized
INFO - 2018-06-17 20:25:55 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: users_helper
INFO - 2018-06-17 14:55:55 --> Language Class Initialized
INFO - 2018-06-17 14:55:55 --> Config Class Initialized
INFO - 2018-06-17 14:55:55 --> Loader Class Initialized
INFO - 2018-06-17 20:25:55 --> Helper loaded: url_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:25:55 --> Helper loaded: users_helper
INFO - 2018-06-17 20:25:55 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:55 --> Database Driver Class Initialized
INFO - 2018-06-17 20:25:55 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:55 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:55 --> Controller Class Initialized
DEBUG - 2018-06-17 20:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:25:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:55 --> Helper loaded: form_helper
INFO - 2018-06-17 20:25:55 --> Form Validation Class Initialized
INFO - 2018-06-17 20:25:55 --> Controller Class Initialized
INFO - 2018-06-17 20:25:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
DEBUG - 2018-06-17 20:25:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:25:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:25:55 --> Model Class Initialized
INFO - 2018-06-17 20:25:55 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:55 --> Total execution time: 0.1060
INFO - 2018-06-17 20:25:55 --> Final output sent to browser
DEBUG - 2018-06-17 20:25:55 --> Total execution time: 0.1356
INFO - 2018-06-17 14:56:12 --> Config Class Initialized
INFO - 2018-06-17 14:56:12 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:12 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:12 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:12 --> URI Class Initialized
INFO - 2018-06-17 14:56:12 --> Router Class Initialized
INFO - 2018-06-17 14:56:12 --> Output Class Initialized
INFO - 2018-06-17 14:56:12 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:12 --> Input Class Initialized
INFO - 2018-06-17 14:56:12 --> Language Class Initialized
INFO - 2018-06-17 14:56:12 --> Language Class Initialized
INFO - 2018-06-17 14:56:12 --> Config Class Initialized
INFO - 2018-06-17 14:56:12 --> Loader Class Initialized
INFO - 2018-06-17 20:26:12 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:12 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:12 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:12 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:12 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:12 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:12 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:12 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:12 --> Controller Class Initialized
INFO - 2018-06-17 20:26:12 --> Model Class Initialized
INFO - 2018-06-17 20:26:12 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:12 --> Model Class Initialized
INFO - 2018-06-17 20:26:12 --> Model Class Initialized
INFO - 2018-06-17 20:26:12 --> Model Class Initialized
INFO - 2018-06-17 20:26:12 --> Model Class Initialized
INFO - 2018-06-17 20:26:12 --> Model Class Initialized
INFO - 2018-06-17 20:26:12 --> Model Class Initialized
INFO - 2018-06-17 20:26:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:12 --> Model Class Initialized
INFO - 2018-06-17 20:26:12 --> Model Class Initialized
ERROR - 2018-06-17 20:26:12 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
ERROR - 2018-06-17 20:26:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 825
INFO - 2018-06-17 20:26:12 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:12 --> Total execution time: 0.1142
INFO - 2018-06-17 14:56:15 --> Config Class Initialized
INFO - 2018-06-17 14:56:15 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:15 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:15 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:15 --> URI Class Initialized
INFO - 2018-06-17 14:56:15 --> Router Class Initialized
INFO - 2018-06-17 14:56:15 --> Output Class Initialized
INFO - 2018-06-17 14:56:15 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:15 --> Input Class Initialized
INFO - 2018-06-17 14:56:15 --> Language Class Initialized
INFO - 2018-06-17 14:56:15 --> Language Class Initialized
INFO - 2018-06-17 14:56:15 --> Config Class Initialized
INFO - 2018-06-17 14:56:15 --> Loader Class Initialized
INFO - 2018-06-17 20:26:15 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:15 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:15 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:15 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:15 --> Controller Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:15 --> Total execution time: 0.1440
INFO - 2018-06-17 14:56:15 --> Config Class Initialized
INFO - 2018-06-17 14:56:15 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:15 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:15 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:15 --> URI Class Initialized
INFO - 2018-06-17 14:56:15 --> Router Class Initialized
INFO - 2018-06-17 14:56:15 --> Config Class Initialized
INFO - 2018-06-17 14:56:15 --> Hooks Class Initialized
INFO - 2018-06-17 14:56:15 --> Output Class Initialized
DEBUG - 2018-06-17 14:56:15 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:15 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:15 --> Security Class Initialized
INFO - 2018-06-17 14:56:15 --> URI Class Initialized
DEBUG - 2018-06-17 14:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:15 --> Input Class Initialized
INFO - 2018-06-17 14:56:15 --> Language Class Initialized
INFO - 2018-06-17 14:56:15 --> Router Class Initialized
INFO - 2018-06-17 14:56:15 --> Output Class Initialized
INFO - 2018-06-17 14:56:15 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:15 --> Input Class Initialized
INFO - 2018-06-17 14:56:15 --> Language Class Initialized
INFO - 2018-06-17 14:56:15 --> Language Class Initialized
INFO - 2018-06-17 14:56:15 --> Config Class Initialized
INFO - 2018-06-17 14:56:15 --> Loader Class Initialized
INFO - 2018-06-17 20:26:15 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: permission_helper
INFO - 2018-06-17 14:56:15 --> Language Class Initialized
INFO - 2018-06-17 14:56:15 --> Config Class Initialized
INFO - 2018-06-17 20:26:15 --> Helper loaded: users_helper
INFO - 2018-06-17 14:56:15 --> Loader Class Initialized
INFO - 2018-06-17 20:26:15 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:15 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:15 --> Database Driver Class Initialized
INFO - 2018-06-17 20:26:15 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:15 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:15 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:15 --> Controller Class Initialized
DEBUG - 2018-06-17 20:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:15 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:15 --> Controller Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:15 --> Model Class Initialized
INFO - 2018-06-17 20:26:15 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:15 --> Total execution time: 0.1514
INFO - 2018-06-17 20:26:15 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:15 --> Total execution time: 0.1385
INFO - 2018-06-17 14:56:17 --> Config Class Initialized
INFO - 2018-06-17 14:56:17 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:17 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:17 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:17 --> URI Class Initialized
INFO - 2018-06-17 14:56:17 --> Router Class Initialized
INFO - 2018-06-17 14:56:17 --> Output Class Initialized
INFO - 2018-06-17 14:56:17 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:17 --> Input Class Initialized
INFO - 2018-06-17 14:56:17 --> Language Class Initialized
INFO - 2018-06-17 14:56:17 --> Language Class Initialized
INFO - 2018-06-17 14:56:17 --> Config Class Initialized
INFO - 2018-06-17 14:56:17 --> Loader Class Initialized
INFO - 2018-06-17 20:26:17 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:17 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:17 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:17 --> Helper loaded: permission_helper
INFO - 2018-06-17 14:56:17 --> Config Class Initialized
INFO - 2018-06-17 14:56:17 --> Hooks Class Initialized
INFO - 2018-06-17 20:26:17 --> Helper loaded: users_helper
DEBUG - 2018-06-17 14:56:17 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:17 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:17 --> URI Class Initialized
INFO - 2018-06-17 14:56:17 --> Router Class Initialized
INFO - 2018-06-17 14:56:17 --> Output Class Initialized
INFO - 2018-06-17 20:26:17 --> Database Driver Class Initialized
INFO - 2018-06-17 14:56:17 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:17 --> Input Class Initialized
INFO - 2018-06-17 14:56:17 --> Language Class Initialized
DEBUG - 2018-06-17 20:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:17 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:17 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:17 --> Controller Class Initialized
INFO - 2018-06-17 14:56:17 --> Language Class Initialized
INFO - 2018-06-17 14:56:17 --> Config Class Initialized
INFO - 2018-06-17 14:56:17 --> Loader Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:26:17 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:17 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:17 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:17 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 20:26:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:17 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:17 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:17 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:17 --> Controller Class Initialized
INFO - 2018-06-17 20:26:17 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:17 --> Total execution time: 0.1350
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:17 --> Model Class Initialized
INFO - 2018-06-17 20:26:17 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:17 --> Total execution time: 0.1602
INFO - 2018-06-17 14:56:24 --> Config Class Initialized
INFO - 2018-06-17 14:56:24 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:24 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:24 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:24 --> URI Class Initialized
INFO - 2018-06-17 14:56:24 --> Router Class Initialized
INFO - 2018-06-17 14:56:24 --> Output Class Initialized
INFO - 2018-06-17 14:56:24 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:24 --> Input Class Initialized
INFO - 2018-06-17 14:56:24 --> Language Class Initialized
INFO - 2018-06-17 14:56:24 --> Language Class Initialized
INFO - 2018-06-17 14:56:24 --> Config Class Initialized
INFO - 2018-06-17 14:56:24 --> Loader Class Initialized
INFO - 2018-06-17 20:26:24 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:24 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:24 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:24 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:24 --> Helper loaded: users_helper
INFO - 2018-06-17 14:56:24 --> Config Class Initialized
INFO - 2018-06-17 14:56:24 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:24 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:24 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:24 --> URI Class Initialized
INFO - 2018-06-17 20:26:24 --> Database Driver Class Initialized
INFO - 2018-06-17 14:56:24 --> Router Class Initialized
INFO - 2018-06-17 14:56:24 --> Output Class Initialized
INFO - 2018-06-17 14:56:24 --> Security Class Initialized
DEBUG - 2018-06-17 20:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 14:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:24 --> Input Class Initialized
INFO - 2018-06-17 14:56:24 --> Language Class Initialized
INFO - 2018-06-17 20:26:24 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:24 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:24 --> Controller Class Initialized
INFO - 2018-06-17 14:56:24 --> Language Class Initialized
INFO - 2018-06-17 14:56:24 --> Config Class Initialized
INFO - 2018-06-17 14:56:24 --> Loader Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:26:24 --> Helper loaded: url_helper
DEBUG - 2018-06-17 20:26:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:24 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:24 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:24 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:24 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:24 --> Total execution time: 0.1170
INFO - 2018-06-17 20:26:24 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:24 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:24 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:24 --> Controller Class Initialized
INFO - 2018-06-17 14:56:24 --> Config Class Initialized
INFO - 2018-06-17 14:56:24 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:24 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:24 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:24 --> URI Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:56:24 --> Router Class Initialized
DEBUG - 2018-06-17 20:26:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 14:56:24 --> Output Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 14:56:24 --> Security Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
DEBUG - 2018-06-17 14:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:24 --> Input Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 14:56:24 --> Language Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 14:56:24 --> Language Class Initialized
INFO - 2018-06-17 14:56:24 --> Config Class Initialized
INFO - 2018-06-17 14:56:24 --> Loader Class Initialized
INFO - 2018-06-17 20:26:24 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:24 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:24 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:24 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:24 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:24 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:24 --> Total execution time: 0.1640
INFO - 2018-06-17 20:26:24 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:24 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:24 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:24 --> Controller Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Model Class Initialized
INFO - 2018-06-17 20:26:24 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:24 --> Total execution time: 0.1161
INFO - 2018-06-17 14:56:27 --> Config Class Initialized
INFO - 2018-06-17 14:56:27 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:27 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:27 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:27 --> URI Class Initialized
INFO - 2018-06-17 14:56:27 --> Router Class Initialized
INFO - 2018-06-17 14:56:27 --> Config Class Initialized
INFO - 2018-06-17 14:56:27 --> Output Class Initialized
INFO - 2018-06-17 14:56:27 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:27 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:27 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:27 --> Security Class Initialized
INFO - 2018-06-17 14:56:27 --> URI Class Initialized
DEBUG - 2018-06-17 14:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:27 --> Input Class Initialized
INFO - 2018-06-17 14:56:27 --> Language Class Initialized
INFO - 2018-06-17 14:56:27 --> Router Class Initialized
INFO - 2018-06-17 14:56:27 --> Output Class Initialized
INFO - 2018-06-17 14:56:27 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:27 --> Input Class Initialized
INFO - 2018-06-17 14:56:27 --> Language Class Initialized
INFO - 2018-06-17 14:56:27 --> Language Class Initialized
INFO - 2018-06-17 14:56:27 --> Config Class Initialized
INFO - 2018-06-17 14:56:27 --> Loader Class Initialized
INFO - 2018-06-17 20:26:27 --> Helper loaded: url_helper
INFO - 2018-06-17 14:56:27 --> Language Class Initialized
INFO - 2018-06-17 14:56:27 --> Config Class Initialized
INFO - 2018-06-17 14:56:27 --> Loader Class Initialized
INFO - 2018-06-17 20:26:27 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:27 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:27 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:27 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:27 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:27 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:27 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:27 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:27 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:27 --> Database Driver Class Initialized
INFO - 2018-06-17 14:56:27 --> Config Class Initialized
INFO - 2018-06-17 14:56:27 --> Hooks Class Initialized
INFO - 2018-06-17 20:26:27 --> Database Driver Class Initialized
DEBUG - 2018-06-17 14:56:27 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:27 --> Utf8 Class Initialized
DEBUG - 2018-06-17 20:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:56:27 --> URI Class Initialized
DEBUG - 2018-06-17 20:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:56:27 --> Router Class Initialized
INFO - 2018-06-17 14:56:27 --> Output Class Initialized
INFO - 2018-06-17 14:56:27 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:27 --> Input Class Initialized
INFO - 2018-06-17 14:56:27 --> Language Class Initialized
INFO - 2018-06-17 20:26:27 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:27 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:27 --> Controller Class Initialized
INFO - 2018-06-17 20:26:27 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:27 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:27 --> Controller Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 14:56:27 --> Language Class Initialized
INFO - 2018-06-17 14:56:27 --> Config Class Initialized
INFO - 2018-06-17 14:56:27 --> Loader Class Initialized
INFO - 2018-06-17 20:26:27 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:27 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:27 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:27 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 20:26:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:27 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:27 --> Total execution time: 0.1394
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:27 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:27 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:27 --> Total execution time: 0.1905
INFO - 2018-06-17 20:26:27 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:27 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:27 --> Controller Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:27 --> Model Class Initialized
INFO - 2018-06-17 20:26:27 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:27 --> Total execution time: 0.1568
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:53 --> URI Class Initialized
INFO - 2018-06-17 14:56:53 --> Router Class Initialized
INFO - 2018-06-17 14:56:53 --> Output Class Initialized
INFO - 2018-06-17 14:56:53 --> Security Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:53 --> Input Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
DEBUG - 2018-06-17 14:56:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:53 --> URI Class Initialized
INFO - 2018-06-17 14:56:53 --> Router Class Initialized
INFO - 2018-06-17 14:56:53 --> Output Class Initialized
INFO - 2018-06-17 14:56:53 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:53 --> Input Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Loader Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: users_helper
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Loader Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:53 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:53 --> Database Driver Class Initialized
INFO - 2018-06-17 20:26:53 --> Controller Class Initialized
DEBUG - 2018-06-17 20:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:53 --> Controller Class Initialized
INFO - 2018-06-17 20:26:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:53 --> Total execution time: 0.1154
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:53 --> Total execution time: 0.1243
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:53 --> URI Class Initialized
INFO - 2018-06-17 14:56:53 --> Router Class Initialized
INFO - 2018-06-17 14:56:53 --> Output Class Initialized
INFO - 2018-06-17 14:56:53 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:53 --> Input Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:53 --> URI Class Initialized
INFO - 2018-06-17 14:56:53 --> Router Class Initialized
INFO - 2018-06-17 14:56:53 --> Output Class Initialized
INFO - 2018-06-17 14:56:53 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:53 --> Input Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Loader Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: users_helper
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Loader Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:53 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Hooks Class Initialized
INFO - 2018-06-17 20:26:53 --> Database Driver Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:53 --> Controller Class Initialized
DEBUG - 2018-06-17 14:56:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:53 --> URI Class Initialized
DEBUG - 2018-06-17 20:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 14:56:53 --> Router Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:53 --> Form Validation Class Initialized
INFO - 2018-06-17 14:56:53 --> Output Class Initialized
INFO - 2018-06-17 20:26:53 --> Controller Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 14:56:53 --> Security Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-06-17 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:53 --> Input Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:53 --> Total execution time: 0.1289
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Loader Class Initialized
INFO - 2018-06-17 20:26:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:53 --> Total execution time: 0.1202
INFO - 2018-06-17 20:26:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:53 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:53 --> Controller Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:53 --> URI Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 14:56:53 --> Router Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:56:53 --> Output Class Initialized
INFO - 2018-06-17 14:56:53 --> Security Class Initialized
DEBUG - 2018-06-17 14:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-17 20:26:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 14:56:53 --> Input Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Loader Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:53 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:53 --> Controller Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:53 --> Utf8 Class Initialized
INFO - 2018-06-17 14:56:53 --> URI Class Initialized
INFO - 2018-06-17 14:56:53 --> Router Class Initialized
INFO - 2018-06-17 14:56:53 --> Output Class Initialized
INFO - 2018-06-17 14:56:53 --> Security Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:53 --> Input Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
DEBUG - 2018-06-17 20:26:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:53 --> Total execution time: 0.2564
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:53 --> Total execution time: 0.1742
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Loader Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: users_helper
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:56:53 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:56:53 --> Utf8 Class Initialized
INFO - 2018-06-17 20:26:53 --> Database Driver Class Initialized
INFO - 2018-06-17 14:56:53 --> URI Class Initialized
DEBUG - 2018-06-17 20:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:56:53 --> Router Class Initialized
INFO - 2018-06-17 14:56:53 --> Output Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: form_helper
INFO - 2018-06-17 14:56:53 --> Security Class Initialized
INFO - 2018-06-17 20:26:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:53 --> Controller Class Initialized
DEBUG - 2018-06-17 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:56:53 --> Input Class Initialized
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:53 --> Total execution time: 0.1251
INFO - 2018-06-17 14:56:53 --> Language Class Initialized
INFO - 2018-06-17 14:56:53 --> Config Class Initialized
INFO - 2018-06-17 14:56:53 --> Loader Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: url_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:26:53 --> Helper loaded: users_helper
INFO - 2018-06-17 20:26:53 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:26:53 --> Helper loaded: form_helper
INFO - 2018-06-17 20:26:53 --> Form Validation Class Initialized
INFO - 2018-06-17 20:26:53 --> Controller Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:26:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:26:53 --> Model Class Initialized
INFO - 2018-06-17 20:26:53 --> Final output sent to browser
DEBUG - 2018-06-17 20:26:53 --> Total execution time: 0.1668
INFO - 2018-06-17 14:57:03 --> Config Class Initialized
INFO - 2018-06-17 14:57:03 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:03 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:03 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:03 --> URI Class Initialized
INFO - 2018-06-17 14:57:03 --> Router Class Initialized
INFO - 2018-06-17 14:57:03 --> Output Class Initialized
INFO - 2018-06-17 14:57:03 --> Security Class Initialized
DEBUG - 2018-06-17 14:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:03 --> Input Class Initialized
INFO - 2018-06-17 14:57:03 --> Language Class Initialized
INFO - 2018-06-17 14:57:03 --> Config Class Initialized
INFO - 2018-06-17 14:57:03 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:03 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:03 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:03 --> URI Class Initialized
INFO - 2018-06-17 14:57:03 --> Router Class Initialized
INFO - 2018-06-17 14:57:03 --> Language Class Initialized
INFO - 2018-06-17 14:57:03 --> Config Class Initialized
INFO - 2018-06-17 14:57:03 --> Loader Class Initialized
INFO - 2018-06-17 14:57:03 --> Output Class Initialized
INFO - 2018-06-17 20:27:03 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:03 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:03 --> Helper loaded: settings_helper
INFO - 2018-06-17 14:57:03 --> Security Class Initialized
INFO - 2018-06-17 20:27:03 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:03 --> Helper loaded: users_helper
DEBUG - 2018-06-17 14:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:03 --> Input Class Initialized
INFO - 2018-06-17 14:57:03 --> Language Class Initialized
INFO - 2018-06-17 20:27:03 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:57:03 --> Language Class Initialized
INFO - 2018-06-17 14:57:03 --> Config Class Initialized
INFO - 2018-06-17 14:57:03 --> Loader Class Initialized
INFO - 2018-06-17 20:27:03 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:03 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:03 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:03 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:03 --> Helper loaded: users_helper
INFO - 2018-06-17 20:27:03 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:03 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:03 --> Controller Class Initialized
INFO - 2018-06-17 20:27:03 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:03 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:03 --> Controller Class Initialized
INFO - 2018-06-17 20:27:03 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:27:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
DEBUG - 2018-06-17 20:27:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:03 --> Total execution time: 0.1491
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:03 --> Model Class Initialized
INFO - 2018-06-17 20:27:03 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:03 --> Total execution time: 0.2171
INFO - 2018-06-17 14:57:05 --> Config Class Initialized
INFO - 2018-06-17 14:57:05 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:05 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:05 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:05 --> URI Class Initialized
INFO - 2018-06-17 14:57:05 --> Router Class Initialized
INFO - 2018-06-17 14:57:05 --> Output Class Initialized
INFO - 2018-06-17 14:57:05 --> Security Class Initialized
DEBUG - 2018-06-17 14:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:05 --> Input Class Initialized
INFO - 2018-06-17 14:57:05 --> Language Class Initialized
INFO - 2018-06-17 14:57:05 --> Language Class Initialized
INFO - 2018-06-17 14:57:05 --> Config Class Initialized
INFO - 2018-06-17 14:57:05 --> Loader Class Initialized
INFO - 2018-06-17 20:27:05 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:05 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:05 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:05 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:05 --> Helper loaded: users_helper
INFO - 2018-06-17 20:27:05 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:27:05 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:05 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:05 --> Controller Class Initialized
INFO - 2018-06-17 14:57:05 --> Config Class Initialized
INFO - 2018-06-17 14:57:05 --> Hooks Class Initialized
INFO - 2018-06-17 20:27:05 --> Model Class Initialized
INFO - 2018-06-17 20:27:05 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:27:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 14:57:05 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:05 --> Utf8 Class Initialized
INFO - 2018-06-17 20:27:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:05 --> Model Class Initialized
INFO - 2018-06-17 20:27:05 --> Model Class Initialized
INFO - 2018-06-17 20:27:05 --> Model Class Initialized
INFO - 2018-06-17 20:27:05 --> Model Class Initialized
INFO - 2018-06-17 14:57:05 --> URI Class Initialized
INFO - 2018-06-17 20:27:05 --> Model Class Initialized
INFO - 2018-06-17 20:27:05 --> Model Class Initialized
INFO - 2018-06-17 20:27:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:05 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:05 --> Total execution time: 0.1392
INFO - 2018-06-17 14:57:06 --> Router Class Initialized
INFO - 2018-06-17 14:57:06 --> Output Class Initialized
INFO - 2018-06-17 14:57:06 --> Security Class Initialized
DEBUG - 2018-06-17 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:06 --> Input Class Initialized
INFO - 2018-06-17 14:57:06 --> Language Class Initialized
INFO - 2018-06-17 14:57:06 --> Language Class Initialized
INFO - 2018-06-17 14:57:06 --> Config Class Initialized
INFO - 2018-06-17 14:57:06 --> Loader Class Initialized
INFO - 2018-06-17 20:27:06 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:06 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:06 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:06 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:06 --> Helper loaded: users_helper
INFO - 2018-06-17 20:27:06 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:27:06 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:06 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:06 --> Controller Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:27:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:06 --> Total execution time: 0.2220
INFO - 2018-06-17 14:57:06 --> Config Class Initialized
INFO - 2018-06-17 14:57:06 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:06 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:06 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:06 --> URI Class Initialized
INFO - 2018-06-17 14:57:06 --> Router Class Initialized
INFO - 2018-06-17 14:57:06 --> Output Class Initialized
INFO - 2018-06-17 14:57:06 --> Security Class Initialized
DEBUG - 2018-06-17 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:06 --> Input Class Initialized
INFO - 2018-06-17 14:57:06 --> Language Class Initialized
INFO - 2018-06-17 14:57:06 --> Language Class Initialized
INFO - 2018-06-17 14:57:06 --> Config Class Initialized
INFO - 2018-06-17 14:57:06 --> Loader Class Initialized
INFO - 2018-06-17 20:27:06 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:06 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:06 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:06 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:06 --> Helper loaded: users_helper
INFO - 2018-06-17 20:27:06 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:27:06 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:06 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:06 --> Controller Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:27:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Model Class Initialized
INFO - 2018-06-17 20:27:06 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:06 --> Total execution time: 0.1196
INFO - 2018-06-17 14:57:24 --> Config Class Initialized
INFO - 2018-06-17 14:57:24 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:24 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:24 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:24 --> URI Class Initialized
INFO - 2018-06-17 14:57:24 --> Config Class Initialized
INFO - 2018-06-17 14:57:24 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:24 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:24 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:24 --> URI Class Initialized
INFO - 2018-06-17 14:57:24 --> Router Class Initialized
INFO - 2018-06-17 14:57:24 --> Router Class Initialized
INFO - 2018-06-17 14:57:24 --> Output Class Initialized
INFO - 2018-06-17 14:57:24 --> Output Class Initialized
INFO - 2018-06-17 14:57:24 --> Security Class Initialized
DEBUG - 2018-06-17 14:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:24 --> Input Class Initialized
INFO - 2018-06-17 14:57:24 --> Security Class Initialized
INFO - 2018-06-17 14:57:24 --> Language Class Initialized
INFO - 2018-06-17 14:57:24 --> Config Class Initialized
INFO - 2018-06-17 14:57:24 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:24 --> Input Class Initialized
INFO - 2018-06-17 14:57:24 --> Language Class Initialized
DEBUG - 2018-06-17 14:57:25 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:25 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:25 --> URI Class Initialized
INFO - 2018-06-17 14:57:25 --> Router Class Initialized
INFO - 2018-06-17 14:57:25 --> Output Class Initialized
INFO - 2018-06-17 14:57:25 --> Language Class Initialized
INFO - 2018-06-17 14:57:25 --> Config Class Initialized
INFO - 2018-06-17 14:57:25 --> Loader Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: permission_helper
INFO - 2018-06-17 14:57:25 --> Security Class Initialized
INFO - 2018-06-17 14:57:25 --> Language Class Initialized
INFO - 2018-06-17 14:57:25 --> Config Class Initialized
INFO - 2018-06-17 14:57:25 --> Loader Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: users_helper
DEBUG - 2018-06-17 14:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:25 --> Input Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: url_helper
INFO - 2018-06-17 14:57:25 --> Language Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: users_helper
INFO - 2018-06-17 20:27:25 --> Database Driver Class Initialized
INFO - 2018-06-17 14:57:25 --> Language Class Initialized
INFO - 2018-06-17 14:57:25 --> Config Class Initialized
INFO - 2018-06-17 14:57:25 --> Loader Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 20:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:27:25 --> Helper loaded: users_helper
INFO - 2018-06-17 20:27:25 --> Database Driver Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:25 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:25 --> Controller Class Initialized
INFO - 2018-06-17 20:27:25 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:27:25 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:25 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:25 --> Controller Class Initialized
DEBUG - 2018-06-17 20:27:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:25 --> Total execution time: 0.1956
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:27:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:25 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:25 --> Controller Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:27:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:25 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:25 --> Total execution time: 0.2747
INFO - 2018-06-17 20:27:25 --> Model Class Initialized
INFO - 2018-06-17 20:27:25 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:25 --> Total execution time: 0.2209
INFO - 2018-06-17 14:57:27 --> Config Class Initialized
INFO - 2018-06-17 14:57:27 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:27 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:27 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:27 --> URI Class Initialized
INFO - 2018-06-17 14:57:27 --> Router Class Initialized
INFO - 2018-06-17 14:57:27 --> Output Class Initialized
INFO - 2018-06-17 14:57:27 --> Security Class Initialized
DEBUG - 2018-06-17 14:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:27 --> Input Class Initialized
INFO - 2018-06-17 14:57:27 --> Language Class Initialized
INFO - 2018-06-17 14:57:27 --> Config Class Initialized
INFO - 2018-06-17 14:57:27 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:27 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:27 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:27 --> URI Class Initialized
INFO - 2018-06-17 14:57:27 --> Language Class Initialized
INFO - 2018-06-17 14:57:27 --> Config Class Initialized
INFO - 2018-06-17 14:57:27 --> Loader Class Initialized
INFO - 2018-06-17 20:27:27 --> Helper loaded: url_helper
INFO - 2018-06-17 14:57:27 --> Router Class Initialized
INFO - 2018-06-17 20:27:27 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:27 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:27 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:27 --> Helper loaded: users_helper
INFO - 2018-06-17 14:57:27 --> Output Class Initialized
INFO - 2018-06-17 14:57:27 --> Security Class Initialized
DEBUG - 2018-06-17 14:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:27 --> Input Class Initialized
INFO - 2018-06-17 14:57:27 --> Language Class Initialized
INFO - 2018-06-17 20:27:27 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 14:57:27 --> Language Class Initialized
INFO - 2018-06-17 14:57:27 --> Config Class Initialized
INFO - 2018-06-17 14:57:27 --> Loader Class Initialized
INFO - 2018-06-17 20:27:27 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:27 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:27 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:27 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:27 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:27 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:27 --> Controller Class Initialized
INFO - 2018-06-17 20:27:27 --> Helper loaded: users_helper
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:27:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:27 --> Database Driver Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
DEBUG - 2018-06-17 20:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:27 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:27 --> Controller Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:27:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Final output sent to browser
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
DEBUG - 2018-06-17 20:27:27 --> Total execution time: 0.1480
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:27:27 --> Model Class Initialized
INFO - 2018-06-17 20:27:27 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:27 --> Total execution time: 0.1410
INFO - 2018-06-17 14:57:28 --> Config Class Initialized
INFO - 2018-06-17 14:57:28 --> Hooks Class Initialized
DEBUG - 2018-06-17 14:57:28 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:28 --> Utf8 Class Initialized
INFO - 2018-06-17 14:57:28 --> URI Class Initialized
INFO - 2018-06-17 14:57:28 --> Router Class Initialized
INFO - 2018-06-17 14:57:28 --> Output Class Initialized
INFO - 2018-06-17 14:57:28 --> Security Class Initialized
DEBUG - 2018-06-17 14:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:28 --> Input Class Initialized
INFO - 2018-06-17 14:57:28 --> Language Class Initialized
INFO - 2018-06-17 14:57:28 --> Language Class Initialized
INFO - 2018-06-17 14:57:28 --> Config Class Initialized
INFO - 2018-06-17 14:57:28 --> Loader Class Initialized
INFO - 2018-06-17 20:27:28 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:28 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:28 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:28 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:28 --> Helper loaded: users_helper
INFO - 2018-06-17 20:27:28 --> Database Driver Class Initialized
INFO - 2018-06-17 14:57:28 --> Config Class Initialized
INFO - 2018-06-17 14:57:28 --> Hooks Class Initialized
DEBUG - 2018-06-17 20:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 14:57:29 --> UTF-8 Support Enabled
INFO - 2018-06-17 14:57:29 --> Utf8 Class Initialized
INFO - 2018-06-17 20:27:29 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:29 --> Form Validation Class Initialized
INFO - 2018-06-17 14:57:29 --> URI Class Initialized
INFO - 2018-06-17 20:27:29 --> Controller Class Initialized
INFO - 2018-06-17 14:57:29 --> Router Class Initialized
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
INFO - 2018-06-17 20:27:29 --> Helper loaded: inflector_helper
INFO - 2018-06-17 14:57:29 --> Output Class Initialized
DEBUG - 2018-06-17 20:27:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 14:57:29 --> Security Class Initialized
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
DEBUG - 2018-06-17 14:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 14:57:29 --> Input Class Initialized
INFO - 2018-06-17 14:57:29 --> Language Class Initialized
INFO - 2018-06-17 20:27:29 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:29 --> Total execution time: 0.1081
INFO - 2018-06-17 14:57:29 --> Language Class Initialized
INFO - 2018-06-17 14:57:29 --> Config Class Initialized
INFO - 2018-06-17 14:57:29 --> Loader Class Initialized
INFO - 2018-06-17 20:27:29 --> Helper loaded: url_helper
INFO - 2018-06-17 20:27:29 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:27:29 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:27:29 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:27:29 --> Helper loaded: users_helper
INFO - 2018-06-17 20:27:29 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:27:29 --> Helper loaded: form_helper
INFO - 2018-06-17 20:27:29 --> Form Validation Class Initialized
INFO - 2018-06-17 20:27:29 --> Controller Class Initialized
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
INFO - 2018-06-17 20:27:29 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:27:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:27:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
INFO - 2018-06-17 20:27:29 --> Model Class Initialized
INFO - 2018-06-17 20:27:29 --> Final output sent to browser
DEBUG - 2018-06-17 20:27:29 --> Total execution time: 0.1517
INFO - 2018-06-17 15:11:09 --> Config Class Initialized
INFO - 2018-06-17 15:11:09 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:09 --> Config Class Initialized
INFO - 2018-06-17 15:11:09 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:09 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:09 --> Utf8 Class Initialized
DEBUG - 2018-06-17 15:11:09 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:09 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:09 --> URI Class Initialized
INFO - 2018-06-17 15:11:09 --> URI Class Initialized
INFO - 2018-06-17 15:11:09 --> Router Class Initialized
INFO - 2018-06-17 15:11:09 --> Output Class Initialized
INFO - 2018-06-17 15:11:09 --> Router Class Initialized
INFO - 2018-06-17 15:11:09 --> Security Class Initialized
INFO - 2018-06-17 15:11:09 --> Output Class Initialized
DEBUG - 2018-06-17 15:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:09 --> Input Class Initialized
INFO - 2018-06-17 15:11:09 --> Language Class Initialized
INFO - 2018-06-17 15:11:09 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:09 --> Input Class Initialized
INFO - 2018-06-17 15:11:09 --> Language Class Initialized
INFO - 2018-06-17 15:11:09 --> Language Class Initialized
INFO - 2018-06-17 15:11:09 --> Config Class Initialized
INFO - 2018-06-17 15:11:09 --> Loader Class Initialized
INFO - 2018-06-17 20:41:09 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: settings_helper
INFO - 2018-06-17 15:11:09 --> Language Class Initialized
INFO - 2018-06-17 15:11:09 --> Config Class Initialized
INFO - 2018-06-17 15:11:09 --> Loader Class Initialized
INFO - 2018-06-17 20:41:09 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:09 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:09 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:09 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:09 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:09 --> Controller Class Initialized
DEBUG - 2018-06-17 20:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:09 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:09 --> Controller Class Initialized
DEBUG - 2018-06-17 20:41:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:09 --> Total execution time: 0.1114
INFO - 2018-06-17 20:41:09 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:09 --> Model Class Initialized
INFO - 2018-06-17 20:41:09 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:09 --> Total execution time: 0.1247
INFO - 2018-06-17 15:11:09 --> Config Class Initialized
INFO - 2018-06-17 15:11:09 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:09 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:09 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:09 --> URI Class Initialized
INFO - 2018-06-17 15:11:09 --> Router Class Initialized
INFO - 2018-06-17 15:11:09 --> Output Class Initialized
INFO - 2018-06-17 15:11:09 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:09 --> Input Class Initialized
INFO - 2018-06-17 15:11:09 --> Language Class Initialized
INFO - 2018-06-17 15:11:09 --> Language Class Initialized
INFO - 2018-06-17 15:11:09 --> Config Class Initialized
INFO - 2018-06-17 15:11:09 --> Loader Class Initialized
INFO - 2018-06-17 20:41:09 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:09 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:09 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:10 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:10 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:10 --> Controller Class Initialized
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:10 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:10 --> Utf8 Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: inflector_helper
INFO - 2018-06-17 15:11:10 --> URI Class Initialized
DEBUG - 2018-06-17 20:41:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 15:11:10 --> Router Class Initialized
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Hooks Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 15:11:10 --> Output Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 15:11:10 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:10 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:10 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:10 --> URI Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
DEBUG - 2018-06-17 15:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:10 --> Input Class Initialized
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 20:41:10 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:10 --> Total execution time: 0.1662
INFO - 2018-06-17 15:11:10 --> Router Class Initialized
INFO - 2018-06-17 15:11:10 --> Output Class Initialized
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Loader Class Initialized
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Hooks Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: url_helper
INFO - 2018-06-17 15:11:10 --> Security Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 15:11:10 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:10 --> Utf8 Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: users_helper
INFO - 2018-06-17 15:11:10 --> URI Class Initialized
DEBUG - 2018-06-17 15:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:10 --> Input Class Initialized
INFO - 2018-06-17 15:11:10 --> Router Class Initialized
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:10 --> Output Class Initialized
INFO - 2018-06-17 15:11:10 --> Security Class Initialized
INFO - 2018-06-17 20:41:10 --> Database Driver Class Initialized
DEBUG - 2018-06-17 15:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:10 --> Input Class Initialized
DEBUG - 2018-06-17 15:11:10 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:10 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 15:11:10 --> URI Class Initialized
DEBUG - 2018-06-17 20:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:10 --> Router Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:10 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:10 --> Controller Class Initialized
DEBUG - 2018-06-17 15:11:10 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:10 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:10 --> Output Class Initialized
INFO - 2018-06-17 15:11:10 --> URI Class Initialized
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Loader Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: url_helper
INFO - 2018-06-17 15:11:10 --> Security Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: settings_helper
DEBUG - 2018-06-17 20:41:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:10 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:10 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 15:11:10 --> Router Class Initialized
DEBUG - 2018-06-17 15:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:10 --> Input Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 20:41:10 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:10 --> Total execution time: 0.1121
INFO - 2018-06-17 15:11:10 --> Output Class Initialized
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Loader Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: url_helper
INFO - 2018-06-17 15:11:10 --> Security Class Initialized
INFO - 2018-06-17 20:41:10 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: permission_helper
DEBUG - 2018-06-17 15:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:10 --> Input Class Initialized
DEBUG - 2018-06-17 20:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 20:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:10 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:10 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:10 --> Controller Class Initialized
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Loader Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:41:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 15:11:10 --> Language Class Initialized
INFO - 2018-06-17 15:11:10 --> Config Class Initialized
INFO - 2018-06-17 15:11:10 --> Loader Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:10 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:10 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:10 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:10 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:10 --> Controller Class Initialized
DEBUG - 2018-06-17 20:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:10 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:10 --> Total execution time: 0.1602
INFO - 2018-06-17 20:41:10 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:10 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:10 --> Controller Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:10 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:10 --> Controller Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:10 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
DEBUG - 2018-06-17 20:41:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
DEBUG - 2018-06-17 20:41:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:10 --> Total execution time: 0.1626
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:10 --> Total execution time: 0.2215
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:10 --> Model Class Initialized
INFO - 2018-06-17 20:41:10 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:10 --> Total execution time: 0.2191
INFO - 2018-06-17 15:11:12 --> Config Class Initialized
INFO - 2018-06-17 15:11:12 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:12 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:12 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:12 --> URI Class Initialized
INFO - 2018-06-17 15:11:12 --> Router Class Initialized
INFO - 2018-06-17 15:11:12 --> Output Class Initialized
INFO - 2018-06-17 15:11:12 --> Config Class Initialized
INFO - 2018-06-17 15:11:12 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:12 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:12 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:12 --> Utf8 Class Initialized
DEBUG - 2018-06-17 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:12 --> Input Class Initialized
INFO - 2018-06-17 15:11:12 --> URI Class Initialized
INFO - 2018-06-17 15:11:12 --> Language Class Initialized
INFO - 2018-06-17 15:11:12 --> Router Class Initialized
INFO - 2018-06-17 15:11:12 --> Output Class Initialized
INFO - 2018-06-17 15:11:12 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:12 --> Input Class Initialized
INFO - 2018-06-17 15:11:12 --> Language Class Initialized
INFO - 2018-06-17 15:11:12 --> Config Class Initialized
INFO - 2018-06-17 15:11:12 --> Loader Class Initialized
INFO - 2018-06-17 15:11:12 --> Language Class Initialized
INFO - 2018-06-17 20:41:12 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:12 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:12 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:12 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:12 --> Helper loaded: users_helper
INFO - 2018-06-17 15:11:12 --> Language Class Initialized
INFO - 2018-06-17 15:11:12 --> Config Class Initialized
INFO - 2018-06-17 15:11:12 --> Loader Class Initialized
INFO - 2018-06-17 20:41:12 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:12 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:12 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:12 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:12 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:12 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:12 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:12 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:12 --> Controller Class Initialized
INFO - 2018-06-17 20:41:12 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:41:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:12 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:12 --> Controller Class Initialized
INFO - 2018-06-17 20:41:12 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:12 --> Total execution time: 0.1011
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Model Class Initialized
INFO - 2018-06-17 20:41:12 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:12 --> Total execution time: 0.1152
INFO - 2018-06-17 15:11:14 --> Config Class Initialized
INFO - 2018-06-17 15:11:14 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:14 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:14 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:14 --> URI Class Initialized
INFO - 2018-06-17 15:11:14 --> Config Class Initialized
INFO - 2018-06-17 15:11:14 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:14 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:14 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:14 --> Router Class Initialized
INFO - 2018-06-17 15:11:14 --> URI Class Initialized
INFO - 2018-06-17 15:11:14 --> Output Class Initialized
INFO - 2018-06-17 15:11:14 --> Security Class Initialized
INFO - 2018-06-17 15:11:14 --> Router Class Initialized
DEBUG - 2018-06-17 15:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:14 --> Input Class Initialized
INFO - 2018-06-17 15:11:14 --> Output Class Initialized
INFO - 2018-06-17 15:11:14 --> Language Class Initialized
INFO - 2018-06-17 15:11:14 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:14 --> Input Class Initialized
INFO - 2018-06-17 15:11:14 --> Language Class Initialized
INFO - 2018-06-17 15:11:14 --> Language Class Initialized
INFO - 2018-06-17 15:11:14 --> Config Class Initialized
INFO - 2018-06-17 15:11:14 --> Loader Class Initialized
INFO - 2018-06-17 20:41:14 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:14 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:14 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:14 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:14 --> Helper loaded: users_helper
INFO - 2018-06-17 15:11:14 --> Language Class Initialized
INFO - 2018-06-17 15:11:14 --> Config Class Initialized
INFO - 2018-06-17 15:11:14 --> Loader Class Initialized
INFO - 2018-06-17 20:41:14 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:14 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:14 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:14 --> Helper loaded: settings_helper
DEBUG - 2018-06-17 20:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:14 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:14 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:14 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:14 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:14 --> Controller Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:14 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:14 --> Total execution time: 0.1007
DEBUG - 2018-06-17 20:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:14 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:14 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:14 --> Controller Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
INFO - 2018-06-17 20:41:14 --> Model Class Initialized
ERROR - 2018-06-17 20:41:14 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-17 20:41:14 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:14 --> Total execution time: 0.1648
INFO - 2018-06-17 15:11:16 --> Config Class Initialized
INFO - 2018-06-17 15:11:16 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:16 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:16 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:16 --> URI Class Initialized
INFO - 2018-06-17 15:11:16 --> Router Class Initialized
INFO - 2018-06-17 15:11:16 --> Output Class Initialized
INFO - 2018-06-17 15:11:16 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:16 --> Input Class Initialized
INFO - 2018-06-17 15:11:16 --> Language Class Initialized
INFO - 2018-06-17 15:11:16 --> Language Class Initialized
INFO - 2018-06-17 15:11:16 --> Config Class Initialized
INFO - 2018-06-17 15:11:16 --> Loader Class Initialized
INFO - 2018-06-17 20:41:16 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:16 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:16 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:16 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:16 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:16 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:16 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:16 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:16 --> Controller Class Initialized
INFO - 2018-06-17 20:41:16 --> Model Class Initialized
INFO - 2018-06-17 20:41:16 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:16 --> Model Class Initialized
INFO - 2018-06-17 20:41:16 --> Model Class Initialized
INFO - 2018-06-17 20:41:16 --> Model Class Initialized
INFO - 2018-06-17 20:41:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:16 --> Model Class Initialized
INFO - 2018-06-17 20:41:16 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:16 --> Total execution time: 0.1091
INFO - 2018-06-17 15:11:22 --> Config Class Initialized
INFO - 2018-06-17 15:11:22 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:22 --> Config Class Initialized
INFO - 2018-06-17 15:11:22 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:22 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:22 --> Utf8 Class Initialized
DEBUG - 2018-06-17 15:11:22 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:22 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:22 --> URI Class Initialized
INFO - 2018-06-17 15:11:22 --> URI Class Initialized
INFO - 2018-06-17 15:11:22 --> Router Class Initialized
INFO - 2018-06-17 15:11:22 --> Router Class Initialized
INFO - 2018-06-17 15:11:22 --> Output Class Initialized
INFO - 2018-06-17 15:11:22 --> Output Class Initialized
INFO - 2018-06-17 15:11:22 --> Security Class Initialized
INFO - 2018-06-17 15:11:22 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:22 --> Input Class Initialized
INFO - 2018-06-17 15:11:22 --> Language Class Initialized
DEBUG - 2018-06-17 15:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:22 --> Input Class Initialized
INFO - 2018-06-17 15:11:22 --> Language Class Initialized
INFO - 2018-06-17 15:11:22 --> Language Class Initialized
INFO - 2018-06-17 15:11:22 --> Config Class Initialized
INFO - 2018-06-17 15:11:22 --> Language Class Initialized
INFO - 2018-06-17 15:11:22 --> Loader Class Initialized
INFO - 2018-06-17 15:11:22 --> Config Class Initialized
INFO - 2018-06-17 15:11:22 --> Loader Class Initialized
INFO - 2018-06-17 20:41:22 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:22 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:22 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:22 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:22 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:22 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:22 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:22 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:22 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:22 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:22 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:22 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:22 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:22 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:22 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:22 --> Controller Class Initialized
INFO - 2018-06-17 20:41:22 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:22 --> Controller Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 20:41:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Model Class Initialized
INFO - 2018-06-17 20:41:22 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:22 --> Total execution time: 0.1063
ERROR - 2018-06-17 20:41:22 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-17 20:41:22 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:22 --> Total execution time: 0.1174
INFO - 2018-06-17 15:11:24 --> Config Class Initialized
INFO - 2018-06-17 15:11:24 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:24 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:24 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:24 --> URI Class Initialized
INFO - 2018-06-17 15:11:24 --> Router Class Initialized
INFO - 2018-06-17 15:11:24 --> Output Class Initialized
INFO - 2018-06-17 15:11:24 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:24 --> Input Class Initialized
INFO - 2018-06-17 15:11:24 --> Language Class Initialized
INFO - 2018-06-17 15:11:24 --> Language Class Initialized
INFO - 2018-06-17 15:11:24 --> Config Class Initialized
INFO - 2018-06-17 15:11:24 --> Loader Class Initialized
INFO - 2018-06-17 20:41:24 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:24 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:24 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:24 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:24 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:24 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:24 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:24 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:24 --> Controller Class Initialized
INFO - 2018-06-17 20:41:24 --> Model Class Initialized
INFO - 2018-06-17 20:41:24 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:24 --> Model Class Initialized
INFO - 2018-06-17 20:41:24 --> Model Class Initialized
INFO - 2018-06-17 20:41:24 --> Model Class Initialized
INFO - 2018-06-17 20:41:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:24 --> Model Class Initialized
INFO - 2018-06-17 20:41:24 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:24 --> Total execution time: 0.1018
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:38 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:38 --> URI Class Initialized
INFO - 2018-06-17 15:11:38 --> Router Class Initialized
INFO - 2018-06-17 15:11:38 --> Output Class Initialized
INFO - 2018-06-17 15:11:38 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:38 --> Input Class Initialized
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Loader Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:38 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:38 --> Helper loaded: settings_helper
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Hooks Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:38 --> Helper loaded: users_helper
DEBUG - 2018-06-17 15:11:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:38 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:38 --> URI Class Initialized
INFO - 2018-06-17 15:11:38 --> Router Class Initialized
INFO - 2018-06-17 15:11:38 --> Output Class Initialized
INFO - 2018-06-17 15:11:38 --> Security Class Initialized
INFO - 2018-06-17 20:41:38 --> Database Driver Class Initialized
DEBUG - 2018-06-17 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:38 --> Input Class Initialized
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
DEBUG - 2018-06-17 20:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:38 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:38 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:38 --> Controller Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: inflector_helper
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Loader Class Initialized
DEBUG - 2018-06-17 20:41:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:38 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:38 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:38 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:38 --> Total execution time: 0.1249
INFO - 2018-06-17 20:41:38 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:38 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:38 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:38 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:38 --> Controller Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:38 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:38 --> Total execution time: 0.1504
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:38 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:38 --> URI Class Initialized
INFO - 2018-06-17 15:11:38 --> Router Class Initialized
INFO - 2018-06-17 15:11:38 --> Output Class Initialized
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:38 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:38 --> Input Class Initialized
DEBUG - 2018-06-17 15:11:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:38 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 15:11:38 --> URI Class Initialized
INFO - 2018-06-17 15:11:38 --> Router Class Initialized
INFO - 2018-06-17 15:11:38 --> Output Class Initialized
INFO - 2018-06-17 15:11:38 --> Security Class Initialized
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Loader Class Initialized
DEBUG - 2018-06-17 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:38 --> Input Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: url_helper
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:38 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:38 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:38 --> Helper loaded: users_helper
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:38 --> UTF-8 Support Enabled
DEBUG - 2018-06-17 15:11:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:38 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:38 --> Utf8 Class Initialized
INFO - 2018-06-17 20:41:38 --> Database Driver Class Initialized
INFO - 2018-06-17 15:11:38 --> URI Class Initialized
INFO - 2018-06-17 15:11:38 --> URI Class Initialized
DEBUG - 2018-06-17 15:11:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:38 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Hooks Class Initialized
DEBUG - 2018-06-17 20:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 15:11:38 --> URI Class Initialized
INFO - 2018-06-17 20:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 15:11:38 --> Config Class Initialized
INFO - 2018-06-17 15:11:38 --> Loader Class Initialized
DEBUG - 2018-06-17 15:11:38 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:38 --> Router Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: url_helper
INFO - 2018-06-17 15:11:38 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:38 --> Router Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:38 --> Helper loaded: settings_helper
INFO - 2018-06-17 15:11:38 --> URI Class Initialized
INFO - 2018-06-17 15:11:38 --> Router Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:38 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:38 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:38 --> Controller Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: users_helper
INFO - 2018-06-17 15:11:38 --> Output Class Initialized
INFO - 2018-06-17 15:11:38 --> Output Class Initialized
INFO - 2018-06-17 15:11:38 --> Router Class Initialized
INFO - 2018-06-17 15:11:38 --> Security Class Initialized
INFO - 2018-06-17 15:11:38 --> Output Class Initialized
INFO - 2018-06-17 15:11:38 --> Security Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 15:11:38 --> Output Class Initialized
INFO - 2018-06-17 20:41:38 --> Helper loaded: inflector_helper
INFO - 2018-06-17 15:11:38 --> Security Class Initialized
DEBUG - 2018-06-17 20:41:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 15:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-06-17 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:38 --> Input Class Initialized
INFO - 2018-06-17 15:11:38 --> Security Class Initialized
INFO - 2018-06-17 15:11:38 --> Input Class Initialized
INFO - 2018-06-17 20:41:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
DEBUG - 2018-06-17 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:38 --> Input Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
DEBUG - 2018-06-17 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:38 --> Input Class Initialized
INFO - 2018-06-17 20:41:38 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 15:11:38 --> Language Class Initialized
INFO - 2018-06-17 20:41:38 --> Model Class Initialized
INFO - 2018-06-17 20:41:38 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:38 --> Total execution time: 0.1097
DEBUG - 2018-06-17 20:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:39 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:39 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:39 --> Controller Class Initialized
INFO - 2018-06-17 15:11:39 --> Language Class Initialized
INFO - 2018-06-17 15:11:39 --> Config Class Initialized
INFO - 2018-06-17 15:11:39 --> Loader Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: url_helper
DEBUG - 2018-06-17 20:41:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:39 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:39 --> Helper loaded: permission_helper
INFO - 2018-06-17 15:11:39 --> Language Class Initialized
INFO - 2018-06-17 15:11:39 --> Config Class Initialized
INFO - 2018-06-17 15:11:39 --> Loader Class Initialized
INFO - 2018-06-17 15:11:39 --> Language Class Initialized
INFO - 2018-06-17 15:11:39 --> Config Class Initialized
INFO - 2018-06-17 15:11:39 --> Loader Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Helper loaded: users_helper
INFO - 2018-06-17 15:11:39 --> Language Class Initialized
INFO - 2018-06-17 15:11:39 --> Config Class Initialized
INFO - 2018-06-17 15:11:39 --> Loader Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:39 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:39 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:39 --> Total execution time: 0.1458
INFO - 2018-06-17 20:41:39 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:39 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:39 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:39 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:39 --> Controller Class Initialized
INFO - 2018-06-17 20:41:39 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:39 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:39 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
DEBUG - 2018-06-17 20:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:39 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:39 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:39 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:39 --> Controller Class Initialized
DEBUG - 2018-06-17 20:41:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
DEBUG - 2018-06-17 20:41:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:39 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:39 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:39 --> Controller Class Initialized
INFO - 2018-06-17 20:41:39 --> Controller Class Initialized
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:39 --> Total execution time: 0.1821
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:39 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-17 20:41:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:39 --> Total execution time: 0.2272
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:39 --> Total execution time: 0.2101
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:39 --> Model Class Initialized
INFO - 2018-06-17 20:41:39 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:39 --> Total execution time: 0.2695
INFO - 2018-06-17 15:11:40 --> Config Class Initialized
INFO - 2018-06-17 15:11:40 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:40 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:40 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:40 --> URI Class Initialized
INFO - 2018-06-17 15:11:40 --> Router Class Initialized
INFO - 2018-06-17 15:11:40 --> Output Class Initialized
INFO - 2018-06-17 15:11:40 --> Config Class Initialized
INFO - 2018-06-17 15:11:40 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:40 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:40 --> Input Class Initialized
DEBUG - 2018-06-17 15:11:40 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:40 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:40 --> Language Class Initialized
INFO - 2018-06-17 15:11:40 --> URI Class Initialized
INFO - 2018-06-17 15:11:40 --> Router Class Initialized
INFO - 2018-06-17 15:11:40 --> Output Class Initialized
INFO - 2018-06-17 15:11:40 --> Security Class Initialized
INFO - 2018-06-17 15:11:40 --> Language Class Initialized
INFO - 2018-06-17 15:11:40 --> Config Class Initialized
INFO - 2018-06-17 15:11:40 --> Loader Class Initialized
DEBUG - 2018-06-17 15:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:40 --> Input Class Initialized
INFO - 2018-06-17 20:41:40 --> Helper loaded: url_helper
INFO - 2018-06-17 15:11:40 --> Language Class Initialized
INFO - 2018-06-17 20:41:40 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:40 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:40 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:40 --> Helper loaded: users_helper
INFO - 2018-06-17 15:11:40 --> Language Class Initialized
INFO - 2018-06-17 15:11:40 --> Config Class Initialized
INFO - 2018-06-17 15:11:40 --> Loader Class Initialized
INFO - 2018-06-17 20:41:40 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:40 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:40 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:40 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:40 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:40 --> Helper loaded: users_helper
DEBUG - 2018-06-17 20:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:40 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:40 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:40 --> Controller Class Initialized
INFO - 2018-06-17 20:41:40 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:41:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:40 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:40 --> Controller Class Initialized
INFO - 2018-06-17 20:41:40 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:40 --> Total execution time: 0.1070
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Model Class Initialized
INFO - 2018-06-17 20:41:40 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:40 --> Total execution time: 0.1170
INFO - 2018-06-17 15:11:41 --> Config Class Initialized
INFO - 2018-06-17 15:11:41 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:41 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:41 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:41 --> URI Class Initialized
INFO - 2018-06-17 15:11:41 --> Config Class Initialized
INFO - 2018-06-17 15:11:41 --> Hooks Class Initialized
INFO - 2018-06-17 15:11:41 --> Router Class Initialized
DEBUG - 2018-06-17 15:11:41 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:41 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:41 --> URI Class Initialized
INFO - 2018-06-17 15:11:41 --> Output Class Initialized
INFO - 2018-06-17 15:11:41 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:41 --> Input Class Initialized
INFO - 2018-06-17 15:11:41 --> Router Class Initialized
INFO - 2018-06-17 15:11:41 --> Language Class Initialized
INFO - 2018-06-17 15:11:41 --> Output Class Initialized
INFO - 2018-06-17 15:11:41 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:41 --> Input Class Initialized
INFO - 2018-06-17 15:11:41 --> Language Class Initialized
INFO - 2018-06-17 15:11:41 --> Language Class Initialized
INFO - 2018-06-17 15:11:41 --> Config Class Initialized
INFO - 2018-06-17 15:11:41 --> Loader Class Initialized
INFO - 2018-06-17 20:41:41 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:41 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:41 --> Helper loaded: settings_helper
INFO - 2018-06-17 15:11:41 --> Language Class Initialized
INFO - 2018-06-17 15:11:41 --> Config Class Initialized
INFO - 2018-06-17 15:11:41 --> Loader Class Initialized
INFO - 2018-06-17 20:41:41 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:41 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:41 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:41 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:41 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:41 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:41 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:41 --> Database Driver Class Initialized
INFO - 2018-06-17 20:41:41 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-06-17 20:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:41 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:41 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:41 --> Controller Class Initialized
INFO - 2018-06-17 20:41:41 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:41 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:41 --> Controller Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Helper loaded: inflector_helper
INFO - 2018-06-17 20:41:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
DEBUG - 2018-06-17 20:41:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:41 --> Model Class Initialized
INFO - 2018-06-17 20:41:41 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:41 --> Total execution time: 0.1015
ERROR - 2018-06-17 20:41:41 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 796
INFO - 2018-06-17 20:41:41 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:41 --> Total execution time: 0.1137
INFO - 2018-06-17 15:11:43 --> Config Class Initialized
INFO - 2018-06-17 15:11:43 --> Hooks Class Initialized
DEBUG - 2018-06-17 15:11:43 --> UTF-8 Support Enabled
INFO - 2018-06-17 15:11:43 --> Utf8 Class Initialized
INFO - 2018-06-17 15:11:43 --> URI Class Initialized
INFO - 2018-06-17 15:11:43 --> Router Class Initialized
INFO - 2018-06-17 15:11:43 --> Output Class Initialized
INFO - 2018-06-17 15:11:43 --> Security Class Initialized
DEBUG - 2018-06-17 15:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 15:11:43 --> Input Class Initialized
INFO - 2018-06-17 15:11:43 --> Language Class Initialized
INFO - 2018-06-17 15:11:43 --> Language Class Initialized
INFO - 2018-06-17 15:11:43 --> Config Class Initialized
INFO - 2018-06-17 15:11:43 --> Loader Class Initialized
INFO - 2018-06-17 20:41:43 --> Helper loaded: url_helper
INFO - 2018-06-17 20:41:43 --> Helper loaded: notification_helper
INFO - 2018-06-17 20:41:43 --> Helper loaded: settings_helper
INFO - 2018-06-17 20:41:43 --> Helper loaded: permission_helper
INFO - 2018-06-17 20:41:43 --> Helper loaded: users_helper
INFO - 2018-06-17 20:41:43 --> Database Driver Class Initialized
DEBUG - 2018-06-17 20:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-17 20:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-17 20:41:43 --> Helper loaded: form_helper
INFO - 2018-06-17 20:41:43 --> Form Validation Class Initialized
INFO - 2018-06-17 20:41:43 --> Controller Class Initialized
INFO - 2018-06-17 20:41:43 --> Model Class Initialized
INFO - 2018-06-17 20:41:43 --> Helper loaded: inflector_helper
DEBUG - 2018-06-17 20:41:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-17 20:41:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-17 20:41:43 --> Model Class Initialized
INFO - 2018-06-17 20:41:43 --> Model Class Initialized
INFO - 2018-06-17 20:41:43 --> Model Class Initialized
INFO - 2018-06-17 20:41:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-17 20:41:43 --> Model Class Initialized
INFO - 2018-06-17 20:41:43 --> Final output sent to browser
DEBUG - 2018-06-17 20:41:43 --> Total execution time: 0.1120
INFO - 2018-06-17 18:30:02 --> Config Class Initialized
INFO - 2018-06-17 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-17 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-17 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-17 18:30:02 --> URI Class Initialized
INFO - 2018-06-17 18:30:02 --> Router Class Initialized
INFO - 2018-06-17 18:30:02 --> Output Class Initialized
INFO - 2018-06-17 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-17 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 18:30:02 --> Input Class Initialized
INFO - 2018-06-17 18:30:02 --> Language Class Initialized
INFO - 2018-06-17 18:30:02 --> Language Class Initialized
INFO - 2018-06-17 18:30:02 --> Config Class Initialized
INFO - 2018-06-17 18:30:02 --> Loader Class Initialized
INFO - 2018-06-17 18:30:02 --> Config Class Initialized
INFO - 2018-06-17 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-17 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-17 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-17 18:30:02 --> URI Class Initialized
INFO - 2018-06-17 18:30:02 --> Router Class Initialized
INFO - 2018-06-17 18:30:02 --> Output Class Initialized
INFO - 2018-06-17 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-17 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-17 18:30:02 --> Input Class Initialized
INFO - 2018-06-17 18:30:02 --> Language Class Initialized
INFO - 2018-06-17 18:30:02 --> Language Class Initialized
INFO - 2018-06-17 18:30:02 --> Config Class Initialized
INFO - 2018-06-17 18:30:02 --> Loader Class Initialized
