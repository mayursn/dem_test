<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-10 00:00:02 --> Helper loaded: url_helper
INFO - 2018-06-10 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-06-10 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-06-10 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-06-10 00:00:02 --> Helper loaded: users_helper
INFO - 2018-06-10 00:00:02 --> Database Driver Class Initialized
DEBUG - 2018-06-10 00:00:02 --> Session: Initialization under CLI aborted.
INFO - 2018-06-10 00:00:02 --> Helper loaded: form_helper
INFO - 2018-06-10 00:00:02 --> Form Validation Class Initialized
INFO - 2018-06-10 00:00:02 --> Controller Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Helper loaded: inflector_helper
DEBUG - 2018-06-10 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-10 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Final output sent to browser
DEBUG - 2018-06-10 00:00:02 --> Total execution time: 0.1358
INFO - 2018-06-10 00:00:02 --> Helper loaded: url_helper
INFO - 2018-06-10 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-06-10 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-06-10 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-06-10 00:00:02 --> Helper loaded: users_helper
INFO - 2018-06-10 00:00:02 --> Database Driver Class Initialized
DEBUG - 2018-06-10 00:00:02 --> Session: Initialization under CLI aborted.
INFO - 2018-06-10 00:00:02 --> Helper loaded: form_helper
INFO - 2018-06-10 00:00:02 --> Form Validation Class Initialized
INFO - 2018-06-10 00:00:02 --> Controller Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Helper loaded: inflector_helper
DEBUG - 2018-06-10 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-10 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-10 00:00:02 --> Model Class Initialized
INFO - 2018-06-10 00:00:02 --> Final output sent to browser
DEBUG - 2018-06-10 00:00:02 --> Total execution time: 0.0777
INFO - 2018-06-10 01:02:18 --> Config Class Initialized
INFO - 2018-06-10 01:02:18 --> Hooks Class Initialized
DEBUG - 2018-06-10 01:02:18 --> UTF-8 Support Enabled
INFO - 2018-06-10 01:02:18 --> Utf8 Class Initialized
INFO - 2018-06-10 01:02:18 --> URI Class Initialized
DEBUG - 2018-06-10 01:02:18 --> No URI present. Default controller set.
INFO - 2018-06-10 01:02:18 --> Router Class Initialized
INFO - 2018-06-10 01:02:18 --> Output Class Initialized
INFO - 2018-06-10 01:02:18 --> Security Class Initialized
DEBUG - 2018-06-10 01:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-10 01:02:18 --> Input Class Initialized
INFO - 2018-06-10 01:02:18 --> Language Class Initialized
INFO - 2018-06-10 01:02:18 --> Language Class Initialized
INFO - 2018-06-10 01:02:18 --> Config Class Initialized
INFO - 2018-06-10 01:02:18 --> Loader Class Initialized
INFO - 2018-06-10 06:32:18 --> Helper loaded: url_helper
INFO - 2018-06-10 06:32:18 --> Helper loaded: notification_helper
INFO - 2018-06-10 06:32:18 --> Helper loaded: settings_helper
INFO - 2018-06-10 06:32:18 --> Helper loaded: permission_helper
INFO - 2018-06-10 06:32:18 --> Helper loaded: users_helper
INFO - 2018-06-10 06:32:18 --> Database Driver Class Initialized
DEBUG - 2018-06-10 06:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-10 06:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-10 06:32:18 --> Helper loaded: form_helper
INFO - 2018-06-10 06:32:18 --> Form Validation Class Initialized
INFO - 2018-06-10 06:32:18 --> Controller Class Initialized
INFO - 2018-06-10 06:32:18 --> Model Class Initialized
INFO - 2018-06-10 06:32:18 --> Helper loaded: inflector_helper
INFO - 2018-06-10 06:32:18 --> Model Class Initialized
DEBUG - 2018-06-10 06:32:18 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-06-10 06:32:18 --> Final output sent to browser
DEBUG - 2018-06-10 06:32:18 --> Total execution time: 0.1561
INFO - 2018-06-10 18:30:02 --> Config Class Initialized
INFO - 2018-06-10 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-10 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-10 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-10 18:30:02 --> URI Class Initialized
INFO - 2018-06-10 18:30:02 --> Router Class Initialized
INFO - 2018-06-10 18:30:02 --> Output Class Initialized
INFO - 2018-06-10 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-10 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-10 18:30:02 --> Input Class Initialized
INFO - 2018-06-10 18:30:02 --> Language Class Initialized
INFO - 2018-06-10 18:30:02 --> Language Class Initialized
INFO - 2018-06-10 18:30:02 --> Config Class Initialized
INFO - 2018-06-10 18:30:02 --> Loader Class Initialized
INFO - 2018-06-10 18:30:02 --> Config Class Initialized
INFO - 2018-06-10 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-10 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-10 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-10 18:30:02 --> URI Class Initialized
INFO - 2018-06-10 18:30:02 --> Router Class Initialized
INFO - 2018-06-10 18:30:02 --> Output Class Initialized
INFO - 2018-06-10 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-10 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-10 18:30:02 --> Input Class Initialized
INFO - 2018-06-10 18:30:02 --> Language Class Initialized
INFO - 2018-06-10 18:30:02 --> Language Class Initialized
INFO - 2018-06-10 18:30:02 --> Config Class Initialized
INFO - 2018-06-10 18:30:02 --> Loader Class Initialized
