<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-06 11:42:49 --> Config Class Initialized
INFO - 2018-04-06 11:42:49 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:42:49 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:42:49 --> Utf8 Class Initialized
INFO - 2018-04-06 11:42:49 --> URI Class Initialized
DEBUG - 2018-04-06 11:42:49 --> No URI present. Default controller set.
INFO - 2018-04-06 11:42:49 --> Router Class Initialized
INFO - 2018-04-06 11:42:49 --> Output Class Initialized
INFO - 2018-04-06 11:42:49 --> Security Class Initialized
DEBUG - 2018-04-06 11:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:42:49 --> Input Class Initialized
INFO - 2018-04-06 11:42:49 --> Language Class Initialized
INFO - 2018-04-06 11:42:49 --> Language Class Initialized
INFO - 2018-04-06 11:42:49 --> Config Class Initialized
INFO - 2018-04-06 11:42:49 --> Loader Class Initialized
INFO - 2018-04-06 17:12:49 --> Helper loaded: url_helper
INFO - 2018-04-06 17:12:49 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:12:49 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:12:49 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:12:49 --> Helper loaded: users_helper
INFO - 2018-04-06 17:12:49 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:12:49 --> Helper loaded: form_helper
INFO - 2018-04-06 17:12:49 --> Form Validation Class Initialized
INFO - 2018-04-06 17:12:49 --> Controller Class Initialized
INFO - 2018-04-06 17:12:49 --> Model Class Initialized
INFO - 2018-04-06 17:12:49 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:12:49 --> Model Class Initialized
DEBUG - 2018-04-06 17:12:49 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-04-06 17:12:49 --> Final output sent to browser
DEBUG - 2018-04-06 17:12:49 --> Total execution time: 0.2645
INFO - 2018-04-06 11:43:04 --> Config Class Initialized
INFO - 2018-04-06 11:43:04 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:04 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:04 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:04 --> URI Class Initialized
INFO - 2018-04-06 11:43:04 --> Router Class Initialized
INFO - 2018-04-06 11:43:04 --> Output Class Initialized
INFO - 2018-04-06 11:43:04 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:04 --> Input Class Initialized
INFO - 2018-04-06 11:43:04 --> Language Class Initialized
INFO - 2018-04-06 11:43:04 --> Language Class Initialized
INFO - 2018-04-06 11:43:04 --> Config Class Initialized
INFO - 2018-04-06 11:43:04 --> Loader Class Initialized
INFO - 2018-04-06 17:13:04 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:04 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:04 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:04 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:04 --> Controller Class Initialized
INFO - 2018-04-06 17:13:04 --> Model Class Initialized
INFO - 2018-04-06 17:13:04 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:04 --> Model Class Initialized
INFO - 2018-04-06 17:13:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-06 11:43:04 --> Config Class Initialized
INFO - 2018-04-06 11:43:04 --> Hooks Class Initialized
INFO - 2018-04-06 11:43:04 --> Config Class Initialized
INFO - 2018-04-06 11:43:04 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:04 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:04 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:04 --> URI Class Initialized
DEBUG - 2018-04-06 11:43:04 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:04 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:04 --> Router Class Initialized
INFO - 2018-04-06 11:43:04 --> URI Class Initialized
INFO - 2018-04-06 11:43:04 --> Output Class Initialized
INFO - 2018-04-06 11:43:04 --> Security Class Initialized
INFO - 2018-04-06 11:43:04 --> Router Class Initialized
DEBUG - 2018-04-06 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:04 --> Input Class Initialized
INFO - 2018-04-06 11:43:04 --> Language Class Initialized
INFO - 2018-04-06 11:43:04 --> Output Class Initialized
INFO - 2018-04-06 11:43:04 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:04 --> Input Class Initialized
INFO - 2018-04-06 11:43:04 --> Language Class Initialized
INFO - 2018-04-06 11:43:04 --> Language Class Initialized
INFO - 2018-04-06 11:43:04 --> Config Class Initialized
INFO - 2018-04-06 11:43:04 --> Loader Class Initialized
INFO - 2018-04-06 17:13:04 --> Helper loaded: url_helper
INFO - 2018-04-06 11:43:04 --> Language Class Initialized
INFO - 2018-04-06 11:43:04 --> Config Class Initialized
INFO - 2018-04-06 11:43:04 --> Loader Class Initialized
INFO - 2018-04-06 17:13:04 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:04 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:04 --> Database Driver Class Initialized
INFO - 2018-04-06 17:13:04 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-04-06 17:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:04 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:04 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:04 --> Controller Class Initialized
INFO - 2018-04-06 17:13:04 --> Model Class Initialized
INFO - 2018-04-06 17:13:04 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:04 --> Model Class Initialized
INFO - 2018-04-06 17:13:04 --> Model Class Initialized
INFO - 2018-04-06 17:13:04 --> Model Class Initialized
INFO - 2018-04-06 17:13:04 --> Model Class Initialized
INFO - 2018-04-06 17:13:04 --> Model Class Initialized
DEBUG - 2018-04-06 17:13:04 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-06 17:13:04 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-04-06 17:13:04 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-06 17:13:04 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:04 --> Total execution time: 0.2681
INFO - 2018-04-06 17:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:04 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:04 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:04 --> Controller Class Initialized
DEBUG - 2018-04-06 17:13:04 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-04-06 17:13:04 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:04 --> Total execution time: 0.2816
INFO - 2018-04-06 11:43:27 --> Config Class Initialized
INFO - 2018-04-06 11:43:27 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:27 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:27 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:27 --> URI Class Initialized
INFO - 2018-04-06 11:43:27 --> Router Class Initialized
INFO - 2018-04-06 11:43:27 --> Output Class Initialized
INFO - 2018-04-06 11:43:27 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:27 --> Input Class Initialized
INFO - 2018-04-06 11:43:27 --> Language Class Initialized
INFO - 2018-04-06 11:43:27 --> Language Class Initialized
INFO - 2018-04-06 11:43:27 --> Config Class Initialized
INFO - 2018-04-06 11:43:27 --> Loader Class Initialized
INFO - 2018-04-06 17:13:27 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:27 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:27 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:27 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:27 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:27 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:27 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:27 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:27 --> Controller Class Initialized
INFO - 2018-04-06 17:13:27 --> Model Class Initialized
INFO - 2018-04-06 17:13:27 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:27 --> Model Class Initialized
INFO - 2018-04-06 17:13:27 --> Model Class Initialized
DEBUG - 2018-04-06 17:13:27 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-06 17:13:27 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-04-06 17:13:27 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-06 17:13:27 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:27 --> Total execution time: 0.1291
INFO - 2018-04-06 11:43:31 --> Config Class Initialized
INFO - 2018-04-06 11:43:31 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:31 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:31 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:31 --> URI Class Initialized
INFO - 2018-04-06 11:43:31 --> Router Class Initialized
INFO - 2018-04-06 11:43:31 --> Output Class Initialized
INFO - 2018-04-06 11:43:31 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:31 --> Input Class Initialized
INFO - 2018-04-06 11:43:31 --> Language Class Initialized
INFO - 2018-04-06 11:43:31 --> Language Class Initialized
INFO - 2018-04-06 11:43:31 --> Config Class Initialized
INFO - 2018-04-06 11:43:31 --> Loader Class Initialized
INFO - 2018-04-06 17:13:31 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:31 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:31 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:31 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:31 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:31 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:31 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:31 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:31 --> Controller Class Initialized
INFO - 2018-04-06 17:13:31 --> Model Class Initialized
INFO - 2018-04-06 17:13:31 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:31 --> Model Class Initialized
INFO - 2018-04-06 17:13:31 --> Model Class Initialized
INFO - 2018-04-06 17:13:31 --> Model Class Initialized
INFO - 2018-04-06 17:13:31 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:31 --> Total execution time: 0.1010
INFO - 2018-04-06 11:43:42 --> Config Class Initialized
INFO - 2018-04-06 11:43:42 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:42 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:42 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:42 --> URI Class Initialized
INFO - 2018-04-06 11:43:42 --> Router Class Initialized
INFO - 2018-04-06 11:43:42 --> Output Class Initialized
INFO - 2018-04-06 11:43:42 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:42 --> Input Class Initialized
INFO - 2018-04-06 11:43:42 --> Language Class Initialized
INFO - 2018-04-06 11:43:42 --> Language Class Initialized
INFO - 2018-04-06 11:43:42 --> Config Class Initialized
INFO - 2018-04-06 11:43:42 --> Loader Class Initialized
INFO - 2018-04-06 17:13:42 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:42 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:42 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:42 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:42 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:42 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:42 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:42 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:42 --> Controller Class Initialized
INFO - 2018-04-06 17:13:42 --> Model Class Initialized
INFO - 2018-04-06 17:13:42 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:42 --> Model Class Initialized
INFO - 2018-04-06 17:13:42 --> Model Class Initialized
INFO - 2018-04-06 17:13:42 --> Model Class Initialized
INFO - 2018-04-06 17:13:42 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:42 --> Total execution time: 0.0774
INFO - 2018-04-06 11:43:43 --> Config Class Initialized
INFO - 2018-04-06 11:43:43 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:43 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:43 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:43 --> URI Class Initialized
INFO - 2018-04-06 11:43:43 --> Router Class Initialized
INFO - 2018-04-06 11:43:43 --> Output Class Initialized
INFO - 2018-04-06 11:43:43 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:43 --> Input Class Initialized
INFO - 2018-04-06 11:43:43 --> Language Class Initialized
INFO - 2018-04-06 11:43:43 --> Language Class Initialized
INFO - 2018-04-06 11:43:43 --> Config Class Initialized
INFO - 2018-04-06 11:43:43 --> Loader Class Initialized
INFO - 2018-04-06 17:13:43 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:43 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:43 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:43 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:43 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:43 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:43 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:43 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:43 --> Controller Class Initialized
INFO - 2018-04-06 17:13:43 --> Model Class Initialized
INFO - 2018-04-06 17:13:43 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:43 --> Model Class Initialized
INFO - 2018-04-06 17:13:43 --> Model Class Initialized
INFO - 2018-04-06 17:13:43 --> Model Class Initialized
DEBUG - 2018-04-06 17:13:43 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-06 17:13:43 --> File loaded: /home/pr01004/public_html/application/views/users/user_details.php
DEBUG - 2018-04-06 17:13:43 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-06 17:13:43 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:43 --> Total execution time: 0.1759
INFO - 2018-04-06 11:43:47 --> Config Class Initialized
INFO - 2018-04-06 11:43:47 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:47 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:47 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:47 --> URI Class Initialized
INFO - 2018-04-06 11:43:47 --> Router Class Initialized
INFO - 2018-04-06 11:43:47 --> Output Class Initialized
INFO - 2018-04-06 11:43:47 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:47 --> Input Class Initialized
INFO - 2018-04-06 11:43:47 --> Language Class Initialized
INFO - 2018-04-06 11:43:47 --> Language Class Initialized
INFO - 2018-04-06 11:43:47 --> Config Class Initialized
INFO - 2018-04-06 11:43:47 --> Loader Class Initialized
INFO - 2018-04-06 17:13:47 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:47 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:47 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:47 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:47 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:47 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:47 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:47 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:47 --> Controller Class Initialized
INFO - 2018-04-06 17:13:47 --> Model Class Initialized
INFO - 2018-04-06 17:13:47 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:47 --> Model Class Initialized
INFO - 2018-04-06 17:13:47 --> Model Class Initialized
DEBUG - 2018-04-06 17:13:47 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-06 17:13:47 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-04-06 17:13:47 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-06 17:13:47 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:47 --> Total execution time: 0.0868
INFO - 2018-04-06 11:43:47 --> Config Class Initialized
INFO - 2018-04-06 11:43:47 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:47 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:47 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:47 --> URI Class Initialized
INFO - 2018-04-06 11:43:47 --> Router Class Initialized
INFO - 2018-04-06 11:43:47 --> Output Class Initialized
INFO - 2018-04-06 11:43:47 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:47 --> Input Class Initialized
INFO - 2018-04-06 11:43:47 --> Language Class Initialized
INFO - 2018-04-06 11:43:47 --> Language Class Initialized
INFO - 2018-04-06 11:43:47 --> Config Class Initialized
INFO - 2018-04-06 11:43:47 --> Loader Class Initialized
INFO - 2018-04-06 17:13:47 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:47 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:47 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:47 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:47 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:47 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:47 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:47 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:47 --> Controller Class Initialized
INFO - 2018-04-06 17:13:47 --> Model Class Initialized
INFO - 2018-04-06 17:13:47 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:47 --> Model Class Initialized
INFO - 2018-04-06 17:13:47 --> Model Class Initialized
INFO - 2018-04-06 17:13:47 --> Model Class Initialized
INFO - 2018-04-06 17:13:47 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:47 --> Total execution time: 0.1056
INFO - 2018-04-06 11:43:49 --> Config Class Initialized
INFO - 2018-04-06 11:43:49 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:49 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:49 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:49 --> URI Class Initialized
INFO - 2018-04-06 11:43:49 --> Router Class Initialized
INFO - 2018-04-06 11:43:49 --> Output Class Initialized
INFO - 2018-04-06 11:43:49 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:49 --> Input Class Initialized
INFO - 2018-04-06 11:43:49 --> Language Class Initialized
INFO - 2018-04-06 11:43:49 --> Language Class Initialized
INFO - 2018-04-06 11:43:49 --> Config Class Initialized
INFO - 2018-04-06 11:43:49 --> Loader Class Initialized
INFO - 2018-04-06 17:13:49 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:49 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:49 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:49 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:49 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:49 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:49 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:49 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:49 --> Controller Class Initialized
INFO - 2018-04-06 17:13:49 --> Model Class Initialized
INFO - 2018-04-06 17:13:49 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:49 --> Model Class Initialized
INFO - 2018-04-06 17:13:49 --> Model Class Initialized
INFO - 2018-04-06 17:13:49 --> Model Class Initialized
DEBUG - 2018-04-06 17:13:49 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-06 17:13:49 --> File loaded: /home/pr01004/public_html/application/views/users/user_details.php
DEBUG - 2018-04-06 17:13:49 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-06 17:13:49 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:49 --> Total execution time: 0.0987
INFO - 2018-04-06 11:43:52 --> Config Class Initialized
INFO - 2018-04-06 11:43:52 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:52 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:52 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:52 --> URI Class Initialized
INFO - 2018-04-06 11:43:52 --> Router Class Initialized
INFO - 2018-04-06 11:43:52 --> Output Class Initialized
INFO - 2018-04-06 11:43:52 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:52 --> Input Class Initialized
INFO - 2018-04-06 11:43:52 --> Language Class Initialized
INFO - 2018-04-06 11:43:52 --> Language Class Initialized
INFO - 2018-04-06 11:43:52 --> Config Class Initialized
INFO - 2018-04-06 11:43:52 --> Loader Class Initialized
INFO - 2018-04-06 17:13:52 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:52 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:52 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:52 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:52 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:52 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:52 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:52 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:52 --> Controller Class Initialized
INFO - 2018-04-06 17:13:52 --> Model Class Initialized
INFO - 2018-04-06 17:13:52 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:52 --> Model Class Initialized
INFO - 2018-04-06 17:13:52 --> Model Class Initialized
DEBUG - 2018-04-06 17:13:52 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-06 17:13:52 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-04-06 17:13:52 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-06 17:13:52 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:52 --> Total execution time: 0.1091
INFO - 2018-04-06 11:43:52 --> Config Class Initialized
INFO - 2018-04-06 11:43:52 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:52 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:52 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:52 --> URI Class Initialized
INFO - 2018-04-06 11:43:52 --> Router Class Initialized
INFO - 2018-04-06 11:43:52 --> Output Class Initialized
INFO - 2018-04-06 11:43:52 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:52 --> Input Class Initialized
INFO - 2018-04-06 11:43:52 --> Language Class Initialized
INFO - 2018-04-06 11:43:52 --> Language Class Initialized
INFO - 2018-04-06 11:43:52 --> Config Class Initialized
INFO - 2018-04-06 11:43:52 --> Loader Class Initialized
INFO - 2018-04-06 17:13:52 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:52 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:52 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:52 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:52 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:52 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:52 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:52 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:52 --> Controller Class Initialized
INFO - 2018-04-06 17:13:52 --> Model Class Initialized
INFO - 2018-04-06 17:13:52 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:52 --> Model Class Initialized
INFO - 2018-04-06 17:13:52 --> Model Class Initialized
INFO - 2018-04-06 17:13:52 --> Model Class Initialized
INFO - 2018-04-06 17:13:52 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:52 --> Total execution time: 0.0968
INFO - 2018-04-06 11:43:55 --> Config Class Initialized
INFO - 2018-04-06 11:43:55 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:55 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:55 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:55 --> URI Class Initialized
INFO - 2018-04-06 11:43:55 --> Router Class Initialized
INFO - 2018-04-06 11:43:55 --> Output Class Initialized
INFO - 2018-04-06 11:43:55 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:55 --> Input Class Initialized
INFO - 2018-04-06 11:43:55 --> Language Class Initialized
INFO - 2018-04-06 11:43:55 --> Language Class Initialized
INFO - 2018-04-06 11:43:55 --> Config Class Initialized
INFO - 2018-04-06 11:43:55 --> Loader Class Initialized
INFO - 2018-04-06 17:13:55 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:55 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:55 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:55 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:55 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:55 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:55 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:55 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:55 --> Controller Class Initialized
INFO - 2018-04-06 17:13:55 --> Model Class Initialized
INFO - 2018-04-06 17:13:55 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:55 --> Model Class Initialized
INFO - 2018-04-06 17:13:55 --> Model Class Initialized
INFO - 2018-04-06 17:13:55 --> Model Class Initialized
INFO - 2018-04-06 17:13:55 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:55 --> Total execution time: 0.0986
INFO - 2018-04-06 11:43:57 --> Config Class Initialized
INFO - 2018-04-06 11:43:57 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:43:57 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:43:57 --> Utf8 Class Initialized
INFO - 2018-04-06 11:43:57 --> URI Class Initialized
INFO - 2018-04-06 11:43:57 --> Router Class Initialized
INFO - 2018-04-06 11:43:57 --> Output Class Initialized
INFO - 2018-04-06 11:43:57 --> Security Class Initialized
DEBUG - 2018-04-06 11:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:43:57 --> Input Class Initialized
INFO - 2018-04-06 11:43:57 --> Language Class Initialized
INFO - 2018-04-06 11:43:57 --> Language Class Initialized
INFO - 2018-04-06 11:43:57 --> Config Class Initialized
INFO - 2018-04-06 11:43:57 --> Loader Class Initialized
INFO - 2018-04-06 17:13:57 --> Helper loaded: url_helper
INFO - 2018-04-06 17:13:57 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:13:57 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:13:57 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:13:57 --> Helper loaded: users_helper
INFO - 2018-04-06 17:13:57 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:13:57 --> Helper loaded: form_helper
INFO - 2018-04-06 17:13:57 --> Form Validation Class Initialized
INFO - 2018-04-06 17:13:57 --> Controller Class Initialized
INFO - 2018-04-06 17:13:57 --> Model Class Initialized
INFO - 2018-04-06 17:13:57 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:13:57 --> Model Class Initialized
INFO - 2018-04-06 17:13:57 --> Model Class Initialized
INFO - 2018-04-06 17:13:57 --> Model Class Initialized
DEBUG - 2018-04-06 17:13:57 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-06 17:13:57 --> File loaded: /home/pr01004/public_html/application/views/users/user_details.php
DEBUG - 2018-04-06 17:13:57 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-06 17:13:57 --> Final output sent to browser
DEBUG - 2018-04-06 17:13:57 --> Total execution time: 0.1046
INFO - 2018-04-06 11:44:01 --> Config Class Initialized
INFO - 2018-04-06 11:44:01 --> Hooks Class Initialized
DEBUG - 2018-04-06 11:44:01 --> UTF-8 Support Enabled
INFO - 2018-04-06 11:44:01 --> Utf8 Class Initialized
INFO - 2018-04-06 11:44:01 --> URI Class Initialized
INFO - 2018-04-06 11:44:01 --> Router Class Initialized
INFO - 2018-04-06 11:44:01 --> Output Class Initialized
INFO - 2018-04-06 11:44:01 --> Security Class Initialized
DEBUG - 2018-04-06 11:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 11:44:01 --> Input Class Initialized
INFO - 2018-04-06 11:44:01 --> Language Class Initialized
INFO - 2018-04-06 11:44:01 --> Language Class Initialized
INFO - 2018-04-06 11:44:01 --> Config Class Initialized
INFO - 2018-04-06 11:44:01 --> Loader Class Initialized
INFO - 2018-04-06 17:14:01 --> Helper loaded: url_helper
INFO - 2018-04-06 17:14:01 --> Helper loaded: notification_helper
INFO - 2018-04-06 17:14:01 --> Helper loaded: settings_helper
INFO - 2018-04-06 17:14:01 --> Helper loaded: permission_helper
INFO - 2018-04-06 17:14:01 --> Helper loaded: users_helper
INFO - 2018-04-06 17:14:01 --> Database Driver Class Initialized
DEBUG - 2018-04-06 17:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 17:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 17:14:01 --> Helper loaded: form_helper
INFO - 2018-04-06 17:14:01 --> Form Validation Class Initialized
INFO - 2018-04-06 17:14:01 --> Controller Class Initialized
INFO - 2018-04-06 17:14:01 --> Model Class Initialized
INFO - 2018-04-06 17:14:01 --> Helper loaded: inflector_helper
INFO - 2018-04-06 17:14:01 --> Model Class Initialized
INFO - 2018-04-06 17:14:01 --> Model Class Initialized
INFO - 2018-04-06 17:14:01 --> Model Class Initialized
DEBUG - 2018-04-06 17:14:01 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-04-06 17:14:01 --> File loaded: /home/pr01004/public_html/application/views/questions/question_list.php
DEBUG - 2018-04-06 17:14:01 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-04-06 17:14:01 --> Final output sent to browser
DEBUG - 2018-04-06 17:14:01 --> Total execution time: 0.1346
