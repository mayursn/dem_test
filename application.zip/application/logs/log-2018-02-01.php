<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-01 06:25:14 --> Config Class Initialized
INFO - 2018-02-01 06:25:14 --> Hooks Class Initialized
DEBUG - 2018-02-01 06:25:14 --> UTF-8 Support Enabled
INFO - 2018-02-01 06:25:14 --> Utf8 Class Initialized
INFO - 2018-02-01 06:25:14 --> URI Class Initialized
DEBUG - 2018-02-01 06:25:14 --> No URI present. Default controller set.
INFO - 2018-02-01 06:25:14 --> Router Class Initialized
INFO - 2018-02-01 06:25:14 --> Output Class Initialized
INFO - 2018-02-01 06:25:14 --> Security Class Initialized
DEBUG - 2018-02-01 06:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 06:25:14 --> Input Class Initialized
INFO - 2018-02-01 06:25:14 --> Language Class Initialized
INFO - 2018-02-01 06:25:14 --> Language Class Initialized
INFO - 2018-02-01 06:25:14 --> Config Class Initialized
INFO - 2018-02-01 06:25:14 --> Loader Class Initialized
INFO - 2018-02-01 11:55:14 --> Helper loaded: url_helper
INFO - 2018-02-01 11:55:14 --> Helper loaded: notification_helper
INFO - 2018-02-01 11:55:14 --> Helper loaded: settings_helper
INFO - 2018-02-01 11:55:14 --> Helper loaded: permission_helper
INFO - 2018-02-01 11:55:14 --> Helper loaded: users_helper
INFO - 2018-02-01 11:55:14 --> Database Driver Class Initialized
DEBUG - 2018-02-01 11:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 11:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 11:55:14 --> Helper loaded: form_helper
INFO - 2018-02-01 11:55:14 --> Form Validation Class Initialized
INFO - 2018-02-01 11:55:14 --> Controller Class Initialized
INFO - 2018-02-01 11:55:14 --> Model Class Initialized
INFO - 2018-02-01 11:55:14 --> Helper loaded: inflector_helper
INFO - 2018-02-01 11:55:14 --> Model Class Initialized
DEBUG - 2018-02-01 11:55:14 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-01 11:55:14 --> Final output sent to browser
DEBUG - 2018-02-01 11:55:14 --> Total execution time: 0.0910
INFO - 2018-02-01 06:25:30 --> Config Class Initialized
INFO - 2018-02-01 06:25:30 --> Hooks Class Initialized
DEBUG - 2018-02-01 06:25:30 --> UTF-8 Support Enabled
INFO - 2018-02-01 06:25:30 --> Utf8 Class Initialized
INFO - 2018-02-01 06:25:30 --> URI Class Initialized
INFO - 2018-02-01 06:25:30 --> Router Class Initialized
INFO - 2018-02-01 06:25:30 --> Output Class Initialized
INFO - 2018-02-01 06:25:30 --> Security Class Initialized
DEBUG - 2018-02-01 06:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 06:25:30 --> Input Class Initialized
INFO - 2018-02-01 06:25:30 --> Language Class Initialized
INFO - 2018-02-01 06:25:30 --> Language Class Initialized
INFO - 2018-02-01 06:25:30 --> Config Class Initialized
INFO - 2018-02-01 06:25:30 --> Loader Class Initialized
INFO - 2018-02-01 11:55:30 --> Helper loaded: url_helper
INFO - 2018-02-01 11:55:30 --> Helper loaded: notification_helper
INFO - 2018-02-01 11:55:30 --> Helper loaded: settings_helper
INFO - 2018-02-01 11:55:30 --> Helper loaded: permission_helper
INFO - 2018-02-01 11:55:30 --> Helper loaded: users_helper
INFO - 2018-02-01 11:55:30 --> Database Driver Class Initialized
DEBUG - 2018-02-01 11:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 11:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 11:55:30 --> Helper loaded: form_helper
INFO - 2018-02-01 11:55:30 --> Form Validation Class Initialized
INFO - 2018-02-01 11:55:30 --> Controller Class Initialized
INFO - 2018-02-01 11:55:30 --> Model Class Initialized
INFO - 2018-02-01 11:55:30 --> Helper loaded: inflector_helper
INFO - 2018-02-01 11:55:30 --> Model Class Initialized
INFO - 2018-02-01 11:55:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-01 06:25:30 --> Config Class Initialized
INFO - 2018-02-01 06:25:30 --> Hooks Class Initialized
INFO - 2018-02-01 06:25:30 --> Config Class Initialized
INFO - 2018-02-01 06:25:30 --> Hooks Class Initialized
DEBUG - 2018-02-01 06:25:30 --> UTF-8 Support Enabled
INFO - 2018-02-01 06:25:30 --> Utf8 Class Initialized
DEBUG - 2018-02-01 06:25:30 --> UTF-8 Support Enabled
INFO - 2018-02-01 06:25:30 --> Utf8 Class Initialized
INFO - 2018-02-01 06:25:30 --> URI Class Initialized
INFO - 2018-02-01 06:25:30 --> URI Class Initialized
INFO - 2018-02-01 06:25:30 --> Router Class Initialized
INFO - 2018-02-01 06:25:30 --> Router Class Initialized
INFO - 2018-02-01 06:25:30 --> Output Class Initialized
INFO - 2018-02-01 06:25:30 --> Output Class Initialized
INFO - 2018-02-01 06:25:30 --> Security Class Initialized
INFO - 2018-02-01 06:25:30 --> Security Class Initialized
DEBUG - 2018-02-01 06:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 06:25:30 --> Input Class Initialized
DEBUG - 2018-02-01 06:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 06:25:30 --> Input Class Initialized
INFO - 2018-02-01 06:25:30 --> Language Class Initialized
INFO - 2018-02-01 06:25:30 --> Language Class Initialized
INFO - 2018-02-01 06:25:31 --> Language Class Initialized
INFO - 2018-02-01 06:25:31 --> Config Class Initialized
INFO - 2018-02-01 06:25:31 --> Loader Class Initialized
INFO - 2018-02-01 06:25:31 --> Language Class Initialized
INFO - 2018-02-01 06:25:31 --> Config Class Initialized
INFO - 2018-02-01 06:25:31 --> Loader Class Initialized
INFO - 2018-02-01 11:55:31 --> Helper loaded: url_helper
INFO - 2018-02-01 11:55:31 --> Helper loaded: notification_helper
INFO - 2018-02-01 11:55:31 --> Helper loaded: settings_helper
INFO - 2018-02-01 11:55:31 --> Helper loaded: url_helper
INFO - 2018-02-01 11:55:31 --> Helper loaded: permission_helper
INFO - 2018-02-01 11:55:31 --> Helper loaded: users_helper
INFO - 2018-02-01 11:55:31 --> Helper loaded: notification_helper
INFO - 2018-02-01 11:55:31 --> Helper loaded: settings_helper
INFO - 2018-02-01 11:55:31 --> Helper loaded: permission_helper
INFO - 2018-02-01 11:55:31 --> Helper loaded: users_helper
INFO - 2018-02-01 11:55:31 --> Database Driver Class Initialized
INFO - 2018-02-01 11:55:31 --> Database Driver Class Initialized
DEBUG - 2018-02-01 11:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 11:55:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-01 11:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 11:55:31 --> Helper loaded: form_helper
INFO - 2018-02-01 11:55:31 --> Form Validation Class Initialized
INFO - 2018-02-01 11:55:31 --> Controller Class Initialized
DEBUG - 2018-02-01 11:55:31 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-01 11:55:31 --> Final output sent to browser
DEBUG - 2018-02-01 11:55:31 --> Total execution time: 0.0782
INFO - 2018-02-01 11:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 11:55:31 --> Helper loaded: form_helper
INFO - 2018-02-01 11:55:31 --> Form Validation Class Initialized
INFO - 2018-02-01 11:55:31 --> Controller Class Initialized
INFO - 2018-02-01 11:55:31 --> Model Class Initialized
INFO - 2018-02-01 11:55:31 --> Helper loaded: inflector_helper
INFO - 2018-02-01 11:55:31 --> Model Class Initialized
INFO - 2018-02-01 11:55:31 --> Model Class Initialized
INFO - 2018-02-01 11:55:31 --> Model Class Initialized
INFO - 2018-02-01 11:55:31 --> Model Class Initialized
INFO - 2018-02-01 11:55:31 --> Model Class Initialized
DEBUG - 2018-02-01 11:55:31 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-01 11:55:31 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-02-01 11:55:31 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-01 11:55:31 --> Final output sent to browser
DEBUG - 2018-02-01 11:55:31 --> Total execution time: 0.1166
INFO - 2018-02-01 06:26:47 --> Config Class Initialized
INFO - 2018-02-01 06:26:47 --> Hooks Class Initialized
DEBUG - 2018-02-01 06:26:47 --> UTF-8 Support Enabled
INFO - 2018-02-01 06:26:47 --> Utf8 Class Initialized
INFO - 2018-02-01 06:26:47 --> URI Class Initialized
INFO - 2018-02-01 06:26:47 --> Router Class Initialized
INFO - 2018-02-01 06:26:47 --> Output Class Initialized
INFO - 2018-02-01 06:26:47 --> Security Class Initialized
DEBUG - 2018-02-01 06:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 06:26:47 --> Input Class Initialized
INFO - 2018-02-01 06:26:47 --> Language Class Initialized
INFO - 2018-02-01 06:26:47 --> Language Class Initialized
INFO - 2018-02-01 06:26:47 --> Config Class Initialized
INFO - 2018-02-01 06:26:47 --> Loader Class Initialized
INFO - 2018-02-01 11:56:47 --> Helper loaded: url_helper
INFO - 2018-02-01 11:56:47 --> Helper loaded: notification_helper
INFO - 2018-02-01 11:56:47 --> Helper loaded: settings_helper
INFO - 2018-02-01 11:56:47 --> Helper loaded: permission_helper
INFO - 2018-02-01 11:56:47 --> Helper loaded: users_helper
INFO - 2018-02-01 11:56:47 --> Database Driver Class Initialized
DEBUG - 2018-02-01 11:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 11:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 11:56:47 --> Helper loaded: form_helper
INFO - 2018-02-01 11:56:47 --> Form Validation Class Initialized
INFO - 2018-02-01 11:56:47 --> Controller Class Initialized
INFO - 2018-02-01 11:56:47 --> Model Class Initialized
INFO - 2018-02-01 11:56:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 11:56:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 11:56:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 11:56:47 --> Model Class Initialized
INFO - 2018-02-01 11:56:47 --> Model Class Initialized
INFO - 2018-02-01 11:56:47 --> Model Class Initialized
INFO - 2018-02-01 11:56:47 --> Model Class Initialized
INFO - 2018-02-01 11:56:47 --> Model Class Initialized
INFO - 2018-02-01 11:56:47 --> Model Class Initialized
INFO - 2018-02-01 11:56:47 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 11:56:47 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-01 11:56:47 --> Final output sent to browser
DEBUG - 2018-02-01 11:56:47 --> Total execution time: 0.1147
INFO - 2018-02-01 06:46:04 --> Config Class Initialized
INFO - 2018-02-01 06:46:04 --> Hooks Class Initialized
DEBUG - 2018-02-01 06:46:04 --> UTF-8 Support Enabled
INFO - 2018-02-01 06:46:04 --> Utf8 Class Initialized
INFO - 2018-02-01 06:46:04 --> URI Class Initialized
INFO - 2018-02-01 06:46:04 --> Router Class Initialized
INFO - 2018-02-01 06:46:04 --> Output Class Initialized
INFO - 2018-02-01 06:46:04 --> Security Class Initialized
DEBUG - 2018-02-01 06:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 06:46:04 --> Input Class Initialized
INFO - 2018-02-01 06:46:04 --> Language Class Initialized
INFO - 2018-02-01 06:46:04 --> Language Class Initialized
INFO - 2018-02-01 06:46:04 --> Config Class Initialized
INFO - 2018-02-01 06:46:04 --> Loader Class Initialized
INFO - 2018-02-01 12:16:04 --> Helper loaded: url_helper
INFO - 2018-02-01 12:16:04 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:16:04 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:16:04 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:16:04 --> Helper loaded: users_helper
INFO - 2018-02-01 12:16:04 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:16:04 --> Helper loaded: form_helper
INFO - 2018-02-01 12:16:04 --> Form Validation Class Initialized
INFO - 2018-02-01 12:16:04 --> Controller Class Initialized
INFO - 2018-02-01 12:16:04 --> Model Class Initialized
INFO - 2018-02-01 12:16:04 --> Helper loaded: inflector_helper
INFO - 2018-02-01 12:16:04 --> Model Class Initialized
INFO - 2018-02-01 12:16:04 --> Model Class Initialized
INFO - 2018-02-01 12:16:04 --> Model Class Initialized
INFO - 2018-02-01 12:16:04 --> Model Class Initialized
INFO - 2018-02-01 12:16:04 --> Model Class Initialized
DEBUG - 2018-02-01 12:16:04 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-01 12:16:04 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-02-01 12:16:04 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-01 12:16:04 --> Final output sent to browser
DEBUG - 2018-02-01 12:16:04 --> Total execution time: 0.0987
INFO - 2018-02-01 06:52:31 --> Config Class Initialized
INFO - 2018-02-01 06:52:31 --> Hooks Class Initialized
DEBUG - 2018-02-01 06:52:31 --> UTF-8 Support Enabled
INFO - 2018-02-01 06:52:31 --> Utf8 Class Initialized
INFO - 2018-02-01 06:52:31 --> URI Class Initialized
INFO - 2018-02-01 06:52:31 --> Router Class Initialized
INFO - 2018-02-01 06:52:31 --> Output Class Initialized
INFO - 2018-02-01 06:52:31 --> Security Class Initialized
DEBUG - 2018-02-01 06:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 06:52:31 --> Input Class Initialized
INFO - 2018-02-01 06:52:31 --> Language Class Initialized
INFO - 2018-02-01 06:52:31 --> Language Class Initialized
INFO - 2018-02-01 06:52:31 --> Config Class Initialized
INFO - 2018-02-01 06:52:31 --> Loader Class Initialized
INFO - 2018-02-01 12:22:31 --> Helper loaded: url_helper
INFO - 2018-02-01 12:22:31 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:22:31 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:22:31 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:22:31 --> Helper loaded: users_helper
INFO - 2018-02-01 12:22:31 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:22:31 --> Helper loaded: form_helper
INFO - 2018-02-01 12:22:31 --> Form Validation Class Initialized
INFO - 2018-02-01 12:22:31 --> Controller Class Initialized
INFO - 2018-02-01 12:22:31 --> Model Class Initialized
INFO - 2018-02-01 12:22:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 12:22:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 12:22:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 12:22:31 --> Model Class Initialized
INFO - 2018-02-01 12:22:31 --> Model Class Initialized
INFO - 2018-02-01 12:22:31 --> Model Class Initialized
INFO - 2018-02-01 12:22:31 --> Model Class Initialized
INFO - 2018-02-01 12:22:31 --> Model Class Initialized
INFO - 2018-02-01 12:22:31 --> Model Class Initialized
INFO - 2018-02-01 12:22:31 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 12:22:31 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-01 12:22:31 --> Final output sent to browser
DEBUG - 2018-02-01 12:22:31 --> Total execution time: 0.1137
INFO - 2018-02-01 06:54:01 --> Config Class Initialized
INFO - 2018-02-01 06:54:01 --> Hooks Class Initialized
DEBUG - 2018-02-01 06:54:01 --> UTF-8 Support Enabled
INFO - 2018-02-01 06:54:01 --> Utf8 Class Initialized
INFO - 2018-02-01 06:54:01 --> URI Class Initialized
DEBUG - 2018-02-01 06:54:01 --> No URI present. Default controller set.
INFO - 2018-02-01 06:54:01 --> Router Class Initialized
INFO - 2018-02-01 06:54:01 --> Output Class Initialized
INFO - 2018-02-01 06:54:01 --> Security Class Initialized
DEBUG - 2018-02-01 06:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 06:54:01 --> Input Class Initialized
INFO - 2018-02-01 06:54:01 --> Language Class Initialized
INFO - 2018-02-01 06:54:01 --> Language Class Initialized
INFO - 2018-02-01 06:54:01 --> Config Class Initialized
INFO - 2018-02-01 06:54:01 --> Loader Class Initialized
INFO - 2018-02-01 12:24:01 --> Helper loaded: url_helper
INFO - 2018-02-01 12:24:01 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:24:01 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:24:01 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:24:01 --> Helper loaded: users_helper
INFO - 2018-02-01 12:24:01 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:24:01 --> Helper loaded: form_helper
INFO - 2018-02-01 12:24:01 --> Form Validation Class Initialized
INFO - 2018-02-01 12:24:01 --> Controller Class Initialized
INFO - 2018-02-01 12:24:01 --> Model Class Initialized
INFO - 2018-02-01 12:24:01 --> Helper loaded: inflector_helper
INFO - 2018-02-01 12:24:01 --> Model Class Initialized
DEBUG - 2018-02-01 12:24:01 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-01 12:24:01 --> Final output sent to browser
DEBUG - 2018-02-01 12:24:01 --> Total execution time: 0.0595
INFO - 2018-02-01 07:25:13 --> Config Class Initialized
INFO - 2018-02-01 07:25:13 --> Hooks Class Initialized
DEBUG - 2018-02-01 07:25:13 --> UTF-8 Support Enabled
INFO - 2018-02-01 07:25:13 --> Utf8 Class Initialized
INFO - 2018-02-01 07:25:13 --> URI Class Initialized
INFO - 2018-02-01 07:25:13 --> Router Class Initialized
INFO - 2018-02-01 07:25:13 --> Output Class Initialized
INFO - 2018-02-01 07:25:13 --> Security Class Initialized
DEBUG - 2018-02-01 07:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 07:25:13 --> Input Class Initialized
INFO - 2018-02-01 07:25:13 --> Language Class Initialized
INFO - 2018-02-01 07:25:13 --> Language Class Initialized
INFO - 2018-02-01 07:25:13 --> Config Class Initialized
INFO - 2018-02-01 07:25:13 --> Loader Class Initialized
INFO - 2018-02-01 12:55:13 --> Helper loaded: url_helper
INFO - 2018-02-01 12:55:13 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:55:13 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:55:13 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:55:13 --> Helper loaded: users_helper
INFO - 2018-02-01 12:55:13 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:55:13 --> Helper loaded: form_helper
INFO - 2018-02-01 12:55:13 --> Form Validation Class Initialized
INFO - 2018-02-01 12:55:13 --> Controller Class Initialized
INFO - 2018-02-01 12:55:13 --> Model Class Initialized
INFO - 2018-02-01 12:55:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 12:55:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 12:55:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 12:55:13 --> Model Class Initialized
INFO - 2018-02-01 12:55:13 --> Model Class Initialized
INFO - 2018-02-01 12:55:13 --> Model Class Initialized
INFO - 2018-02-01 12:55:13 --> Model Class Initialized
INFO - 2018-02-01 12:55:13 --> Model Class Initialized
INFO - 2018-02-01 12:55:13 --> Model Class Initialized
INFO - 2018-02-01 12:55:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 12:55:13 --> Final output sent to browser
DEBUG - 2018-02-01 12:55:13 --> Total execution time: 0.1428
INFO - 2018-02-01 07:25:48 --> Config Class Initialized
INFO - 2018-02-01 07:25:48 --> Hooks Class Initialized
DEBUG - 2018-02-01 07:25:48 --> UTF-8 Support Enabled
INFO - 2018-02-01 07:25:48 --> Utf8 Class Initialized
INFO - 2018-02-01 07:25:48 --> URI Class Initialized
INFO - 2018-02-01 07:25:48 --> Router Class Initialized
INFO - 2018-02-01 07:25:48 --> Output Class Initialized
INFO - 2018-02-01 07:25:48 --> Security Class Initialized
DEBUG - 2018-02-01 07:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 07:25:48 --> Input Class Initialized
INFO - 2018-02-01 07:25:48 --> Language Class Initialized
INFO - 2018-02-01 07:25:48 --> Language Class Initialized
INFO - 2018-02-01 07:25:48 --> Config Class Initialized
INFO - 2018-02-01 07:25:48 --> Loader Class Initialized
INFO - 2018-02-01 12:55:48 --> Helper loaded: url_helper
INFO - 2018-02-01 12:55:48 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:55:48 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:55:48 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:55:48 --> Helper loaded: users_helper
INFO - 2018-02-01 12:55:48 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:55:48 --> Helper loaded: form_helper
INFO - 2018-02-01 12:55:48 --> Form Validation Class Initialized
INFO - 2018-02-01 12:55:48 --> Controller Class Initialized
INFO - 2018-02-01 12:55:48 --> Model Class Initialized
INFO - 2018-02-01 12:55:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 12:55:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 12:55:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 12:55:48 --> Model Class Initialized
INFO - 2018-02-01 12:55:48 --> Model Class Initialized
INFO - 2018-02-01 12:55:48 --> Model Class Initialized
INFO - 2018-02-01 12:55:48 --> Model Class Initialized
INFO - 2018-02-01 12:55:48 --> Model Class Initialized
INFO - 2018-02-01 12:55:48 --> Model Class Initialized
INFO - 2018-02-01 12:55:48 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 12:55:48 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-01 12:55:48 --> Final output sent to browser
DEBUG - 2018-02-01 12:55:48 --> Total execution time: 0.1170
INFO - 2018-02-01 07:25:55 --> Config Class Initialized
INFO - 2018-02-01 07:25:55 --> Hooks Class Initialized
DEBUG - 2018-02-01 07:25:55 --> UTF-8 Support Enabled
INFO - 2018-02-01 07:25:55 --> Utf8 Class Initialized
INFO - 2018-02-01 07:25:55 --> URI Class Initialized
INFO - 2018-02-01 07:25:55 --> Router Class Initialized
INFO - 2018-02-01 07:25:55 --> Output Class Initialized
INFO - 2018-02-01 07:25:55 --> Security Class Initialized
DEBUG - 2018-02-01 07:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 07:25:55 --> Input Class Initialized
INFO - 2018-02-01 07:25:55 --> Language Class Initialized
INFO - 2018-02-01 07:25:55 --> Language Class Initialized
INFO - 2018-02-01 07:25:55 --> Config Class Initialized
INFO - 2018-02-01 07:25:55 --> Loader Class Initialized
INFO - 2018-02-01 12:55:55 --> Helper loaded: url_helper
INFO - 2018-02-01 12:55:55 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:55:55 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:55:55 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:55:55 --> Helper loaded: users_helper
INFO - 2018-02-01 12:55:55 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:55:55 --> Helper loaded: form_helper
INFO - 2018-02-01 12:55:55 --> Form Validation Class Initialized
INFO - 2018-02-01 12:55:55 --> Controller Class Initialized
INFO - 2018-02-01 12:55:55 --> Model Class Initialized
INFO - 2018-02-01 12:55:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 12:55:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 12:55:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 12:55:55 --> Model Class Initialized
INFO - 2018-02-01 12:55:55 --> Model Class Initialized
INFO - 2018-02-01 12:55:55 --> Model Class Initialized
INFO - 2018-02-01 12:55:55 --> Model Class Initialized
INFO - 2018-02-01 12:55:55 --> Model Class Initialized
INFO - 2018-02-01 12:55:55 --> Model Class Initialized
INFO - 2018-02-01 12:55:55 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 12:55:55 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-01 12:55:55 --> Final output sent to browser
DEBUG - 2018-02-01 12:55:55 --> Total execution time: 0.0791
INFO - 2018-02-01 07:27:49 --> Config Class Initialized
INFO - 2018-02-01 07:27:49 --> Hooks Class Initialized
DEBUG - 2018-02-01 07:27:49 --> UTF-8 Support Enabled
INFO - 2018-02-01 07:27:49 --> Utf8 Class Initialized
INFO - 2018-02-01 07:27:49 --> URI Class Initialized
INFO - 2018-02-01 07:27:49 --> Router Class Initialized
INFO - 2018-02-01 07:27:49 --> Output Class Initialized
INFO - 2018-02-01 07:27:49 --> Security Class Initialized
DEBUG - 2018-02-01 07:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 07:27:49 --> Input Class Initialized
INFO - 2018-02-01 07:27:49 --> Language Class Initialized
INFO - 2018-02-01 07:27:49 --> Language Class Initialized
INFO - 2018-02-01 07:27:49 --> Config Class Initialized
INFO - 2018-02-01 07:27:49 --> Loader Class Initialized
INFO - 2018-02-01 12:57:49 --> Helper loaded: url_helper
INFO - 2018-02-01 12:57:49 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:57:49 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:57:49 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:57:49 --> Helper loaded: users_helper
INFO - 2018-02-01 12:57:49 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:57:49 --> Helper loaded: form_helper
INFO - 2018-02-01 12:57:49 --> Form Validation Class Initialized
INFO - 2018-02-01 12:57:49 --> Controller Class Initialized
INFO - 2018-02-01 12:57:49 --> Model Class Initialized
INFO - 2018-02-01 12:57:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 12:57:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 12:57:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 12:57:49 --> Model Class Initialized
INFO - 2018-02-01 12:57:49 --> Model Class Initialized
INFO - 2018-02-01 12:57:49 --> Model Class Initialized
INFO - 2018-02-01 12:57:49 --> Model Class Initialized
INFO - 2018-02-01 12:57:49 --> Model Class Initialized
INFO - 2018-02-01 12:57:49 --> Model Class Initialized
INFO - 2018-02-01 12:57:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 12:57:49 --> Final output sent to browser
DEBUG - 2018-02-01 12:57:49 --> Total execution time: 0.1514
INFO - 2018-02-01 07:27:53 --> Config Class Initialized
INFO - 2018-02-01 07:27:53 --> Hooks Class Initialized
DEBUG - 2018-02-01 07:27:53 --> UTF-8 Support Enabled
INFO - 2018-02-01 07:27:53 --> Utf8 Class Initialized
INFO - 2018-02-01 07:27:53 --> URI Class Initialized
INFO - 2018-02-01 07:27:53 --> Router Class Initialized
INFO - 2018-02-01 07:27:53 --> Output Class Initialized
INFO - 2018-02-01 07:27:53 --> Security Class Initialized
DEBUG - 2018-02-01 07:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 07:27:53 --> Input Class Initialized
INFO - 2018-02-01 07:27:53 --> Language Class Initialized
INFO - 2018-02-01 07:27:54 --> Language Class Initialized
INFO - 2018-02-01 07:27:54 --> Config Class Initialized
INFO - 2018-02-01 07:27:54 --> Loader Class Initialized
INFO - 2018-02-01 12:57:54 --> Helper loaded: url_helper
INFO - 2018-02-01 12:57:54 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:57:54 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:57:54 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:57:54 --> Helper loaded: users_helper
INFO - 2018-02-01 12:57:54 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:57:54 --> Helper loaded: form_helper
INFO - 2018-02-01 12:57:54 --> Form Validation Class Initialized
INFO - 2018-02-01 12:57:54 --> Controller Class Initialized
INFO - 2018-02-01 12:57:54 --> Model Class Initialized
INFO - 2018-02-01 12:57:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 12:57:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 12:57:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 12:57:54 --> Model Class Initialized
INFO - 2018-02-01 12:57:54 --> Model Class Initialized
INFO - 2018-02-01 12:57:54 --> Model Class Initialized
INFO - 2018-02-01 12:57:54 --> Model Class Initialized
INFO - 2018-02-01 12:57:54 --> Model Class Initialized
INFO - 2018-02-01 12:57:54 --> Model Class Initialized
INFO - 2018-02-01 12:57:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 12:57:54 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-01 12:57:54 --> Final output sent to browser
DEBUG - 2018-02-01 12:57:54 --> Total execution time: 0.1232
INFO - 2018-02-01 07:28:37 --> Config Class Initialized
INFO - 2018-02-01 07:28:37 --> Hooks Class Initialized
DEBUG - 2018-02-01 07:28:37 --> UTF-8 Support Enabled
INFO - 2018-02-01 07:28:37 --> Utf8 Class Initialized
INFO - 2018-02-01 07:28:37 --> URI Class Initialized
INFO - 2018-02-01 07:28:37 --> Router Class Initialized
INFO - 2018-02-01 07:28:37 --> Output Class Initialized
INFO - 2018-02-01 07:28:37 --> Security Class Initialized
DEBUG - 2018-02-01 07:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 07:28:37 --> Input Class Initialized
INFO - 2018-02-01 07:28:37 --> Language Class Initialized
INFO - 2018-02-01 07:28:37 --> Language Class Initialized
INFO - 2018-02-01 07:28:37 --> Config Class Initialized
INFO - 2018-02-01 07:28:37 --> Loader Class Initialized
INFO - 2018-02-01 12:58:37 --> Helper loaded: url_helper
INFO - 2018-02-01 12:58:37 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:58:37 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:58:37 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:58:37 --> Helper loaded: users_helper
INFO - 2018-02-01 12:58:37 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:58:37 --> Helper loaded: form_helper
INFO - 2018-02-01 12:58:37 --> Form Validation Class Initialized
INFO - 2018-02-01 12:58:37 --> Controller Class Initialized
INFO - 2018-02-01 12:58:37 --> Model Class Initialized
INFO - 2018-02-01 12:58:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 12:58:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 12:58:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 12:58:37 --> Model Class Initialized
INFO - 2018-02-01 12:58:37 --> Model Class Initialized
INFO - 2018-02-01 12:58:37 --> Model Class Initialized
INFO - 2018-02-01 12:58:37 --> Model Class Initialized
ERROR - 2018-02-01 12:58:37 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/likes/youLike', 'get', 'a:1:{s:8:\"users_id\";s:2:\"34\";}', '111.93.247.154', 1517470117, 1, 'user like list', 1, '34')
INFO - 2018-02-01 12:58:37 --> Final output sent to browser
DEBUG - 2018-02-01 12:58:37 --> Total execution time: 0.1881
INFO - 2018-02-01 07:28:49 --> Config Class Initialized
INFO - 2018-02-01 07:28:49 --> Hooks Class Initialized
DEBUG - 2018-02-01 07:28:49 --> UTF-8 Support Enabled
INFO - 2018-02-01 07:28:49 --> Utf8 Class Initialized
INFO - 2018-02-01 07:28:49 --> URI Class Initialized
INFO - 2018-02-01 07:28:49 --> Router Class Initialized
INFO - 2018-02-01 07:28:49 --> Output Class Initialized
INFO - 2018-02-01 07:28:49 --> Security Class Initialized
DEBUG - 2018-02-01 07:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 07:28:49 --> Input Class Initialized
INFO - 2018-02-01 07:28:49 --> Language Class Initialized
INFO - 2018-02-01 07:28:49 --> Language Class Initialized
INFO - 2018-02-01 07:28:49 --> Config Class Initialized
INFO - 2018-02-01 07:28:49 --> Loader Class Initialized
INFO - 2018-02-01 12:58:49 --> Helper loaded: url_helper
INFO - 2018-02-01 12:58:49 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:58:49 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:58:49 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:58:49 --> Helper loaded: users_helper
INFO - 2018-02-01 12:58:49 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:58:49 --> Helper loaded: form_helper
INFO - 2018-02-01 12:58:49 --> Form Validation Class Initialized
INFO - 2018-02-01 12:58:49 --> Controller Class Initialized
INFO - 2018-02-01 12:58:49 --> Model Class Initialized
INFO - 2018-02-01 12:58:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 12:58:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 12:58:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 12:58:49 --> Model Class Initialized
INFO - 2018-02-01 12:58:49 --> Model Class Initialized
INFO - 2018-02-01 12:58:49 --> Model Class Initialized
INFO - 2018-02-01 12:58:49 --> Model Class Initialized
INFO - 2018-02-01 12:58:49 --> Final output sent to browser
DEBUG - 2018-02-01 12:58:49 --> Total execution time: 0.1137
INFO - 2018-02-01 07:29:08 --> Config Class Initialized
INFO - 2018-02-01 07:29:08 --> Hooks Class Initialized
DEBUG - 2018-02-01 07:29:08 --> UTF-8 Support Enabled
INFO - 2018-02-01 07:29:08 --> Utf8 Class Initialized
INFO - 2018-02-01 07:29:08 --> URI Class Initialized
INFO - 2018-02-01 07:29:08 --> Router Class Initialized
INFO - 2018-02-01 07:29:08 --> Output Class Initialized
INFO - 2018-02-01 07:29:08 --> Security Class Initialized
DEBUG - 2018-02-01 07:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 07:29:08 --> Input Class Initialized
INFO - 2018-02-01 07:29:08 --> Language Class Initialized
INFO - 2018-02-01 07:29:08 --> Language Class Initialized
INFO - 2018-02-01 07:29:08 --> Config Class Initialized
INFO - 2018-02-01 07:29:08 --> Loader Class Initialized
INFO - 2018-02-01 12:59:08 --> Helper loaded: url_helper
INFO - 2018-02-01 12:59:08 --> Helper loaded: notification_helper
INFO - 2018-02-01 12:59:08 --> Helper loaded: settings_helper
INFO - 2018-02-01 12:59:08 --> Helper loaded: permission_helper
INFO - 2018-02-01 12:59:08 --> Helper loaded: users_helper
INFO - 2018-02-01 12:59:08 --> Database Driver Class Initialized
DEBUG - 2018-02-01 12:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 12:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 12:59:08 --> Helper loaded: form_helper
INFO - 2018-02-01 12:59:08 --> Form Validation Class Initialized
INFO - 2018-02-01 12:59:08 --> Controller Class Initialized
INFO - 2018-02-01 12:59:08 --> Model Class Initialized
INFO - 2018-02-01 12:59:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 12:59:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 12:59:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 12:59:08 --> Model Class Initialized
INFO - 2018-02-01 12:59:08 --> Model Class Initialized
INFO - 2018-02-01 12:59:08 --> Model Class Initialized
INFO - 2018-02-01 12:59:08 --> Model Class Initialized
INFO - 2018-02-01 12:59:08 --> Model Class Initialized
INFO - 2018-02-01 12:59:08 --> Model Class Initialized
INFO - 2018-02-01 12:59:08 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 12:59:08 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-01 12:59:08 --> Final output sent to browser
DEBUG - 2018-02-01 12:59:08 --> Total execution time: 0.1088
INFO - 2018-02-01 08:04:27 --> Config Class Initialized
INFO - 2018-02-01 08:04:27 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:04:27 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:04:27 --> Utf8 Class Initialized
INFO - 2018-02-01 08:04:27 --> URI Class Initialized
INFO - 2018-02-01 08:04:27 --> Router Class Initialized
INFO - 2018-02-01 08:04:27 --> Output Class Initialized
INFO - 2018-02-01 08:04:27 --> Security Class Initialized
DEBUG - 2018-02-01 08:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:04:27 --> Input Class Initialized
INFO - 2018-02-01 08:04:27 --> Language Class Initialized
INFO - 2018-02-01 08:04:27 --> Language Class Initialized
INFO - 2018-02-01 08:04:27 --> Config Class Initialized
INFO - 2018-02-01 08:04:27 --> Loader Class Initialized
INFO - 2018-02-01 13:34:27 --> Helper loaded: url_helper
INFO - 2018-02-01 13:34:27 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:34:27 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:34:27 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:34:27 --> Helper loaded: users_helper
INFO - 2018-02-01 13:34:27 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:34:27 --> Helper loaded: form_helper
INFO - 2018-02-01 13:34:27 --> Form Validation Class Initialized
INFO - 2018-02-01 13:34:27 --> Controller Class Initialized
INFO - 2018-02-01 13:34:27 --> Model Class Initialized
INFO - 2018-02-01 13:34:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:34:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:34:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:34:27 --> Model Class Initialized
INFO - 2018-02-01 13:34:27 --> Model Class Initialized
INFO - 2018-02-01 13:34:27 --> Model Class Initialized
INFO - 2018-02-01 13:34:27 --> Model Class Initialized
INFO - 2018-02-01 13:34:27 --> Model Class Initialized
INFO - 2018-02-01 13:34:27 --> Model Class Initialized
INFO - 2018-02-01 13:34:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 13:34:27 --> Final output sent to browser
DEBUG - 2018-02-01 13:34:27 --> Total execution time: 0.1100
INFO - 2018-02-01 08:07:08 --> Config Class Initialized
INFO - 2018-02-01 08:07:08 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:07:08 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:07:08 --> Utf8 Class Initialized
INFO - 2018-02-01 08:07:08 --> URI Class Initialized
INFO - 2018-02-01 08:07:08 --> Router Class Initialized
INFO - 2018-02-01 08:07:08 --> Output Class Initialized
INFO - 2018-02-01 08:07:08 --> Security Class Initialized
DEBUG - 2018-02-01 08:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:07:08 --> Input Class Initialized
INFO - 2018-02-01 08:07:08 --> Language Class Initialized
INFO - 2018-02-01 08:07:08 --> Language Class Initialized
INFO - 2018-02-01 08:07:08 --> Config Class Initialized
INFO - 2018-02-01 08:07:08 --> Loader Class Initialized
INFO - 2018-02-01 13:37:08 --> Helper loaded: url_helper
INFO - 2018-02-01 13:37:08 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:37:08 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:37:08 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:37:08 --> Helper loaded: users_helper
INFO - 2018-02-01 13:37:08 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:37:08 --> Helper loaded: form_helper
INFO - 2018-02-01 13:37:08 --> Form Validation Class Initialized
INFO - 2018-02-01 13:37:08 --> Controller Class Initialized
INFO - 2018-02-01 13:37:08 --> Model Class Initialized
INFO - 2018-02-01 13:37:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:37:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:37:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:37:08 --> Model Class Initialized
INFO - 2018-02-01 13:37:08 --> Model Class Initialized
INFO - 2018-02-01 13:37:08 --> Model Class Initialized
INFO - 2018-02-01 13:37:08 --> Model Class Initialized
INFO - 2018-02-01 13:37:08 --> Model Class Initialized
INFO - 2018-02-01 13:37:08 --> Model Class Initialized
INFO - 2018-02-01 13:37:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 13:37:08 --> Final output sent to browser
DEBUG - 2018-02-01 13:37:08 --> Total execution time: 0.1022
INFO - 2018-02-01 08:12:12 --> Config Class Initialized
INFO - 2018-02-01 08:12:12 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:12:12 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:12:12 --> Utf8 Class Initialized
INFO - 2018-02-01 08:12:12 --> URI Class Initialized
INFO - 2018-02-01 08:12:12 --> Router Class Initialized
INFO - 2018-02-01 08:12:12 --> Output Class Initialized
INFO - 2018-02-01 08:12:12 --> Security Class Initialized
DEBUG - 2018-02-01 08:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:12:12 --> Input Class Initialized
INFO - 2018-02-01 08:12:12 --> Language Class Initialized
INFO - 2018-02-01 08:12:12 --> Language Class Initialized
INFO - 2018-02-01 08:12:12 --> Config Class Initialized
INFO - 2018-02-01 08:12:12 --> Loader Class Initialized
INFO - 2018-02-01 13:42:12 --> Helper loaded: url_helper
INFO - 2018-02-01 13:42:12 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:42:12 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:42:12 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:42:12 --> Helper loaded: users_helper
INFO - 2018-02-01 13:42:12 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:42:12 --> Helper loaded: form_helper
INFO - 2018-02-01 13:42:12 --> Form Validation Class Initialized
INFO - 2018-02-01 13:42:12 --> Controller Class Initialized
INFO - 2018-02-01 13:42:12 --> Model Class Initialized
INFO - 2018-02-01 13:42:12 --> Helper loaded: inflector_helper
INFO - 2018-02-01 13:42:12 --> Model Class Initialized
INFO - 2018-02-01 13:42:12 --> Model Class Initialized
DEBUG - 2018-02-01 13:42:12 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-01 13:42:12 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-02-01 13:42:12 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-01 13:42:12 --> Final output sent to browser
DEBUG - 2018-02-01 13:42:12 --> Total execution time: 0.1011
INFO - 2018-02-01 08:12:14 --> Config Class Initialized
INFO - 2018-02-01 08:12:14 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:12:14 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:12:14 --> Utf8 Class Initialized
INFO - 2018-02-01 08:12:14 --> URI Class Initialized
INFO - 2018-02-01 08:12:14 --> Router Class Initialized
INFO - 2018-02-01 08:12:14 --> Output Class Initialized
INFO - 2018-02-01 08:12:14 --> Security Class Initialized
DEBUG - 2018-02-01 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:12:14 --> Input Class Initialized
INFO - 2018-02-01 08:12:14 --> Language Class Initialized
INFO - 2018-02-01 08:12:14 --> Language Class Initialized
INFO - 2018-02-01 08:12:14 --> Config Class Initialized
INFO - 2018-02-01 08:12:14 --> Loader Class Initialized
INFO - 2018-02-01 13:42:14 --> Helper loaded: url_helper
INFO - 2018-02-01 13:42:14 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:42:14 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:42:14 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:42:14 --> Helper loaded: users_helper
INFO - 2018-02-01 13:42:14 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:42:14 --> Helper loaded: form_helper
INFO - 2018-02-01 13:42:14 --> Form Validation Class Initialized
INFO - 2018-02-01 13:42:14 --> Controller Class Initialized
INFO - 2018-02-01 13:42:14 --> Model Class Initialized
INFO - 2018-02-01 13:42:14 --> Helper loaded: inflector_helper
INFO - 2018-02-01 13:42:14 --> Model Class Initialized
INFO - 2018-02-01 13:42:14 --> Model Class Initialized
INFO - 2018-02-01 13:42:14 --> Model Class Initialized
INFO - 2018-02-01 13:42:14 --> Final output sent to browser
DEBUG - 2018-02-01 13:42:14 --> Total execution time: 0.1002
INFO - 2018-02-01 08:13:40 --> Config Class Initialized
INFO - 2018-02-01 08:13:40 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:13:40 --> Utf8 Class Initialized
INFO - 2018-02-01 08:13:40 --> URI Class Initialized
INFO - 2018-02-01 08:13:40 --> Router Class Initialized
INFO - 2018-02-01 08:13:40 --> Output Class Initialized
INFO - 2018-02-01 08:13:40 --> Security Class Initialized
DEBUG - 2018-02-01 08:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:13:40 --> Input Class Initialized
INFO - 2018-02-01 08:13:40 --> Language Class Initialized
INFO - 2018-02-01 08:13:40 --> Language Class Initialized
INFO - 2018-02-01 08:13:40 --> Config Class Initialized
INFO - 2018-02-01 08:13:40 --> Loader Class Initialized
INFO - 2018-02-01 13:43:40 --> Helper loaded: url_helper
INFO - 2018-02-01 13:43:40 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:43:40 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:43:40 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:43:40 --> Helper loaded: users_helper
INFO - 2018-02-01 13:43:40 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:43:40 --> Helper loaded: form_helper
INFO - 2018-02-01 13:43:40 --> Form Validation Class Initialized
INFO - 2018-02-01 13:43:40 --> Controller Class Initialized
INFO - 2018-02-01 13:43:40 --> Model Class Initialized
INFO - 2018-02-01 13:43:40 --> Helper loaded: inflector_helper
INFO - 2018-02-01 13:43:40 --> Model Class Initialized
INFO - 2018-02-01 13:43:40 --> Model Class Initialized
DEBUG - 2018-02-01 13:43:40 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-01 13:43:40 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-02-01 13:43:40 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-01 13:43:40 --> Final output sent to browser
DEBUG - 2018-02-01 13:43:40 --> Total execution time: 0.0920
INFO - 2018-02-01 08:13:40 --> Config Class Initialized
INFO - 2018-02-01 08:13:40 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:13:40 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:13:40 --> Utf8 Class Initialized
INFO - 2018-02-01 08:13:40 --> URI Class Initialized
INFO - 2018-02-01 08:13:40 --> Router Class Initialized
INFO - 2018-02-01 08:13:40 --> Output Class Initialized
INFO - 2018-02-01 08:13:40 --> Security Class Initialized
DEBUG - 2018-02-01 08:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:13:40 --> Input Class Initialized
INFO - 2018-02-01 08:13:41 --> Language Class Initialized
INFO - 2018-02-01 08:13:41 --> Language Class Initialized
INFO - 2018-02-01 08:13:41 --> Config Class Initialized
INFO - 2018-02-01 08:13:41 --> Loader Class Initialized
INFO - 2018-02-01 13:43:41 --> Helper loaded: url_helper
INFO - 2018-02-01 13:43:41 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:43:41 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:43:41 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:43:41 --> Helper loaded: users_helper
INFO - 2018-02-01 13:43:41 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:43:41 --> Helper loaded: form_helper
INFO - 2018-02-01 13:43:41 --> Form Validation Class Initialized
INFO - 2018-02-01 13:43:41 --> Controller Class Initialized
INFO - 2018-02-01 13:43:41 --> Model Class Initialized
INFO - 2018-02-01 13:43:41 --> Helper loaded: inflector_helper
INFO - 2018-02-01 13:43:41 --> Model Class Initialized
INFO - 2018-02-01 13:43:41 --> Model Class Initialized
INFO - 2018-02-01 13:43:41 --> Model Class Initialized
INFO - 2018-02-01 13:43:41 --> Final output sent to browser
DEBUG - 2018-02-01 13:43:41 --> Total execution time: 0.0903
INFO - 2018-02-01 08:13:48 --> Config Class Initialized
INFO - 2018-02-01 08:13:48 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:13:48 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:13:48 --> Utf8 Class Initialized
INFO - 2018-02-01 08:13:48 --> URI Class Initialized
INFO - 2018-02-01 08:13:48 --> Router Class Initialized
INFO - 2018-02-01 08:13:48 --> Output Class Initialized
INFO - 2018-02-01 08:13:48 --> Security Class Initialized
DEBUG - 2018-02-01 08:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:13:48 --> Input Class Initialized
INFO - 2018-02-01 08:13:48 --> Language Class Initialized
INFO - 2018-02-01 08:13:48 --> Language Class Initialized
INFO - 2018-02-01 08:13:48 --> Config Class Initialized
INFO - 2018-02-01 08:13:48 --> Loader Class Initialized
INFO - 2018-02-01 13:43:48 --> Helper loaded: url_helper
INFO - 2018-02-01 13:43:48 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:43:48 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:43:48 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:43:48 --> Helper loaded: users_helper
INFO - 2018-02-01 13:43:48 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:43:48 --> Helper loaded: form_helper
INFO - 2018-02-01 13:43:48 --> Form Validation Class Initialized
INFO - 2018-02-01 13:43:48 --> Controller Class Initialized
INFO - 2018-02-01 13:43:48 --> Model Class Initialized
INFO - 2018-02-01 13:43:48 --> Helper loaded: inflector_helper
INFO - 2018-02-01 13:43:48 --> Model Class Initialized
INFO - 2018-02-01 13:43:48 --> Model Class Initialized
INFO - 2018-02-01 13:43:48 --> Model Class Initialized
INFO - 2018-02-01 13:43:48 --> Final output sent to browser
DEBUG - 2018-02-01 13:43:48 --> Total execution time: 0.0910
INFO - 2018-02-01 08:13:49 --> Config Class Initialized
INFO - 2018-02-01 08:13:49 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:13:49 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:13:49 --> Utf8 Class Initialized
INFO - 2018-02-01 08:13:49 --> URI Class Initialized
INFO - 2018-02-01 08:13:49 --> Router Class Initialized
INFO - 2018-02-01 08:13:49 --> Output Class Initialized
INFO - 2018-02-01 08:13:49 --> Security Class Initialized
DEBUG - 2018-02-01 08:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:13:49 --> Input Class Initialized
INFO - 2018-02-01 08:13:49 --> Language Class Initialized
INFO - 2018-02-01 08:13:49 --> Language Class Initialized
INFO - 2018-02-01 08:13:49 --> Config Class Initialized
INFO - 2018-02-01 08:13:49 --> Loader Class Initialized
INFO - 2018-02-01 13:43:49 --> Helper loaded: url_helper
INFO - 2018-02-01 13:43:49 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:43:49 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:43:49 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:43:49 --> Helper loaded: users_helper
INFO - 2018-02-01 13:43:49 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:43:49 --> Helper loaded: form_helper
INFO - 2018-02-01 13:43:49 --> Form Validation Class Initialized
INFO - 2018-02-01 13:43:49 --> Controller Class Initialized
INFO - 2018-02-01 13:43:49 --> Model Class Initialized
INFO - 2018-02-01 13:43:49 --> Helper loaded: inflector_helper
INFO - 2018-02-01 13:43:49 --> Model Class Initialized
INFO - 2018-02-01 13:43:49 --> Model Class Initialized
INFO - 2018-02-01 13:43:49 --> Model Class Initialized
INFO - 2018-02-01 13:43:49 --> Final output sent to browser
DEBUG - 2018-02-01 13:43:49 --> Total execution time: 0.0860
INFO - 2018-02-01 08:13:50 --> Config Class Initialized
INFO - 2018-02-01 08:13:50 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:13:50 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:13:50 --> Utf8 Class Initialized
INFO - 2018-02-01 08:13:50 --> URI Class Initialized
INFO - 2018-02-01 08:13:50 --> Router Class Initialized
INFO - 2018-02-01 08:13:50 --> Output Class Initialized
INFO - 2018-02-01 08:13:50 --> Security Class Initialized
DEBUG - 2018-02-01 08:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:13:50 --> Input Class Initialized
INFO - 2018-02-01 08:13:50 --> Language Class Initialized
INFO - 2018-02-01 08:13:50 --> Language Class Initialized
INFO - 2018-02-01 08:13:50 --> Config Class Initialized
INFO - 2018-02-01 08:13:50 --> Loader Class Initialized
INFO - 2018-02-01 13:43:50 --> Helper loaded: url_helper
INFO - 2018-02-01 13:43:50 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:43:50 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:43:50 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:43:50 --> Helper loaded: users_helper
INFO - 2018-02-01 13:43:50 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:43:50 --> Helper loaded: form_helper
INFO - 2018-02-01 13:43:50 --> Form Validation Class Initialized
INFO - 2018-02-01 13:43:50 --> Controller Class Initialized
INFO - 2018-02-01 13:43:50 --> Model Class Initialized
INFO - 2018-02-01 13:43:50 --> Helper loaded: inflector_helper
INFO - 2018-02-01 13:43:50 --> Model Class Initialized
INFO - 2018-02-01 13:43:50 --> Model Class Initialized
INFO - 2018-02-01 13:43:50 --> Model Class Initialized
INFO - 2018-02-01 13:43:50 --> Final output sent to browser
DEBUG - 2018-02-01 13:43:50 --> Total execution time: 0.0912
INFO - 2018-02-01 08:14:45 --> Config Class Initialized
INFO - 2018-02-01 08:14:45 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:14:45 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:14:45 --> Utf8 Class Initialized
INFO - 2018-02-01 08:14:45 --> URI Class Initialized
INFO - 2018-02-01 08:14:45 --> Router Class Initialized
INFO - 2018-02-01 08:14:45 --> Output Class Initialized
INFO - 2018-02-01 08:14:45 --> Security Class Initialized
DEBUG - 2018-02-01 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:14:45 --> Input Class Initialized
INFO - 2018-02-01 08:14:45 --> Language Class Initialized
INFO - 2018-02-01 08:14:45 --> Language Class Initialized
INFO - 2018-02-01 08:14:45 --> Config Class Initialized
INFO - 2018-02-01 08:14:45 --> Loader Class Initialized
INFO - 2018-02-01 13:44:45 --> Helper loaded: url_helper
INFO - 2018-02-01 13:44:45 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:44:45 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:44:45 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:44:45 --> Helper loaded: users_helper
INFO - 2018-02-01 13:44:46 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:44:46 --> Helper loaded: form_helper
INFO - 2018-02-01 13:44:46 --> Form Validation Class Initialized
INFO - 2018-02-01 13:44:46 --> Controller Class Initialized
INFO - 2018-02-01 13:44:46 --> Model Class Initialized
INFO - 2018-02-01 13:44:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:44:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:44:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:44:46 --> Model Class Initialized
INFO - 2018-02-01 13:44:46 --> Model Class Initialized
INFO - 2018-02-01 13:44:46 --> Model Class Initialized
INFO - 2018-02-01 13:44:46 --> Model Class Initialized
ERROR - 2018-02-01 13:44:46 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`pr01004_1`.`logs`, CONSTRAINT `logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `ip_address`, `time`, `authorized`, `message`, `status`, `user_id`) VALUES ('api/likes/youLike', 'get', 'a:1:{s:8:\"users_id\";s:4:\"3461\";}', '111.93.247.154', 1517472886, 1, 'user like list', 1, '3461')
INFO - 2018-02-01 13:44:46 --> Final output sent to browser
DEBUG - 2018-02-01 13:44:46 --> Total execution time: 0.0845
INFO - 2018-02-01 08:14:50 --> Config Class Initialized
INFO - 2018-02-01 08:14:50 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:14:50 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:14:50 --> Utf8 Class Initialized
INFO - 2018-02-01 08:14:50 --> URI Class Initialized
INFO - 2018-02-01 08:14:50 --> Router Class Initialized
INFO - 2018-02-01 08:14:50 --> Output Class Initialized
INFO - 2018-02-01 08:14:50 --> Security Class Initialized
DEBUG - 2018-02-01 08:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:14:50 --> Input Class Initialized
INFO - 2018-02-01 08:14:50 --> Language Class Initialized
INFO - 2018-02-01 08:14:50 --> Language Class Initialized
INFO - 2018-02-01 08:14:50 --> Config Class Initialized
INFO - 2018-02-01 08:14:50 --> Loader Class Initialized
INFO - 2018-02-01 13:44:50 --> Helper loaded: url_helper
INFO - 2018-02-01 13:44:50 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:44:50 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:44:50 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:44:50 --> Helper loaded: users_helper
INFO - 2018-02-01 13:44:50 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:44:50 --> Helper loaded: form_helper
INFO - 2018-02-01 13:44:50 --> Form Validation Class Initialized
INFO - 2018-02-01 13:44:50 --> Controller Class Initialized
INFO - 2018-02-01 13:44:50 --> Model Class Initialized
INFO - 2018-02-01 13:44:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:44:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:44:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:44:50 --> Model Class Initialized
INFO - 2018-02-01 13:44:50 --> Model Class Initialized
INFO - 2018-02-01 13:44:50 --> Model Class Initialized
INFO - 2018-02-01 13:44:50 --> Model Class Initialized
INFO - 2018-02-01 13:44:50 --> Final output sent to browser
DEBUG - 2018-02-01 13:44:50 --> Total execution time: 0.1089
INFO - 2018-02-01 08:15:00 --> Config Class Initialized
INFO - 2018-02-01 08:15:00 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:15:00 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:15:00 --> Utf8 Class Initialized
INFO - 2018-02-01 08:15:00 --> URI Class Initialized
INFO - 2018-02-01 08:15:00 --> Router Class Initialized
INFO - 2018-02-01 08:15:00 --> Output Class Initialized
INFO - 2018-02-01 08:15:00 --> Security Class Initialized
DEBUG - 2018-02-01 08:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:15:00 --> Input Class Initialized
INFO - 2018-02-01 08:15:00 --> Language Class Initialized
INFO - 2018-02-01 08:15:00 --> Language Class Initialized
INFO - 2018-02-01 08:15:00 --> Config Class Initialized
INFO - 2018-02-01 08:15:00 --> Loader Class Initialized
INFO - 2018-02-01 13:45:00 --> Helper loaded: url_helper
INFO - 2018-02-01 13:45:00 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:45:00 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:45:00 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:45:00 --> Helper loaded: users_helper
INFO - 2018-02-01 13:45:00 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:45:00 --> Helper loaded: form_helper
INFO - 2018-02-01 13:45:00 --> Form Validation Class Initialized
INFO - 2018-02-01 13:45:00 --> Controller Class Initialized
INFO - 2018-02-01 13:45:00 --> Model Class Initialized
INFO - 2018-02-01 13:45:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:45:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:45:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:45:00 --> Model Class Initialized
INFO - 2018-02-01 13:45:00 --> Model Class Initialized
INFO - 2018-02-01 13:45:00 --> Model Class Initialized
INFO - 2018-02-01 13:45:00 --> Model Class Initialized
INFO - 2018-02-01 13:45:00 --> Final output sent to browser
DEBUG - 2018-02-01 13:45:00 --> Total execution time: 0.1042
INFO - 2018-02-01 08:16:22 --> Config Class Initialized
INFO - 2018-02-01 08:16:22 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:16:22 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:16:22 --> Utf8 Class Initialized
INFO - 2018-02-01 08:16:22 --> URI Class Initialized
INFO - 2018-02-01 08:16:22 --> Router Class Initialized
INFO - 2018-02-01 08:16:22 --> Output Class Initialized
INFO - 2018-02-01 08:16:22 --> Security Class Initialized
DEBUG - 2018-02-01 08:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:16:22 --> Input Class Initialized
INFO - 2018-02-01 08:16:22 --> Language Class Initialized
INFO - 2018-02-01 08:16:22 --> Language Class Initialized
INFO - 2018-02-01 08:16:22 --> Config Class Initialized
INFO - 2018-02-01 08:16:22 --> Loader Class Initialized
INFO - 2018-02-01 13:46:22 --> Helper loaded: url_helper
INFO - 2018-02-01 13:46:22 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:46:22 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:46:22 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:46:22 --> Helper loaded: users_helper
INFO - 2018-02-01 13:46:22 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:46:22 --> Helper loaded: form_helper
INFO - 2018-02-01 13:46:22 --> Form Validation Class Initialized
INFO - 2018-02-01 13:46:22 --> Controller Class Initialized
INFO - 2018-02-01 13:46:22 --> Model Class Initialized
INFO - 2018-02-01 13:46:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:46:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:46:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:46:22 --> Model Class Initialized
INFO - 2018-02-01 13:46:22 --> Model Class Initialized
INFO - 2018-02-01 13:46:22 --> Model Class Initialized
INFO - 2018-02-01 13:46:22 --> Model Class Initialized
INFO - 2018-02-01 13:46:22 --> Final output sent to browser
DEBUG - 2018-02-01 13:46:22 --> Total execution time: 0.1037
INFO - 2018-02-01 08:25:52 --> Config Class Initialized
INFO - 2018-02-01 08:25:52 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:25:52 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:25:52 --> Utf8 Class Initialized
INFO - 2018-02-01 08:25:52 --> URI Class Initialized
INFO - 2018-02-01 08:25:52 --> Router Class Initialized
INFO - 2018-02-01 08:25:52 --> Output Class Initialized
INFO - 2018-02-01 08:25:52 --> Security Class Initialized
DEBUG - 2018-02-01 08:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:25:52 --> Input Class Initialized
INFO - 2018-02-01 08:25:52 --> Language Class Initialized
INFO - 2018-02-01 08:25:52 --> Language Class Initialized
INFO - 2018-02-01 08:25:52 --> Config Class Initialized
INFO - 2018-02-01 08:25:52 --> Loader Class Initialized
INFO - 2018-02-01 13:55:52 --> Helper loaded: url_helper
INFO - 2018-02-01 13:55:52 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:55:52 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:55:52 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:55:52 --> Helper loaded: users_helper
INFO - 2018-02-01 13:55:52 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:55:52 --> Helper loaded: form_helper
INFO - 2018-02-01 13:55:52 --> Form Validation Class Initialized
INFO - 2018-02-01 13:55:52 --> Controller Class Initialized
INFO - 2018-02-01 13:55:52 --> Model Class Initialized
INFO - 2018-02-01 13:55:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:55:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:55:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:55:52 --> Model Class Initialized
INFO - 2018-02-01 13:55:52 --> Model Class Initialized
INFO - 2018-02-01 13:55:52 --> Model Class Initialized
INFO - 2018-02-01 13:55:52 --> Model Class Initialized
INFO - 2018-02-01 13:55:52 --> Final output sent to browser
DEBUG - 2018-02-01 13:55:52 --> Total execution time: 0.1014
INFO - 2018-02-01 08:26:10 --> Config Class Initialized
INFO - 2018-02-01 08:26:10 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:26:10 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:26:10 --> Utf8 Class Initialized
INFO - 2018-02-01 08:26:10 --> URI Class Initialized
INFO - 2018-02-01 08:26:10 --> Router Class Initialized
INFO - 2018-02-01 08:26:10 --> Output Class Initialized
INFO - 2018-02-01 08:26:10 --> Security Class Initialized
DEBUG - 2018-02-01 08:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:26:10 --> Input Class Initialized
INFO - 2018-02-01 08:26:10 --> Language Class Initialized
INFO - 2018-02-01 08:26:10 --> Language Class Initialized
INFO - 2018-02-01 08:26:10 --> Config Class Initialized
INFO - 2018-02-01 08:26:10 --> Loader Class Initialized
INFO - 2018-02-01 13:56:10 --> Helper loaded: url_helper
INFO - 2018-02-01 13:56:10 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:56:10 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:56:10 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:56:10 --> Helper loaded: users_helper
INFO - 2018-02-01 13:56:10 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:56:10 --> Helper loaded: form_helper
INFO - 2018-02-01 13:56:10 --> Form Validation Class Initialized
INFO - 2018-02-01 13:56:10 --> Controller Class Initialized
INFO - 2018-02-01 13:56:10 --> Model Class Initialized
INFO - 2018-02-01 13:56:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:56:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:56:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:56:10 --> Model Class Initialized
INFO - 2018-02-01 13:56:10 --> Model Class Initialized
INFO - 2018-02-01 13:56:10 --> Model Class Initialized
INFO - 2018-02-01 13:56:10 --> Model Class Initialized
INFO - 2018-02-01 13:56:10 --> Model Class Initialized
INFO - 2018-02-01 13:56:10 --> Model Class Initialized
INFO - 2018-02-01 13:56:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 13:56:10 --> Final output sent to browser
DEBUG - 2018-02-01 13:56:10 --> Total execution time: 0.1196
INFO - 2018-02-01 08:26:11 --> Config Class Initialized
INFO - 2018-02-01 08:26:11 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:26:11 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:26:11 --> Utf8 Class Initialized
INFO - 2018-02-01 08:26:11 --> URI Class Initialized
INFO - 2018-02-01 08:26:11 --> Router Class Initialized
INFO - 2018-02-01 08:26:11 --> Output Class Initialized
INFO - 2018-02-01 08:26:11 --> Security Class Initialized
DEBUG - 2018-02-01 08:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:26:11 --> Input Class Initialized
INFO - 2018-02-01 08:26:11 --> Language Class Initialized
INFO - 2018-02-01 08:26:11 --> Language Class Initialized
INFO - 2018-02-01 08:26:11 --> Config Class Initialized
INFO - 2018-02-01 08:26:11 --> Loader Class Initialized
INFO - 2018-02-01 13:56:11 --> Helper loaded: url_helper
INFO - 2018-02-01 13:56:11 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:56:11 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:56:11 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:56:11 --> Helper loaded: users_helper
INFO - 2018-02-01 13:56:11 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:56:11 --> Helper loaded: form_helper
INFO - 2018-02-01 13:56:11 --> Form Validation Class Initialized
INFO - 2018-02-01 13:56:11 --> Controller Class Initialized
INFO - 2018-02-01 13:56:11 --> Model Class Initialized
INFO - 2018-02-01 13:56:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:56:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:56:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:56:11 --> Model Class Initialized
INFO - 2018-02-01 13:56:11 --> Model Class Initialized
INFO - 2018-02-01 13:56:11 --> Model Class Initialized
INFO - 2018-02-01 13:56:11 --> Model Class Initialized
INFO - 2018-02-01 13:56:11 --> Final output sent to browser
DEBUG - 2018-02-01 13:56:11 --> Total execution time: 0.0964
INFO - 2018-02-01 08:26:16 --> Config Class Initialized
INFO - 2018-02-01 08:26:16 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:26:16 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:26:16 --> Utf8 Class Initialized
INFO - 2018-02-01 08:26:16 --> URI Class Initialized
INFO - 2018-02-01 08:26:16 --> Router Class Initialized
INFO - 2018-02-01 08:26:16 --> Output Class Initialized
INFO - 2018-02-01 08:26:16 --> Security Class Initialized
DEBUG - 2018-02-01 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:26:16 --> Input Class Initialized
INFO - 2018-02-01 08:26:16 --> Language Class Initialized
INFO - 2018-02-01 08:26:16 --> Language Class Initialized
INFO - 2018-02-01 08:26:16 --> Config Class Initialized
INFO - 2018-02-01 08:26:16 --> Loader Class Initialized
INFO - 2018-02-01 13:56:16 --> Helper loaded: url_helper
INFO - 2018-02-01 13:56:16 --> Helper loaded: notification_helper
INFO - 2018-02-01 13:56:16 --> Helper loaded: settings_helper
INFO - 2018-02-01 13:56:16 --> Helper loaded: permission_helper
INFO - 2018-02-01 13:56:16 --> Helper loaded: users_helper
INFO - 2018-02-01 13:56:16 --> Database Driver Class Initialized
DEBUG - 2018-02-01 13:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 13:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 13:56:17 --> Helper loaded: form_helper
INFO - 2018-02-01 13:56:17 --> Form Validation Class Initialized
INFO - 2018-02-01 13:56:17 --> Controller Class Initialized
INFO - 2018-02-01 13:56:17 --> Model Class Initialized
INFO - 2018-02-01 13:56:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 13:56:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 13:56:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 13:56:17 --> Model Class Initialized
INFO - 2018-02-01 13:56:17 --> Model Class Initialized
INFO - 2018-02-01 13:56:17 --> Model Class Initialized
INFO - 2018-02-01 13:56:17 --> Model Class Initialized
INFO - 2018-02-01 13:56:17 --> Model Class Initialized
INFO - 2018-02-01 13:56:17 --> Model Class Initialized
INFO - 2018-02-01 13:56:17 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 13:56:17 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 771
INFO - 2018-02-01 13:56:17 --> Final output sent to browser
DEBUG - 2018-02-01 13:56:17 --> Total execution time: 0.1201
INFO - 2018-02-01 08:34:09 --> Config Class Initialized
INFO - 2018-02-01 08:34:09 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:34:09 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:34:09 --> Utf8 Class Initialized
INFO - 2018-02-01 08:34:09 --> URI Class Initialized
INFO - 2018-02-01 08:34:09 --> Router Class Initialized
INFO - 2018-02-01 08:34:09 --> Output Class Initialized
INFO - 2018-02-01 08:34:09 --> Security Class Initialized
DEBUG - 2018-02-01 08:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:34:09 --> Input Class Initialized
INFO - 2018-02-01 08:34:09 --> Language Class Initialized
INFO - 2018-02-01 08:34:09 --> Language Class Initialized
INFO - 2018-02-01 08:34:09 --> Config Class Initialized
INFO - 2018-02-01 08:34:09 --> Loader Class Initialized
INFO - 2018-02-01 14:04:09 --> Helper loaded: url_helper
INFO - 2018-02-01 14:04:09 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:04:09 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:04:09 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:04:09 --> Helper loaded: users_helper
INFO - 2018-02-01 14:04:09 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:04:09 --> Helper loaded: form_helper
INFO - 2018-02-01 14:04:09 --> Form Validation Class Initialized
INFO - 2018-02-01 14:04:09 --> Controller Class Initialized
INFO - 2018-02-01 14:04:09 --> Model Class Initialized
INFO - 2018-02-01 14:04:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:04:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:04:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:04:09 --> Model Class Initialized
INFO - 2018-02-01 14:04:09 --> Model Class Initialized
INFO - 2018-02-01 14:04:09 --> Model Class Initialized
INFO - 2018-02-01 14:04:09 --> Model Class Initialized
INFO - 2018-02-01 14:04:09 --> Model Class Initialized
INFO - 2018-02-01 14:04:09 --> Model Class Initialized
INFO - 2018-02-01 14:04:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 14:04:09 --> Final output sent to browser
DEBUG - 2018-02-01 14:04:09 --> Total execution time: 0.0834
INFO - 2018-02-01 08:34:16 --> Config Class Initialized
INFO - 2018-02-01 08:34:16 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:34:16 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:34:16 --> Utf8 Class Initialized
INFO - 2018-02-01 08:34:16 --> URI Class Initialized
INFO - 2018-02-01 08:34:16 --> Router Class Initialized
INFO - 2018-02-01 08:34:16 --> Output Class Initialized
INFO - 2018-02-01 08:34:16 --> Security Class Initialized
DEBUG - 2018-02-01 08:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:34:16 --> Input Class Initialized
INFO - 2018-02-01 08:34:16 --> Language Class Initialized
INFO - 2018-02-01 08:34:16 --> Language Class Initialized
INFO - 2018-02-01 08:34:16 --> Config Class Initialized
INFO - 2018-02-01 08:34:16 --> Loader Class Initialized
INFO - 2018-02-01 14:04:16 --> Helper loaded: url_helper
INFO - 2018-02-01 14:04:16 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:04:16 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:04:16 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:04:16 --> Helper loaded: users_helper
INFO - 2018-02-01 14:04:16 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:04:16 --> Helper loaded: form_helper
INFO - 2018-02-01 14:04:16 --> Form Validation Class Initialized
INFO - 2018-02-01 14:04:16 --> Controller Class Initialized
INFO - 2018-02-01 14:04:16 --> Model Class Initialized
INFO - 2018-02-01 14:04:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:04:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:04:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:04:16 --> Model Class Initialized
INFO - 2018-02-01 14:04:16 --> Model Class Initialized
INFO - 2018-02-01 14:04:16 --> Model Class Initialized
INFO - 2018-02-01 14:04:16 --> Model Class Initialized
INFO - 2018-02-01 14:04:16 --> Final output sent to browser
DEBUG - 2018-02-01 14:04:16 --> Total execution time: 0.1041
INFO - 2018-02-01 08:34:26 --> Config Class Initialized
INFO - 2018-02-01 08:34:26 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:34:26 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:34:26 --> Utf8 Class Initialized
INFO - 2018-02-01 08:34:26 --> URI Class Initialized
INFO - 2018-02-01 08:34:26 --> Router Class Initialized
INFO - 2018-02-01 08:34:26 --> Output Class Initialized
INFO - 2018-02-01 08:34:26 --> Security Class Initialized
DEBUG - 2018-02-01 08:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:34:26 --> Input Class Initialized
INFO - 2018-02-01 08:34:26 --> Language Class Initialized
INFO - 2018-02-01 08:34:26 --> Language Class Initialized
INFO - 2018-02-01 08:34:26 --> Config Class Initialized
INFO - 2018-02-01 08:34:26 --> Loader Class Initialized
INFO - 2018-02-01 14:04:26 --> Helper loaded: url_helper
INFO - 2018-02-01 14:04:26 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:04:26 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:04:26 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:04:26 --> Helper loaded: users_helper
INFO - 2018-02-01 14:04:26 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:04:26 --> Helper loaded: form_helper
INFO - 2018-02-01 14:04:26 --> Form Validation Class Initialized
INFO - 2018-02-01 14:04:26 --> Controller Class Initialized
INFO - 2018-02-01 14:04:26 --> Model Class Initialized
INFO - 2018-02-01 14:04:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:04:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:04:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:04:26 --> Model Class Initialized
INFO - 2018-02-01 14:04:26 --> Model Class Initialized
INFO - 2018-02-01 14:04:26 --> Model Class Initialized
INFO - 2018-02-01 14:04:26 --> Model Class Initialized
INFO - 2018-02-01 14:04:26 --> Final output sent to browser
DEBUG - 2018-02-01 14:04:26 --> Total execution time: 0.1068
INFO - 2018-02-01 08:40:00 --> Config Class Initialized
INFO - 2018-02-01 08:40:00 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:40:00 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:40:00 --> Utf8 Class Initialized
INFO - 2018-02-01 08:40:00 --> URI Class Initialized
INFO - 2018-02-01 08:40:00 --> Router Class Initialized
INFO - 2018-02-01 08:40:00 --> Output Class Initialized
INFO - 2018-02-01 08:40:00 --> Security Class Initialized
DEBUG - 2018-02-01 08:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:40:00 --> Input Class Initialized
INFO - 2018-02-01 08:40:00 --> Language Class Initialized
INFO - 2018-02-01 08:40:00 --> Language Class Initialized
INFO - 2018-02-01 08:40:00 --> Config Class Initialized
INFO - 2018-02-01 08:40:00 --> Loader Class Initialized
INFO - 2018-02-01 14:10:00 --> Helper loaded: url_helper
INFO - 2018-02-01 14:10:00 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:10:00 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:10:00 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:10:00 --> Helper loaded: users_helper
INFO - 2018-02-01 14:10:00 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:10:00 --> Helper loaded: form_helper
INFO - 2018-02-01 14:10:00 --> Form Validation Class Initialized
INFO - 2018-02-01 14:10:00 --> Controller Class Initialized
INFO - 2018-02-01 14:10:00 --> Model Class Initialized
INFO - 2018-02-01 14:10:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:10:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:10:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:10:00 --> Model Class Initialized
INFO - 2018-02-01 14:10:00 --> Model Class Initialized
INFO - 2018-02-01 14:10:00 --> Model Class Initialized
INFO - 2018-02-01 14:10:00 --> Model Class Initialized
INFO - 2018-02-01 14:10:00 --> Final output sent to browser
DEBUG - 2018-02-01 14:10:00 --> Total execution time: 0.1014
INFO - 2018-02-01 08:41:15 --> Config Class Initialized
INFO - 2018-02-01 08:41:15 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:41:15 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:41:15 --> Utf8 Class Initialized
INFO - 2018-02-01 08:41:15 --> URI Class Initialized
INFO - 2018-02-01 08:41:15 --> Router Class Initialized
INFO - 2018-02-01 08:41:15 --> Output Class Initialized
INFO - 2018-02-01 08:41:15 --> Security Class Initialized
DEBUG - 2018-02-01 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:41:15 --> Input Class Initialized
INFO - 2018-02-01 08:41:15 --> Language Class Initialized
INFO - 2018-02-01 08:41:15 --> Language Class Initialized
INFO - 2018-02-01 08:41:15 --> Config Class Initialized
INFO - 2018-02-01 08:41:15 --> Loader Class Initialized
INFO - 2018-02-01 14:11:15 --> Helper loaded: url_helper
INFO - 2018-02-01 14:11:15 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:11:15 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:11:15 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:11:15 --> Helper loaded: users_helper
INFO - 2018-02-01 14:11:15 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:11:15 --> Helper loaded: form_helper
INFO - 2018-02-01 14:11:15 --> Form Validation Class Initialized
INFO - 2018-02-01 14:11:15 --> Controller Class Initialized
INFO - 2018-02-01 14:11:15 --> Model Class Initialized
INFO - 2018-02-01 14:11:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:11:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:11:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:11:15 --> Model Class Initialized
INFO - 2018-02-01 14:11:15 --> Model Class Initialized
INFO - 2018-02-01 14:11:15 --> Model Class Initialized
INFO - 2018-02-01 14:11:15 --> Model Class Initialized
INFO - 2018-02-01 14:11:15 --> Final output sent to browser
DEBUG - 2018-02-01 14:11:15 --> Total execution time: 0.0771
INFO - 2018-02-01 08:42:12 --> Config Class Initialized
INFO - 2018-02-01 08:42:12 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:42:12 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:42:12 --> Utf8 Class Initialized
INFO - 2018-02-01 08:42:12 --> URI Class Initialized
INFO - 2018-02-01 08:42:12 --> Router Class Initialized
INFO - 2018-02-01 08:42:12 --> Output Class Initialized
INFO - 2018-02-01 08:42:12 --> Security Class Initialized
DEBUG - 2018-02-01 08:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:42:12 --> Input Class Initialized
INFO - 2018-02-01 08:42:12 --> Language Class Initialized
INFO - 2018-02-01 08:42:12 --> Language Class Initialized
INFO - 2018-02-01 08:42:12 --> Config Class Initialized
INFO - 2018-02-01 08:42:12 --> Loader Class Initialized
INFO - 2018-02-01 14:12:12 --> Helper loaded: url_helper
INFO - 2018-02-01 14:12:12 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:12:12 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:12:12 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:12:12 --> Helper loaded: users_helper
INFO - 2018-02-01 14:12:12 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:12:12 --> Helper loaded: form_helper
INFO - 2018-02-01 14:12:12 --> Form Validation Class Initialized
INFO - 2018-02-01 14:12:12 --> Controller Class Initialized
INFO - 2018-02-01 14:12:12 --> Model Class Initialized
INFO - 2018-02-01 14:12:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:12:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:12:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:12:12 --> Model Class Initialized
INFO - 2018-02-01 14:12:12 --> Model Class Initialized
INFO - 2018-02-01 14:12:12 --> Model Class Initialized
INFO - 2018-02-01 14:12:12 --> Model Class Initialized
INFO - 2018-02-01 14:12:12 --> Final output sent to browser
DEBUG - 2018-02-01 14:12:12 --> Total execution time: 0.0766
INFO - 2018-02-01 08:43:06 --> Config Class Initialized
INFO - 2018-02-01 08:43:06 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:43:06 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:43:06 --> Utf8 Class Initialized
INFO - 2018-02-01 08:43:06 --> URI Class Initialized
INFO - 2018-02-01 08:43:06 --> Router Class Initialized
INFO - 2018-02-01 08:43:06 --> Output Class Initialized
INFO - 2018-02-01 08:43:06 --> Security Class Initialized
DEBUG - 2018-02-01 08:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:43:06 --> Input Class Initialized
INFO - 2018-02-01 08:43:06 --> Language Class Initialized
INFO - 2018-02-01 08:43:06 --> Language Class Initialized
INFO - 2018-02-01 08:43:06 --> Config Class Initialized
INFO - 2018-02-01 08:43:06 --> Loader Class Initialized
INFO - 2018-02-01 14:13:06 --> Helper loaded: url_helper
INFO - 2018-02-01 14:13:06 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:13:06 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:13:06 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:13:06 --> Helper loaded: users_helper
INFO - 2018-02-01 14:13:06 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:13:06 --> Helper loaded: form_helper
INFO - 2018-02-01 14:13:06 --> Form Validation Class Initialized
INFO - 2018-02-01 14:13:06 --> Controller Class Initialized
INFO - 2018-02-01 14:13:06 --> Model Class Initialized
INFO - 2018-02-01 14:13:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:13:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:13:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:13:06 --> Model Class Initialized
INFO - 2018-02-01 14:13:06 --> Model Class Initialized
INFO - 2018-02-01 14:13:06 --> Model Class Initialized
INFO - 2018-02-01 14:13:06 --> Model Class Initialized
INFO - 2018-02-01 08:44:20 --> Config Class Initialized
INFO - 2018-02-01 08:44:20 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:44:20 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:44:20 --> Utf8 Class Initialized
INFO - 2018-02-01 08:44:20 --> URI Class Initialized
INFO - 2018-02-01 08:44:20 --> Router Class Initialized
INFO - 2018-02-01 08:44:20 --> Output Class Initialized
INFO - 2018-02-01 08:44:20 --> Security Class Initialized
DEBUG - 2018-02-01 08:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:44:20 --> Input Class Initialized
INFO - 2018-02-01 08:44:20 --> Language Class Initialized
INFO - 2018-02-01 08:44:20 --> Language Class Initialized
INFO - 2018-02-01 08:44:20 --> Config Class Initialized
INFO - 2018-02-01 08:44:20 --> Loader Class Initialized
INFO - 2018-02-01 14:14:20 --> Helper loaded: url_helper
INFO - 2018-02-01 14:14:20 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:14:20 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:14:20 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:14:20 --> Helper loaded: users_helper
INFO - 2018-02-01 14:14:20 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:14:20 --> Helper loaded: form_helper
INFO - 2018-02-01 14:14:20 --> Form Validation Class Initialized
INFO - 2018-02-01 14:14:20 --> Controller Class Initialized
INFO - 2018-02-01 14:14:20 --> Model Class Initialized
INFO - 2018-02-01 14:14:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:14:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:14:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:14:20 --> Model Class Initialized
INFO - 2018-02-01 14:14:20 --> Model Class Initialized
INFO - 2018-02-01 14:14:20 --> Model Class Initialized
INFO - 2018-02-01 14:14:20 --> Model Class Initialized
INFO - 2018-02-01 08:44:49 --> Config Class Initialized
INFO - 2018-02-01 08:44:49 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:44:49 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:44:49 --> Utf8 Class Initialized
INFO - 2018-02-01 08:44:49 --> URI Class Initialized
INFO - 2018-02-01 08:44:49 --> Router Class Initialized
INFO - 2018-02-01 08:44:49 --> Output Class Initialized
INFO - 2018-02-01 08:44:49 --> Security Class Initialized
DEBUG - 2018-02-01 08:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:44:49 --> Input Class Initialized
INFO - 2018-02-01 08:44:49 --> Language Class Initialized
INFO - 2018-02-01 08:44:49 --> Language Class Initialized
INFO - 2018-02-01 08:44:49 --> Config Class Initialized
INFO - 2018-02-01 08:44:49 --> Loader Class Initialized
INFO - 2018-02-01 14:14:49 --> Helper loaded: url_helper
INFO - 2018-02-01 14:14:49 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:14:49 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:14:49 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:14:49 --> Helper loaded: users_helper
INFO - 2018-02-01 14:14:49 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:14:49 --> Helper loaded: form_helper
INFO - 2018-02-01 14:14:49 --> Form Validation Class Initialized
INFO - 2018-02-01 14:14:49 --> Controller Class Initialized
INFO - 2018-02-01 14:14:49 --> Model Class Initialized
INFO - 2018-02-01 14:14:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:14:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:14:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:14:49 --> Model Class Initialized
INFO - 2018-02-01 14:14:49 --> Model Class Initialized
INFO - 2018-02-01 14:14:49 --> Model Class Initialized
INFO - 2018-02-01 14:14:49 --> Model Class Initialized
INFO - 2018-02-01 14:14:49 --> Final output sent to browser
DEBUG - 2018-02-01 14:14:49 --> Total execution time: 0.0950
INFO - 2018-02-01 08:45:45 --> Config Class Initialized
INFO - 2018-02-01 08:45:45 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:45:45 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:45:45 --> Utf8 Class Initialized
INFO - 2018-02-01 08:45:45 --> URI Class Initialized
INFO - 2018-02-01 08:45:45 --> Router Class Initialized
INFO - 2018-02-01 08:45:45 --> Output Class Initialized
INFO - 2018-02-01 08:45:45 --> Security Class Initialized
DEBUG - 2018-02-01 08:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:45:45 --> Input Class Initialized
INFO - 2018-02-01 08:45:45 --> Language Class Initialized
INFO - 2018-02-01 08:45:45 --> Language Class Initialized
INFO - 2018-02-01 08:45:45 --> Config Class Initialized
INFO - 2018-02-01 08:45:45 --> Loader Class Initialized
INFO - 2018-02-01 14:15:45 --> Helper loaded: url_helper
INFO - 2018-02-01 14:15:45 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:15:45 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:15:45 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:15:45 --> Helper loaded: users_helper
INFO - 2018-02-01 14:15:45 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:15:45 --> Helper loaded: form_helper
INFO - 2018-02-01 14:15:45 --> Form Validation Class Initialized
INFO - 2018-02-01 14:15:45 --> Controller Class Initialized
INFO - 2018-02-01 14:15:45 --> Model Class Initialized
INFO - 2018-02-01 14:15:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:15:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:15:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:15:45 --> Model Class Initialized
INFO - 2018-02-01 14:15:45 --> Model Class Initialized
INFO - 2018-02-01 14:15:45 --> Model Class Initialized
INFO - 2018-02-01 14:15:45 --> Model Class Initialized
INFO - 2018-02-01 14:15:45 --> Final output sent to browser
DEBUG - 2018-02-01 14:15:45 --> Total execution time: 0.1049
INFO - 2018-02-01 08:46:51 --> Config Class Initialized
INFO - 2018-02-01 08:46:51 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:46:51 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:46:51 --> Utf8 Class Initialized
INFO - 2018-02-01 08:46:51 --> URI Class Initialized
INFO - 2018-02-01 08:46:51 --> Router Class Initialized
INFO - 2018-02-01 08:46:51 --> Output Class Initialized
INFO - 2018-02-01 08:46:51 --> Security Class Initialized
DEBUG - 2018-02-01 08:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:46:51 --> Input Class Initialized
INFO - 2018-02-01 08:46:51 --> Language Class Initialized
INFO - 2018-02-01 08:46:51 --> Language Class Initialized
INFO - 2018-02-01 08:46:51 --> Config Class Initialized
INFO - 2018-02-01 08:46:51 --> Loader Class Initialized
INFO - 2018-02-01 14:16:51 --> Helper loaded: url_helper
INFO - 2018-02-01 14:16:51 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:16:51 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:16:51 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:16:51 --> Helper loaded: users_helper
INFO - 2018-02-01 14:16:51 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:16:51 --> Helper loaded: form_helper
INFO - 2018-02-01 14:16:51 --> Form Validation Class Initialized
INFO - 2018-02-01 14:16:51 --> Controller Class Initialized
INFO - 2018-02-01 14:16:51 --> Model Class Initialized
INFO - 2018-02-01 14:16:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:16:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:16:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:16:51 --> Model Class Initialized
INFO - 2018-02-01 14:16:51 --> Model Class Initialized
INFO - 2018-02-01 14:16:51 --> Model Class Initialized
INFO - 2018-02-01 14:16:51 --> Model Class Initialized
INFO - 2018-02-01 14:16:51 --> Final output sent to browser
DEBUG - 2018-02-01 14:16:51 --> Total execution time: 0.1059
INFO - 2018-02-01 08:48:43 --> Config Class Initialized
INFO - 2018-02-01 08:48:43 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:48:43 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:48:43 --> Utf8 Class Initialized
INFO - 2018-02-01 08:48:43 --> URI Class Initialized
INFO - 2018-02-01 08:48:43 --> Router Class Initialized
INFO - 2018-02-01 08:48:43 --> Output Class Initialized
INFO - 2018-02-01 08:48:43 --> Security Class Initialized
DEBUG - 2018-02-01 08:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:48:43 --> Input Class Initialized
INFO - 2018-02-01 08:48:43 --> Language Class Initialized
INFO - 2018-02-01 08:48:43 --> Language Class Initialized
INFO - 2018-02-01 08:48:43 --> Config Class Initialized
INFO - 2018-02-01 08:48:43 --> Loader Class Initialized
INFO - 2018-02-01 14:18:43 --> Helper loaded: url_helper
INFO - 2018-02-01 14:18:43 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:18:43 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:18:43 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:18:43 --> Helper loaded: users_helper
INFO - 2018-02-01 14:18:43 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:18:43 --> Helper loaded: form_helper
INFO - 2018-02-01 14:18:43 --> Form Validation Class Initialized
INFO - 2018-02-01 14:18:43 --> Controller Class Initialized
INFO - 2018-02-01 14:18:43 --> Model Class Initialized
INFO - 2018-02-01 14:18:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:18:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:18:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:18:43 --> Model Class Initialized
INFO - 2018-02-01 14:18:43 --> Model Class Initialized
INFO - 2018-02-01 14:18:43 --> Model Class Initialized
INFO - 2018-02-01 14:18:43 --> Model Class Initialized
INFO - 2018-02-01 14:18:43 --> Model Class Initialized
INFO - 2018-02-01 14:18:43 --> Model Class Initialized
INFO - 2018-02-01 14:18:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 14:18:43 --> Final output sent to browser
DEBUG - 2018-02-01 14:18:43 --> Total execution time: 0.1079
INFO - 2018-02-01 08:48:45 --> Config Class Initialized
INFO - 2018-02-01 08:48:45 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:48:45 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:48:45 --> Utf8 Class Initialized
INFO - 2018-02-01 08:48:45 --> URI Class Initialized
INFO - 2018-02-01 08:48:45 --> Router Class Initialized
INFO - 2018-02-01 08:48:45 --> Output Class Initialized
INFO - 2018-02-01 08:48:45 --> Security Class Initialized
DEBUG - 2018-02-01 08:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:48:45 --> Input Class Initialized
INFO - 2018-02-01 08:48:45 --> Language Class Initialized
INFO - 2018-02-01 08:48:45 --> Language Class Initialized
INFO - 2018-02-01 08:48:45 --> Config Class Initialized
INFO - 2018-02-01 08:48:45 --> Loader Class Initialized
INFO - 2018-02-01 14:18:45 --> Helper loaded: url_helper
INFO - 2018-02-01 14:18:45 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:18:45 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:18:45 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:18:45 --> Helper loaded: users_helper
INFO - 2018-02-01 14:18:45 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:18:45 --> Helper loaded: form_helper
INFO - 2018-02-01 14:18:45 --> Form Validation Class Initialized
INFO - 2018-02-01 14:18:45 --> Controller Class Initialized
INFO - 2018-02-01 14:18:45 --> Model Class Initialized
INFO - 2018-02-01 14:18:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:18:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:18:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:18:45 --> Model Class Initialized
INFO - 2018-02-01 14:18:45 --> Model Class Initialized
INFO - 2018-02-01 14:18:45 --> Model Class Initialized
INFO - 2018-02-01 14:18:45 --> Model Class Initialized
INFO - 2018-02-01 14:18:45 --> Final output sent to browser
DEBUG - 2018-02-01 14:18:45 --> Total execution time: 0.0982
INFO - 2018-02-01 08:48:48 --> Config Class Initialized
INFO - 2018-02-01 08:48:48 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:48:48 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:48:48 --> Utf8 Class Initialized
INFO - 2018-02-01 08:48:48 --> URI Class Initialized
INFO - 2018-02-01 08:48:48 --> Router Class Initialized
INFO - 2018-02-01 08:48:48 --> Output Class Initialized
INFO - 2018-02-01 08:48:48 --> Security Class Initialized
DEBUG - 2018-02-01 08:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:48:48 --> Input Class Initialized
INFO - 2018-02-01 08:48:48 --> Language Class Initialized
INFO - 2018-02-01 08:48:48 --> Language Class Initialized
INFO - 2018-02-01 08:48:48 --> Config Class Initialized
INFO - 2018-02-01 08:48:48 --> Loader Class Initialized
INFO - 2018-02-01 14:18:48 --> Helper loaded: url_helper
INFO - 2018-02-01 14:18:48 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:18:48 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:18:48 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:18:48 --> Helper loaded: users_helper
INFO - 2018-02-01 14:18:48 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:18:48 --> Helper loaded: form_helper
INFO - 2018-02-01 14:18:48 --> Form Validation Class Initialized
INFO - 2018-02-01 14:18:48 --> Controller Class Initialized
INFO - 2018-02-01 14:18:48 --> Model Class Initialized
INFO - 2018-02-01 14:18:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:18:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:18:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:18:48 --> Model Class Initialized
INFO - 2018-02-01 14:18:48 --> Model Class Initialized
INFO - 2018-02-01 14:18:48 --> Model Class Initialized
INFO - 2018-02-01 14:18:48 --> Model Class Initialized
INFO - 2018-02-01 14:18:48 --> Final output sent to browser
DEBUG - 2018-02-01 14:18:48 --> Total execution time: 0.1043
INFO - 2018-02-01 08:49:06 --> Config Class Initialized
INFO - 2018-02-01 08:49:06 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:49:06 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:49:06 --> Utf8 Class Initialized
INFO - 2018-02-01 08:49:06 --> URI Class Initialized
INFO - 2018-02-01 08:49:06 --> Router Class Initialized
INFO - 2018-02-01 08:49:06 --> Output Class Initialized
INFO - 2018-02-01 08:49:06 --> Security Class Initialized
DEBUG - 2018-02-01 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:49:06 --> Input Class Initialized
INFO - 2018-02-01 08:49:06 --> Language Class Initialized
INFO - 2018-02-01 08:49:06 --> Language Class Initialized
INFO - 2018-02-01 08:49:06 --> Config Class Initialized
INFO - 2018-02-01 08:49:06 --> Loader Class Initialized
INFO - 2018-02-01 14:19:06 --> Helper loaded: url_helper
INFO - 2018-02-01 14:19:06 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:19:06 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:19:06 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:19:06 --> Helper loaded: users_helper
INFO - 2018-02-01 14:19:06 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:19:06 --> Helper loaded: form_helper
INFO - 2018-02-01 14:19:06 --> Form Validation Class Initialized
INFO - 2018-02-01 14:19:06 --> Controller Class Initialized
INFO - 2018-02-01 14:19:07 --> Model Class Initialized
INFO - 2018-02-01 14:19:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:19:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:19:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:19:07 --> Model Class Initialized
INFO - 2018-02-01 14:19:07 --> Model Class Initialized
INFO - 2018-02-01 14:19:07 --> Model Class Initialized
INFO - 2018-02-01 14:19:07 --> Model Class Initialized
INFO - 2018-02-01 14:19:07 --> Final output sent to browser
DEBUG - 2018-02-01 14:19:07 --> Total execution time: 0.1190
INFO - 2018-02-01 08:49:17 --> Config Class Initialized
INFO - 2018-02-01 08:49:17 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:49:17 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:49:17 --> Utf8 Class Initialized
INFO - 2018-02-01 08:49:17 --> URI Class Initialized
INFO - 2018-02-01 08:49:17 --> Router Class Initialized
INFO - 2018-02-01 08:49:17 --> Output Class Initialized
INFO - 2018-02-01 08:49:17 --> Security Class Initialized
DEBUG - 2018-02-01 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:49:17 --> Input Class Initialized
INFO - 2018-02-01 08:49:17 --> Language Class Initialized
INFO - 2018-02-01 08:49:17 --> Language Class Initialized
INFO - 2018-02-01 08:49:17 --> Config Class Initialized
INFO - 2018-02-01 08:49:17 --> Loader Class Initialized
INFO - 2018-02-01 14:19:17 --> Helper loaded: url_helper
INFO - 2018-02-01 14:19:17 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:19:17 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:19:17 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:19:17 --> Helper loaded: users_helper
INFO - 2018-02-01 14:19:17 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:19:17 --> Helper loaded: form_helper
INFO - 2018-02-01 14:19:17 --> Form Validation Class Initialized
INFO - 2018-02-01 14:19:17 --> Controller Class Initialized
INFO - 2018-02-01 14:19:17 --> Model Class Initialized
INFO - 2018-02-01 14:19:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:19:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:19:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:19:17 --> Model Class Initialized
INFO - 2018-02-01 14:19:17 --> Model Class Initialized
INFO - 2018-02-01 14:19:17 --> Model Class Initialized
INFO - 2018-02-01 14:19:17 --> Model Class Initialized
INFO - 2018-02-01 14:19:17 --> Final output sent to browser
DEBUG - 2018-02-01 14:19:17 --> Total execution time: 0.1070
INFO - 2018-02-01 08:51:18 --> Config Class Initialized
INFO - 2018-02-01 08:51:18 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:51:18 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:51:18 --> Utf8 Class Initialized
INFO - 2018-02-01 08:51:18 --> URI Class Initialized
INFO - 2018-02-01 08:51:18 --> Router Class Initialized
INFO - 2018-02-01 08:51:18 --> Output Class Initialized
INFO - 2018-02-01 08:51:18 --> Security Class Initialized
DEBUG - 2018-02-01 08:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:51:18 --> Input Class Initialized
INFO - 2018-02-01 08:51:18 --> Language Class Initialized
INFO - 2018-02-01 08:51:18 --> Language Class Initialized
INFO - 2018-02-01 08:51:18 --> Config Class Initialized
INFO - 2018-02-01 08:51:18 --> Loader Class Initialized
INFO - 2018-02-01 14:21:18 --> Helper loaded: url_helper
INFO - 2018-02-01 14:21:18 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:21:18 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:21:18 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:21:18 --> Helper loaded: users_helper
INFO - 2018-02-01 14:21:18 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:21:18 --> Helper loaded: form_helper
INFO - 2018-02-01 14:21:18 --> Form Validation Class Initialized
INFO - 2018-02-01 14:21:18 --> Controller Class Initialized
INFO - 2018-02-01 14:21:18 --> Model Class Initialized
INFO - 2018-02-01 14:21:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:21:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:21:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:21:18 --> Model Class Initialized
INFO - 2018-02-01 14:21:18 --> Model Class Initialized
INFO - 2018-02-01 14:21:18 --> Model Class Initialized
INFO - 2018-02-01 14:21:18 --> Model Class Initialized
INFO - 2018-02-01 14:21:18 --> Final output sent to browser
DEBUG - 2018-02-01 14:21:18 --> Total execution time: 0.0961
INFO - 2018-02-01 08:59:36 --> Config Class Initialized
INFO - 2018-02-01 08:59:36 --> Hooks Class Initialized
DEBUG - 2018-02-01 08:59:36 --> UTF-8 Support Enabled
INFO - 2018-02-01 08:59:36 --> Utf8 Class Initialized
INFO - 2018-02-01 08:59:36 --> URI Class Initialized
INFO - 2018-02-01 08:59:36 --> Router Class Initialized
INFO - 2018-02-01 08:59:36 --> Output Class Initialized
INFO - 2018-02-01 08:59:36 --> Security Class Initialized
DEBUG - 2018-02-01 08:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 08:59:36 --> Input Class Initialized
INFO - 2018-02-01 08:59:36 --> Language Class Initialized
INFO - 2018-02-01 08:59:36 --> Language Class Initialized
INFO - 2018-02-01 08:59:36 --> Config Class Initialized
INFO - 2018-02-01 08:59:36 --> Loader Class Initialized
INFO - 2018-02-01 14:29:36 --> Helper loaded: url_helper
INFO - 2018-02-01 14:29:36 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:29:36 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:29:36 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:29:36 --> Helper loaded: users_helper
INFO - 2018-02-01 14:29:36 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:29:36 --> Helper loaded: form_helper
INFO - 2018-02-01 14:29:36 --> Form Validation Class Initialized
INFO - 2018-02-01 14:29:36 --> Controller Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:29:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:29:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Model Class Initialized
INFO - 2018-02-01 14:29:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 14:29:36 --> Final output sent to browser
DEBUG - 2018-02-01 14:29:36 --> Total execution time: 0.1142
INFO - 2018-02-01 09:00:06 --> Config Class Initialized
INFO - 2018-02-01 09:00:06 --> Hooks Class Initialized
DEBUG - 2018-02-01 09:00:06 --> UTF-8 Support Enabled
INFO - 2018-02-01 09:00:06 --> Utf8 Class Initialized
INFO - 2018-02-01 09:00:06 --> URI Class Initialized
INFO - 2018-02-01 09:00:06 --> Router Class Initialized
INFO - 2018-02-01 09:00:06 --> Output Class Initialized
INFO - 2018-02-01 09:00:06 --> Security Class Initialized
DEBUG - 2018-02-01 09:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 09:00:06 --> Input Class Initialized
INFO - 2018-02-01 09:00:06 --> Language Class Initialized
INFO - 2018-02-01 09:00:06 --> Language Class Initialized
INFO - 2018-02-01 09:00:06 --> Config Class Initialized
INFO - 2018-02-01 09:00:06 --> Loader Class Initialized
INFO - 2018-02-01 14:30:06 --> Helper loaded: url_helper
INFO - 2018-02-01 14:30:06 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:30:06 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:30:06 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:30:06 --> Helper loaded: users_helper
INFO - 2018-02-01 14:30:06 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:30:06 --> Helper loaded: form_helper
INFO - 2018-02-01 14:30:06 --> Form Validation Class Initialized
INFO - 2018-02-01 14:30:06 --> Controller Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:30:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:30:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Model Class Initialized
INFO - 2018-02-01 14:30:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 14:30:06 --> Final output sent to browser
DEBUG - 2018-02-01 14:30:06 --> Total execution time: 0.1135
INFO - 2018-02-01 09:00:12 --> Config Class Initialized
INFO - 2018-02-01 09:00:12 --> Hooks Class Initialized
DEBUG - 2018-02-01 09:00:12 --> UTF-8 Support Enabled
INFO - 2018-02-01 09:00:12 --> Utf8 Class Initialized
INFO - 2018-02-01 09:00:12 --> URI Class Initialized
INFO - 2018-02-01 09:00:12 --> Router Class Initialized
INFO - 2018-02-01 09:00:12 --> Output Class Initialized
INFO - 2018-02-01 09:00:12 --> Security Class Initialized
DEBUG - 2018-02-01 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 09:00:12 --> Input Class Initialized
INFO - 2018-02-01 09:00:12 --> Language Class Initialized
INFO - 2018-02-01 09:00:12 --> Language Class Initialized
INFO - 2018-02-01 09:00:12 --> Config Class Initialized
INFO - 2018-02-01 09:00:12 --> Loader Class Initialized
INFO - 2018-02-01 14:30:12 --> Helper loaded: url_helper
INFO - 2018-02-01 14:30:12 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:30:12 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:30:12 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:30:12 --> Helper loaded: users_helper
INFO - 2018-02-01 14:30:12 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:30:12 --> Helper loaded: form_helper
INFO - 2018-02-01 14:30:12 --> Form Validation Class Initialized
INFO - 2018-02-01 14:30:12 --> Controller Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:30:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:30:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Model Class Initialized
INFO - 2018-02-01 14:30:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 14:30:12 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT concat(users_fname, ' ', users_lname) as name, `users`.`users_id`, IFNULL(users_age, '') as users_age, IFNULL(lc.name, '') as users_location, IFNULL(lcc.name, '') as country, IFNULL(users.about, '') as self_summery, ( 3959 * acos( cos( radians() ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians() ) + sin( radians() ) * sin( radians( users_latitude ) ) ) ) AS distance, IFNULL(users.is_online, '0') as is_onine
FROM `users`
LEFT JOIN `location` `lc` ON `lc`.`location_id`=`users`.`users_location`
LEFT JOIN `user_preference` `up` ON `up`.`users_id`=`users`.`users_id`
LEFT JOIN `location` `lcc` ON `lcc`.`location_id`=`users`.`country`
WHERE `users_status` = '1'
AND  `users`.`users_id` NOT IN (119)
AND `users`.`discovery` = '1'
AND `is_online` = '1'
GROUP BY `users`.`users_id`
HAVING `distance` < 50
ERROR - 2018-02-01 14:30:12 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/pr01004/public_html/application/models/Filter_model.php 390
INFO - 2018-02-01 09:01:12 --> Config Class Initialized
INFO - 2018-02-01 09:01:12 --> Hooks Class Initialized
DEBUG - 2018-02-01 09:01:12 --> UTF-8 Support Enabled
INFO - 2018-02-01 09:01:12 --> Utf8 Class Initialized
INFO - 2018-02-01 09:01:12 --> URI Class Initialized
INFO - 2018-02-01 09:01:12 --> Router Class Initialized
INFO - 2018-02-01 09:01:12 --> Output Class Initialized
INFO - 2018-02-01 09:01:12 --> Security Class Initialized
DEBUG - 2018-02-01 09:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 09:01:12 --> Input Class Initialized
INFO - 2018-02-01 09:01:12 --> Language Class Initialized
INFO - 2018-02-01 09:01:12 --> Language Class Initialized
INFO - 2018-02-01 09:01:12 --> Config Class Initialized
INFO - 2018-02-01 09:01:12 --> Loader Class Initialized
INFO - 2018-02-01 14:31:12 --> Helper loaded: url_helper
INFO - 2018-02-01 14:31:12 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:31:12 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:31:12 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:31:12 --> Helper loaded: users_helper
INFO - 2018-02-01 14:31:12 --> Database Driver Class Initialized
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/pr01004/public_html/system/libraries/Session/Session.php 284
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when headers already sent /home/pr01004/public_html/system/libraries/Session/Session.php 296
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/pr01004/public_html/system/libraries/Session/Session.php 306
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/pr01004/public_html/system/libraries/Session/Session.php 316
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/pr01004/public_html/system/libraries/Session/Session.php 317
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/pr01004/public_html/system/libraries/Session/Session.php 318
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/pr01004/public_html/system/libraries/Session/Session.php 319
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/pr01004/public_html/system/libraries/Session/Session.php 377
DEBUG - 2018-02-01 14:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when headers already sent /home/pr01004/public_html/system/libraries/Session/Session.php 110
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> session_start(): Cannot start session when headers already sent /home/pr01004/public_html/system/libraries/Session/Session.php 143
INFO - 2018-02-01 14:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:31:12 --> Helper loaded: form_helper
INFO - 2018-02-01 14:31:12 --> Form Validation Class Initialized
INFO - 2018-02-01 14:31:12 --> Controller Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:31:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:31:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Model Class Initialized
INFO - 2018-02-01 14:31:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 14:31:12 --> Severity: Notice --> Trying to get property 'users_latitude' of non-object /home/pr01004/public_html/application/models/Filter_model.php 338
ERROR - 2018-02-01 14:31:12 --> Severity: Notice --> Trying to get property 'users_longitude' of non-object /home/pr01004/public_html/application/models/Filter_model.php 339
ERROR - 2018-02-01 14:31:12 --> Severity: Notice --> Trying to get property 'from_age' of non-object /home/pr01004/public_html/application/models/Filter_model.php 340
ERROR - 2018-02-01 14:31:12 --> Severity: Notice --> Trying to get property 'to_age' of non-object /home/pr01004/public_html/application/models/Filter_model.php 341
ERROR - 2018-02-01 14:31:12 --> Severity: Notice --> Trying to get property 'looking_for' of non-object /home/pr01004/public_html/application/models/Filter_model.php 342
ERROR - 2018-02-01 14:31:12 --> Severity: Notice --> Trying to get property 'saved_height' of non-object /home/pr01004/public_html/application/models/Filter_model.php 363
ERROR - 2018-02-01 14:31:12 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT concat(users_fname, ' ', users_lname) as name, `users`.`users_id`, IFNULL(users_age, '') as users_age, IFNULL(lc.name, '') as users_location, IFNULL(lcc.name, '') as country, IFNULL(users.about, '') as self_summery, ( 3959 * acos( cos( radians() ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians() ) + sin( radians() ) * sin( radians( users_latitude ) ) ) ) AS distance, IFNULL(users.is_online, '0') as is_onine
FROM `users`
LEFT JOIN `location` `lc` ON `lc`.`location_id`=`users`.`users_location`
LEFT JOIN `user_preference` `up` ON `up`.`users_id`=`users`.`users_id`
LEFT JOIN `location` `lcc` ON `lcc`.`location_id`=`users`.`country`
WHERE `users_status` = '1'
AND  `users`.`users_id` NOT IN (119)
AND `users`.`discovery` = '1'
AND `is_online` = '1'
GROUP BY `users`.`users_id`
HAVING `distance` < 50
INFO - 2018-02-01 14:31:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-02-01 14:31:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/pr01004/public_html/application/config/constants.php:90) /home/pr01004/public_html/system/core/Common.php 564
INFO - 2018-02-01 09:02:14 --> Config Class Initialized
INFO - 2018-02-01 09:02:14 --> Hooks Class Initialized
DEBUG - 2018-02-01 09:02:14 --> UTF-8 Support Enabled
INFO - 2018-02-01 09:02:14 --> Utf8 Class Initialized
INFO - 2018-02-01 09:02:14 --> URI Class Initialized
INFO - 2018-02-01 09:02:14 --> Router Class Initialized
INFO - 2018-02-01 09:02:14 --> Output Class Initialized
INFO - 2018-02-01 09:02:14 --> Security Class Initialized
DEBUG - 2018-02-01 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 09:02:14 --> Input Class Initialized
INFO - 2018-02-01 09:02:14 --> Language Class Initialized
INFO - 2018-02-01 09:02:14 --> Language Class Initialized
INFO - 2018-02-01 09:02:14 --> Config Class Initialized
INFO - 2018-02-01 09:02:14 --> Loader Class Initialized
INFO - 2018-02-01 14:32:14 --> Helper loaded: url_helper
INFO - 2018-02-01 14:32:14 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:32:14 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:32:14 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:32:14 --> Helper loaded: users_helper
INFO - 2018-02-01 14:32:14 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:32:14 --> Helper loaded: form_helper
INFO - 2018-02-01 14:32:14 --> Form Validation Class Initialized
INFO - 2018-02-01 14:32:14 --> Controller Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:32:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:32:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Model Class Initialized
INFO - 2018-02-01 14:32:14 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 14:32:14 --> Severity: Notice --> Trying to get property 'users_latitude' of non-object /home/pr01004/public_html/application/models/Filter_model.php 338
ERROR - 2018-02-01 14:32:14 --> Severity: Notice --> Trying to get property 'users_longitude' of non-object /home/pr01004/public_html/application/models/Filter_model.php 339
ERROR - 2018-02-01 14:32:14 --> Severity: Notice --> Trying to get property 'from_age' of non-object /home/pr01004/public_html/application/models/Filter_model.php 340
ERROR - 2018-02-01 14:32:14 --> Severity: Notice --> Trying to get property 'to_age' of non-object /home/pr01004/public_html/application/models/Filter_model.php 341
ERROR - 2018-02-01 14:32:14 --> Severity: Notice --> Trying to get property 'looking_for' of non-object /home/pr01004/public_html/application/models/Filter_model.php 342
ERROR - 2018-02-01 14:32:14 --> Severity: Notice --> Trying to get property 'saved_height' of non-object /home/pr01004/public_html/application/models/Filter_model.php 363
ERROR - 2018-02-01 14:32:14 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT concat(users_fname, ' ', users_lname) as name, `users`.`users_id`, IFNULL(users_age, '') as users_age, IFNULL(lc.name, '') as users_location, IFNULL(lcc.name, '') as country, IFNULL(users.about, '') as self_summery, ( 3959 * acos( cos( radians() ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians() ) + sin( radians() ) * sin( radians( users_latitude ) ) ) ) AS distance, IFNULL(users.is_online, '0') as is_onine
FROM `users`
LEFT JOIN `location` `lc` ON `lc`.`location_id`=`users`.`users_location`
LEFT JOIN `user_preference` `up` ON `up`.`users_id`=`users`.`users_id`
LEFT JOIN `location` `lcc` ON `lcc`.`location_id`=`users`.`country`
WHERE `users_status` = '1'
AND  `users`.`users_id` NOT IN (119)
AND `users`.`discovery` = '1'
AND `is_online` = '1'
GROUP BY `users`.`users_id`
HAVING `distance` < 50
INFO - 2018-02-01 14:32:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-02-01 14:32:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/pr01004/public_html/system/core/Exceptions.php:271) /home/pr01004/public_html/system/core/Common.php 564
INFO - 2018-02-01 09:07:20 --> Config Class Initialized
INFO - 2018-02-01 09:07:20 --> Hooks Class Initialized
DEBUG - 2018-02-01 09:07:20 --> UTF-8 Support Enabled
INFO - 2018-02-01 09:07:20 --> Utf8 Class Initialized
INFO - 2018-02-01 09:07:20 --> URI Class Initialized
INFO - 2018-02-01 09:07:20 --> Router Class Initialized
INFO - 2018-02-01 09:07:20 --> Output Class Initialized
INFO - 2018-02-01 09:07:20 --> Security Class Initialized
DEBUG - 2018-02-01 09:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 09:07:20 --> Input Class Initialized
INFO - 2018-02-01 09:07:20 --> Language Class Initialized
INFO - 2018-02-01 09:07:20 --> Language Class Initialized
INFO - 2018-02-01 09:07:20 --> Config Class Initialized
INFO - 2018-02-01 09:07:20 --> Loader Class Initialized
INFO - 2018-02-01 14:37:20 --> Helper loaded: url_helper
INFO - 2018-02-01 14:37:20 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:37:20 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:37:20 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:37:20 --> Helper loaded: users_helper
INFO - 2018-02-01 14:37:20 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:37:20 --> Helper loaded: form_helper
INFO - 2018-02-01 14:37:20 --> Form Validation Class Initialized
INFO - 2018-02-01 14:37:20 --> Controller Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:37:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:37:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Model Class Initialized
INFO - 2018-02-01 14:37:20 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 14:37:20 --> Severity: Notice --> Trying to get property 'users_latitude' of non-object /home/pr01004/public_html/application/models/Filter_model.php 338
ERROR - 2018-02-01 14:37:20 --> Severity: Notice --> Trying to get property 'users_longitude' of non-object /home/pr01004/public_html/application/models/Filter_model.php 339
ERROR - 2018-02-01 14:37:20 --> Severity: Notice --> Trying to get property 'from_age' of non-object /home/pr01004/public_html/application/models/Filter_model.php 340
ERROR - 2018-02-01 14:37:20 --> Severity: Notice --> Trying to get property 'to_age' of non-object /home/pr01004/public_html/application/models/Filter_model.php 341
ERROR - 2018-02-01 14:37:20 --> Severity: Notice --> Trying to get property 'looking_for' of non-object /home/pr01004/public_html/application/models/Filter_model.php 342
ERROR - 2018-02-01 14:37:20 --> Severity: Notice --> Trying to get property 'saved_height' of non-object /home/pr01004/public_html/application/models/Filter_model.php 363
ERROR - 2018-02-01 14:37:20 --> Query error: Incorrect parameter count in the call to native function 'radians' - Invalid query: SELECT concat(users_fname, ' ', users_lname) as name, `users`.`users_id`, IFNULL(users_age, '') as users_age, IFNULL(lc.name, '') as users_location, IFNULL(lcc.name, '') as country, IFNULL(users.about, '') as self_summery, ( 3959 * acos( cos( radians() ) * cos( radians( users_latitude ) ) * cos( radians( users_longitude ) - radians() ) + sin( radians() ) * sin( radians( users_latitude ) ) ) ) AS distance, IFNULL(users.is_online, '0') as is_onine
FROM `users`
LEFT JOIN `location` `lc` ON `lc`.`location_id`=`users`.`users_location`
LEFT JOIN `user_preference` `up` ON `up`.`users_id`=`users`.`users_id`
LEFT JOIN `location` `lcc` ON `lcc`.`location_id`=`users`.`country`
WHERE `users_status` = '1'
AND  `users`.`users_id` NOT IN (119)
AND `users`.`discovery` = '1'
AND `is_online` = '1'
GROUP BY `users`.`users_id`
HAVING `distance` < 50
INFO - 2018-02-01 14:37:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-02-01 14:37:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/pr01004/public_html/system/core/Exceptions.php:271) /home/pr01004/public_html/system/core/Common.php 564
INFO - 2018-02-01 09:07:52 --> Config Class Initialized
INFO - 2018-02-01 09:07:52 --> Hooks Class Initialized
DEBUG - 2018-02-01 09:07:52 --> UTF-8 Support Enabled
INFO - 2018-02-01 09:07:52 --> Utf8 Class Initialized
INFO - 2018-02-01 09:07:52 --> URI Class Initialized
INFO - 2018-02-01 09:07:52 --> Router Class Initialized
INFO - 2018-02-01 09:07:52 --> Output Class Initialized
INFO - 2018-02-01 09:07:52 --> Security Class Initialized
DEBUG - 2018-02-01 09:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 09:07:52 --> Input Class Initialized
INFO - 2018-02-01 09:07:52 --> Language Class Initialized
INFO - 2018-02-01 09:07:52 --> Language Class Initialized
INFO - 2018-02-01 09:07:52 --> Config Class Initialized
INFO - 2018-02-01 09:07:52 --> Loader Class Initialized
INFO - 2018-02-01 14:37:52 --> Helper loaded: url_helper
INFO - 2018-02-01 14:37:52 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:37:52 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:37:52 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:37:52 --> Helper loaded: users_helper
INFO - 2018-02-01 14:37:52 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:37:52 --> Helper loaded: form_helper
INFO - 2018-02-01 14:37:52 --> Form Validation Class Initialized
INFO - 2018-02-01 14:37:52 --> Controller Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:37:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:37:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Model Class Initialized
INFO - 2018-02-01 14:37:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 14:37:52 --> Final output sent to browser
DEBUG - 2018-02-01 14:37:52 --> Total execution time: 0.1101
INFO - 2018-02-01 09:08:04 --> Config Class Initialized
INFO - 2018-02-01 09:08:04 --> Hooks Class Initialized
DEBUG - 2018-02-01 09:08:04 --> UTF-8 Support Enabled
INFO - 2018-02-01 09:08:04 --> Utf8 Class Initialized
INFO - 2018-02-01 09:08:04 --> URI Class Initialized
INFO - 2018-02-01 09:08:04 --> Router Class Initialized
INFO - 2018-02-01 09:08:04 --> Output Class Initialized
INFO - 2018-02-01 09:08:04 --> Security Class Initialized
DEBUG - 2018-02-01 09:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 09:08:04 --> Input Class Initialized
INFO - 2018-02-01 09:08:04 --> Language Class Initialized
INFO - 2018-02-01 09:08:04 --> Language Class Initialized
INFO - 2018-02-01 09:08:04 --> Config Class Initialized
INFO - 2018-02-01 09:08:04 --> Loader Class Initialized
INFO - 2018-02-01 14:38:04 --> Helper loaded: url_helper
INFO - 2018-02-01 14:38:04 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:38:04 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:38:04 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:38:04 --> Helper loaded: users_helper
INFO - 2018-02-01 14:38:04 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:38:04 --> Helper loaded: form_helper
INFO - 2018-02-01 14:38:04 --> Form Validation Class Initialized
INFO - 2018-02-01 14:38:04 --> Controller Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:38:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:38:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Model Class Initialized
INFO - 2018-02-01 14:38:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 14:38:04 --> Final output sent to browser
DEBUG - 2018-02-01 14:38:04 --> Total execution time: 0.1244
INFO - 2018-02-01 09:11:29 --> Config Class Initialized
INFO - 2018-02-01 09:11:29 --> Hooks Class Initialized
DEBUG - 2018-02-01 09:11:29 --> UTF-8 Support Enabled
INFO - 2018-02-01 09:11:29 --> Utf8 Class Initialized
INFO - 2018-02-01 09:11:29 --> URI Class Initialized
INFO - 2018-02-01 09:11:29 --> Router Class Initialized
INFO - 2018-02-01 09:11:29 --> Output Class Initialized
INFO - 2018-02-01 09:11:29 --> Security Class Initialized
DEBUG - 2018-02-01 09:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 09:11:29 --> Input Class Initialized
INFO - 2018-02-01 09:11:29 --> Language Class Initialized
INFO - 2018-02-01 09:11:29 --> Language Class Initialized
INFO - 2018-02-01 09:11:29 --> Config Class Initialized
INFO - 2018-02-01 09:11:29 --> Loader Class Initialized
INFO - 2018-02-01 14:41:29 --> Helper loaded: url_helper
INFO - 2018-02-01 14:41:29 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:41:29 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:41:29 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:41:29 --> Helper loaded: users_helper
INFO - 2018-02-01 14:41:29 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:41:29 --> Helper loaded: form_helper
INFO - 2018-02-01 14:41:29 --> Form Validation Class Initialized
INFO - 2018-02-01 14:41:29 --> Controller Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:41:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:41:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Model Class Initialized
INFO - 2018-02-01 14:41:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 14:41:29 --> Final output sent to browser
DEBUG - 2018-02-01 14:41:29 --> Total execution time: 0.1228
INFO - 2018-02-01 09:11:53 --> Config Class Initialized
INFO - 2018-02-01 09:11:53 --> Hooks Class Initialized
DEBUG - 2018-02-01 09:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-01 09:11:53 --> Utf8 Class Initialized
INFO - 2018-02-01 09:11:53 --> URI Class Initialized
INFO - 2018-02-01 09:11:53 --> Router Class Initialized
INFO - 2018-02-01 09:11:53 --> Output Class Initialized
INFO - 2018-02-01 09:11:53 --> Security Class Initialized
DEBUG - 2018-02-01 09:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 09:11:53 --> Input Class Initialized
INFO - 2018-02-01 09:11:53 --> Language Class Initialized
INFO - 2018-02-01 09:11:53 --> Language Class Initialized
INFO - 2018-02-01 09:11:53 --> Config Class Initialized
INFO - 2018-02-01 09:11:53 --> Loader Class Initialized
INFO - 2018-02-01 14:41:53 --> Helper loaded: url_helper
INFO - 2018-02-01 14:41:53 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:41:53 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:41:53 --> Helper loaded: permission_helper
INFO - 2018-02-01 14:41:53 --> Helper loaded: users_helper
INFO - 2018-02-01 14:41:53 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 14:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:41:53 --> Helper loaded: form_helper
INFO - 2018-02-01 14:41:53 --> Form Validation Class Initialized
INFO - 2018-02-01 14:41:53 --> Controller Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:41:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:41:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Model Class Initialized
INFO - 2018-02-01 14:41:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 14:41:53 --> Final output sent to browser
DEBUG - 2018-02-01 14:41:53 --> Total execution time: 0.1225
INFO - 2018-02-01 13:57:50 --> Config Class Initialized
INFO - 2018-02-01 13:57:50 --> Hooks Class Initialized
DEBUG - 2018-02-01 13:57:50 --> UTF-8 Support Enabled
INFO - 2018-02-01 13:57:50 --> Utf8 Class Initialized
INFO - 2018-02-01 13:57:50 --> URI Class Initialized
DEBUG - 2018-02-01 13:57:50 --> No URI present. Default controller set.
INFO - 2018-02-01 13:57:50 --> Router Class Initialized
INFO - 2018-02-01 13:57:50 --> Output Class Initialized
INFO - 2018-02-01 13:57:50 --> Security Class Initialized
DEBUG - 2018-02-01 13:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 13:57:50 --> Input Class Initialized
INFO - 2018-02-01 13:57:50 --> Language Class Initialized
INFO - 2018-02-01 13:57:50 --> Language Class Initialized
INFO - 2018-02-01 13:57:50 --> Config Class Initialized
INFO - 2018-02-01 13:57:50 --> Loader Class Initialized
INFO - 2018-02-01 19:27:50 --> Helper loaded: url_helper
INFO - 2018-02-01 19:27:50 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:27:50 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:27:50 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:27:50 --> Helper loaded: users_helper
INFO - 2018-02-01 19:27:50 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:27:50 --> Helper loaded: form_helper
INFO - 2018-02-01 19:27:50 --> Form Validation Class Initialized
INFO - 2018-02-01 19:27:50 --> Controller Class Initialized
INFO - 2018-02-01 19:27:50 --> Model Class Initialized
INFO - 2018-02-01 19:27:50 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:27:50 --> Model Class Initialized
DEBUG - 2018-02-01 19:27:50 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-01 19:27:50 --> Final output sent to browser
DEBUG - 2018-02-01 19:27:50 --> Total execution time: 0.1374
INFO - 2018-02-01 13:58:27 --> Config Class Initialized
INFO - 2018-02-01 13:58:27 --> Hooks Class Initialized
DEBUG - 2018-02-01 13:58:27 --> UTF-8 Support Enabled
INFO - 2018-02-01 13:58:27 --> Utf8 Class Initialized
INFO - 2018-02-01 13:58:27 --> URI Class Initialized
INFO - 2018-02-01 13:58:27 --> Router Class Initialized
INFO - 2018-02-01 13:58:27 --> Output Class Initialized
INFO - 2018-02-01 13:58:27 --> Security Class Initialized
DEBUG - 2018-02-01 13:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 13:58:27 --> Input Class Initialized
INFO - 2018-02-01 13:58:27 --> Language Class Initialized
INFO - 2018-02-01 13:58:27 --> Language Class Initialized
INFO - 2018-02-01 13:58:27 --> Config Class Initialized
INFO - 2018-02-01 13:58:27 --> Loader Class Initialized
INFO - 2018-02-01 19:28:27 --> Helper loaded: url_helper
INFO - 2018-02-01 19:28:27 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:28:27 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:28:27 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:28:27 --> Helper loaded: users_helper
INFO - 2018-02-01 19:28:27 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:28:27 --> Helper loaded: form_helper
INFO - 2018-02-01 19:28:27 --> Form Validation Class Initialized
INFO - 2018-02-01 19:28:27 --> Controller Class Initialized
INFO - 2018-02-01 19:28:27 --> Model Class Initialized
INFO - 2018-02-01 19:28:27 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:28:27 --> Model Class Initialized
INFO - 2018-02-01 19:28:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-01 13:58:44 --> Config Class Initialized
INFO - 2018-02-01 13:58:44 --> Hooks Class Initialized
DEBUG - 2018-02-01 13:58:44 --> UTF-8 Support Enabled
INFO - 2018-02-01 13:58:44 --> Utf8 Class Initialized
INFO - 2018-02-01 13:58:44 --> URI Class Initialized
DEBUG - 2018-02-01 13:58:44 --> No URI present. Default controller set.
INFO - 2018-02-01 13:58:44 --> Router Class Initialized
INFO - 2018-02-01 13:58:44 --> Output Class Initialized
INFO - 2018-02-01 13:58:44 --> Security Class Initialized
DEBUG - 2018-02-01 13:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 13:58:44 --> Input Class Initialized
INFO - 2018-02-01 13:58:44 --> Language Class Initialized
INFO - 2018-02-01 13:58:44 --> Language Class Initialized
INFO - 2018-02-01 13:58:44 --> Config Class Initialized
INFO - 2018-02-01 13:58:44 --> Loader Class Initialized
INFO - 2018-02-01 19:28:44 --> Helper loaded: url_helper
INFO - 2018-02-01 19:28:44 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:28:44 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:28:44 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:28:44 --> Helper loaded: users_helper
INFO - 2018-02-01 19:28:44 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:28:44 --> Helper loaded: form_helper
INFO - 2018-02-01 19:28:44 --> Form Validation Class Initialized
INFO - 2018-02-01 19:28:44 --> Controller Class Initialized
INFO - 2018-02-01 19:28:44 --> Model Class Initialized
INFO - 2018-02-01 19:28:44 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:28:44 --> Model Class Initialized
INFO - 2018-02-01 19:28:44 --> Model Class Initialized
INFO - 2018-02-01 13:58:45 --> Config Class Initialized
INFO - 2018-02-01 13:58:45 --> Hooks Class Initialized
DEBUG - 2018-02-01 13:58:45 --> UTF-8 Support Enabled
INFO - 2018-02-01 13:58:45 --> Utf8 Class Initialized
INFO - 2018-02-01 13:58:45 --> URI Class Initialized
INFO - 2018-02-01 13:58:45 --> Router Class Initialized
INFO - 2018-02-01 13:58:45 --> Output Class Initialized
INFO - 2018-02-01 13:58:45 --> Security Class Initialized
DEBUG - 2018-02-01 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 13:58:45 --> Input Class Initialized
INFO - 2018-02-01 13:58:45 --> Language Class Initialized
INFO - 2018-02-01 13:58:45 --> Language Class Initialized
INFO - 2018-02-01 13:58:45 --> Config Class Initialized
INFO - 2018-02-01 13:58:45 --> Loader Class Initialized
INFO - 2018-02-01 19:28:45 --> Helper loaded: url_helper
INFO - 2018-02-01 19:28:45 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:28:45 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:28:45 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:28:45 --> Helper loaded: users_helper
INFO - 2018-02-01 19:28:45 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:28:45 --> Helper loaded: form_helper
INFO - 2018-02-01 19:28:45 --> Form Validation Class Initialized
INFO - 2018-02-01 19:28:45 --> Controller Class Initialized
INFO - 2018-02-01 19:28:45 --> Model Class Initialized
INFO - 2018-02-01 19:28:45 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:28:45 --> Model Class Initialized
INFO - 2018-02-01 19:28:45 --> Model Class Initialized
INFO - 2018-02-01 19:28:45 --> Model Class Initialized
INFO - 2018-02-01 19:28:45 --> Model Class Initialized
INFO - 2018-02-01 19:28:45 --> Model Class Initialized
DEBUG - 2018-02-01 19:28:45 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-01 19:28:45 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-02-01 19:28:45 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-01 19:28:45 --> Final output sent to browser
DEBUG - 2018-02-01 19:28:45 --> Total execution time: 0.1098
INFO - 2018-02-01 13:58:50 --> Config Class Initialized
INFO - 2018-02-01 13:58:50 --> Hooks Class Initialized
DEBUG - 2018-02-01 13:58:50 --> UTF-8 Support Enabled
INFO - 2018-02-01 13:58:50 --> Utf8 Class Initialized
INFO - 2018-02-01 13:58:50 --> URI Class Initialized
INFO - 2018-02-01 13:58:50 --> Router Class Initialized
INFO - 2018-02-01 13:58:50 --> Output Class Initialized
INFO - 2018-02-01 13:58:50 --> Security Class Initialized
DEBUG - 2018-02-01 13:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 13:58:50 --> Input Class Initialized
INFO - 2018-02-01 13:58:50 --> Language Class Initialized
INFO - 2018-02-01 13:58:50 --> Language Class Initialized
INFO - 2018-02-01 13:58:50 --> Config Class Initialized
INFO - 2018-02-01 13:58:50 --> Loader Class Initialized
INFO - 2018-02-01 19:28:50 --> Helper loaded: url_helper
INFO - 2018-02-01 19:28:50 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:28:50 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:28:50 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:28:50 --> Helper loaded: users_helper
INFO - 2018-02-01 19:28:50 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:28:50 --> Helper loaded: form_helper
INFO - 2018-02-01 19:28:50 --> Form Validation Class Initialized
INFO - 2018-02-01 19:28:50 --> Controller Class Initialized
INFO - 2018-02-01 19:28:50 --> Model Class Initialized
INFO - 2018-02-01 19:28:50 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:28:50 --> Model Class Initialized
INFO - 2018-02-01 19:28:50 --> Model Class Initialized
INFO - 2018-02-01 19:28:50 --> Model Class Initialized
DEBUG - 2018-02-01 19:28:50 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-01 19:28:50 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-01 19:28:50 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-01 19:28:50 --> Final output sent to browser
DEBUG - 2018-02-01 19:28:50 --> Total execution time: 0.1697
INFO - 2018-02-01 13:59:27 --> Config Class Initialized
INFO - 2018-02-01 13:59:27 --> Hooks Class Initialized
DEBUG - 2018-02-01 13:59:27 --> UTF-8 Support Enabled
INFO - 2018-02-01 13:59:27 --> Utf8 Class Initialized
INFO - 2018-02-01 13:59:27 --> URI Class Initialized
INFO - 2018-02-01 13:59:27 --> Router Class Initialized
INFO - 2018-02-01 13:59:27 --> Output Class Initialized
INFO - 2018-02-01 13:59:27 --> Security Class Initialized
DEBUG - 2018-02-01 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 13:59:27 --> Input Class Initialized
INFO - 2018-02-01 13:59:27 --> Language Class Initialized
INFO - 2018-02-01 13:59:27 --> Language Class Initialized
INFO - 2018-02-01 13:59:27 --> Config Class Initialized
INFO - 2018-02-01 13:59:27 --> Loader Class Initialized
INFO - 2018-02-01 19:29:27 --> Helper loaded: url_helper
INFO - 2018-02-01 19:29:27 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:29:27 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:29:27 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:29:27 --> Helper loaded: users_helper
INFO - 2018-02-01 19:29:27 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:29:27 --> Helper loaded: form_helper
INFO - 2018-02-01 19:29:27 --> Form Validation Class Initialized
INFO - 2018-02-01 19:29:27 --> Controller Class Initialized
INFO - 2018-02-01 19:29:27 --> Model Class Initialized
INFO - 2018-02-01 19:29:27 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:29:27 --> Model Class Initialized
INFO - 2018-02-01 19:29:27 --> Model Class Initialized
INFO - 2018-02-01 19:29:27 --> Model Class Initialized
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:29:29 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
INFO - 2018-02-01 13:59:29 --> Config Class Initialized
INFO - 2018-02-01 13:59:29 --> Hooks Class Initialized
DEBUG - 2018-02-01 13:59:29 --> UTF-8 Support Enabled
INFO - 2018-02-01 13:59:29 --> Utf8 Class Initialized
INFO - 2018-02-01 13:59:29 --> URI Class Initialized
INFO - 2018-02-01 13:59:29 --> Router Class Initialized
INFO - 2018-02-01 13:59:29 --> Output Class Initialized
INFO - 2018-02-01 13:59:29 --> Security Class Initialized
DEBUG - 2018-02-01 13:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 13:59:29 --> Input Class Initialized
INFO - 2018-02-01 13:59:29 --> Language Class Initialized
INFO - 2018-02-01 13:59:29 --> Language Class Initialized
INFO - 2018-02-01 13:59:29 --> Config Class Initialized
INFO - 2018-02-01 13:59:29 --> Loader Class Initialized
INFO - 2018-02-01 19:29:29 --> Helper loaded: url_helper
INFO - 2018-02-01 19:29:29 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:29:29 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:29:29 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:29:29 --> Helper loaded: users_helper
INFO - 2018-02-01 19:29:29 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:29:29 --> Helper loaded: form_helper
INFO - 2018-02-01 19:29:29 --> Form Validation Class Initialized
INFO - 2018-02-01 19:29:29 --> Controller Class Initialized
INFO - 2018-02-01 19:29:29 --> Model Class Initialized
INFO - 2018-02-01 19:29:29 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:29:29 --> Model Class Initialized
INFO - 2018-02-01 19:29:29 --> Model Class Initialized
INFO - 2018-02-01 19:29:29 --> Model Class Initialized
DEBUG - 2018-02-01 19:29:29 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-01 19:29:29 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-01 19:29:29 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-01 19:29:29 --> Final output sent to browser
DEBUG - 2018-02-01 19:29:29 --> Total execution time: 0.0793
INFO - 2018-02-01 14:00:03 --> Config Class Initialized
INFO - 2018-02-01 14:00:03 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:00:03 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:00:03 --> Utf8 Class Initialized
INFO - 2018-02-01 14:00:03 --> URI Class Initialized
INFO - 2018-02-01 14:00:03 --> Router Class Initialized
INFO - 2018-02-01 14:00:03 --> Output Class Initialized
INFO - 2018-02-01 14:00:03 --> Security Class Initialized
DEBUG - 2018-02-01 14:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:00:03 --> Input Class Initialized
INFO - 2018-02-01 14:00:03 --> Language Class Initialized
INFO - 2018-02-01 14:00:03 --> Language Class Initialized
INFO - 2018-02-01 14:00:03 --> Config Class Initialized
INFO - 2018-02-01 14:00:03 --> Loader Class Initialized
INFO - 2018-02-01 19:30:03 --> Helper loaded: url_helper
INFO - 2018-02-01 19:30:03 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:30:03 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:30:03 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:30:03 --> Helper loaded: users_helper
INFO - 2018-02-01 19:30:04 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:30:04 --> Helper loaded: form_helper
INFO - 2018-02-01 19:30:04 --> Form Validation Class Initialized
INFO - 2018-02-01 19:30:04 --> Controller Class Initialized
INFO - 2018-02-01 19:30:04 --> Model Class Initialized
INFO - 2018-02-01 19:30:04 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:30:04 --> Model Class Initialized
INFO - 2018-02-01 19:30:04 --> Model Class Initialized
INFO - 2018-02-01 19:30:04 --> Model Class Initialized
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:30:05 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
INFO - 2018-02-01 14:00:06 --> Config Class Initialized
INFO - 2018-02-01 14:00:06 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:00:06 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:00:06 --> Utf8 Class Initialized
INFO - 2018-02-01 14:00:06 --> URI Class Initialized
INFO - 2018-02-01 14:00:06 --> Router Class Initialized
INFO - 2018-02-01 14:00:06 --> Output Class Initialized
INFO - 2018-02-01 14:00:06 --> Security Class Initialized
DEBUG - 2018-02-01 14:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:00:06 --> Input Class Initialized
INFO - 2018-02-01 14:00:06 --> Language Class Initialized
INFO - 2018-02-01 14:00:06 --> Language Class Initialized
INFO - 2018-02-01 14:00:06 --> Config Class Initialized
INFO - 2018-02-01 14:00:06 --> Loader Class Initialized
INFO - 2018-02-01 19:30:06 --> Helper loaded: url_helper
INFO - 2018-02-01 19:30:06 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:30:06 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:30:06 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:30:06 --> Helper loaded: users_helper
INFO - 2018-02-01 19:30:06 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:30:06 --> Helper loaded: form_helper
INFO - 2018-02-01 19:30:06 --> Form Validation Class Initialized
INFO - 2018-02-01 19:30:06 --> Controller Class Initialized
INFO - 2018-02-01 19:30:06 --> Model Class Initialized
INFO - 2018-02-01 19:30:06 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:30:06 --> Model Class Initialized
INFO - 2018-02-01 19:30:06 --> Model Class Initialized
INFO - 2018-02-01 19:30:06 --> Model Class Initialized
DEBUG - 2018-02-01 19:30:06 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-01 19:30:06 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-01 19:30:06 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-01 19:30:06 --> Final output sent to browser
DEBUG - 2018-02-01 19:30:06 --> Total execution time: 0.0992
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 14:00:33 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:00:33 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:00:33 --> Utf8 Class Initialized
INFO - 2018-02-01 14:00:33 --> URI Class Initialized
INFO - 2018-02-01 14:00:33 --> Router Class Initialized
INFO - 2018-02-01 14:00:33 --> Output Class Initialized
INFO - 2018-02-01 14:00:33 --> Security Class Initialized
DEBUG - 2018-02-01 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:00:33 --> Input Class Initialized
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 14:00:33 --> Loader Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: url_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: users_helper
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 14:00:33 --> Hooks Class Initialized
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 14:00:33 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:00:33 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:00:33 --> Utf8 Class Initialized
DEBUG - 2018-02-01 14:00:33 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:00:33 --> Utf8 Class Initialized
INFO - 2018-02-01 14:00:33 --> URI Class Initialized
INFO - 2018-02-01 14:00:33 --> URI Class Initialized
INFO - 2018-02-01 19:30:33 --> Database Driver Class Initialized
INFO - 2018-02-01 14:00:33 --> Router Class Initialized
INFO - 2018-02-01 14:00:33 --> Router Class Initialized
DEBUG - 2018-02-01 19:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:00:33 --> Output Class Initialized
INFO - 2018-02-01 14:00:33 --> Output Class Initialized
INFO - 2018-02-01 14:00:33 --> Security Class Initialized
INFO - 2018-02-01 14:00:33 --> Security Class Initialized
DEBUG - 2018-02-01 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:00:33 --> Input Class Initialized
DEBUG - 2018-02-01 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:00:33 --> Input Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: form_helper
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 19:30:33 --> Form Validation Class Initialized
INFO - 2018-02-01 19:30:33 --> Controller Class Initialized
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 14:00:33 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:00:33 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:00:33 --> Utf8 Class Initialized
INFO - 2018-02-01 14:00:33 --> URI Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: inflector_helper
INFO - 2018-02-01 14:00:33 --> Router Class Initialized
DEBUG - 2018-02-01 19:30:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:00:33 --> Output Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 14:00:33 --> Loader Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 14:00:33 --> Security Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 14:00:33 --> Loader Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: url_helper
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: notification_helper
DEBUG - 2018-02-01 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:00:33 --> Input Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: url_helper
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: users_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:30:33 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: users_helper
INFO - 2018-02-01 19:30:33 --> Final output sent to browser
DEBUG - 2018-02-01 19:30:33 --> Total execution time: 0.1014
INFO - 2018-02-01 19:30:33 --> Database Driver Class Initialized
INFO - 2018-02-01 19:30:33 --> Database Driver Class Initialized
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 14:00:33 --> Loader Class Initialized
DEBUG - 2018-02-01 19:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:30:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-01 19:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:30:33 --> Helper loaded: url_helper
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 14:00:33 --> Hooks Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: permission_helper
DEBUG - 2018-02-01 14:00:33 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:00:33 --> Utf8 Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: users_helper
INFO - 2018-02-01 14:00:33 --> URI Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: form_helper
INFO - 2018-02-01 19:30:33 --> Form Validation Class Initialized
INFO - 2018-02-01 19:30:33 --> Controller Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: form_helper
INFO - 2018-02-01 19:30:33 --> Form Validation Class Initialized
INFO - 2018-02-01 19:30:33 --> Controller Class Initialized
INFO - 2018-02-01 14:00:33 --> Router Class Initialized
INFO - 2018-02-01 14:00:33 --> Output Class Initialized
INFO - 2018-02-01 14:00:33 --> Security Class Initialized
DEBUG - 2018-02-01 14:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:00:33 --> Input Class Initialized
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:30:33 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:30:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-01 19:30:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
DEBUG - 2018-02-01 19:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 14:00:33 --> Language Class Initialized
INFO - 2018-02-01 14:00:33 --> Config Class Initialized
INFO - 2018-02-01 14:00:33 --> Loader Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:30:33 --> Helper loaded: url_helper
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:30:33 --> Final output sent to browser
DEBUG - 2018-02-01 19:30:33 --> Total execution time: 0.1122
INFO - 2018-02-01 19:30:33 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:30:33 --> Helper loaded: form_helper
INFO - 2018-02-01 19:30:33 --> Form Validation Class Initialized
INFO - 2018-02-01 19:30:33 --> Controller Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: users_helper
INFO - 2018-02-01 19:30:33 --> Final output sent to browser
DEBUG - 2018-02-01 19:30:33 --> Total execution time: 0.1214
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Database Driver Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-01 19:30:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: form_helper
INFO - 2018-02-01 19:30:33 --> Form Validation Class Initialized
INFO - 2018-02-01 19:30:33 --> Controller Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Final output sent to browser
DEBUG - 2018-02-01 19:30:33 --> Total execution time: 0.1162
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:30:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:30:33 --> Model Class Initialized
INFO - 2018-02-01 19:30:33 --> Final output sent to browser
DEBUG - 2018-02-01 19:30:33 --> Total execution time: 0.0820
INFO - 2018-02-01 14:00:35 --> Config Class Initialized
INFO - 2018-02-01 14:00:35 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:00:35 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:00:35 --> Utf8 Class Initialized
INFO - 2018-02-01 14:00:35 --> URI Class Initialized
INFO - 2018-02-01 14:00:35 --> Router Class Initialized
INFO - 2018-02-01 14:00:35 --> Output Class Initialized
INFO - 2018-02-01 14:00:35 --> Security Class Initialized
DEBUG - 2018-02-01 14:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:00:35 --> Input Class Initialized
INFO - 2018-02-01 14:00:35 --> Language Class Initialized
INFO - 2018-02-01 14:00:35 --> Language Class Initialized
INFO - 2018-02-01 14:00:35 --> Config Class Initialized
INFO - 2018-02-01 14:00:35 --> Loader Class Initialized
INFO - 2018-02-01 19:30:35 --> Helper loaded: url_helper
INFO - 2018-02-01 19:30:35 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:30:35 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:30:35 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:30:35 --> Helper loaded: users_helper
INFO - 2018-02-01 19:30:35 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:30:35 --> Helper loaded: form_helper
INFO - 2018-02-01 19:30:35 --> Form Validation Class Initialized
INFO - 2018-02-01 19:30:35 --> Controller Class Initialized
INFO - 2018-02-01 19:30:35 --> Model Class Initialized
INFO - 2018-02-01 19:30:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:30:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:30:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:30:35 --> Model Class Initialized
INFO - 2018-02-01 19:30:35 --> Model Class Initialized
INFO - 2018-02-01 19:30:35 --> Model Class Initialized
INFO - 2018-02-01 19:30:35 --> Model Class Initialized
INFO - 2018-02-01 19:30:35 --> Model Class Initialized
INFO - 2018-02-01 19:30:35 --> Model Class Initialized
INFO - 2018-02-01 19:30:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:30:35 --> Final output sent to browser
DEBUG - 2018-02-01 19:30:35 --> Total execution time: 0.0819
INFO - 2018-02-01 14:03:11 --> Config Class Initialized
INFO - 2018-02-01 14:03:11 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:03:11 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:03:11 --> Utf8 Class Initialized
INFO - 2018-02-01 14:03:11 --> URI Class Initialized
INFO - 2018-02-01 14:03:11 --> Router Class Initialized
INFO - 2018-02-01 14:03:11 --> Output Class Initialized
INFO - 2018-02-01 14:03:11 --> Security Class Initialized
DEBUG - 2018-02-01 14:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:03:11 --> Input Class Initialized
INFO - 2018-02-01 14:03:11 --> Language Class Initialized
INFO - 2018-02-01 14:03:11 --> Language Class Initialized
INFO - 2018-02-01 14:03:11 --> Config Class Initialized
INFO - 2018-02-01 14:03:11 --> Loader Class Initialized
INFO - 2018-02-01 19:33:11 --> Helper loaded: url_helper
INFO - 2018-02-01 19:33:11 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:33:11 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:33:11 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:33:11 --> Helper loaded: users_helper
INFO - 2018-02-01 19:33:11 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:33:11 --> Helper loaded: form_helper
INFO - 2018-02-01 19:33:11 --> Form Validation Class Initialized
INFO - 2018-02-01 19:33:11 --> Controller Class Initialized
INFO - 2018-02-01 19:33:11 --> Model Class Initialized
INFO - 2018-02-01 19:33:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:33:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:33:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:33:11 --> Model Class Initialized
INFO - 2018-02-01 19:33:11 --> Model Class Initialized
INFO - 2018-02-01 19:33:11 --> Model Class Initialized
INFO - 2018-02-01 19:33:11 --> Model Class Initialized
INFO - 2018-02-01 19:33:11 --> Model Class Initialized
INFO - 2018-02-01 19:33:11 --> Model Class Initialized
INFO - 2018-02-01 19:33:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:33:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-01 19:33:11 --> Model Class Initialized
INFO - 2018-02-01 19:33:11 --> Email Class Initialized
INFO - 2018-02-01 19:33:12 --> Language file loaded: language/english/email_lang.php
INFO - 2018-02-01 19:33:14 --> Final output sent to browser
DEBUG - 2018-02-01 19:33:14 --> Total execution time: 2.6873
INFO - 2018-02-01 14:03:15 --> Config Class Initialized
INFO - 2018-02-01 14:03:15 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:03:15 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:03:15 --> Utf8 Class Initialized
INFO - 2018-02-01 14:03:15 --> URI Class Initialized
INFO - 2018-02-01 14:03:15 --> Router Class Initialized
INFO - 2018-02-01 14:03:15 --> Output Class Initialized
INFO - 2018-02-01 14:03:15 --> Security Class Initialized
DEBUG - 2018-02-01 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:03:15 --> Input Class Initialized
INFO - 2018-02-01 14:03:15 --> Language Class Initialized
INFO - 2018-02-01 14:03:15 --> Language Class Initialized
INFO - 2018-02-01 14:03:15 --> Config Class Initialized
INFO - 2018-02-01 14:03:15 --> Loader Class Initialized
INFO - 2018-02-01 19:33:15 --> Helper loaded: url_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: users_helper
INFO - 2018-02-01 19:33:15 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:33:15 --> Helper loaded: form_helper
INFO - 2018-02-01 19:33:15 --> Form Validation Class Initialized
INFO - 2018-02-01 19:33:15 --> Controller Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:33:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:33:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:33:15 --> Final output sent to browser
DEBUG - 2018-02-01 19:33:15 --> Total execution time: 0.1184
INFO - 2018-02-01 14:03:15 --> Config Class Initialized
INFO - 2018-02-01 14:03:15 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:03:15 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:03:15 --> Utf8 Class Initialized
INFO - 2018-02-01 14:03:15 --> URI Class Initialized
INFO - 2018-02-01 14:03:15 --> Router Class Initialized
INFO - 2018-02-01 14:03:15 --> Output Class Initialized
INFO - 2018-02-01 14:03:15 --> Security Class Initialized
DEBUG - 2018-02-01 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:03:15 --> Input Class Initialized
INFO - 2018-02-01 14:03:15 --> Language Class Initialized
INFO - 2018-02-01 14:03:15 --> Config Class Initialized
INFO - 2018-02-01 14:03:15 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:03:15 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:03:15 --> Utf8 Class Initialized
INFO - 2018-02-01 14:03:15 --> URI Class Initialized
INFO - 2018-02-01 14:03:15 --> Router Class Initialized
INFO - 2018-02-01 14:03:15 --> Output Class Initialized
INFO - 2018-02-01 14:03:15 --> Security Class Initialized
DEBUG - 2018-02-01 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:03:15 --> Input Class Initialized
INFO - 2018-02-01 14:03:15 --> Language Class Initialized
INFO - 2018-02-01 14:03:15 --> Language Class Initialized
INFO - 2018-02-01 14:03:15 --> Config Class Initialized
INFO - 2018-02-01 14:03:15 --> Loader Class Initialized
INFO - 2018-02-01 19:33:15 --> Helper loaded: url_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: users_helper
INFO - 2018-02-01 19:33:15 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:33:15 --> Helper loaded: form_helper
INFO - 2018-02-01 19:33:15 --> Form Validation Class Initialized
INFO - 2018-02-01 19:33:15 --> Controller Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Helper loaded: inflector_helper
INFO - 2018-02-01 14:03:15 --> Language Class Initialized
INFO - 2018-02-01 14:03:15 --> Config Class Initialized
INFO - 2018-02-01 14:03:15 --> Loader Class Initialized
DEBUG - 2018-02-01 19:33:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:33:15 --> Helper loaded: url_helper
INFO - 2018-02-01 19:33:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:33:15 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:33:15 --> Helper loaded: users_helper
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 19:33:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 553
INFO - 2018-02-01 19:33:15 --> Final output sent to browser
DEBUG - 2018-02-01 19:33:15 --> Total execution time: 0.1131
INFO - 2018-02-01 19:33:15 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:33:15 --> Helper loaded: form_helper
INFO - 2018-02-01 19:33:15 --> Form Validation Class Initialized
INFO - 2018-02-01 19:33:15 --> Controller Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:33:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:33:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:33:15 --> Model Class Initialized
INFO - 2018-02-01 19:33:15 --> Final output sent to browser
DEBUG - 2018-02-01 19:33:15 --> Total execution time: 0.2575
INFO - 2018-02-01 14:03:16 --> Config Class Initialized
INFO - 2018-02-01 14:03:16 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:03:16 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:03:16 --> Utf8 Class Initialized
INFO - 2018-02-01 14:03:16 --> URI Class Initialized
INFO - 2018-02-01 14:03:16 --> Router Class Initialized
INFO - 2018-02-01 14:03:16 --> Output Class Initialized
INFO - 2018-02-01 14:03:16 --> Security Class Initialized
DEBUG - 2018-02-01 14:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:03:16 --> Input Class Initialized
INFO - 2018-02-01 14:03:16 --> Language Class Initialized
INFO - 2018-02-01 14:03:16 --> Language Class Initialized
INFO - 2018-02-01 14:03:16 --> Config Class Initialized
INFO - 2018-02-01 14:03:16 --> Loader Class Initialized
INFO - 2018-02-01 19:33:16 --> Helper loaded: url_helper
INFO - 2018-02-01 19:33:16 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:33:16 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:33:16 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:33:16 --> Helper loaded: users_helper
INFO - 2018-02-01 19:33:16 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:33:16 --> Helper loaded: form_helper
INFO - 2018-02-01 19:33:16 --> Form Validation Class Initialized
INFO - 2018-02-01 19:33:16 --> Controller Class Initialized
INFO - 2018-02-01 19:33:16 --> Model Class Initialized
INFO - 2018-02-01 19:33:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:33:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:33:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:33:16 --> Model Class Initialized
INFO - 2018-02-01 19:33:16 --> Model Class Initialized
INFO - 2018-02-01 19:33:16 --> Model Class Initialized
INFO - 2018-02-01 19:33:16 --> Model Class Initialized
INFO - 2018-02-01 19:33:16 --> Model Class Initialized
INFO - 2018-02-01 19:33:16 --> Model Class Initialized
INFO - 2018-02-01 19:33:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:33:16 --> Final output sent to browser
DEBUG - 2018-02-01 19:33:16 --> Total execution time: 0.1033
INFO - 2018-02-01 14:03:34 --> Config Class Initialized
INFO - 2018-02-01 14:03:34 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:03:34 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:03:34 --> Utf8 Class Initialized
INFO - 2018-02-01 14:03:34 --> URI Class Initialized
INFO - 2018-02-01 14:03:34 --> Router Class Initialized
INFO - 2018-02-01 14:03:34 --> Output Class Initialized
INFO - 2018-02-01 14:03:34 --> Security Class Initialized
DEBUG - 2018-02-01 14:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:03:34 --> Input Class Initialized
INFO - 2018-02-01 14:03:34 --> Language Class Initialized
INFO - 2018-02-01 14:03:34 --> Language Class Initialized
INFO - 2018-02-01 14:03:34 --> Config Class Initialized
INFO - 2018-02-01 14:03:34 --> Loader Class Initialized
INFO - 2018-02-01 19:33:34 --> Helper loaded: url_helper
INFO - 2018-02-01 19:33:34 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:33:34 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:33:34 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:33:34 --> Helper loaded: users_helper
INFO - 2018-02-01 19:33:34 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:33:34 --> Helper loaded: form_helper
INFO - 2018-02-01 19:33:34 --> Form Validation Class Initialized
INFO - 2018-02-01 19:33:34 --> Controller Class Initialized
INFO - 2018-02-01 19:33:34 --> Model Class Initialized
INFO - 2018-02-01 19:33:34 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:33:34 --> Model Class Initialized
INFO - 2018-02-01 19:33:34 --> Model Class Initialized
INFO - 2018-02-01 19:33:34 --> Model Class Initialized
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-01 19:33:35 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
INFO - 2018-02-01 14:03:35 --> Config Class Initialized
INFO - 2018-02-01 14:03:35 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:03:35 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:03:35 --> Utf8 Class Initialized
INFO - 2018-02-01 14:03:35 --> URI Class Initialized
INFO - 2018-02-01 14:03:35 --> Router Class Initialized
INFO - 2018-02-01 14:03:35 --> Output Class Initialized
INFO - 2018-02-01 14:03:35 --> Security Class Initialized
DEBUG - 2018-02-01 14:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:03:35 --> Input Class Initialized
INFO - 2018-02-01 14:03:35 --> Language Class Initialized
INFO - 2018-02-01 14:03:35 --> Language Class Initialized
INFO - 2018-02-01 14:03:35 --> Config Class Initialized
INFO - 2018-02-01 14:03:35 --> Loader Class Initialized
INFO - 2018-02-01 19:33:35 --> Helper loaded: url_helper
INFO - 2018-02-01 19:33:35 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:33:35 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:33:35 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:33:35 --> Helper loaded: users_helper
INFO - 2018-02-01 19:33:35 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:33:36 --> Helper loaded: form_helper
INFO - 2018-02-01 19:33:36 --> Form Validation Class Initialized
INFO - 2018-02-01 19:33:36 --> Controller Class Initialized
INFO - 2018-02-01 19:33:36 --> Model Class Initialized
INFO - 2018-02-01 19:33:36 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:33:36 --> Model Class Initialized
INFO - 2018-02-01 19:33:36 --> Model Class Initialized
INFO - 2018-02-01 19:33:36 --> Model Class Initialized
DEBUG - 2018-02-01 19:33:36 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-01 19:33:36 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-01 19:33:36 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-01 19:33:36 --> Final output sent to browser
DEBUG - 2018-02-01 19:33:36 --> Total execution time: 0.0941
INFO - 2018-02-01 14:04:06 --> Config Class Initialized
INFO - 2018-02-01 14:04:06 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:06 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:06 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:06 --> URI Class Initialized
INFO - 2018-02-01 14:04:06 --> Router Class Initialized
INFO - 2018-02-01 14:04:06 --> Output Class Initialized
INFO - 2018-02-01 14:04:06 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:06 --> Input Class Initialized
INFO - 2018-02-01 14:04:06 --> Language Class Initialized
INFO - 2018-02-01 14:04:06 --> Language Class Initialized
INFO - 2018-02-01 14:04:06 --> Config Class Initialized
INFO - 2018-02-01 14:04:06 --> Loader Class Initialized
INFO - 2018-02-01 19:34:06 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:06 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:06 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:06 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:06 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:06 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:06 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:06 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:06 --> Controller Class Initialized
INFO - 2018-02-01 19:34:06 --> Model Class Initialized
INFO - 2018-02-01 19:34:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:06 --> Model Class Initialized
INFO - 2018-02-01 19:34:06 --> Model Class Initialized
INFO - 2018-02-01 19:34:06 --> Model Class Initialized
INFO - 2018-02-01 19:34:06 --> Model Class Initialized
INFO - 2018-02-01 19:34:06 --> Model Class Initialized
INFO - 2018-02-01 19:34:06 --> Model Class Initialized
INFO - 2018-02-01 19:34:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:34:06 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:06 --> Total execution time: 0.0842
INFO - 2018-02-01 14:04:06 --> Config Class Initialized
INFO - 2018-02-01 14:04:06 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:06 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:06 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:06 --> URI Class Initialized
INFO - 2018-02-01 14:04:06 --> Router Class Initialized
INFO - 2018-02-01 14:04:06 --> Output Class Initialized
INFO - 2018-02-01 14:04:06 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:06 --> Input Class Initialized
INFO - 2018-02-01 14:04:06 --> Language Class Initialized
INFO - 2018-02-01 14:04:07 --> Config Class Initialized
INFO - 2018-02-01 14:04:07 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:07 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:07 --> URI Class Initialized
INFO - 2018-02-01 14:04:07 --> Router Class Initialized
INFO - 2018-02-01 14:04:07 --> Output Class Initialized
INFO - 2018-02-01 14:04:07 --> Language Class Initialized
INFO - 2018-02-01 14:04:07 --> Config Class Initialized
INFO - 2018-02-01 14:04:07 --> Loader Class Initialized
INFO - 2018-02-01 14:04:07 --> Security Class Initialized
INFO - 2018-02-01 19:34:07 --> Helper loaded: url_helper
DEBUG - 2018-02-01 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:07 --> Input Class Initialized
INFO - 2018-02-01 19:34:07 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:04:07 --> Language Class Initialized
INFO - 2018-02-01 19:34:07 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:07 --> Database Driver Class Initialized
INFO - 2018-02-01 14:04:07 --> Language Class Initialized
INFO - 2018-02-01 14:04:07 --> Config Class Initialized
INFO - 2018-02-01 14:04:07 --> Loader Class Initialized
DEBUG - 2018-02-01 19:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:07 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:07 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:07 --> Controller Class Initialized
INFO - 2018-02-01 19:34:07 --> Database Driver Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-01 19:34:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:07 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:07 --> Controller Class Initialized
INFO - 2018-02-01 19:34:07 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:07 --> Total execution time: 0.1219
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 19:34:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 553
INFO - 2018-02-01 19:34:07 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:07 --> Total execution time: 0.1068
INFO - 2018-02-01 14:04:07 --> Config Class Initialized
INFO - 2018-02-01 14:04:07 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:07 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:07 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:07 --> URI Class Initialized
INFO - 2018-02-01 14:04:07 --> Router Class Initialized
INFO - 2018-02-01 14:04:07 --> Output Class Initialized
INFO - 2018-02-01 14:04:07 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:07 --> Input Class Initialized
INFO - 2018-02-01 14:04:07 --> Language Class Initialized
INFO - 2018-02-01 14:04:07 --> Language Class Initialized
INFO - 2018-02-01 14:04:07 --> Config Class Initialized
INFO - 2018-02-01 14:04:07 --> Loader Class Initialized
INFO - 2018-02-01 19:34:07 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:07 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:07 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:07 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:07 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:07 --> Controller Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Model Class Initialized
INFO - 2018-02-01 19:34:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:34:07 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:07 --> Total execution time: 0.1151
INFO - 2018-02-01 14:04:19 --> Config Class Initialized
INFO - 2018-02-01 14:04:19 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:19 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:19 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:19 --> URI Class Initialized
INFO - 2018-02-01 14:04:19 --> Router Class Initialized
INFO - 2018-02-01 14:04:19 --> Output Class Initialized
INFO - 2018-02-01 14:04:19 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:19 --> Input Class Initialized
INFO - 2018-02-01 14:04:19 --> Language Class Initialized
INFO - 2018-02-01 14:04:19 --> Language Class Initialized
INFO - 2018-02-01 14:04:19 --> Config Class Initialized
INFO - 2018-02-01 14:04:19 --> Loader Class Initialized
INFO - 2018-02-01 19:34:19 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:19 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:19 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:19 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:19 --> Controller Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:34:19 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:19 --> Total execution time: 0.1049
INFO - 2018-02-01 14:04:19 --> Config Class Initialized
INFO - 2018-02-01 14:04:19 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:19 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:19 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:19 --> URI Class Initialized
INFO - 2018-02-01 14:04:19 --> Router Class Initialized
INFO - 2018-02-01 14:04:19 --> Output Class Initialized
INFO - 2018-02-01 14:04:19 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:19 --> Input Class Initialized
INFO - 2018-02-01 14:04:19 --> Language Class Initialized
INFO - 2018-02-01 14:04:19 --> Language Class Initialized
INFO - 2018-02-01 14:04:19 --> Config Class Initialized
INFO - 2018-02-01 14:04:19 --> Loader Class Initialized
INFO - 2018-02-01 19:34:19 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:19 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:19 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:19 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:19 --> Controller Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 19:34:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 553
INFO - 2018-02-01 19:34:19 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:19 --> Total execution time: 0.1203
INFO - 2018-02-01 14:04:19 --> Config Class Initialized
INFO - 2018-02-01 14:04:19 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:19 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:19 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:19 --> URI Class Initialized
INFO - 2018-02-01 14:04:19 --> Router Class Initialized
INFO - 2018-02-01 14:04:19 --> Output Class Initialized
INFO - 2018-02-01 14:04:19 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:19 --> Input Class Initialized
INFO - 2018-02-01 14:04:19 --> Language Class Initialized
INFO - 2018-02-01 14:04:19 --> Language Class Initialized
INFO - 2018-02-01 14:04:19 --> Config Class Initialized
INFO - 2018-02-01 14:04:19 --> Loader Class Initialized
INFO - 2018-02-01 19:34:19 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:19 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:19 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:19 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:19 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:19 --> Controller Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:34:19 --> Model Class Initialized
INFO - 2018-02-01 19:34:19 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:19 --> Total execution time: 0.1079
INFO - 2018-02-01 14:04:20 --> Config Class Initialized
INFO - 2018-02-01 14:04:20 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:20 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:20 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:20 --> URI Class Initialized
INFO - 2018-02-01 14:04:20 --> Router Class Initialized
INFO - 2018-02-01 14:04:20 --> Output Class Initialized
INFO - 2018-02-01 14:04:20 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:20 --> Input Class Initialized
INFO - 2018-02-01 14:04:20 --> Language Class Initialized
INFO - 2018-02-01 14:04:20 --> Language Class Initialized
INFO - 2018-02-01 14:04:20 --> Config Class Initialized
INFO - 2018-02-01 14:04:20 --> Loader Class Initialized
INFO - 2018-02-01 19:34:20 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:20 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:20 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:20 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:20 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:20 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:20 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:20 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:20 --> Controller Class Initialized
INFO - 2018-02-01 19:34:20 --> Model Class Initialized
INFO - 2018-02-01 19:34:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:20 --> Model Class Initialized
INFO - 2018-02-01 19:34:20 --> Model Class Initialized
INFO - 2018-02-01 19:34:20 --> Model Class Initialized
INFO - 2018-02-01 19:34:20 --> Model Class Initialized
INFO - 2018-02-01 19:34:20 --> Model Class Initialized
INFO - 2018-02-01 19:34:20 --> Model Class Initialized
INFO - 2018-02-01 19:34:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:34:20 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:20 --> Total execution time: 0.1221
INFO - 2018-02-01 14:04:51 --> Config Class Initialized
INFO - 2018-02-01 14:04:51 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:51 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:51 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:51 --> URI Class Initialized
INFO - 2018-02-01 14:04:51 --> Router Class Initialized
INFO - 2018-02-01 14:04:51 --> Output Class Initialized
INFO - 2018-02-01 14:04:51 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:51 --> Input Class Initialized
INFO - 2018-02-01 14:04:51 --> Language Class Initialized
INFO - 2018-02-01 14:04:51 --> Config Class Initialized
INFO - 2018-02-01 14:04:51 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:51 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:51 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:51 --> URI Class Initialized
INFO - 2018-02-01 14:04:51 --> Router Class Initialized
INFO - 2018-02-01 14:04:51 --> Output Class Initialized
INFO - 2018-02-01 14:04:51 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:51 --> Input Class Initialized
INFO - 2018-02-01 14:04:51 --> Language Class Initialized
INFO - 2018-02-01 14:04:51 --> Language Class Initialized
INFO - 2018-02-01 14:04:51 --> Config Class Initialized
INFO - 2018-02-01 14:04:51 --> Loader Class Initialized
INFO - 2018-02-01 19:34:51 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: users_helper
INFO - 2018-02-01 14:04:51 --> Language Class Initialized
INFO - 2018-02-01 14:04:51 --> Config Class Initialized
INFO - 2018-02-01 14:04:51 --> Loader Class Initialized
INFO - 2018-02-01 19:34:51 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:51 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:51 --> Database Driver Class Initialized
INFO - 2018-02-01 19:34:51 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:51 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:51 --> Controller Class Initialized
DEBUG - 2018-02-01 19:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: form_helper
DEBUG - 2018-02-01 19:34:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:51 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:51 --> Controller Class Initialized
INFO - 2018-02-01 19:34:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:34:51 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:51 --> Total execution time: 0.1124
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:51 --> Total execution time: 0.1085
INFO - 2018-02-01 14:04:51 --> Config Class Initialized
INFO - 2018-02-01 14:04:51 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:51 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:51 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:51 --> URI Class Initialized
INFO - 2018-02-01 14:04:51 --> Router Class Initialized
INFO - 2018-02-01 14:04:51 --> Output Class Initialized
INFO - 2018-02-01 14:04:51 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:51 --> Input Class Initialized
INFO - 2018-02-01 14:04:51 --> Language Class Initialized
INFO - 2018-02-01 14:04:51 --> Language Class Initialized
INFO - 2018-02-01 14:04:51 --> Config Class Initialized
INFO - 2018-02-01 14:04:51 --> Loader Class Initialized
INFO - 2018-02-01 19:34:51 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:51 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:51 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:51 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:51 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:51 --> Controller Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Model Class Initialized
INFO - 2018-02-01 19:34:51 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 19:34:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 553
INFO - 2018-02-01 19:34:51 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:51 --> Total execution time: 0.1104
INFO - 2018-02-01 14:04:52 --> Config Class Initialized
INFO - 2018-02-01 14:04:52 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:04:52 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:04:52 --> Utf8 Class Initialized
INFO - 2018-02-01 14:04:52 --> URI Class Initialized
INFO - 2018-02-01 14:04:52 --> Router Class Initialized
INFO - 2018-02-01 14:04:52 --> Output Class Initialized
INFO - 2018-02-01 14:04:52 --> Security Class Initialized
DEBUG - 2018-02-01 14:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:04:52 --> Input Class Initialized
INFO - 2018-02-01 14:04:52 --> Language Class Initialized
INFO - 2018-02-01 14:04:52 --> Language Class Initialized
INFO - 2018-02-01 14:04:52 --> Config Class Initialized
INFO - 2018-02-01 14:04:52 --> Loader Class Initialized
INFO - 2018-02-01 19:34:52 --> Helper loaded: url_helper
INFO - 2018-02-01 19:34:52 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:34:52 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:34:52 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:34:52 --> Helper loaded: users_helper
INFO - 2018-02-01 19:34:52 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:34:52 --> Helper loaded: form_helper
INFO - 2018-02-01 19:34:52 --> Form Validation Class Initialized
INFO - 2018-02-01 19:34:52 --> Controller Class Initialized
INFO - 2018-02-01 19:34:52 --> Model Class Initialized
INFO - 2018-02-01 19:34:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:34:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:34:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:34:52 --> Model Class Initialized
INFO - 2018-02-01 19:34:52 --> Model Class Initialized
INFO - 2018-02-01 19:34:52 --> Model Class Initialized
INFO - 2018-02-01 19:34:52 --> Model Class Initialized
INFO - 2018-02-01 19:34:52 --> Model Class Initialized
INFO - 2018-02-01 19:34:52 --> Model Class Initialized
INFO - 2018-02-01 19:34:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:34:52 --> Final output sent to browser
DEBUG - 2018-02-01 19:34:52 --> Total execution time: 0.1134
INFO - 2018-02-01 14:05:10 --> Config Class Initialized
INFO - 2018-02-01 14:05:10 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:10 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:10 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:10 --> URI Class Initialized
INFO - 2018-02-01 14:05:10 --> Router Class Initialized
INFO - 2018-02-01 14:05:10 --> Output Class Initialized
INFO - 2018-02-01 14:05:10 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:10 --> Input Class Initialized
INFO - 2018-02-01 14:05:10 --> Language Class Initialized
INFO - 2018-02-01 14:05:10 --> Language Class Initialized
INFO - 2018-02-01 14:05:10 --> Config Class Initialized
INFO - 2018-02-01 14:05:10 --> Loader Class Initialized
INFO - 2018-02-01 19:35:10 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:10 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:10 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:10 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:10 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:10 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:10 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:10 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:10 --> Controller Class Initialized
INFO - 2018-02-01 19:35:10 --> Model Class Initialized
INFO - 2018-02-01 19:35:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:10 --> Model Class Initialized
INFO - 2018-02-01 19:35:10 --> Model Class Initialized
INFO - 2018-02-01 19:35:10 --> Model Class Initialized
INFO - 2018-02-01 19:35:10 --> Model Class Initialized
INFO - 2018-02-01 19:35:10 --> Model Class Initialized
INFO - 2018-02-01 19:35:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-01 19:35:10 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:10 --> Total execution time: 0.1128
INFO - 2018-02-01 14:05:10 --> Config Class Initialized
INFO - 2018-02-01 14:05:10 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:10 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:10 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:10 --> URI Class Initialized
INFO - 2018-02-01 14:05:10 --> Router Class Initialized
INFO - 2018-02-01 14:05:10 --> Output Class Initialized
INFO - 2018-02-01 14:05:10 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:10 --> Input Class Initialized
INFO - 2018-02-01 14:05:10 --> Language Class Initialized
INFO - 2018-02-01 14:05:10 --> Language Class Initialized
INFO - 2018-02-01 14:05:10 --> Config Class Initialized
INFO - 2018-02-01 14:05:10 --> Loader Class Initialized
INFO - 2018-02-01 19:35:10 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:10 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:10 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:10 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:10 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:10 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:10 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:10 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:10 --> Controller Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:11 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:11 --> Total execution time: 0.1039
INFO - 2018-02-01 14:05:11 --> Config Class Initialized
INFO - 2018-02-01 14:05:11 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:11 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:11 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:11 --> URI Class Initialized
INFO - 2018-02-01 14:05:11 --> Config Class Initialized
INFO - 2018-02-01 14:05:11 --> Hooks Class Initialized
INFO - 2018-02-01 14:05:11 --> Router Class Initialized
DEBUG - 2018-02-01 14:05:11 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:11 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:11 --> Output Class Initialized
INFO - 2018-02-01 14:05:11 --> URI Class Initialized
INFO - 2018-02-01 14:05:11 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:11 --> Input Class Initialized
INFO - 2018-02-01 14:05:11 --> Router Class Initialized
INFO - 2018-02-01 14:05:11 --> Language Class Initialized
INFO - 2018-02-01 14:05:11 --> Output Class Initialized
INFO - 2018-02-01 14:05:11 --> Config Class Initialized
INFO - 2018-02-01 14:05:11 --> Hooks Class Initialized
INFO - 2018-02-01 14:05:11 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:11 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:11 --> Utf8 Class Initialized
DEBUG - 2018-02-01 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:11 --> Input Class Initialized
INFO - 2018-02-01 14:05:11 --> URI Class Initialized
INFO - 2018-02-01 14:05:11 --> Language Class Initialized
INFO - 2018-02-01 14:05:11 --> Router Class Initialized
INFO - 2018-02-01 14:05:11 --> Output Class Initialized
INFO - 2018-02-01 14:05:11 --> Security Class Initialized
INFO - 2018-02-01 14:05:11 --> Language Class Initialized
INFO - 2018-02-01 14:05:11 --> Config Class Initialized
INFO - 2018-02-01 14:05:11 --> Loader Class Initialized
DEBUG - 2018-02-01 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 19:35:11 --> Helper loaded: url_helper
INFO - 2018-02-01 14:05:11 --> Input Class Initialized
INFO - 2018-02-01 14:05:11 --> Language Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: users_helper
INFO - 2018-02-01 14:05:11 --> Language Class Initialized
INFO - 2018-02-01 14:05:11 --> Config Class Initialized
INFO - 2018-02-01 14:05:11 --> Loader Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:11 --> Database Driver Class Initialized
INFO - 2018-02-01 14:05:11 --> Language Class Initialized
INFO - 2018-02-01 14:05:11 --> Config Class Initialized
INFO - 2018-02-01 14:05:11 --> Loader Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: settings_helper
DEBUG - 2018-02-01 19:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:11 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:11 --> Database Driver Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:11 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:11 --> Controller Class Initialized
DEBUG - 2018-02-01 19:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:05:11 --> Config Class Initialized
INFO - 2018-02-01 14:05:11 --> Hooks Class Initialized
INFO - 2018-02-01 19:35:11 --> Database Driver Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
DEBUG - 2018-02-01 14:05:11 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:11 --> Utf8 Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: inflector_helper
INFO - 2018-02-01 14:05:11 --> URI Class Initialized
DEBUG - 2018-02-01 19:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-01 19:35:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:11 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:11 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:11 --> Controller Class Initialized
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 14:05:11 --> Router Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 14:05:11 --> Output Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:11 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:11 --> Controller Class Initialized
INFO - 2018-02-01 14:05:11 --> Security Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:11 --> Total execution time: 0.1051
INFO - 2018-02-01 19:35:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:11 --> Input Class Initialized
INFO - 2018-02-01 14:05:11 --> Language Class Initialized
DEBUG - 2018-02-01 19:35:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
DEBUG - 2018-02-01 19:35:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 14:05:11 --> Language Class Initialized
INFO - 2018-02-01 14:05:11 --> Config Class Initialized
INFO - 2018-02-01 14:05:11 --> Loader Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:11 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:11 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:11 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:11 --> Total execution time: 0.1428
INFO - 2018-02-01 19:35:11 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:11 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:11 --> Controller Class Initialized
INFO - 2018-02-01 19:35:11 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:11 --> Total execution time: 0.1367
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:11 --> Model Class Initialized
INFO - 2018-02-01 19:35:11 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:11 --> Total execution time: 0.0956
INFO - 2018-02-01 14:05:15 --> Config Class Initialized
INFO - 2018-02-01 14:05:15 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:15 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:15 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:15 --> URI Class Initialized
INFO - 2018-02-01 14:05:15 --> Router Class Initialized
INFO - 2018-02-01 14:05:15 --> Output Class Initialized
INFO - 2018-02-01 14:05:15 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:15 --> Input Class Initialized
INFO - 2018-02-01 14:05:15 --> Language Class Initialized
INFO - 2018-02-01 14:05:15 --> Language Class Initialized
INFO - 2018-02-01 14:05:15 --> Config Class Initialized
INFO - 2018-02-01 14:05:15 --> Loader Class Initialized
INFO - 2018-02-01 19:35:15 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:15 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:05:15 --> Config Class Initialized
INFO - 2018-02-01 14:05:15 --> Hooks Class Initialized
INFO - 2018-02-01 19:35:15 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:15 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:15 --> Helper loaded: users_helper
DEBUG - 2018-02-01 14:05:15 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:15 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:15 --> URI Class Initialized
INFO - 2018-02-01 14:05:15 --> Router Class Initialized
INFO - 2018-02-01 14:05:15 --> Output Class Initialized
INFO - 2018-02-01 14:05:15 --> Security Class Initialized
INFO - 2018-02-01 19:35:15 --> Database Driver Class Initialized
DEBUG - 2018-02-01 14:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:15 --> Input Class Initialized
INFO - 2018-02-01 14:05:15 --> Language Class Initialized
DEBUG - 2018-02-01 19:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:15 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:15 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:15 --> Controller Class Initialized
INFO - 2018-02-01 14:05:15 --> Language Class Initialized
INFO - 2018-02-01 14:05:15 --> Config Class Initialized
INFO - 2018-02-01 14:05:15 --> Loader Class Initialized
INFO - 2018-02-01 19:35:15 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:35:15 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:15 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:15 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:15 --> Helper loaded: users_helper
DEBUG - 2018-02-01 19:35:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:15 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:15 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:15 --> Total execution time: 0.1257
INFO - 2018-02-01 19:35:15 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:15 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:15 --> Controller Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:15 --> Model Class Initialized
INFO - 2018-02-01 19:35:15 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:15 --> Total execution time: 0.1365
INFO - 2018-02-01 14:05:22 --> Config Class Initialized
INFO - 2018-02-01 14:05:22 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:22 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:22 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:22 --> URI Class Initialized
INFO - 2018-02-01 14:05:22 --> Router Class Initialized
INFO - 2018-02-01 14:05:22 --> Output Class Initialized
INFO - 2018-02-01 14:05:22 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:22 --> Input Class Initialized
INFO - 2018-02-01 14:05:22 --> Language Class Initialized
INFO - 2018-02-01 14:05:22 --> Config Class Initialized
INFO - 2018-02-01 14:05:22 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:22 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:22 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:22 --> URI Class Initialized
INFO - 2018-02-01 14:05:22 --> Language Class Initialized
INFO - 2018-02-01 14:05:22 --> Config Class Initialized
INFO - 2018-02-01 14:05:22 --> Loader Class Initialized
INFO - 2018-02-01 14:05:22 --> Router Class Initialized
INFO - 2018-02-01 19:35:22 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:22 --> Helper loaded: notification_helper
INFO - 2018-02-01 14:05:22 --> Output Class Initialized
INFO - 2018-02-01 19:35:22 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:22 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:22 --> Helper loaded: users_helper
INFO - 2018-02-01 14:05:22 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:22 --> Input Class Initialized
INFO - 2018-02-01 14:05:22 --> Language Class Initialized
INFO - 2018-02-01 19:35:22 --> Database Driver Class Initialized
INFO - 2018-02-01 14:05:22 --> Language Class Initialized
INFO - 2018-02-01 14:05:22 --> Config Class Initialized
INFO - 2018-02-01 14:05:22 --> Loader Class Initialized
DEBUG - 2018-02-01 19:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:22 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:22 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:22 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:22 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:22 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:22 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:22 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:22 --> Controller Class Initialized
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Database Driver Class Initialized
INFO - 2018-02-01 19:35:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-01 19:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:22 --> Total execution time: 0.1022
INFO - 2018-02-01 19:35:22 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:22 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:22 --> Controller Class Initialized
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Model Class Initialized
INFO - 2018-02-01 19:35:22 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:22 --> Total execution time: 0.0979
INFO - 2018-02-01 14:05:23 --> Config Class Initialized
INFO - 2018-02-01 14:05:23 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:23 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:23 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:23 --> URI Class Initialized
INFO - 2018-02-01 14:05:23 --> Router Class Initialized
INFO - 2018-02-01 14:05:23 --> Output Class Initialized
INFO - 2018-02-01 14:05:23 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:23 --> Input Class Initialized
INFO - 2018-02-01 14:05:23 --> Language Class Initialized
INFO - 2018-02-01 14:05:23 --> Language Class Initialized
INFO - 2018-02-01 14:05:23 --> Config Class Initialized
INFO - 2018-02-01 14:05:23 --> Loader Class Initialized
INFO - 2018-02-01 19:35:23 --> Helper loaded: url_helper
INFO - 2018-02-01 14:05:23 --> Config Class Initialized
INFO - 2018-02-01 14:05:23 --> Hooks Class Initialized
INFO - 2018-02-01 19:35:23 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:23 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:23 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:23 --> Helper loaded: users_helper
DEBUG - 2018-02-01 14:05:23 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:23 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:23 --> URI Class Initialized
INFO - 2018-02-01 14:05:23 --> Router Class Initialized
INFO - 2018-02-01 14:05:23 --> Output Class Initialized
INFO - 2018-02-01 14:05:23 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:23 --> Input Class Initialized
INFO - 2018-02-01 14:05:23 --> Language Class Initialized
INFO - 2018-02-01 19:35:23 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:05:23 --> Language Class Initialized
INFO - 2018-02-01 14:05:23 --> Config Class Initialized
INFO - 2018-02-01 14:05:23 --> Loader Class Initialized
INFO - 2018-02-01 19:35:23 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:23 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:23 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:23 --> Controller Class Initialized
INFO - 2018-02-01 19:35:23 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:23 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:23 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:23 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:35:23 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-01 19:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:23 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:23 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:23 --> Controller Class Initialized
ERROR - 2018-02-01 19:35:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 553
INFO - 2018-02-01 19:35:23 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:23 --> Total execution time: 0.1110
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Model Class Initialized
INFO - 2018-02-01 19:35:23 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-01 19:35:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1410
INFO - 2018-02-01 19:35:23 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:23 --> Total execution time: 0.0819
INFO - 2018-02-01 14:05:24 --> Config Class Initialized
INFO - 2018-02-01 14:05:24 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:24 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:24 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:24 --> URI Class Initialized
INFO - 2018-02-01 14:05:24 --> Router Class Initialized
INFO - 2018-02-01 14:05:24 --> Output Class Initialized
INFO - 2018-02-01 14:05:24 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:24 --> Input Class Initialized
INFO - 2018-02-01 14:05:24 --> Language Class Initialized
INFO - 2018-02-01 14:05:24 --> Language Class Initialized
INFO - 2018-02-01 14:05:24 --> Config Class Initialized
INFO - 2018-02-01 14:05:24 --> Loader Class Initialized
INFO - 2018-02-01 19:35:24 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:24 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:24 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:24 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:24 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:24 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:24 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:24 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:24 --> Controller Class Initialized
INFO - 2018-02-01 19:35:24 --> Model Class Initialized
INFO - 2018-02-01 19:35:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:24 --> Model Class Initialized
INFO - 2018-02-01 19:35:24 --> Model Class Initialized
INFO - 2018-02-01 19:35:24 --> Model Class Initialized
INFO - 2018-02-01 19:35:24 --> Model Class Initialized
INFO - 2018-02-01 19:35:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:24 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:24 --> Total execution time: 0.1369
INFO - 2018-02-01 14:05:26 --> Config Class Initialized
INFO - 2018-02-01 14:05:26 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:26 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:26 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:26 --> URI Class Initialized
INFO - 2018-02-01 14:05:26 --> Router Class Initialized
INFO - 2018-02-01 14:05:26 --> Output Class Initialized
INFO - 2018-02-01 14:05:26 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:26 --> Input Class Initialized
INFO - 2018-02-01 14:05:26 --> Language Class Initialized
INFO - 2018-02-01 14:05:26 --> Language Class Initialized
INFO - 2018-02-01 14:05:26 --> Config Class Initialized
INFO - 2018-02-01 14:05:26 --> Loader Class Initialized
INFO - 2018-02-01 19:35:26 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:26 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:26 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:26 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:26 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:26 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:26 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:26 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:26 --> Controller Class Initialized
INFO - 2018-02-01 19:35:26 --> Model Class Initialized
INFO - 2018-02-01 19:35:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:26 --> Model Class Initialized
INFO - 2018-02-01 19:35:26 --> Model Class Initialized
INFO - 2018-02-01 19:35:26 --> Model Class Initialized
INFO - 2018-02-01 19:35:26 --> Model Class Initialized
INFO - 2018-02-01 19:35:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:26 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:26 --> Total execution time: 0.0987
INFO - 2018-02-01 14:05:28 --> Config Class Initialized
INFO - 2018-02-01 14:05:28 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:28 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:28 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:28 --> URI Class Initialized
INFO - 2018-02-01 14:05:28 --> Router Class Initialized
INFO - 2018-02-01 14:05:28 --> Output Class Initialized
INFO - 2018-02-01 14:05:28 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:28 --> Input Class Initialized
INFO - 2018-02-01 14:05:28 --> Language Class Initialized
INFO - 2018-02-01 14:05:28 --> Language Class Initialized
INFO - 2018-02-01 14:05:28 --> Config Class Initialized
INFO - 2018-02-01 14:05:28 --> Loader Class Initialized
INFO - 2018-02-01 19:35:28 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:28 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:28 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:28 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:28 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:28 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:28 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:28 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:28 --> Controller Class Initialized
INFO - 2018-02-01 19:35:28 --> Model Class Initialized
INFO - 2018-02-01 19:35:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:28 --> Model Class Initialized
INFO - 2018-02-01 19:35:28 --> Model Class Initialized
INFO - 2018-02-01 19:35:28 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:28 --> Total execution time: 0.1073
INFO - 2018-02-01 14:05:34 --> Config Class Initialized
INFO - 2018-02-01 14:05:34 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:34 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:34 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:34 --> URI Class Initialized
INFO - 2018-02-01 14:05:34 --> Router Class Initialized
INFO - 2018-02-01 14:05:34 --> Output Class Initialized
INFO - 2018-02-01 14:05:34 --> Security Class Initialized
DEBUG - 2018-02-01 14:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:34 --> Input Class Initialized
INFO - 2018-02-01 14:05:34 --> Language Class Initialized
INFO - 2018-02-01 14:05:34 --> Config Class Initialized
INFO - 2018-02-01 14:05:34 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:05:34 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:05:34 --> Utf8 Class Initialized
INFO - 2018-02-01 14:05:34 --> URI Class Initialized
INFO - 2018-02-01 14:05:34 --> Router Class Initialized
INFO - 2018-02-01 14:05:34 --> Language Class Initialized
INFO - 2018-02-01 14:05:34 --> Config Class Initialized
INFO - 2018-02-01 14:05:34 --> Loader Class Initialized
INFO - 2018-02-01 14:05:34 --> Output Class Initialized
INFO - 2018-02-01 19:35:34 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:34 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:34 --> Helper loaded: settings_helper
INFO - 2018-02-01 14:05:34 --> Security Class Initialized
INFO - 2018-02-01 19:35:34 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:34 --> Helper loaded: users_helper
DEBUG - 2018-02-01 14:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:05:34 --> Input Class Initialized
INFO - 2018-02-01 14:05:34 --> Language Class Initialized
INFO - 2018-02-01 19:35:34 --> Database Driver Class Initialized
INFO - 2018-02-01 14:05:34 --> Language Class Initialized
INFO - 2018-02-01 14:05:34 --> Config Class Initialized
INFO - 2018-02-01 14:05:34 --> Loader Class Initialized
DEBUG - 2018-02-01 19:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:34 --> Helper loaded: url_helper
INFO - 2018-02-01 19:35:34 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:35:34 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:35:34 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:35:34 --> Helper loaded: users_helper
INFO - 2018-02-01 19:35:34 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:34 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:34 --> Controller Class Initialized
INFO - 2018-02-01 19:35:34 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:35:34 --> Helper loaded: form_helper
INFO - 2018-02-01 19:35:34 --> Form Validation Class Initialized
INFO - 2018-02-01 19:35:34 --> Controller Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:35:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-01 19:35:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:35:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:34 --> Total execution time: 0.1462
INFO - 2018-02-01 19:35:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:35:34 --> Model Class Initialized
INFO - 2018-02-01 19:35:34 --> Final output sent to browser
DEBUG - 2018-02-01 19:35:34 --> Total execution time: 0.1435
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:06:13 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:06:13 --> Utf8 Class Initialized
INFO - 2018-02-01 14:06:13 --> URI Class Initialized
INFO - 2018-02-01 14:06:13 --> Router Class Initialized
INFO - 2018-02-01 14:06:13 --> Output Class Initialized
INFO - 2018-02-01 14:06:13 --> Security Class Initialized
DEBUG - 2018-02-01 14:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:06:13 --> Input Class Initialized
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Loader Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: url_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: users_helper
INFO - 2018-02-01 19:36:13 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:36:13 --> Helper loaded: form_helper
INFO - 2018-02-01 19:36:13 --> Form Validation Class Initialized
INFO - 2018-02-01 19:36:13 --> Controller Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:36:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:36:13 --> Final output sent to browser
DEBUG - 2018-02-01 19:36:13 --> Total execution time: 0.1131
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:06:13 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:06:13 --> Utf8 Class Initialized
INFO - 2018-02-01 14:06:13 --> URI Class Initialized
INFO - 2018-02-01 14:06:13 --> Router Class Initialized
INFO - 2018-02-01 14:06:13 --> Output Class Initialized
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Hooks Class Initialized
INFO - 2018-02-01 14:06:13 --> Security Class Initialized
DEBUG - 2018-02-01 14:06:13 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:06:13 --> Utf8 Class Initialized
DEBUG - 2018-02-01 14:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:06:13 --> Input Class Initialized
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 14:06:13 --> URI Class Initialized
INFO - 2018-02-01 14:06:13 --> Router Class Initialized
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Hooks Class Initialized
INFO - 2018-02-01 14:06:13 --> Output Class Initialized
DEBUG - 2018-02-01 14:06:13 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:06:13 --> Utf8 Class Initialized
INFO - 2018-02-01 14:06:13 --> Security Class Initialized
INFO - 2018-02-01 14:06:13 --> URI Class Initialized
DEBUG - 2018-02-01 14:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:06:13 --> Input Class Initialized
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 14:06:13 --> Router Class Initialized
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Loader Class Initialized
INFO - 2018-02-01 14:06:13 --> Output Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: url_helper
INFO - 2018-02-01 14:06:13 --> Security Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: permission_helper
DEBUG - 2018-02-01 14:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:06:13 --> Input Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: users_helper
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Loader Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: url_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:36:13 --> Database Driver Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: users_helper
DEBUG - 2018-02-01 19:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Loader Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: url_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: users_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: form_helper
INFO - 2018-02-01 19:36:13 --> Form Validation Class Initialized
INFO - 2018-02-01 19:36:13 --> Controller Class Initialized
INFO - 2018-02-01 19:36:13 --> Database Driver Class Initialized
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:06:13 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:06:13 --> Utf8 Class Initialized
DEBUG - 2018-02-01 19:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:06:13 --> URI Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: inflector_helper
INFO - 2018-02-01 14:06:13 --> Router Class Initialized
DEBUG - 2018-02-01 19:36:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:36:13 --> Database Driver Class Initialized
INFO - 2018-02-01 14:06:13 --> Output Class Initialized
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:36:13 --> Helper loaded: form_helper
INFO - 2018-02-01 19:36:13 --> Form Validation Class Initialized
INFO - 2018-02-01 19:36:13 --> Controller Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 14:06:13 --> Security Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
DEBUG - 2018-02-01 19:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
DEBUG - 2018-02-01 14:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:06:13 --> Input Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: inflector_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: form_helper
INFO - 2018-02-01 19:36:13 --> Form Validation Class Initialized
INFO - 2018-02-01 19:36:13 --> Controller Class Initialized
DEBUG - 2018-02-01 19:36:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Final output sent to browser
DEBUG - 2018-02-01 19:36:13 --> Total execution time: 0.1226
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: inflector_helper
INFO - 2018-02-01 14:06:13 --> Language Class Initialized
INFO - 2018-02-01 14:06:13 --> Config Class Initialized
INFO - 2018-02-01 14:06:13 --> Loader Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-01 19:36:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: url_helper
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:36:13 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:36:13 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: users_helper
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Final output sent to browser
DEBUG - 2018-02-01 19:36:13 --> Total execution time: 0.1148
INFO - 2018-02-01 19:36:13 --> Database Driver Class Initialized
INFO - 2018-02-01 19:36:13 --> Final output sent to browser
DEBUG - 2018-02-01 19:36:13 --> Total execution time: 0.1380
DEBUG - 2018-02-01 19:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:36:13 --> Helper loaded: form_helper
INFO - 2018-02-01 19:36:13 --> Form Validation Class Initialized
INFO - 2018-02-01 19:36:13 --> Controller Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:36:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:36:13 --> Model Class Initialized
INFO - 2018-02-01 19:36:13 --> Final output sent to browser
DEBUG - 2018-02-01 19:36:13 --> Total execution time: 0.1279
INFO - 2018-02-01 14:06:15 --> Config Class Initialized
INFO - 2018-02-01 14:06:15 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:06:15 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:06:15 --> Utf8 Class Initialized
INFO - 2018-02-01 14:06:15 --> URI Class Initialized
INFO - 2018-02-01 14:06:15 --> Router Class Initialized
INFO - 2018-02-01 14:06:15 --> Output Class Initialized
INFO - 2018-02-01 14:06:15 --> Security Class Initialized
DEBUG - 2018-02-01 14:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:06:15 --> Input Class Initialized
INFO - 2018-02-01 14:06:15 --> Language Class Initialized
INFO - 2018-02-01 14:06:15 --> Language Class Initialized
INFO - 2018-02-01 14:06:15 --> Config Class Initialized
INFO - 2018-02-01 14:06:15 --> Loader Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: url_helper
INFO - 2018-02-01 19:36:15 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:36:15 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:36:15 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:36:15 --> Helper loaded: users_helper
INFO - 2018-02-01 19:36:15 --> Database Driver Class Initialized
INFO - 2018-02-01 14:06:15 --> Config Class Initialized
INFO - 2018-02-01 14:06:15 --> Hooks Class Initialized
DEBUG - 2018-02-01 19:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:36:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-01 14:06:15 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:06:15 --> Utf8 Class Initialized
INFO - 2018-02-01 14:06:15 --> URI Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: form_helper
INFO - 2018-02-01 19:36:15 --> Form Validation Class Initialized
INFO - 2018-02-01 19:36:15 --> Controller Class Initialized
INFO - 2018-02-01 14:06:15 --> Router Class Initialized
INFO - 2018-02-01 14:06:15 --> Output Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: inflector_helper
INFO - 2018-02-01 14:06:15 --> Security Class Initialized
DEBUG - 2018-02-01 19:36:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-01 14:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:06:15 --> Input Class Initialized
INFO - 2018-02-01 14:06:15 --> Language Class Initialized
INFO - 2018-02-01 19:36:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:36:15 --> Final output sent to browser
DEBUG - 2018-02-01 19:36:15 --> Total execution time: 0.0903
INFO - 2018-02-01 14:06:15 --> Language Class Initialized
INFO - 2018-02-01 14:06:15 --> Config Class Initialized
INFO - 2018-02-01 14:06:15 --> Loader Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: url_helper
INFO - 2018-02-01 19:36:15 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:36:15 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:36:15 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:36:15 --> Helper loaded: users_helper
INFO - 2018-02-01 14:06:15 --> Config Class Initialized
INFO - 2018-02-01 14:06:15 --> Hooks Class Initialized
DEBUG - 2018-02-01 14:06:15 --> UTF-8 Support Enabled
INFO - 2018-02-01 14:06:15 --> Utf8 Class Initialized
INFO - 2018-02-01 19:36:15 --> Database Driver Class Initialized
INFO - 2018-02-01 14:06:15 --> URI Class Initialized
INFO - 2018-02-01 14:06:15 --> Router Class Initialized
DEBUG - 2018-02-01 19:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 14:06:15 --> Output Class Initialized
INFO - 2018-02-01 14:06:15 --> Security Class Initialized
DEBUG - 2018-02-01 14:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-01 14:06:15 --> Input Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: form_helper
INFO - 2018-02-01 19:36:15 --> Form Validation Class Initialized
INFO - 2018-02-01 19:36:15 --> Controller Class Initialized
INFO - 2018-02-01 14:06:15 --> Language Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:36:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 14:06:15 --> Language Class Initialized
INFO - 2018-02-01 14:06:15 --> Config Class Initialized
INFO - 2018-02-01 14:06:15 --> Loader Class Initialized
INFO - 2018-02-01 19:36:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: url_helper
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: notification_helper
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: settings_helper
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:36:15 --> Helper loaded: permission_helper
INFO - 2018-02-01 19:36:15 --> Helper loaded: users_helper
INFO - 2018-02-01 19:36:15 --> Final output sent to browser
DEBUG - 2018-02-01 19:36:15 --> Total execution time: 0.1159
INFO - 2018-02-01 19:36:15 --> Database Driver Class Initialized
DEBUG - 2018-02-01 19:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-01 19:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-01 19:36:15 --> Helper loaded: form_helper
INFO - 2018-02-01 19:36:15 --> Form Validation Class Initialized
INFO - 2018-02-01 19:36:15 --> Controller Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-01 19:36:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-01 19:36:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Model Class Initialized
INFO - 2018-02-01 19:36:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-01 19:36:15 --> Final output sent to browser
DEBUG - 2018-02-01 19:36:15 --> Total execution time: 0.1046
