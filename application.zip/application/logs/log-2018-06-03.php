INFO - 2018-06-03 00:00:02 --> Helper loaded: url_helper
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-06-03 00:00:02 --> Helper loaded: url_helper
INFO - 2018-06-03 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-06-03 00:00:02 --> Helper loaded: notification_helper
INFO - 2018-06-03 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-06-03 00:00:02 --> Helper loaded: settings_helper
INFO - 2018-06-03 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-06-03 00:00:02 --> Helper loaded: users_helper
INFO - 2018-06-03 00:00:02 --> Helper loaded: permission_helper
INFO - 2018-06-03 00:00:02 --> Helper loaded: users_helper
INFO - 2018-06-03 00:00:02 --> Database Driver Class Initialized
INFO - 2018-06-03 00:00:02 --> Database Driver Class Initialized
DEBUG - 2018-06-03 00:00:02 --> Session: Initialization under CLI aborted.
DEBUG - 2018-06-03 00:00:02 --> Session: Initialization under CLI aborted.
INFO - 2018-06-03 00:00:02 --> Helper loaded: form_helper
INFO - 2018-06-03 00:00:02 --> Form Validation Class Initialized
INFO - 2018-06-03 00:00:02 --> Controller Class Initialized
INFO - 2018-06-03 00:00:02 --> Helper loaded: form_helper
INFO - 2018-06-03 00:00:02 --> Form Validation Class Initialized
INFO - 2018-06-03 00:00:02 --> Controller Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Helper loaded: inflector_helper
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Helper loaded: inflector_helper
DEBUG - 2018-06-03 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-06-03 00:00:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-03 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-03 00:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-03 00:00:02 --> Model Class Initialized
INFO - 2018-06-03 00:00:02 --> Final output sent to browser
DEBUG - 2018-06-03 00:00:02 --> Total execution time: 0.3124
INFO - 2018-06-03 00:00:02 --> Final output sent to browser
DEBUG - 2018-06-03 00:00:02 --> Total execution time: 0.2852
INFO - 2018-06-03 08:48:48 --> Config Class Initialized
INFO - 2018-06-03 08:48:48 --> Hooks Class Initialized
DEBUG - 2018-06-03 08:48:48 --> UTF-8 Support Enabled
INFO - 2018-06-03 08:48:48 --> Utf8 Class Initialized
INFO - 2018-06-03 08:48:48 --> URI Class Initialized
INFO - 2018-06-03 08:48:48 --> Router Class Initialized
INFO - 2018-06-03 08:48:48 --> Output Class Initialized
INFO - 2018-06-03 08:48:48 --> Security Class Initialized
DEBUG - 2018-06-03 08:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-03 08:48:48 --> Input Class Initialized
INFO - 2018-06-03 08:48:48 --> Language Class Initialized
INFO - 2018-06-03 08:48:49 --> Language Class Initialized
INFO - 2018-06-03 08:48:49 --> Config Class Initialized
INFO - 2018-06-03 08:48:49 --> Loader Class Initialized
INFO - 2018-06-03 14:18:49 --> Helper loaded: url_helper
INFO - 2018-06-03 14:18:49 --> Helper loaded: notification_helper
INFO - 2018-06-03 14:18:49 --> Helper loaded: settings_helper
INFO - 2018-06-03 14:18:49 --> Helper loaded: permission_helper
INFO - 2018-06-03 14:18:49 --> Helper loaded: users_helper
INFO - 2018-06-03 14:18:49 --> Database Driver Class Initialized
DEBUG - 2018-06-03 14:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-03 14:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-03 14:18:49 --> Helper loaded: form_helper
INFO - 2018-06-03 14:18:49 --> Form Validation Class Initialized
INFO - 2018-06-03 14:18:49 --> Controller Class Initialized
INFO - 2018-06-03 14:18:49 --> Model Class Initialized
INFO - 2018-06-03 14:18:49 --> Helper loaded: inflector_helper
DEBUG - 2018-06-03 14:18:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-03 14:18:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-03 14:18:49 --> Model Class Initialized
INFO - 2018-06-03 14:18:49 --> Model Class Initialized
INFO - 2018-06-03 14:18:49 --> Model Class Initialized
INFO - 2018-06-03 14:18:49 --> Model Class Initialized
INFO - 2018-06-03 14:18:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-03 14:18:49 --> Model Class Initialized
INFO - 2018-06-03 14:18:49 --> Final output sent to browser
DEBUG - 2018-06-03 14:18:49 --> Total execution time: 0.3770
INFO - 2018-06-03 08:48:52 --> Config Class Initialized
INFO - 2018-06-03 08:48:52 --> Hooks Class Initialized
DEBUG - 2018-06-03 08:48:52 --> UTF-8 Support Enabled
INFO - 2018-06-03 08:48:52 --> Utf8 Class Initialized
INFO - 2018-06-03 08:48:52 --> URI Class Initialized
INFO - 2018-06-03 08:48:52 --> Router Class Initialized
INFO - 2018-06-03 08:48:52 --> Output Class Initialized
INFO - 2018-06-03 08:48:52 --> Security Class Initialized
DEBUG - 2018-06-03 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-03 08:48:52 --> Input Class Initialized
INFO - 2018-06-03 08:48:52 --> Language Class Initialized
INFO - 2018-06-03 08:48:52 --> Language Class Initialized
INFO - 2018-06-03 08:48:52 --> Config Class Initialized
INFO - 2018-06-03 08:48:52 --> Loader Class Initialized
INFO - 2018-06-03 14:18:52 --> Helper loaded: url_helper
INFO - 2018-06-03 14:18:52 --> Helper loaded: notification_helper
INFO - 2018-06-03 14:18:52 --> Helper loaded: settings_helper
INFO - 2018-06-03 14:18:52 --> Helper loaded: permission_helper
INFO - 2018-06-03 14:18:52 --> Helper loaded: users_helper
INFO - 2018-06-03 14:18:52 --> Database Driver Class Initialized
DEBUG - 2018-06-03 14:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-03 14:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-03 14:18:52 --> Helper loaded: form_helper
INFO - 2018-06-03 14:18:52 --> Form Validation Class Initialized
INFO - 2018-06-03 14:18:52 --> Controller Class Initialized
INFO - 2018-06-03 14:18:52 --> Model Class Initialized
INFO - 2018-06-03 14:18:52 --> Helper loaded: inflector_helper
DEBUG - 2018-06-03 14:18:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-03 14:18:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-03 14:18:52 --> Model Class Initialized
INFO - 2018-06-03 14:18:52 --> Model Class Initialized
INFO - 2018-06-03 14:18:52 --> Model Class Initialized
INFO - 2018-06-03 14:18:52 --> Model Class Initialized
INFO - 2018-06-03 14:18:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-03 14:18:52 --> Model Class Initialized
INFO - 2018-06-03 14:18:52 --> Final output sent to browser
DEBUG - 2018-06-03 14:18:52 --> Total execution time: 0.1026
INFO - 2018-06-03 08:48:55 --> Config Class Initialized
INFO - 2018-06-03 08:48:55 --> Hooks Class Initialized
DEBUG - 2018-06-03 08:48:55 --> UTF-8 Support Enabled
INFO - 2018-06-03 08:48:55 --> Utf8 Class Initialized
INFO - 2018-06-03 08:48:55 --> URI Class Initialized
INFO - 2018-06-03 08:48:55 --> Router Class Initialized
INFO - 2018-06-03 08:48:55 --> Output Class Initialized
INFO - 2018-06-03 08:48:55 --> Security Class Initialized
DEBUG - 2018-06-03 08:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-03 08:48:55 --> Input Class Initialized
INFO - 2018-06-03 08:48:55 --> Language Class Initialized
INFO - 2018-06-03 08:48:55 --> Language Class Initialized
INFO - 2018-06-03 08:48:55 --> Config Class Initialized
INFO - 2018-06-03 08:48:55 --> Loader Class Initialized
INFO - 2018-06-03 14:18:55 --> Helper loaded: url_helper
INFO - 2018-06-03 14:18:55 --> Helper loaded: notification_helper
INFO - 2018-06-03 14:18:55 --> Helper loaded: settings_helper
INFO - 2018-06-03 14:18:55 --> Helper loaded: permission_helper
INFO - 2018-06-03 14:18:55 --> Helper loaded: users_helper
INFO - 2018-06-03 14:18:55 --> Database Driver Class Initialized
DEBUG - 2018-06-03 14:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-03 14:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-03 14:18:55 --> Helper loaded: form_helper
INFO - 2018-06-03 14:18:55 --> Form Validation Class Initialized
INFO - 2018-06-03 14:18:55 --> Controller Class Initialized
INFO - 2018-06-03 14:18:55 --> Model Class Initialized
INFO - 2018-06-03 14:18:55 --> Helper loaded: inflector_helper
DEBUG - 2018-06-03 14:18:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-03 14:18:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-03 14:18:55 --> Model Class Initialized
INFO - 2018-06-03 14:18:55 --> Model Class Initialized
INFO - 2018-06-03 14:18:55 --> Model Class Initialized
INFO - 2018-06-03 14:18:55 --> Model Class Initialized
INFO - 2018-06-03 14:18:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-03 14:18:55 --> Model Class Initialized
INFO - 2018-06-03 14:18:55 --> Final output sent to browser
DEBUG - 2018-06-03 14:18:55 --> Total execution time: 0.1857
INFO - 2018-06-03 08:49:28 --> Config Class Initialized
INFO - 2018-06-03 08:49:28 --> Hooks Class Initialized
DEBUG - 2018-06-03 08:49:28 --> UTF-8 Support Enabled
INFO - 2018-06-03 08:49:28 --> Utf8 Class Initialized
INFO - 2018-06-03 08:49:28 --> URI Class Initialized
INFO - 2018-06-03 08:49:28 --> Router Class Initialized
INFO - 2018-06-03 08:49:28 --> Output Class Initialized
INFO - 2018-06-03 08:49:28 --> Security Class Initialized
DEBUG - 2018-06-03 08:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-03 08:49:28 --> Input Class Initialized
INFO - 2018-06-03 08:49:28 --> Language Class Initialized
INFO - 2018-06-03 08:49:28 --> Language Class Initialized
INFO - 2018-06-03 08:49:28 --> Config Class Initialized
INFO - 2018-06-03 08:49:28 --> Loader Class Initialized
INFO - 2018-06-03 14:19:28 --> Helper loaded: url_helper
INFO - 2018-06-03 14:19:28 --> Helper loaded: notification_helper
INFO - 2018-06-03 14:19:28 --> Helper loaded: settings_helper
INFO - 2018-06-03 14:19:28 --> Helper loaded: permission_helper
INFO - 2018-06-03 14:19:28 --> Helper loaded: users_helper
INFO - 2018-06-03 14:19:28 --> Database Driver Class Initialized
DEBUG - 2018-06-03 14:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-06-03 14:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-06-03 14:19:28 --> Helper loaded: form_helper
INFO - 2018-06-03 14:19:28 --> Form Validation Class Initialized
INFO - 2018-06-03 14:19:28 --> Controller Class Initialized
INFO - 2018-06-03 14:19:28 --> Model Class Initialized
INFO - 2018-06-03 14:19:28 --> Helper loaded: inflector_helper
DEBUG - 2018-06-03 14:19:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-06-03 14:19:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-06-03 14:19:28 --> Model Class Initialized
INFO - 2018-06-03 14:19:28 --> Model Class Initialized
INFO - 2018-06-03 14:19:28 --> Model Class Initialized
INFO - 2018-06-03 14:19:28 --> Model Class Initialized
INFO - 2018-06-03 14:19:28 --> Model Class Initialized
INFO - 2018-06-03 14:19:28 --> Model Class Initialized
INFO - 2018-06-03 14:19:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-06-03 14:19:28 --> Final output sent to browser
DEBUG - 2018-06-03 14:19:28 --> Total execution time: 0.1534
INFO - 2018-06-03 18:30:02 --> Config Class Initialized
INFO - 2018-06-03 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-03 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-03 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-03 18:30:02 --> URI Class Initialized
INFO - 2018-06-03 18:30:02 --> Router Class Initialized
INFO - 2018-06-03 18:30:02 --> Output Class Initialized
INFO - 2018-06-03 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-03 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-03 18:30:02 --> Input Class Initialized
INFO - 2018-06-03 18:30:02 --> Language Class Initialized
INFO - 2018-06-03 18:30:02 --> Language Class Initialized
INFO - 2018-06-03 18:30:02 --> Config Class Initialized
INFO - 2018-06-03 18:30:02 --> Loader Class Initialized
INFO - 2018-06-03 18:30:02 --> Config Class Initialized
INFO - 2018-06-03 18:30:02 --> Hooks Class Initialized
DEBUG - 2018-06-03 18:30:02 --> UTF-8 Support Enabled
INFO - 2018-06-03 18:30:02 --> Utf8 Class Initialized
INFO - 2018-06-03 18:30:02 --> URI Class Initialized
INFO - 2018-06-03 18:30:02 --> Router Class Initialized
INFO - 2018-06-03 18:30:02 --> Output Class Initialized
INFO - 2018-06-03 18:30:02 --> Security Class Initialized
DEBUG - 2018-06-03 18:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-06-03 18:30:02 --> Input Class Initialized
INFO - 2018-06-03 18:30:02 --> Language Class Initialized
INFO - 2018-06-03 18:30:02 --> Language Class Initialized
INFO - 2018-06-03 18:30:02 --> Config Class Initialized
INFO - 2018-06-03 18:30:02 --> Loader Class Initialized
