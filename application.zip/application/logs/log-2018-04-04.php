<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-04 05:28:29 --> Config Class Initialized
INFO - 2018-04-04 05:28:29 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:29 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:29 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:29 --> URI Class Initialized
INFO - 2018-04-04 05:28:29 --> Router Class Initialized
INFO - 2018-04-04 05:28:29 --> Output Class Initialized
INFO - 2018-04-04 05:28:29 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:29 --> Input Class Initialized
INFO - 2018-04-04 05:28:29 --> Language Class Initialized
INFO - 2018-04-04 05:28:29 --> Language Class Initialized
INFO - 2018-04-04 05:28:29 --> Config Class Initialized
INFO - 2018-04-04 05:28:29 --> Loader Class Initialized
INFO - 2018-04-04 10:58:29 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:29 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:29 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:29 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:29 --> Helper loaded: users_helper
INFO - 2018-04-04 10:58:29 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:29 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:29 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:29 --> Controller Class Initialized
INFO - 2018-04-04 10:58:29 --> Model Class Initialized
INFO - 2018-04-04 10:58:29 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:29 --> Model Class Initialized
INFO - 2018-04-04 10:58:29 --> Model Class Initialized
INFO - 2018-04-04 10:58:29 --> Model Class Initialized
INFO - 2018-04-04 10:58:29 --> Model Class Initialized
INFO - 2018-04-04 10:58:29 --> Model Class Initialized
INFO - 2018-04-04 10:58:29 --> Model Class Initialized
INFO - 2018-04-04 10:58:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-04 10:58:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-04 10:58:29 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:29 --> Total execution time: 0.1004
INFO - 2018-04-04 05:28:30 --> Config Class Initialized
INFO - 2018-04-04 05:28:30 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:30 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:30 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:30 --> URI Class Initialized
INFO - 2018-04-04 05:28:30 --> Router Class Initialized
INFO - 2018-04-04 05:28:30 --> Output Class Initialized
INFO - 2018-04-04 05:28:30 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:30 --> Input Class Initialized
INFO - 2018-04-04 05:28:30 --> Language Class Initialized
INFO - 2018-04-04 05:28:30 --> Language Class Initialized
INFO - 2018-04-04 05:28:30 --> Config Class Initialized
INFO - 2018-04-04 05:28:30 --> Loader Class Initialized
INFO - 2018-04-04 10:58:30 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:30 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:30 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:30 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:30 --> Helper loaded: users_helper
INFO - 2018-04-04 10:58:30 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:30 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:30 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:30 --> Controller Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-04 10:58:30 --> Model Class Initialized
INFO - 2018-04-04 10:58:30 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:30 --> Total execution time: 0.1903
INFO - 2018-04-04 05:28:31 --> Config Class Initialized
INFO - 2018-04-04 05:28:31 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:32 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:32 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:32 --> URI Class Initialized
INFO - 2018-04-04 05:28:32 --> Router Class Initialized
INFO - 2018-04-04 05:28:32 --> Output Class Initialized
INFO - 2018-04-04 05:28:32 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:32 --> Input Class Initialized
INFO - 2018-04-04 05:28:32 --> Language Class Initialized
INFO - 2018-04-04 05:28:33 --> Language Class Initialized
INFO - 2018-04-04 05:28:33 --> Config Class Initialized
INFO - 2018-04-04 05:28:33 --> Loader Class Initialized
INFO - 2018-04-04 10:58:33 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:33 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:33 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:33 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:33 --> Helper loaded: users_helper
INFO - 2018-04-04 05:28:34 --> Config Class Initialized
INFO - 2018-04-04 05:28:34 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:34 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:34 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:34 --> URI Class Initialized
INFO - 2018-04-04 05:28:34 --> Router Class Initialized
INFO - 2018-04-04 05:28:34 --> Output Class Initialized
INFO - 2018-04-04 05:28:34 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:34 --> Input Class Initialized
INFO - 2018-04-04 05:28:34 --> Language Class Initialized
INFO - 2018-04-04 05:28:34 --> Language Class Initialized
INFO - 2018-04-04 05:28:34 --> Config Class Initialized
INFO - 2018-04-04 05:28:34 --> Loader Class Initialized
INFO - 2018-04-04 10:58:34 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:34 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:34 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:34 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:34 --> Helper loaded: users_helper
INFO - 2018-04-04 10:58:34 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:34 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:34 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:34 --> Controller Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-04 10:58:34 --> Model Class Initialized
INFO - 2018-04-04 10:58:34 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:34 --> Total execution time: 0.2134
INFO - 2018-04-04 10:58:34 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:34 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:34 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:34 --> Controller Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-04 10:58:35 --> Model Class Initialized
INFO - 2018-04-04 10:58:35 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:35 --> Total execution time: 3.6472
INFO - 2018-04-04 05:28:40 --> Config Class Initialized
INFO - 2018-04-04 05:28:40 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:40 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:40 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:40 --> URI Class Initialized
INFO - 2018-04-04 05:28:40 --> Router Class Initialized
INFO - 2018-04-04 05:28:40 --> Output Class Initialized
INFO - 2018-04-04 05:28:40 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:40 --> Input Class Initialized
INFO - 2018-04-04 05:28:40 --> Language Class Initialized
INFO - 2018-04-04 05:28:40 --> Language Class Initialized
INFO - 2018-04-04 05:28:40 --> Config Class Initialized
INFO - 2018-04-04 05:28:40 --> Loader Class Initialized
INFO - 2018-04-04 10:58:40 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:40 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:40 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:40 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:40 --> Helper loaded: users_helper
INFO - 2018-04-04 10:58:40 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:40 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:40 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:40 --> Controller Class Initialized
INFO - 2018-04-04 10:58:40 --> Model Class Initialized
INFO - 2018-04-04 10:58:40 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:40 --> Model Class Initialized
INFO - 2018-04-04 10:58:40 --> Model Class Initialized
INFO - 2018-04-04 10:58:40 --> Model Class Initialized
INFO - 2018-04-04 10:58:40 --> Model Class Initialized
INFO - 2018-04-04 10:58:40 --> Model Class Initialized
INFO - 2018-04-04 10:58:40 --> Model Class Initialized
INFO - 2018-04-04 10:58:40 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-04-04 10:58:40 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-04-04 10:58:40 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:40 --> Total execution time: 0.1317
INFO - 2018-04-04 05:28:42 --> Config Class Initialized
INFO - 2018-04-04 05:28:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:42 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:42 --> URI Class Initialized
INFO - 2018-04-04 05:28:42 --> Router Class Initialized
INFO - 2018-04-04 05:28:42 --> Output Class Initialized
INFO - 2018-04-04 05:28:42 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:42 --> Input Class Initialized
INFO - 2018-04-04 05:28:42 --> Language Class Initialized
INFO - 2018-04-04 05:28:42 --> Language Class Initialized
INFO - 2018-04-04 05:28:42 --> Config Class Initialized
INFO - 2018-04-04 05:28:42 --> Loader Class Initialized
INFO - 2018-04-04 10:58:42 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:42 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:42 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:42 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:42 --> Helper loaded: users_helper
INFO - 2018-04-04 10:58:42 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:42 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:42 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:42 --> Controller Class Initialized
INFO - 2018-04-04 10:58:42 --> Model Class Initialized
INFO - 2018-04-04 10:58:42 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:42 --> Model Class Initialized
INFO - 2018-04-04 10:58:42 --> Model Class Initialized
INFO - 2018-04-04 10:58:42 --> Model Class Initialized
INFO - 2018-04-04 10:58:42 --> Model Class Initialized
INFO - 2018-04-04 10:58:42 --> Model Class Initialized
INFO - 2018-04-04 10:58:42 --> Model Class Initialized
INFO - 2018-04-04 10:58:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-04 10:58:42 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:42 --> Total execution time: 0.1131
INFO - 2018-04-04 05:28:42 --> Config Class Initialized
INFO - 2018-04-04 05:28:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:42 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:42 --> URI Class Initialized
INFO - 2018-04-04 05:28:42 --> Router Class Initialized
INFO - 2018-04-04 05:28:43 --> Output Class Initialized
INFO - 2018-04-04 05:28:43 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:43 --> Input Class Initialized
INFO - 2018-04-04 05:28:43 --> Language Class Initialized
INFO - 2018-04-04 05:28:43 --> Language Class Initialized
INFO - 2018-04-04 05:28:43 --> Config Class Initialized
INFO - 2018-04-04 05:28:43 --> Loader Class Initialized
INFO - 2018-04-04 10:58:43 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:43 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:43 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:43 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:43 --> Helper loaded: users_helper
INFO - 2018-04-04 10:58:43 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:43 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:43 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:43 --> Controller Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-04 10:58:43 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:43 --> Total execution time: 0.1222
INFO - 2018-04-04 05:28:43 --> Config Class Initialized
INFO - 2018-04-04 05:28:43 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:43 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:43 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:43 --> URI Class Initialized
INFO - 2018-04-04 05:28:43 --> Router Class Initialized
INFO - 2018-04-04 05:28:43 --> Output Class Initialized
INFO - 2018-04-04 05:28:43 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:43 --> Input Class Initialized
INFO - 2018-04-04 05:28:43 --> Language Class Initialized
INFO - 2018-04-04 05:28:43 --> Language Class Initialized
INFO - 2018-04-04 05:28:43 --> Config Class Initialized
INFO - 2018-04-04 05:28:43 --> Loader Class Initialized
INFO - 2018-04-04 10:58:43 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:43 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:43 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:43 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:43 --> Helper loaded: users_helper
INFO - 2018-04-04 10:58:43 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:43 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:43 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:43 --> Controller Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Model Class Initialized
INFO - 2018-04-04 10:58:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-04 10:58:43 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:43 --> Total execution time: 0.2468
INFO - 2018-04-04 05:28:45 --> Config Class Initialized
INFO - 2018-04-04 05:28:45 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:45 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:45 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:45 --> URI Class Initialized
INFO - 2018-04-04 05:28:45 --> Router Class Initialized
INFO - 2018-04-04 05:28:45 --> Output Class Initialized
INFO - 2018-04-04 05:28:45 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:45 --> Input Class Initialized
INFO - 2018-04-04 05:28:45 --> Language Class Initialized
INFO - 2018-04-04 05:28:45 --> Language Class Initialized
INFO - 2018-04-04 05:28:45 --> Config Class Initialized
INFO - 2018-04-04 05:28:45 --> Loader Class Initialized
INFO - 2018-04-04 10:58:45 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:45 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:45 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:45 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:45 --> Helper loaded: users_helper
INFO - 2018-04-04 10:58:45 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:45 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:45 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:45 --> Controller Class Initialized
INFO - 2018-04-04 10:58:45 --> Model Class Initialized
INFO - 2018-04-04 10:58:45 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:45 --> Model Class Initialized
INFO - 2018-04-04 10:58:45 --> Model Class Initialized
INFO - 2018-04-04 10:58:45 --> Model Class Initialized
INFO - 2018-04-04 10:58:45 --> Model Class Initialized
INFO - 2018-04-04 10:58:45 --> Model Class Initialized
INFO - 2018-04-04 10:58:45 --> Model Class Initialized
INFO - 2018-04-04 10:58:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-04 10:58:45 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:45 --> Total execution time: 0.2058
INFO - 2018-04-04 05:28:58 --> Config Class Initialized
INFO - 2018-04-04 05:28:58 --> Hooks Class Initialized
DEBUG - 2018-04-04 05:28:58 --> UTF-8 Support Enabled
INFO - 2018-04-04 05:28:58 --> Utf8 Class Initialized
INFO - 2018-04-04 05:28:58 --> URI Class Initialized
INFO - 2018-04-04 05:28:58 --> Router Class Initialized
INFO - 2018-04-04 05:28:58 --> Output Class Initialized
INFO - 2018-04-04 05:28:58 --> Security Class Initialized
DEBUG - 2018-04-04 05:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 05:28:58 --> Input Class Initialized
INFO - 2018-04-04 05:28:58 --> Language Class Initialized
INFO - 2018-04-04 05:28:58 --> Language Class Initialized
INFO - 2018-04-04 05:28:58 --> Config Class Initialized
INFO - 2018-04-04 05:28:58 --> Loader Class Initialized
INFO - 2018-04-04 10:58:58 --> Helper loaded: url_helper
INFO - 2018-04-04 10:58:58 --> Helper loaded: notification_helper
INFO - 2018-04-04 10:58:58 --> Helper loaded: settings_helper
INFO - 2018-04-04 10:58:58 --> Helper loaded: permission_helper
INFO - 2018-04-04 10:58:58 --> Helper loaded: users_helper
INFO - 2018-04-04 10:58:58 --> Database Driver Class Initialized
DEBUG - 2018-04-04 10:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 10:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 10:58:58 --> Helper loaded: form_helper
INFO - 2018-04-04 10:58:58 --> Form Validation Class Initialized
INFO - 2018-04-04 10:58:58 --> Controller Class Initialized
INFO - 2018-04-04 10:58:58 --> Model Class Initialized
INFO - 2018-04-04 10:58:58 --> Helper loaded: inflector_helper
DEBUG - 2018-04-04 10:58:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-04-04 10:58:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-04-04 10:58:58 --> Model Class Initialized
INFO - 2018-04-04 10:58:58 --> Model Class Initialized
INFO - 2018-04-04 10:58:58 --> Model Class Initialized
INFO - 2018-04-04 10:58:58 --> Model Class Initialized
INFO - 2018-04-04 10:58:58 --> Model Class Initialized
INFO - 2018-04-04 10:58:58 --> Model Class Initialized
INFO - 2018-04-04 10:58:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-04-04 10:58:58 --> Final output sent to browser
DEBUG - 2018-04-04 10:58:58 --> Total execution time: 0.1987
