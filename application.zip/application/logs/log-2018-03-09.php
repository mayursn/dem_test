<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-09 09:18:31 --> Config Class Initialized
INFO - 2018-03-09 09:18:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:18:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:31 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:31 --> URI Class Initialized
INFO - 2018-03-09 09:18:31 --> Router Class Initialized
INFO - 2018-03-09 09:18:31 --> Config Class Initialized
INFO - 2018-03-09 09:18:31 --> Hooks Class Initialized
INFO - 2018-03-09 09:18:31 --> Output Class Initialized
DEBUG - 2018-03-09 09:18:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:31 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:31 --> Security Class Initialized
INFO - 2018-03-09 09:18:31 --> URI Class Initialized
DEBUG - 2018-03-09 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:31 --> Input Class Initialized
INFO - 2018-03-09 09:18:31 --> Config Class Initialized
INFO - 2018-03-09 09:18:31 --> Hooks Class Initialized
INFO - 2018-03-09 09:18:31 --> Language Class Initialized
INFO - 2018-03-09 09:18:31 --> Router Class Initialized
INFO - 2018-03-09 09:18:31 --> Output Class Initialized
INFO - 2018-03-09 09:18:31 --> Security Class Initialized
DEBUG - 2018-03-09 09:18:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:31 --> Utf8 Class Initialized
DEBUG - 2018-03-09 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:31 --> Input Class Initialized
INFO - 2018-03-09 09:18:31 --> Language Class Initialized
INFO - 2018-03-09 09:18:31 --> URI Class Initialized
INFO - 2018-03-09 09:18:31 --> Language Class Initialized
INFO - 2018-03-09 09:18:31 --> Config Class Initialized
INFO - 2018-03-09 09:18:31 --> Loader Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: users_helper
INFO - 2018-03-09 09:18:31 --> Language Class Initialized
INFO - 2018-03-09 09:18:31 --> Config Class Initialized
INFO - 2018-03-09 09:18:31 --> Loader Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: url_helper
INFO - 2018-03-09 09:18:31 --> Router Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: users_helper
INFO - 2018-03-09 14:48:31 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:48:31 --> Database Driver Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: form_helper
INFO - 2018-03-09 14:48:31 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:31 --> Controller Class Initialized
INFO - 2018-03-09 09:18:31 --> Output Class Initialized
DEBUG - 2018-03-09 14:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: inflector_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: form_helper
INFO - 2018-03-09 09:18:31 --> Security Class Initialized
INFO - 2018-03-09 14:48:31 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:31 --> Controller Class Initialized
DEBUG - 2018-03-09 14:48:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:48:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
DEBUG - 2018-03-09 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:31 --> Input Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: inflector_helper
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 09:18:31 --> Language Class Initialized
INFO - 2018-03-09 14:48:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
DEBUG - 2018-03-09 14:48:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:48:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:31 --> Total execution time: 0.1621
INFO - 2018-03-09 14:48:31 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:31 --> Total execution time: 0.1419
INFO - 2018-03-09 09:18:31 --> Config Class Initialized
INFO - 2018-03-09 09:18:31 --> Hooks Class Initialized
INFO - 2018-03-09 09:18:31 --> Language Class Initialized
INFO - 2018-03-09 09:18:31 --> Config Class Initialized
INFO - 2018-03-09 09:18:31 --> Loader Class Initialized
DEBUG - 2018-03-09 09:18:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:31 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:31 --> URI Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: permission_helper
INFO - 2018-03-09 09:18:31 --> Router Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: users_helper
INFO - 2018-03-09 09:18:31 --> Output Class Initialized
INFO - 2018-03-09 09:18:31 --> Security Class Initialized
DEBUG - 2018-03-09 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:31 --> Input Class Initialized
INFO - 2018-03-09 09:18:31 --> Language Class Initialized
INFO - 2018-03-09 14:48:31 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:48:31 --> Helper loaded: form_helper
INFO - 2018-03-09 14:48:31 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:31 --> Controller Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: inflector_helper
INFO - 2018-03-09 09:18:31 --> Language Class Initialized
INFO - 2018-03-09 09:18:31 --> Config Class Initialized
INFO - 2018-03-09 09:18:31 --> Loader Class Initialized
DEBUG - 2018-03-09 14:48:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:48:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:31 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:31 --> Total execution time: 0.3279
INFO - 2018-03-09 14:48:31 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:48:31 --> Helper loaded: users_helper
INFO - 2018-03-09 14:48:31 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:48:31 --> Helper loaded: form_helper
INFO - 2018-03-09 14:48:31 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:31 --> Controller Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:48:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:48:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Model Class Initialized
INFO - 2018-03-09 14:48:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:48:31 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:31 --> Total execution time: 0.2714
INFO - 2018-03-09 09:18:32 --> Config Class Initialized
INFO - 2018-03-09 09:18:32 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:18:32 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:32 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:32 --> URI Class Initialized
INFO - 2018-03-09 09:18:32 --> Router Class Initialized
INFO - 2018-03-09 09:18:32 --> Output Class Initialized
INFO - 2018-03-09 09:18:32 --> Security Class Initialized
DEBUG - 2018-03-09 09:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:32 --> Input Class Initialized
INFO - 2018-03-09 09:18:32 --> Language Class Initialized
INFO - 2018-03-09 09:18:32 --> Language Class Initialized
INFO - 2018-03-09 09:18:32 --> Config Class Initialized
INFO - 2018-03-09 09:18:32 --> Loader Class Initialized
INFO - 2018-03-09 14:48:32 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:32 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:32 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:32 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:48:32 --> Helper loaded: users_helper
INFO - 2018-03-09 14:48:32 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:48:33 --> Helper loaded: form_helper
INFO - 2018-03-09 14:48:33 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:33 --> Controller Class Initialized
INFO - 2018-03-09 14:48:33 --> Model Class Initialized
INFO - 2018-03-09 14:48:33 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:48:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:48:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:48:33 --> Model Class Initialized
INFO - 2018-03-09 14:48:33 --> Model Class Initialized
INFO - 2018-03-09 14:48:33 --> Model Class Initialized
INFO - 2018-03-09 14:48:33 --> Model Class Initialized
INFO - 2018-03-09 14:48:33 --> Model Class Initialized
INFO - 2018-03-09 14:48:33 --> Model Class Initialized
INFO - 2018-03-09 14:48:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:48:33 --> Model Class Initialized
INFO - 2018-03-09 14:48:33 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:33 --> Total execution time: 1.2699
INFO - 2018-03-09 09:18:50 --> Config Class Initialized
INFO - 2018-03-09 09:18:50 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:18:50 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:50 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:50 --> URI Class Initialized
INFO - 2018-03-09 09:18:50 --> Router Class Initialized
INFO - 2018-03-09 09:18:50 --> Output Class Initialized
INFO - 2018-03-09 09:18:50 --> Security Class Initialized
DEBUG - 2018-03-09 09:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:50 --> Input Class Initialized
INFO - 2018-03-09 09:18:50 --> Language Class Initialized
INFO - 2018-03-09 09:18:51 --> Language Class Initialized
INFO - 2018-03-09 09:18:51 --> Config Class Initialized
INFO - 2018-03-09 09:18:51 --> Loader Class Initialized
INFO - 2018-03-09 14:48:51 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:51 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:51 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:51 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:48:51 --> Helper loaded: users_helper
INFO - 2018-03-09 14:48:51 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:48:51 --> Helper loaded: form_helper
INFO - 2018-03-09 14:48:51 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:51 --> Controller Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:48:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:48:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Model Class Initialized
INFO - 2018-03-09 14:48:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:48:51 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:51 --> Total execution time: 0.4532
INFO - 2018-03-09 09:18:51 --> Config Class Initialized
INFO - 2018-03-09 09:18:51 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:18:51 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:51 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:51 --> URI Class Initialized
INFO - 2018-03-09 09:18:52 --> Router Class Initialized
INFO - 2018-03-09 09:18:52 --> Output Class Initialized
INFO - 2018-03-09 09:18:52 --> Security Class Initialized
DEBUG - 2018-03-09 09:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:52 --> Input Class Initialized
INFO - 2018-03-09 09:18:52 --> Language Class Initialized
INFO - 2018-03-09 09:18:52 --> Language Class Initialized
INFO - 2018-03-09 09:18:52 --> Config Class Initialized
INFO - 2018-03-09 09:18:52 --> Loader Class Initialized
INFO - 2018-03-09 14:48:52 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:52 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:52 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:52 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:48:52 --> Helper loaded: users_helper
INFO - 2018-03-09 14:48:52 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:48:53 --> Helper loaded: form_helper
INFO - 2018-03-09 14:48:53 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:53 --> Controller Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:48:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:48:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:53 --> Total execution time: 1.7636
INFO - 2018-03-09 09:18:53 --> Config Class Initialized
INFO - 2018-03-09 09:18:53 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:18:53 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:53 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:53 --> URI Class Initialized
INFO - 2018-03-09 09:18:53 --> Router Class Initialized
INFO - 2018-03-09 09:18:53 --> Output Class Initialized
INFO - 2018-03-09 09:18:53 --> Security Class Initialized
DEBUG - 2018-03-09 09:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:53 --> Input Class Initialized
INFO - 2018-03-09 09:18:53 --> Language Class Initialized
INFO - 2018-03-09 09:18:53 --> Language Class Initialized
INFO - 2018-03-09 09:18:53 --> Config Class Initialized
INFO - 2018-03-09 09:18:53 --> Loader Class Initialized
INFO - 2018-03-09 14:48:53 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:53 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:53 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:53 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:48:53 --> Helper loaded: users_helper
INFO - 2018-03-09 14:48:53 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:48:53 --> Helper loaded: form_helper
INFO - 2018-03-09 14:48:53 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:53 --> Controller Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:48:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:48:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:48:53 --> Model Class Initialized
INFO - 2018-03-09 14:48:53 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:53 --> Total execution time: 0.1193
INFO - 2018-03-09 09:18:56 --> Config Class Initialized
INFO - 2018-03-09 09:18:56 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:18:56 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:56 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:56 --> URI Class Initialized
INFO - 2018-03-09 09:18:56 --> Router Class Initialized
INFO - 2018-03-09 09:18:56 --> Output Class Initialized
INFO - 2018-03-09 09:18:56 --> Security Class Initialized
DEBUG - 2018-03-09 09:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:56 --> Input Class Initialized
INFO - 2018-03-09 09:18:56 --> Language Class Initialized
INFO - 2018-03-09 09:18:56 --> Language Class Initialized
INFO - 2018-03-09 09:18:56 --> Config Class Initialized
INFO - 2018-03-09 09:18:56 --> Loader Class Initialized
INFO - 2018-03-09 14:48:56 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:56 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:56 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:56 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:48:57 --> Helper loaded: users_helper
INFO - 2018-03-09 09:18:57 --> Config Class Initialized
INFO - 2018-03-09 09:18:57 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:18:57 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:57 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:57 --> URI Class Initialized
INFO - 2018-03-09 09:18:57 --> Router Class Initialized
INFO - 2018-03-09 09:18:57 --> Output Class Initialized
INFO - 2018-03-09 09:18:57 --> Security Class Initialized
DEBUG - 2018-03-09 09:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:57 --> Input Class Initialized
INFO - 2018-03-09 09:18:57 --> Language Class Initialized
INFO - 2018-03-09 09:18:57 --> Language Class Initialized
INFO - 2018-03-09 09:18:57 --> Config Class Initialized
INFO - 2018-03-09 09:18:57 --> Loader Class Initialized
INFO - 2018-03-09 14:48:57 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:57 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:57 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:57 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:48:57 --> Helper loaded: users_helper
INFO - 2018-03-09 14:48:57 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:48:57 --> Database Driver Class Initialized
INFO - 2018-03-09 14:48:57 --> Helper loaded: form_helper
INFO - 2018-03-09 14:48:57 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:57 --> Controller Class Initialized
DEBUG - 2018-03-09 14:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 09:18:58 --> Config Class Initialized
INFO - 2018-03-09 09:18:58 --> Hooks Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:48:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:48:58 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-03-09 09:18:58 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:58 --> Utf8 Class Initialized
INFO - 2018-03-09 14:48:58 --> Helper loaded: form_helper
INFO - 2018-03-09 14:48:58 --> Form Validation Class Initialized
INFO - 2018-03-09 14:48:58 --> Controller Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 09:18:58 --> Config Class Initialized
INFO - 2018-03-09 09:18:58 --> Hooks Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-09 09:18:58 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:18:58 --> Utf8 Class Initialized
INFO - 2018-03-09 09:18:58 --> URI Class Initialized
INFO - 2018-03-09 09:18:58 --> URI Class Initialized
INFO - 2018-03-09 09:18:58 --> Router Class Initialized
INFO - 2018-03-09 14:48:58 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:58 --> Total execution time: 1.3149
INFO - 2018-03-09 09:18:58 --> Router Class Initialized
INFO - 2018-03-09 09:18:58 --> Output Class Initialized
INFO - 2018-03-09 09:18:58 --> Output Class Initialized
INFO - 2018-03-09 09:18:58 --> Security Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 09:18:58 --> Security Class Initialized
INFO - 2018-03-09 14:48:58 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:58 --> Input Class Initialized
INFO - 2018-03-09 09:18:58 --> Language Class Initialized
DEBUG - 2018-03-09 14:48:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-03-09 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:18:58 --> Input Class Initialized
INFO - 2018-03-09 09:18:58 --> Language Class Initialized
INFO - 2018-03-09 14:48:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Model Class Initialized
INFO - 2018-03-09 14:48:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:48:59 --> Final output sent to browser
DEBUG - 2018-03-09 14:48:59 --> Total execution time: 2.7020
INFO - 2018-03-09 09:18:59 --> Language Class Initialized
INFO - 2018-03-09 09:18:59 --> Config Class Initialized
INFO - 2018-03-09 09:18:59 --> Loader Class Initialized
INFO - 2018-03-09 09:18:59 --> Language Class Initialized
INFO - 2018-03-09 09:18:59 --> Config Class Initialized
INFO - 2018-03-09 09:18:59 --> Loader Class Initialized
INFO - 2018-03-09 14:48:59 --> Helper loaded: url_helper
INFO - 2018-03-09 14:48:59 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:48:59 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:48:59 --> Helper loaded: url_helper
INFO - 2018-03-09 14:49:00 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:49:00 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:49:00 --> Helper loaded: users_helper
INFO - 2018-03-09 14:49:00 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:49:00 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:49:00 --> Helper loaded: users_helper
INFO - 2018-03-09 14:49:00 --> Database Driver Class Initialized
INFO - 2018-03-09 09:19:00 --> Config Class Initialized
DEBUG - 2018-03-09 14:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 09:19:00 --> Hooks Class Initialized
INFO - 2018-03-09 14:49:00 --> Helper loaded: form_helper
INFO - 2018-03-09 14:49:00 --> Form Validation Class Initialized
INFO - 2018-03-09 14:49:00 --> Controller Class Initialized
INFO - 2018-03-09 14:49:00 --> Model Class Initialized
INFO - 2018-03-09 14:49:00 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:49:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:49:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:49:00 --> Model Class Initialized
INFO - 2018-03-09 14:49:00 --> Model Class Initialized
INFO - 2018-03-09 14:49:00 --> Model Class Initialized
INFO - 2018-03-09 14:49:00 --> Model Class Initialized
INFO - 2018-03-09 14:49:00 --> Model Class Initialized
INFO - 2018-03-09 14:49:00 --> Model Class Initialized
INFO - 2018-03-09 14:49:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:49:00 --> Final output sent to browser
DEBUG - 2018-03-09 14:49:00 --> Total execution time: 2.1800
DEBUG - 2018-03-09 09:19:00 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:19:00 --> Utf8 Class Initialized
INFO - 2018-03-09 09:19:00 --> URI Class Initialized
INFO - 2018-03-09 14:49:00 --> Database Driver Class Initialized
INFO - 2018-03-09 09:19:01 --> Config Class Initialized
DEBUG - 2018-03-09 14:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 09:19:01 --> Hooks Class Initialized
INFO - 2018-03-09 09:19:01 --> Router Class Initialized
INFO - 2018-03-09 14:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 09:19:01 --> Output Class Initialized
DEBUG - 2018-03-09 09:19:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:19:01 --> Utf8 Class Initialized
INFO - 2018-03-09 09:19:01 --> Security Class Initialized
INFO - 2018-03-09 09:19:01 --> URI Class Initialized
DEBUG - 2018-03-09 09:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:19:01 --> Input Class Initialized
INFO - 2018-03-09 09:19:01 --> Language Class Initialized
INFO - 2018-03-09 14:49:01 --> Helper loaded: form_helper
INFO - 2018-03-09 14:49:01 --> Form Validation Class Initialized
INFO - 2018-03-09 14:49:01 --> Controller Class Initialized
INFO - 2018-03-09 09:19:01 --> Router Class Initialized
INFO - 2018-03-09 09:19:01 --> Output Class Initialized
INFO - 2018-03-09 09:19:01 --> Security Class Initialized
INFO - 2018-03-09 14:49:01 --> Model Class Initialized
INFO - 2018-03-09 14:49:01 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 09:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:19:01 --> Input Class Initialized
INFO - 2018-03-09 09:19:01 --> Language Class Initialized
DEBUG - 2018-03-09 14:49:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:49:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:49:01 --> Model Class Initialized
INFO - 2018-03-09 14:49:01 --> Model Class Initialized
INFO - 2018-03-09 14:49:01 --> Model Class Initialized
INFO - 2018-03-09 14:49:01 --> Model Class Initialized
INFO - 2018-03-09 14:49:02 --> Model Class Initialized
INFO - 2018-03-09 14:49:02 --> Model Class Initialized
INFO - 2018-03-09 14:49:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:49:02 --> Final output sent to browser
DEBUG - 2018-03-09 14:49:02 --> Total execution time: 4.3663
INFO - 2018-03-09 09:19:02 --> Language Class Initialized
INFO - 2018-03-09 09:19:02 --> Config Class Initialized
INFO - 2018-03-09 09:19:02 --> Loader Class Initialized
INFO - 2018-03-09 14:49:02 --> Helper loaded: url_helper
INFO - 2018-03-09 14:49:02 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:49:02 --> Helper loaded: settings_helper
INFO - 2018-03-09 09:19:02 --> Language Class Initialized
INFO - 2018-03-09 09:19:02 --> Config Class Initialized
INFO - 2018-03-09 09:19:02 --> Loader Class Initialized
INFO - 2018-03-09 14:49:02 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:49:02 --> Helper loaded: users_helper
INFO - 2018-03-09 14:49:02 --> Helper loaded: url_helper
INFO - 2018-03-09 14:49:02 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:49:02 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:49:02 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:49:02 --> Helper loaded: users_helper
INFO - 2018-03-09 14:49:03 --> Database Driver Class Initialized
INFO - 2018-03-09 14:49:03 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-09 14:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:49:03 --> Helper loaded: form_helper
INFO - 2018-03-09 14:49:03 --> Form Validation Class Initialized
INFO - 2018-03-09 14:49:03 --> Controller Class Initialized
INFO - 2018-03-09 14:49:03 --> Helper loaded: form_helper
INFO - 2018-03-09 14:49:03 --> Form Validation Class Initialized
INFO - 2018-03-09 14:49:03 --> Controller Class Initialized
INFO - 2018-03-09 14:49:03 --> Model Class Initialized
INFO - 2018-03-09 14:49:03 --> Helper loaded: inflector_helper
INFO - 2018-03-09 14:49:03 --> Model Class Initialized
DEBUG - 2018-03-09 14:49:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:49:03 --> Helper loaded: inflector_helper
INFO - 2018-03-09 14:49:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:49:03 --> Model Class Initialized
INFO - 2018-03-09 14:49:03 --> Model Class Initialized
INFO - 2018-03-09 14:49:03 --> Model Class Initialized
INFO - 2018-03-09 14:49:03 --> Model Class Initialized
INFO - 2018-03-09 14:49:03 --> Model Class Initialized
INFO - 2018-03-09 14:49:03 --> Model Class Initialized
INFO - 2018-03-09 14:49:03 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-03-09 14:49:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:49:03 --> Final output sent to browser
DEBUG - 2018-03-09 14:49:03 --> Total execution time: 3.7556
INFO - 2018-03-09 14:49:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:49:04 --> Model Class Initialized
INFO - 2018-03-09 14:49:04 --> Model Class Initialized
INFO - 2018-03-09 14:49:04 --> Model Class Initialized
INFO - 2018-03-09 14:49:04 --> Model Class Initialized
INFO - 2018-03-09 14:49:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:49:04 --> Final output sent to browser
DEBUG - 2018-03-09 14:49:04 --> Total execution time: 3.7380
INFO - 2018-03-09 09:19:06 --> Config Class Initialized
INFO - 2018-03-09 09:19:06 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:19:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:19:06 --> Utf8 Class Initialized
INFO - 2018-03-09 09:19:06 --> URI Class Initialized
INFO - 2018-03-09 09:19:06 --> Router Class Initialized
INFO - 2018-03-09 09:19:06 --> Output Class Initialized
INFO - 2018-03-09 09:19:06 --> Security Class Initialized
DEBUG - 2018-03-09 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:19:06 --> Input Class Initialized
INFO - 2018-03-09 09:19:06 --> Language Class Initialized
INFO - 2018-03-09 09:19:06 --> Language Class Initialized
INFO - 2018-03-09 09:19:06 --> Config Class Initialized
INFO - 2018-03-09 09:19:06 --> Loader Class Initialized
INFO - 2018-03-09 14:49:06 --> Helper loaded: url_helper
INFO - 2018-03-09 14:49:06 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:49:06 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:49:06 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:49:06 --> Helper loaded: users_helper
INFO - 2018-03-09 09:19:06 --> Config Class Initialized
INFO - 2018-03-09 09:19:06 --> Hooks Class Initialized
INFO - 2018-03-09 14:49:06 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:49:07 --> Helper loaded: form_helper
INFO - 2018-03-09 14:49:07 --> Form Validation Class Initialized
INFO - 2018-03-09 14:49:07 --> Controller Class Initialized
INFO - 2018-03-09 14:49:07 --> Model Class Initialized
INFO - 2018-03-09 14:49:07 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:49:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:49:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:49:07 --> Model Class Initialized
INFO - 2018-03-09 14:49:07 --> Model Class Initialized
INFO - 2018-03-09 14:49:07 --> Model Class Initialized
INFO - 2018-03-09 14:49:07 --> Model Class Initialized
DEBUG - 2018-03-09 09:19:07 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:19:07 --> Utf8 Class Initialized
INFO - 2018-03-09 14:49:07 --> Final output sent to browser
DEBUG - 2018-03-09 14:49:07 --> Total execution time: 0.4684
INFO - 2018-03-09 09:19:07 --> URI Class Initialized
INFO - 2018-03-09 09:19:07 --> Router Class Initialized
INFO - 2018-03-09 09:19:07 --> Output Class Initialized
INFO - 2018-03-09 09:19:07 --> Security Class Initialized
DEBUG - 2018-03-09 09:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:19:07 --> Input Class Initialized
INFO - 2018-03-09 09:19:07 --> Language Class Initialized
INFO - 2018-03-09 09:19:07 --> Language Class Initialized
INFO - 2018-03-09 09:19:07 --> Config Class Initialized
INFO - 2018-03-09 09:19:07 --> Loader Class Initialized
INFO - 2018-03-09 14:49:07 --> Helper loaded: url_helper
INFO - 2018-03-09 14:49:07 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:49:07 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:49:07 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:49:07 --> Helper loaded: users_helper
INFO - 2018-03-09 14:49:07 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:49:08 --> Helper loaded: form_helper
INFO - 2018-03-09 14:49:08 --> Form Validation Class Initialized
INFO - 2018-03-09 14:49:08 --> Controller Class Initialized
INFO - 2018-03-09 14:49:08 --> Model Class Initialized
INFO - 2018-03-09 14:49:08 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:49:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:49:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:49:08 --> Model Class Initialized
INFO - 2018-03-09 14:49:08 --> Model Class Initialized
INFO - 2018-03-09 14:49:08 --> Model Class Initialized
INFO - 2018-03-09 14:49:08 --> Model Class Initialized
INFO - 2018-03-09 14:49:08 --> Final output sent to browser
DEBUG - 2018-03-09 14:49:08 --> Total execution time: 1.2634
INFO - 2018-03-09 09:19:09 --> Config Class Initialized
INFO - 2018-03-09 09:19:09 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:19:09 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:19:09 --> Utf8 Class Initialized
INFO - 2018-03-09 09:19:09 --> URI Class Initialized
INFO - 2018-03-09 09:19:09 --> Router Class Initialized
INFO - 2018-03-09 09:19:09 --> Output Class Initialized
INFO - 2018-03-09 09:19:09 --> Security Class Initialized
DEBUG - 2018-03-09 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:19:09 --> Input Class Initialized
INFO - 2018-03-09 09:19:09 --> Language Class Initialized
INFO - 2018-03-09 09:19:09 --> Language Class Initialized
INFO - 2018-03-09 09:19:09 --> Config Class Initialized
INFO - 2018-03-09 09:19:09 --> Loader Class Initialized
INFO - 2018-03-09 14:49:09 --> Helper loaded: url_helper
INFO - 2018-03-09 14:49:09 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:49:09 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:49:09 --> Helper loaded: permission_helper
INFO - 2018-03-09 09:19:09 --> Config Class Initialized
INFO - 2018-03-09 14:49:09 --> Helper loaded: users_helper
INFO - 2018-03-09 09:19:09 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:19:09 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:19:09 --> Utf8 Class Initialized
INFO - 2018-03-09 09:19:09 --> URI Class Initialized
INFO - 2018-03-09 09:19:09 --> Router Class Initialized
INFO - 2018-03-09 14:49:09 --> Database Driver Class Initialized
INFO - 2018-03-09 09:19:09 --> Output Class Initialized
INFO - 2018-03-09 09:19:09 --> Security Class Initialized
DEBUG - 2018-03-09 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:19:09 --> Input Class Initialized
DEBUG - 2018-03-09 14:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 09:19:09 --> Language Class Initialized
INFO - 2018-03-09 14:49:09 --> Helper loaded: form_helper
INFO - 2018-03-09 14:49:09 --> Form Validation Class Initialized
INFO - 2018-03-09 14:49:09 --> Controller Class Initialized
INFO - 2018-03-09 09:19:09 --> Language Class Initialized
INFO - 2018-03-09 09:19:09 --> Config Class Initialized
INFO - 2018-03-09 09:19:09 --> Loader Class Initialized
INFO - 2018-03-09 14:49:09 --> Helper loaded: url_helper
INFO - 2018-03-09 14:49:09 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:49:09 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:49:09 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:49:09 --> Helper loaded: users_helper
INFO - 2018-03-09 14:49:09 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:49:10 --> Helper loaded: form_helper
INFO - 2018-03-09 14:49:10 --> Form Validation Class Initialized
INFO - 2018-03-09 14:49:10 --> Controller Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:49:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:49:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:49:10 --> Final output sent to browser
DEBUG - 2018-03-09 14:49:10 --> Total execution time: 0.2396
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Helper loaded: inflector_helper
INFO - 2018-03-09 09:19:10 --> Config Class Initialized
INFO - 2018-03-09 09:19:10 --> Hooks Class Initialized
DEBUG - 2018-03-09 09:19:10 --> UTF-8 Support Enabled
INFO - 2018-03-09 09:19:10 --> Utf8 Class Initialized
DEBUG - 2018-03-09 14:49:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 09:19:10 --> URI Class Initialized
INFO - 2018-03-09 09:19:10 --> Router Class Initialized
INFO - 2018-03-09 09:19:10 --> Output Class Initialized
INFO - 2018-03-09 14:49:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 09:19:10 --> Security Class Initialized
DEBUG - 2018-03-09 09:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 09:19:10 --> Input Class Initialized
INFO - 2018-03-09 09:19:10 --> Language Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Model Class Initialized
INFO - 2018-03-09 14:49:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 09:19:10 --> Language Class Initialized
INFO - 2018-03-09 09:19:10 --> Config Class Initialized
INFO - 2018-03-09 09:19:10 --> Loader Class Initialized
INFO - 2018-03-09 14:49:10 --> Helper loaded: url_helper
INFO - 2018-03-09 14:49:10 --> Helper loaded: notification_helper
INFO - 2018-03-09 14:49:10 --> Helper loaded: settings_helper
INFO - 2018-03-09 14:49:10 --> Helper loaded: permission_helper
INFO - 2018-03-09 14:49:10 --> Helper loaded: users_helper
INFO - 2018-03-09 14:49:10 --> Final output sent to browser
DEBUG - 2018-03-09 14:49:10 --> Total execution time: 0.9290
INFO - 2018-03-09 14:49:11 --> Database Driver Class Initialized
DEBUG - 2018-03-09 14:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-09 14:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 14:49:11 --> Helper loaded: form_helper
INFO - 2018-03-09 14:49:11 --> Form Validation Class Initialized
INFO - 2018-03-09 14:49:11 --> Controller Class Initialized
INFO - 2018-03-09 14:49:11 --> Model Class Initialized
INFO - 2018-03-09 14:49:11 --> Helper loaded: inflector_helper
DEBUG - 2018-03-09 14:49:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-03-09 14:49:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-03-09 14:49:11 --> Model Class Initialized
INFO - 2018-03-09 14:49:11 --> Model Class Initialized
INFO - 2018-03-09 14:49:11 --> Model Class Initialized
INFO - 2018-03-09 14:49:11 --> Model Class Initialized
INFO - 2018-03-09 14:49:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-03-09 14:49:11 --> Final output sent to browser
DEBUG - 2018-03-09 14:49:11 --> Total execution time: 1.0556
