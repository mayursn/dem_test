<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-04 14:26:16 --> Config Class Initialized
INFO - 2018-05-04 14:26:16 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:16 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:16 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:16 --> URI Class Initialized
INFO - 2018-05-04 14:26:16 --> Config Class Initialized
INFO - 2018-05-04 14:26:16 --> Hooks Class Initialized
INFO - 2018-05-04 14:26:16 --> Router Class Initialized
INFO - 2018-05-04 14:26:16 --> Output Class Initialized
DEBUG - 2018-05-04 14:26:16 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:16 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:16 --> URI Class Initialized
INFO - 2018-05-04 14:26:16 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:16 --> Input Class Initialized
INFO - 2018-05-04 14:26:16 --> Config Class Initialized
INFO - 2018-05-04 14:26:16 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:16 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:16 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:16 --> Language Class Initialized
INFO - 2018-05-04 14:26:16 --> URI Class Initialized
INFO - 2018-05-04 14:26:16 --> Router Class Initialized
INFO - 2018-05-04 14:26:16 --> Output Class Initialized
INFO - 2018-05-04 14:26:16 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:16 --> Input Class Initialized
INFO - 2018-05-04 14:26:16 --> Language Class Initialized
INFO - 2018-05-04 14:26:16 --> Router Class Initialized
INFO - 2018-05-04 14:26:16 --> Output Class Initialized
INFO - 2018-05-04 14:26:16 --> Language Class Initialized
INFO - 2018-05-04 14:26:16 --> Language Class Initialized
INFO - 2018-05-04 14:26:16 --> Config Class Initialized
INFO - 2018-05-04 14:26:16 --> Loader Class Initialized
INFO - 2018-05-04 14:26:16 --> Config Class Initialized
INFO - 2018-05-04 14:26:16 --> Loader Class Initialized
INFO - 2018-05-04 14:26:16 --> Security Class Initialized
INFO - 2018-05-04 19:56:16 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:16 --> Helper loaded: url_helper
DEBUG - 2018-05-04 14:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:16 --> Input Class Initialized
INFO - 2018-05-04 19:56:16 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:16 --> Helper loaded: notification_helper
INFO - 2018-05-04 14:26:16 --> Language Class Initialized
INFO - 2018-05-04 19:56:16 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:16 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:16 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:16 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:16 --> Helper loaded: users_helper
INFO - 2018-05-04 19:56:16 --> Helper loaded: users_helper
INFO - 2018-05-04 14:26:16 --> Language Class Initialized
INFO - 2018-05-04 14:26:16 --> Config Class Initialized
INFO - 2018-05-04 14:26:16 --> Loader Class Initialized
INFO - 2018-05-04 19:56:16 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:16 --> Database Driver Class Initialized
INFO - 2018-05-04 19:56:16 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:16 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:16 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:16 --> Database Driver Class Initialized
INFO - 2018-05-04 19:56:16 --> Helper loaded: users_helper
DEBUG - 2018-05-04 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-05-04 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:16 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:17 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:17 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:17 --> Controller Class Initialized
INFO - 2018-05-04 19:56:17 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:17 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:17 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:17 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:17 --> Controller Class Initialized
INFO - 2018-05-04 19:56:17 --> Controller Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Helper loaded: inflector_helper
INFO - 2018-05-04 19:56:17 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-05-04 19:56:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Helper loaded: inflector_helper
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
DEBUG - 2018-05-04 19:56:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-04 19:56:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-04 19:56:17 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:17 --> Total execution time: 0.8328
INFO - 2018-05-04 19:56:17 --> Model Class Initialized
INFO - 2018-05-04 19:56:17 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:17 --> Total execution time: 0.8880
INFO - 2018-05-04 19:56:17 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:17 --> Total execution time: 0.8872
INFO - 2018-05-04 14:26:19 --> Config Class Initialized
INFO - 2018-05-04 14:26:19 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:19 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:19 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:19 --> URI Class Initialized
INFO - 2018-05-04 14:26:19 --> Router Class Initialized
INFO - 2018-05-04 14:26:19 --> Output Class Initialized
INFO - 2018-05-04 14:26:19 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:19 --> Input Class Initialized
INFO - 2018-05-04 14:26:19 --> Language Class Initialized
INFO - 2018-05-04 14:26:19 --> Config Class Initialized
INFO - 2018-05-04 14:26:19 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:19 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:19 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:19 --> URI Class Initialized
INFO - 2018-05-04 14:26:19 --> Router Class Initialized
INFO - 2018-05-04 14:26:19 --> Output Class Initialized
INFO - 2018-05-04 14:26:19 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:19 --> Input Class Initialized
INFO - 2018-05-04 14:26:19 --> Language Class Initialized
INFO - 2018-05-04 14:26:19 --> Language Class Initialized
INFO - 2018-05-04 14:26:19 --> Config Class Initialized
INFO - 2018-05-04 14:26:19 --> Loader Class Initialized
INFO - 2018-05-04 19:56:19 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:19 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:19 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:19 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:19 --> Helper loaded: users_helper
INFO - 2018-05-04 14:26:19 --> Language Class Initialized
INFO - 2018-05-04 14:26:19 --> Config Class Initialized
INFO - 2018-05-04 14:26:19 --> Loader Class Initialized
INFO - 2018-05-04 19:56:19 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:19 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:19 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:19 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:19 --> Controller Class Initialized
INFO - 2018-05-04 19:56:19 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:19 --> Helper loaded: inflector_helper
INFO - 2018-05-04 19:56:19 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:19 --> Helper loaded: users_helper
DEBUG - 2018-05-04 19:56:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-04 19:56:19 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2018-05-04 19:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1439
INFO - 2018-05-04 19:56:19 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:19 --> Total execution time: 0.1429
INFO - 2018-05-04 19:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:19 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:19 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:19 --> Controller Class Initialized
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Model Class Initialized
INFO - 2018-05-04 19:56:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-04 19:56:19 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:19 --> Total execution time: 0.2178
INFO - 2018-05-04 14:26:30 --> Config Class Initialized
INFO - 2018-05-04 14:26:30 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:30 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:30 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:30 --> URI Class Initialized
INFO - 2018-05-04 14:26:30 --> Router Class Initialized
INFO - 2018-05-04 14:26:30 --> Output Class Initialized
INFO - 2018-05-04 14:26:30 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:30 --> Input Class Initialized
INFO - 2018-05-04 14:26:30 --> Language Class Initialized
INFO - 2018-05-04 14:26:30 --> Language Class Initialized
INFO - 2018-05-04 14:26:30 --> Config Class Initialized
INFO - 2018-05-04 14:26:30 --> Loader Class Initialized
INFO - 2018-05-04 19:56:30 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:30 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:30 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:30 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:30 --> Helper loaded: users_helper
INFO - 2018-05-04 19:56:30 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:30 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:30 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:30 --> Controller Class Initialized
INFO - 2018-05-04 19:56:30 --> Model Class Initialized
INFO - 2018-05-04 19:56:30 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:30 --> Model Class Initialized
INFO - 2018-05-04 19:56:30 --> Model Class Initialized
INFO - 2018-05-04 19:56:30 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:30 --> Total execution time: 0.3343
INFO - 2018-05-04 14:26:34 --> Config Class Initialized
INFO - 2018-05-04 14:26:34 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:34 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:34 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:34 --> URI Class Initialized
INFO - 2018-05-04 14:26:34 --> Router Class Initialized
INFO - 2018-05-04 14:26:34 --> Output Class Initialized
INFO - 2018-05-04 14:26:34 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:34 --> Input Class Initialized
INFO - 2018-05-04 14:26:34 --> Language Class Initialized
INFO - 2018-05-04 14:26:34 --> Language Class Initialized
INFO - 2018-05-04 14:26:34 --> Config Class Initialized
INFO - 2018-05-04 14:26:34 --> Loader Class Initialized
INFO - 2018-05-04 19:56:34 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:34 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:34 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:34 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:34 --> Helper loaded: users_helper
INFO - 2018-05-04 19:56:34 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:34 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:34 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:34 --> Controller Class Initialized
INFO - 2018-05-04 19:56:34 --> Model Class Initialized
INFO - 2018-05-04 19:56:34 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:34 --> Model Class Initialized
INFO - 2018-05-04 19:56:34 --> Model Class Initialized
INFO - 2018-05-04 19:56:34 --> Model Class Initialized
INFO - 2018-05-04 19:56:34 --> Model Class Initialized
INFO - 2018-05-04 19:56:34 --> Model Class Initialized
INFO - 2018-05-04 19:56:34 --> Model Class Initialized
INFO - 2018-05-04 19:56:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-04 19:56:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1439
INFO - 2018-05-04 19:56:34 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:34 --> Total execution time: 0.0791
INFO - 2018-05-04 14:26:43 --> Config Class Initialized
INFO - 2018-05-04 14:26:43 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:43 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:43 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:43 --> URI Class Initialized
INFO - 2018-05-04 14:26:43 --> Router Class Initialized
INFO - 2018-05-04 14:26:43 --> Output Class Initialized
INFO - 2018-05-04 14:26:43 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:43 --> Input Class Initialized
INFO - 2018-05-04 14:26:43 --> Language Class Initialized
INFO - 2018-05-04 14:26:43 --> Language Class Initialized
INFO - 2018-05-04 14:26:43 --> Config Class Initialized
INFO - 2018-05-04 14:26:43 --> Loader Class Initialized
INFO - 2018-05-04 19:56:43 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:43 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:43 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:43 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:43 --> Helper loaded: users_helper
INFO - 2018-05-04 19:56:43 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:43 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:43 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:43 --> Controller Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-04 19:56:43 --> Model Class Initialized
INFO - 2018-05-04 19:56:43 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:43 --> Total execution time: 0.6260
INFO - 2018-05-04 14:26:46 --> Config Class Initialized
INFO - 2018-05-04 14:26:46 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:46 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:46 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:46 --> URI Class Initialized
INFO - 2018-05-04 14:26:46 --> Router Class Initialized
INFO - 2018-05-04 14:26:46 --> Output Class Initialized
INFO - 2018-05-04 14:26:46 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:46 --> Input Class Initialized
INFO - 2018-05-04 14:26:46 --> Language Class Initialized
INFO - 2018-05-04 14:26:46 --> Language Class Initialized
INFO - 2018-05-04 14:26:46 --> Config Class Initialized
INFO - 2018-05-04 14:26:46 --> Loader Class Initialized
INFO - 2018-05-04 19:56:46 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:46 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:46 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:46 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:46 --> Helper loaded: users_helper
INFO - 2018-05-04 19:56:46 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:46 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:46 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:46 --> Controller Class Initialized
INFO - 2018-05-04 19:56:46 --> Model Class Initialized
INFO - 2018-05-04 19:56:46 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:46 --> Model Class Initialized
INFO - 2018-05-04 19:56:46 --> Model Class Initialized
INFO - 2018-05-04 19:56:46 --> Model Class Initialized
INFO - 2018-05-04 19:56:46 --> Model Class Initialized
INFO - 2018-05-04 19:56:46 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:46 --> Total execution time: 0.3679
INFO - 2018-05-04 14:26:48 --> Config Class Initialized
INFO - 2018-05-04 14:26:48 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:48 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:48 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:48 --> URI Class Initialized
INFO - 2018-05-04 14:26:48 --> Router Class Initialized
INFO - 2018-05-04 14:26:48 --> Output Class Initialized
INFO - 2018-05-04 14:26:48 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:48 --> Input Class Initialized
INFO - 2018-05-04 14:26:48 --> Language Class Initialized
INFO - 2018-05-04 14:26:48 --> Language Class Initialized
INFO - 2018-05-04 14:26:48 --> Config Class Initialized
INFO - 2018-05-04 14:26:48 --> Loader Class Initialized
INFO - 2018-05-04 19:56:48 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:48 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:48 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:48 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:48 --> Helper loaded: users_helper
INFO - 2018-05-04 19:56:48 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:48 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:48 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:48 --> Controller Class Initialized
INFO - 2018-05-04 19:56:48 --> Model Class Initialized
INFO - 2018-05-04 19:56:48 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:48 --> Model Class Initialized
INFO - 2018-05-04 19:56:48 --> Model Class Initialized
INFO - 2018-05-04 19:56:48 --> Model Class Initialized
INFO - 2018-05-04 19:56:48 --> Model Class Initialized
INFO - 2018-05-04 19:56:48 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:48 --> Total execution time: 0.3762
INFO - 2018-05-04 14:26:54 --> Config Class Initialized
INFO - 2018-05-04 14:26:54 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:54 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:54 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:54 --> URI Class Initialized
INFO - 2018-05-04 14:26:54 --> Router Class Initialized
INFO - 2018-05-04 14:26:54 --> Output Class Initialized
INFO - 2018-05-04 14:26:54 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:54 --> Input Class Initialized
INFO - 2018-05-04 14:26:54 --> Language Class Initialized
INFO - 2018-05-04 14:26:54 --> Language Class Initialized
INFO - 2018-05-04 14:26:54 --> Config Class Initialized
INFO - 2018-05-04 14:26:54 --> Loader Class Initialized
INFO - 2018-05-04 19:56:54 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:54 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:54 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:54 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:54 --> Helper loaded: users_helper
INFO - 2018-05-04 19:56:54 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:54 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:54 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:54 --> Controller Class Initialized
INFO - 2018-05-04 19:56:54 --> Model Class Initialized
INFO - 2018-05-04 19:56:54 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:54 --> Model Class Initialized
INFO - 2018-05-04 19:56:54 --> Model Class Initialized
INFO - 2018-05-04 19:56:54 --> Model Class Initialized
INFO - 2018-05-04 19:56:54 --> Model Class Initialized
INFO - 2018-05-04 19:56:54 --> Model Class Initialized
INFO - 2018-05-04 19:56:54 --> Model Class Initialized
INFO - 2018-05-04 19:56:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-05-04 19:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1439
INFO - 2018-05-04 19:56:54 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:54 --> Total execution time: 0.2535
INFO - 2018-05-04 14:26:56 --> Config Class Initialized
INFO - 2018-05-04 14:26:56 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:56 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:56 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:56 --> URI Class Initialized
INFO - 2018-05-04 14:26:56 --> Router Class Initialized
INFO - 2018-05-04 14:26:56 --> Output Class Initialized
INFO - 2018-05-04 14:26:56 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:56 --> Input Class Initialized
INFO - 2018-05-04 14:26:56 --> Language Class Initialized
INFO - 2018-05-04 14:26:56 --> Language Class Initialized
INFO - 2018-05-04 14:26:56 --> Config Class Initialized
INFO - 2018-05-04 14:26:56 --> Loader Class Initialized
INFO - 2018-05-04 19:56:56 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:56 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:56 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:56 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:56 --> Helper loaded: users_helper
INFO - 2018-05-04 19:56:56 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:57 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:57 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:57 --> Controller Class Initialized
INFO - 2018-05-04 19:56:57 --> Model Class Initialized
INFO - 2018-05-04 19:56:57 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:57 --> Model Class Initialized
INFO - 2018-05-04 19:56:57 --> Model Class Initialized
INFO - 2018-05-04 19:56:57 --> Model Class Initialized
INFO - 2018-05-04 19:56:57 --> Model Class Initialized
INFO - 2018-05-04 19:56:57 --> Model Class Initialized
INFO - 2018-05-04 19:56:57 --> Model Class Initialized
INFO - 2018-05-04 19:56:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-05-04 19:56:57 --> Final output sent to browser
DEBUG - 2018-05-04 19:56:57 --> Total execution time: 0.4121
INFO - 2018-05-04 14:26:58 --> Config Class Initialized
INFO - 2018-05-04 14:26:58 --> Hooks Class Initialized
DEBUG - 2018-05-04 14:26:58 --> UTF-8 Support Enabled
INFO - 2018-05-04 14:26:58 --> Utf8 Class Initialized
INFO - 2018-05-04 14:26:58 --> URI Class Initialized
INFO - 2018-05-04 14:26:58 --> Router Class Initialized
INFO - 2018-05-04 14:26:58 --> Output Class Initialized
INFO - 2018-05-04 14:26:58 --> Security Class Initialized
DEBUG - 2018-05-04 14:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-04 14:26:58 --> Input Class Initialized
INFO - 2018-05-04 14:26:58 --> Language Class Initialized
INFO - 2018-05-04 14:26:58 --> Language Class Initialized
INFO - 2018-05-04 14:26:58 --> Config Class Initialized
INFO - 2018-05-04 14:26:58 --> Loader Class Initialized
INFO - 2018-05-04 19:56:58 --> Helper loaded: url_helper
INFO - 2018-05-04 19:56:58 --> Helper loaded: notification_helper
INFO - 2018-05-04 19:56:58 --> Helper loaded: settings_helper
INFO - 2018-05-04 19:56:58 --> Helper loaded: permission_helper
INFO - 2018-05-04 19:56:58 --> Helper loaded: users_helper
INFO - 2018-05-04 19:56:58 --> Database Driver Class Initialized
DEBUG - 2018-05-04 19:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-05-04 19:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-04 19:56:58 --> Helper loaded: form_helper
INFO - 2018-05-04 19:56:58 --> Form Validation Class Initialized
INFO - 2018-05-04 19:56:58 --> Controller Class Initialized
INFO - 2018-05-04 19:56:58 --> Model Class Initialized
INFO - 2018-05-04 19:56:58 --> Helper loaded: inflector_helper
DEBUG - 2018-05-04 19:56:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-05-04 19:56:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-05-04 19:56:58 --> Model Class Initialized
INFO - 2018-05-04 19:56:58 --> Model Class Initialized
INFO - 2018-05-04 19:56:58 --> Model Class Initialized
INFO - 2018-05-04 19:56:58 --> Model Class Initialized
INFO - 2018-05-04 19:56:58 --> Model Class Initialized
INFO - 2018-05-04 19:56:58 --> Model Class Initialized
INFO - 2018-05-04 19:56:58 --> Language file loaded: language/english/message_lang.php
