<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-02-13 05:38:04 --> Config Class Initialized
INFO - 2018-02-13 05:38:04 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:38:04 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:38:04 --> Utf8 Class Initialized
INFO - 2018-02-13 05:38:04 --> URI Class Initialized
DEBUG - 2018-02-13 05:38:04 --> No URI present. Default controller set.
INFO - 2018-02-13 05:38:04 --> Router Class Initialized
INFO - 2018-02-13 05:38:04 --> Output Class Initialized
INFO - 2018-02-13 05:38:04 --> Security Class Initialized
DEBUG - 2018-02-13 05:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:38:04 --> Input Class Initialized
INFO - 2018-02-13 05:38:04 --> Language Class Initialized
INFO - 2018-02-13 05:38:04 --> Language Class Initialized
INFO - 2018-02-13 05:38:04 --> Config Class Initialized
INFO - 2018-02-13 05:38:04 --> Loader Class Initialized
INFO - 2018-02-13 11:08:04 --> Helper loaded: url_helper
INFO - 2018-02-13 11:08:04 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:08:04 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:08:04 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:08:04 --> Helper loaded: users_helper
INFO - 2018-02-13 11:08:04 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:08:04 --> Helper loaded: form_helper
INFO - 2018-02-13 11:08:04 --> Form Validation Class Initialized
INFO - 2018-02-13 11:08:04 --> Controller Class Initialized
INFO - 2018-02-13 11:08:04 --> Model Class Initialized
INFO - 2018-02-13 11:08:04 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:08:04 --> Model Class Initialized
DEBUG - 2018-02-13 11:08:04 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-13 11:08:04 --> Final output sent to browser
DEBUG - 2018-02-13 11:08:04 --> Total execution time: 0.1223
INFO - 2018-02-13 05:43:57 --> Config Class Initialized
INFO - 2018-02-13 05:43:57 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:43:57 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:43:57 --> Utf8 Class Initialized
INFO - 2018-02-13 05:43:57 --> URI Class Initialized
INFO - 2018-02-13 05:43:57 --> Router Class Initialized
INFO - 2018-02-13 05:43:57 --> Output Class Initialized
INFO - 2018-02-13 05:43:57 --> Security Class Initialized
DEBUG - 2018-02-13 05:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:43:57 --> Input Class Initialized
INFO - 2018-02-13 05:43:57 --> Language Class Initialized
INFO - 2018-02-13 05:43:57 --> Language Class Initialized
INFO - 2018-02-13 05:43:57 --> Config Class Initialized
INFO - 2018-02-13 05:43:57 --> Loader Class Initialized
INFO - 2018-02-13 11:13:57 --> Helper loaded: url_helper
INFO - 2018-02-13 11:13:57 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:13:57 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:13:57 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:13:57 --> Helper loaded: users_helper
INFO - 2018-02-13 11:13:57 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:13:57 --> Helper loaded: form_helper
INFO - 2018-02-13 11:13:57 --> Form Validation Class Initialized
INFO - 2018-02-13 11:13:57 --> Controller Class Initialized
INFO - 2018-02-13 11:13:57 --> Model Class Initialized
INFO - 2018-02-13 11:13:57 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:13:57 --> Model Class Initialized
INFO - 2018-02-13 11:13:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-13 05:43:58 --> Config Class Initialized
INFO - 2018-02-13 05:43:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:43:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:43:58 --> Utf8 Class Initialized
INFO - 2018-02-13 05:43:58 --> URI Class Initialized
INFO - 2018-02-13 05:43:58 --> Router Class Initialized
INFO - 2018-02-13 05:43:58 --> Output Class Initialized
INFO - 2018-02-13 05:43:58 --> Security Class Initialized
DEBUG - 2018-02-13 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:43:58 --> Input Class Initialized
INFO - 2018-02-13 05:43:58 --> Language Class Initialized
INFO - 2018-02-13 05:43:58 --> Language Class Initialized
INFO - 2018-02-13 05:43:58 --> Config Class Initialized
INFO - 2018-02-13 05:43:58 --> Loader Class Initialized
INFO - 2018-02-13 11:13:58 --> Helper loaded: url_helper
INFO - 2018-02-13 11:13:58 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:13:58 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:13:58 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:13:58 --> Helper loaded: users_helper
INFO - 2018-02-13 11:13:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:13:58 --> Helper loaded: form_helper
INFO - 2018-02-13 11:13:58 --> Form Validation Class Initialized
INFO - 2018-02-13 11:13:58 --> Controller Class Initialized
INFO - 2018-02-13 11:13:58 --> Model Class Initialized
INFO - 2018-02-13 11:13:58 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:13:58 --> Model Class Initialized
INFO - 2018-02-13 11:13:58 --> Model Class Initialized
INFO - 2018-02-13 11:13:58 --> Model Class Initialized
INFO - 2018-02-13 11:13:58 --> Model Class Initialized
INFO - 2018-02-13 11:13:58 --> Model Class Initialized
DEBUG - 2018-02-13 11:13:58 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:13:58 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-02-13 11:13:58 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:13:58 --> Final output sent to browser
DEBUG - 2018-02-13 11:13:58 --> Total execution time: 0.1213
INFO - 2018-02-13 05:43:58 --> Config Class Initialized
INFO - 2018-02-13 05:43:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:43:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:43:58 --> Utf8 Class Initialized
INFO - 2018-02-13 05:43:58 --> URI Class Initialized
INFO - 2018-02-13 05:43:58 --> Router Class Initialized
INFO - 2018-02-13 05:43:58 --> Output Class Initialized
INFO - 2018-02-13 05:43:58 --> Security Class Initialized
DEBUG - 2018-02-13 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:43:58 --> Input Class Initialized
INFO - 2018-02-13 05:43:58 --> Language Class Initialized
INFO - 2018-02-13 05:43:58 --> Language Class Initialized
INFO - 2018-02-13 05:43:58 --> Config Class Initialized
INFO - 2018-02-13 05:43:58 --> Loader Class Initialized
INFO - 2018-02-13 11:13:58 --> Helper loaded: url_helper
INFO - 2018-02-13 11:13:58 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:13:58 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:13:58 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:13:58 --> Helper loaded: users_helper
INFO - 2018-02-13 11:13:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:13:58 --> Helper loaded: form_helper
INFO - 2018-02-13 11:13:58 --> Form Validation Class Initialized
INFO - 2018-02-13 11:13:58 --> Controller Class Initialized
DEBUG - 2018-02-13 11:13:58 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-13 11:13:58 --> Final output sent to browser
DEBUG - 2018-02-13 11:13:58 --> Total execution time: 0.0740
INFO - 2018-02-13 05:44:11 --> Config Class Initialized
INFO - 2018-02-13 05:44:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:44:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:44:11 --> Utf8 Class Initialized
INFO - 2018-02-13 05:44:11 --> URI Class Initialized
INFO - 2018-02-13 05:44:11 --> Router Class Initialized
INFO - 2018-02-13 05:44:11 --> Output Class Initialized
INFO - 2018-02-13 05:44:11 --> Security Class Initialized
DEBUG - 2018-02-13 05:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:44:11 --> Input Class Initialized
INFO - 2018-02-13 05:44:11 --> Language Class Initialized
INFO - 2018-02-13 05:44:11 --> Language Class Initialized
INFO - 2018-02-13 05:44:11 --> Config Class Initialized
INFO - 2018-02-13 05:44:11 --> Loader Class Initialized
INFO - 2018-02-13 11:14:11 --> Helper loaded: url_helper
INFO - 2018-02-13 11:14:11 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:14:11 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:14:11 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:14:11 --> Helper loaded: users_helper
INFO - 2018-02-13 11:14:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:14:11 --> Helper loaded: form_helper
INFO - 2018-02-13 11:14:11 --> Form Validation Class Initialized
INFO - 2018-02-13 11:14:11 --> Controller Class Initialized
INFO - 2018-02-13 11:14:11 --> Model Class Initialized
INFO - 2018-02-13 11:14:11 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:14:11 --> Model Class Initialized
INFO - 2018-02-13 11:14:11 --> Model Class Initialized
INFO - 2018-02-13 11:14:11 --> Model Class Initialized
DEBUG - 2018-02-13 11:14:11 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:14:11 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-13 11:14:11 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:14:11 --> Final output sent to browser
DEBUG - 2018-02-13 11:14:11 --> Total execution time: 0.1086
INFO - 2018-02-13 05:44:23 --> Config Class Initialized
INFO - 2018-02-13 05:44:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:44:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:44:23 --> Utf8 Class Initialized
INFO - 2018-02-13 05:44:23 --> URI Class Initialized
INFO - 2018-02-13 05:44:23 --> Router Class Initialized
INFO - 2018-02-13 05:44:23 --> Output Class Initialized
INFO - 2018-02-13 05:44:23 --> Security Class Initialized
DEBUG - 2018-02-13 05:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:44:23 --> Input Class Initialized
INFO - 2018-02-13 05:44:23 --> Language Class Initialized
INFO - 2018-02-13 05:44:23 --> Language Class Initialized
INFO - 2018-02-13 05:44:23 --> Config Class Initialized
INFO - 2018-02-13 05:44:23 --> Loader Class Initialized
INFO - 2018-02-13 11:14:23 --> Helper loaded: url_helper
INFO - 2018-02-13 11:14:23 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:14:23 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:14:23 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:14:23 --> Helper loaded: users_helper
INFO - 2018-02-13 11:14:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:14:23 --> Helper loaded: form_helper
INFO - 2018-02-13 11:14:23 --> Form Validation Class Initialized
INFO - 2018-02-13 11:14:23 --> Controller Class Initialized
INFO - 2018-02-13 11:14:23 --> Model Class Initialized
INFO - 2018-02-13 11:14:23 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:14:23 --> Model Class Initialized
INFO - 2018-02-13 11:14:23 --> Model Class Initialized
INFO - 2018-02-13 11:14:23 --> Model Class Initialized
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:14:25 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
INFO - 2018-02-13 05:44:25 --> Config Class Initialized
INFO - 2018-02-13 05:44:25 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:44:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:44:25 --> Utf8 Class Initialized
INFO - 2018-02-13 05:44:25 --> URI Class Initialized
INFO - 2018-02-13 05:44:25 --> Router Class Initialized
INFO - 2018-02-13 05:44:25 --> Output Class Initialized
INFO - 2018-02-13 05:44:25 --> Security Class Initialized
DEBUG - 2018-02-13 05:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:44:25 --> Input Class Initialized
INFO - 2018-02-13 05:44:25 --> Language Class Initialized
INFO - 2018-02-13 05:44:25 --> Language Class Initialized
INFO - 2018-02-13 05:44:25 --> Config Class Initialized
INFO - 2018-02-13 05:44:25 --> Loader Class Initialized
INFO - 2018-02-13 11:14:25 --> Helper loaded: url_helper
INFO - 2018-02-13 11:14:25 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:14:25 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:14:25 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:14:25 --> Helper loaded: users_helper
INFO - 2018-02-13 11:14:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:14:25 --> Helper loaded: form_helper
INFO - 2018-02-13 11:14:25 --> Form Validation Class Initialized
INFO - 2018-02-13 11:14:25 --> Controller Class Initialized
INFO - 2018-02-13 11:14:25 --> Model Class Initialized
INFO - 2018-02-13 11:14:25 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:14:25 --> Model Class Initialized
INFO - 2018-02-13 11:14:25 --> Model Class Initialized
INFO - 2018-02-13 11:14:25 --> Model Class Initialized
DEBUG - 2018-02-13 11:14:25 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:14:25 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-13 11:14:25 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:14:25 --> Final output sent to browser
DEBUG - 2018-02-13 11:14:25 --> Total execution time: 0.1525
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:45:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:07 --> Utf8 Class Initialized
INFO - 2018-02-13 05:45:07 --> URI Class Initialized
INFO - 2018-02-13 05:45:07 --> Router Class Initialized
INFO - 2018-02-13 05:45:07 --> Output Class Initialized
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Hooks Class Initialized
INFO - 2018-02-13 05:45:07 --> Security Class Initialized
DEBUG - 2018-02-13 05:45:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:07 --> Utf8 Class Initialized
DEBUG - 2018-02-13 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:07 --> Input Class Initialized
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
INFO - 2018-02-13 05:45:07 --> URI Class Initialized
INFO - 2018-02-13 05:45:07 --> Router Class Initialized
INFO - 2018-02-13 05:45:07 --> Output Class Initialized
INFO - 2018-02-13 05:45:07 --> Security Class Initialized
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:07 --> Input Class Initialized
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
DEBUG - 2018-02-13 05:45:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:07 --> Utf8 Class Initialized
INFO - 2018-02-13 05:45:07 --> URI Class Initialized
INFO - 2018-02-13 05:45:07 --> Router Class Initialized
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Loader Class Initialized
INFO - 2018-02-13 05:45:07 --> Output Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: url_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 05:45:07 --> Security Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: users_helper
DEBUG - 2018-02-13 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:07 --> Input Class Initialized
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:45:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:07 --> Utf8 Class Initialized
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Loader Class Initialized
INFO - 2018-02-13 05:45:07 --> URI Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: url_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: users_helper
INFO - 2018-02-13 05:45:07 --> Router Class Initialized
INFO - 2018-02-13 11:15:07 --> Database Driver Class Initialized
INFO - 2018-02-13 05:45:07 --> Output Class Initialized
INFO - 2018-02-13 05:45:07 --> Security Class Initialized
DEBUG - 2018-02-13 11:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Loader Class Initialized
DEBUG - 2018-02-13 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:07 --> Input Class Initialized
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: url_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: users_helper
INFO - 2018-02-13 11:15:07 --> Database Driver Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:07 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:07 --> Controller Class Initialized
DEBUG - 2018-02-13 11:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Hooks Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: inflector_helper
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Loader Class Initialized
DEBUG - 2018-02-13 05:45:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:07 --> Utf8 Class Initialized
INFO - 2018-02-13 11:15:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:15:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:07 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:07 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:07 --> Controller Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: url_helper
INFO - 2018-02-13 05:45:07 --> URI Class Initialized
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: users_helper
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 05:45:07 --> Router Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
DEBUG - 2018-02-13 11:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 05:45:07 --> Output Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:07 --> Total execution time: 0.1081
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 05:45:07 --> Security Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:07 --> Input Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:07 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:07 --> Controller Class Initialized
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
DEBUG - 2018-02-13 11:15:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Database Driver Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:07 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:07 --> Total execution time: 0.1083
INFO - 2018-02-13 11:15:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 11:15:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:07 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:07 --> Controller Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 05:45:07 --> Language Class Initialized
INFO - 2018-02-13 05:45:07 --> Config Class Initialized
INFO - 2018-02-13 05:45:07 --> Loader Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: url_helper
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:07 --> Helper loaded: users_helper
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:15:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:07 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:07 --> Total execution time: 0.1131
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Database Driver Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
DEBUG - 2018-02-13 11:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:15:07 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:07 --> Total execution time: 0.1135
INFO - 2018-02-13 11:15:07 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:07 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:07 --> Controller Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:15:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Model Class Initialized
INFO - 2018-02-13 11:15:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:07 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:07 --> Total execution time: 0.1064
INFO - 2018-02-13 05:45:10 --> Config Class Initialized
INFO - 2018-02-13 05:45:10 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:45:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:10 --> Utf8 Class Initialized
INFO - 2018-02-13 05:45:10 --> URI Class Initialized
INFO - 2018-02-13 05:45:10 --> Router Class Initialized
INFO - 2018-02-13 05:45:10 --> Output Class Initialized
INFO - 2018-02-13 05:45:10 --> Security Class Initialized
DEBUG - 2018-02-13 05:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:10 --> Input Class Initialized
INFO - 2018-02-13 05:45:10 --> Language Class Initialized
INFO - 2018-02-13 05:45:10 --> Language Class Initialized
INFO - 2018-02-13 05:45:10 --> Config Class Initialized
INFO - 2018-02-13 05:45:10 --> Loader Class Initialized
INFO - 2018-02-13 11:15:10 --> Helper loaded: url_helper
INFO - 2018-02-13 11:15:10 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:10 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:10 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:10 --> Helper loaded: users_helper
INFO - 2018-02-13 11:15:10 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:15:10 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:10 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:10 --> Controller Class Initialized
INFO - 2018-02-13 11:15:10 --> Model Class Initialized
INFO - 2018-02-13 11:15:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:15:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:10 --> Model Class Initialized
INFO - 2018-02-13 11:15:10 --> Model Class Initialized
INFO - 2018-02-13 11:15:10 --> Model Class Initialized
INFO - 2018-02-13 11:15:10 --> Model Class Initialized
INFO - 2018-02-13 11:15:10 --> Model Class Initialized
INFO - 2018-02-13 11:15:10 --> Model Class Initialized
INFO - 2018-02-13 11:15:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:10 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:10 --> Total execution time: 0.0959
INFO - 2018-02-13 05:45:16 --> Config Class Initialized
INFO - 2018-02-13 05:45:16 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:45:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:16 --> Utf8 Class Initialized
INFO - 2018-02-13 05:45:16 --> URI Class Initialized
INFO - 2018-02-13 05:45:16 --> Router Class Initialized
INFO - 2018-02-13 05:45:16 --> Output Class Initialized
INFO - 2018-02-13 05:45:16 --> Security Class Initialized
DEBUG - 2018-02-13 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:16 --> Input Class Initialized
INFO - 2018-02-13 05:45:16 --> Language Class Initialized
INFO - 2018-02-13 05:45:16 --> Language Class Initialized
INFO - 2018-02-13 05:45:16 --> Config Class Initialized
INFO - 2018-02-13 05:45:16 --> Loader Class Initialized
INFO - 2018-02-13 11:15:16 --> Helper loaded: url_helper
INFO - 2018-02-13 11:15:16 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:16 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:16 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:16 --> Helper loaded: users_helper
INFO - 2018-02-13 11:15:16 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:15:16 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:16 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:16 --> Controller Class Initialized
INFO - 2018-02-13 11:15:16 --> Model Class Initialized
INFO - 2018-02-13 11:15:16 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:15:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:16 --> Model Class Initialized
INFO - 2018-02-13 11:15:16 --> Model Class Initialized
INFO - 2018-02-13 11:15:16 --> Model Class Initialized
INFO - 2018-02-13 11:15:16 --> Model Class Initialized
INFO - 2018-02-13 11:15:16 --> Model Class Initialized
INFO - 2018-02-13 11:15:16 --> Model Class Initialized
INFO - 2018-02-13 11:15:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:16 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:16 --> Total execution time: 0.1068
INFO - 2018-02-13 05:45:16 --> Config Class Initialized
INFO - 2018-02-13 05:45:16 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:45:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:16 --> Utf8 Class Initialized
INFO - 2018-02-13 05:45:16 --> URI Class Initialized
INFO - 2018-02-13 05:45:16 --> Router Class Initialized
INFO - 2018-02-13 05:45:16 --> Output Class Initialized
INFO - 2018-02-13 05:45:16 --> Security Class Initialized
DEBUG - 2018-02-13 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:16 --> Input Class Initialized
INFO - 2018-02-13 05:45:16 --> Language Class Initialized
INFO - 2018-02-13 05:45:17 --> Language Class Initialized
INFO - 2018-02-13 05:45:17 --> Config Class Initialized
INFO - 2018-02-13 05:45:17 --> Loader Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: url_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: users_helper
INFO - 2018-02-13 11:15:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:15:17 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:17 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:17 --> Controller Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:15:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:17 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:17 --> Total execution time: 0.1191
INFO - 2018-02-13 05:45:17 --> Config Class Initialized
INFO - 2018-02-13 05:45:17 --> Hooks Class Initialized
INFO - 2018-02-13 05:45:17 --> Config Class Initialized
INFO - 2018-02-13 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:17 --> Utf8 Class Initialized
DEBUG - 2018-02-13 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:17 --> Utf8 Class Initialized
INFO - 2018-02-13 05:45:17 --> URI Class Initialized
INFO - 2018-02-13 05:45:17 --> URI Class Initialized
INFO - 2018-02-13 05:45:17 --> Router Class Initialized
INFO - 2018-02-13 05:45:17 --> Router Class Initialized
INFO - 2018-02-13 05:45:17 --> Output Class Initialized
INFO - 2018-02-13 05:45:17 --> Output Class Initialized
INFO - 2018-02-13 05:45:17 --> Security Class Initialized
INFO - 2018-02-13 05:45:17 --> Security Class Initialized
DEBUG - 2018-02-13 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:17 --> Input Class Initialized
DEBUG - 2018-02-13 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:17 --> Input Class Initialized
INFO - 2018-02-13 05:45:17 --> Language Class Initialized
INFO - 2018-02-13 05:45:17 --> Language Class Initialized
INFO - 2018-02-13 05:45:17 --> Language Class Initialized
INFO - 2018-02-13 05:45:17 --> Config Class Initialized
INFO - 2018-02-13 05:45:17 --> Loader Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: url_helper
INFO - 2018-02-13 05:45:17 --> Language Class Initialized
INFO - 2018-02-13 05:45:17 --> Config Class Initialized
INFO - 2018-02-13 05:45:17 --> Loader Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 05:45:17 --> Config Class Initialized
INFO - 2018-02-13 05:45:17 --> Hooks Class Initialized
INFO - 2018-02-13 05:45:17 --> Config Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: url_helper
INFO - 2018-02-13 05:45:17 --> Hooks Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: users_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: settings_helper
DEBUG - 2018-02-13 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:17 --> Utf8 Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: permission_helper
DEBUG - 2018-02-13 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:45:17 --> Utf8 Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: users_helper
INFO - 2018-02-13 05:45:17 --> URI Class Initialized
INFO - 2018-02-13 05:45:17 --> URI Class Initialized
INFO - 2018-02-13 05:45:17 --> Router Class Initialized
INFO - 2018-02-13 05:45:17 --> Router Class Initialized
INFO - 2018-02-13 05:45:17 --> Output Class Initialized
INFO - 2018-02-13 05:45:17 --> Security Class Initialized
INFO - 2018-02-13 05:45:17 --> Output Class Initialized
DEBUG - 2018-02-13 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:17 --> Input Class Initialized
INFO - 2018-02-13 05:45:17 --> Language Class Initialized
INFO - 2018-02-13 05:45:17 --> Security Class Initialized
INFO - 2018-02-13 11:15:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:45:17 --> Input Class Initialized
INFO - 2018-02-13 11:15:17 --> Database Driver Class Initialized
INFO - 2018-02-13 05:45:17 --> Language Class Initialized
DEBUG - 2018-02-13 11:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 11:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:15:17 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:17 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:17 --> Controller Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:17 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:17 --> Controller Class Initialized
INFO - 2018-02-13 05:45:17 --> Language Class Initialized
INFO - 2018-02-13 05:45:17 --> Config Class Initialized
INFO - 2018-02-13 05:45:17 --> Loader Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: url_helper
INFO - 2018-02-13 05:45:17 --> Language Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 05:45:17 --> Config Class Initialized
INFO - 2018-02-13 05:45:17 --> Loader Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: users_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: url_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:15:17 --> Helper loaded: users_helper
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:15:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-13 11:15:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Database Driver Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
DEBUG - 2018-02-13 11:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:17 --> Total execution time: 0.1142
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Database Driver Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:17 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:17 --> Controller Class Initialized
DEBUG - 2018-02-13 11:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:15:17 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:17 --> Total execution time: 0.1247
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:15:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:17 --> Helper loaded: form_helper
INFO - 2018-02-13 11:15:17 --> Form Validation Class Initialized
INFO - 2018-02-13 11:15:17 --> Controller Class Initialized
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:17 --> Total execution time: 0.0917
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:15:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:15:17 --> Model Class Initialized
INFO - 2018-02-13 11:15:17 --> Final output sent to browser
DEBUG - 2018-02-13 11:15:17 --> Total execution time: 0.1203
INFO - 2018-02-13 05:57:19 --> Config Class Initialized
INFO - 2018-02-13 05:57:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:57:19 --> Utf8 Class Initialized
INFO - 2018-02-13 05:57:19 --> URI Class Initialized
INFO - 2018-02-13 05:57:19 --> Router Class Initialized
INFO - 2018-02-13 05:57:19 --> Output Class Initialized
INFO - 2018-02-13 05:57:19 --> Security Class Initialized
DEBUG - 2018-02-13 05:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:57:19 --> Input Class Initialized
INFO - 2018-02-13 05:57:19 --> Language Class Initialized
INFO - 2018-02-13 05:57:19 --> Language Class Initialized
INFO - 2018-02-13 05:57:19 --> Config Class Initialized
INFO - 2018-02-13 05:57:19 --> Loader Class Initialized
INFO - 2018-02-13 11:27:19 --> Helper loaded: url_helper
INFO - 2018-02-13 11:27:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:27:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:27:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:27:19 --> Helper loaded: users_helper
INFO - 2018-02-13 11:27:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:27:19 --> Helper loaded: form_helper
INFO - 2018-02-13 11:27:19 --> Form Validation Class Initialized
INFO - 2018-02-13 11:27:19 --> Controller Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:27:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:27:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:27:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-13 11:27:19 --> Final output sent to browser
DEBUG - 2018-02-13 11:27:19 --> Total execution time: 0.0853
INFO - 2018-02-13 05:57:19 --> Config Class Initialized
INFO - 2018-02-13 05:57:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:57:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:57:19 --> Utf8 Class Initialized
INFO - 2018-02-13 05:57:19 --> URI Class Initialized
INFO - 2018-02-13 05:57:19 --> Router Class Initialized
INFO - 2018-02-13 05:57:19 --> Output Class Initialized
INFO - 2018-02-13 05:57:19 --> Security Class Initialized
DEBUG - 2018-02-13 05:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:57:19 --> Input Class Initialized
INFO - 2018-02-13 05:57:19 --> Language Class Initialized
INFO - 2018-02-13 05:57:19 --> Language Class Initialized
INFO - 2018-02-13 05:57:19 --> Config Class Initialized
INFO - 2018-02-13 05:57:19 --> Loader Class Initialized
INFO - 2018-02-13 11:27:19 --> Helper loaded: url_helper
INFO - 2018-02-13 11:27:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:27:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:27:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:27:19 --> Helper loaded: users_helper
INFO - 2018-02-13 11:27:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:27:19 --> Helper loaded: form_helper
INFO - 2018-02-13 11:27:19 --> Form Validation Class Initialized
INFO - 2018-02-13 11:27:19 --> Controller Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:27:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:27:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:27:19 --> Model Class Initialized
INFO - 2018-02-13 11:27:20 --> Final output sent to browser
DEBUG - 2018-02-13 11:27:20 --> Total execution time: 0.1586
INFO - 2018-02-13 05:57:24 --> Config Class Initialized
INFO - 2018-02-13 05:57:24 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:57:24 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:57:24 --> Utf8 Class Initialized
INFO - 2018-02-13 05:57:24 --> URI Class Initialized
INFO - 2018-02-13 05:57:24 --> Router Class Initialized
INFO - 2018-02-13 05:57:24 --> Output Class Initialized
INFO - 2018-02-13 05:57:24 --> Security Class Initialized
DEBUG - 2018-02-13 05:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:57:24 --> Input Class Initialized
INFO - 2018-02-13 05:57:24 --> Language Class Initialized
INFO - 2018-02-13 05:57:24 --> Language Class Initialized
INFO - 2018-02-13 05:57:24 --> Config Class Initialized
INFO - 2018-02-13 05:57:24 --> Loader Class Initialized
INFO - 2018-02-13 11:27:24 --> Helper loaded: url_helper
INFO - 2018-02-13 11:27:24 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:27:24 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:27:24 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:27:24 --> Helper loaded: users_helper
INFO - 2018-02-13 11:27:24 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:27:24 --> Helper loaded: form_helper
INFO - 2018-02-13 11:27:24 --> Form Validation Class Initialized
INFO - 2018-02-13 11:27:24 --> Controller Class Initialized
INFO - 2018-02-13 11:27:24 --> Model Class Initialized
INFO - 2018-02-13 11:27:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:27:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:27:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:27:24 --> Model Class Initialized
INFO - 2018-02-13 11:27:24 --> Model Class Initialized
INFO - 2018-02-13 11:27:24 --> Model Class Initialized
INFO - 2018-02-13 11:27:24 --> Model Class Initialized
INFO - 2018-02-13 11:27:24 --> Model Class Initialized
INFO - 2018-02-13 11:27:24 --> Model Class Initialized
INFO - 2018-02-13 11:27:24 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:27:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-13 11:27:24 --> Final output sent to browser
DEBUG - 2018-02-13 11:27:24 --> Total execution time: 0.1132
INFO - 2018-02-13 05:57:24 --> Config Class Initialized
INFO - 2018-02-13 05:57:24 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:57:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:57:25 --> Utf8 Class Initialized
INFO - 2018-02-13 05:57:25 --> URI Class Initialized
INFO - 2018-02-13 05:57:25 --> Router Class Initialized
INFO - 2018-02-13 05:57:25 --> Output Class Initialized
INFO - 2018-02-13 05:57:25 --> Security Class Initialized
DEBUG - 2018-02-13 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:57:25 --> Input Class Initialized
INFO - 2018-02-13 05:57:25 --> Language Class Initialized
INFO - 2018-02-13 05:57:25 --> Language Class Initialized
INFO - 2018-02-13 05:57:25 --> Config Class Initialized
INFO - 2018-02-13 05:57:25 --> Loader Class Initialized
INFO - 2018-02-13 11:27:25 --> Helper loaded: url_helper
INFO - 2018-02-13 11:27:25 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:27:25 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:27:25 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:27:25 --> Helper loaded: users_helper
INFO - 2018-02-13 11:27:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:27:25 --> Helper loaded: form_helper
INFO - 2018-02-13 11:27:25 --> Form Validation Class Initialized
INFO - 2018-02-13 11:27:25 --> Controller Class Initialized
INFO - 2018-02-13 11:27:25 --> Model Class Initialized
INFO - 2018-02-13 11:27:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:27:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:27:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:27:25 --> Model Class Initialized
INFO - 2018-02-13 11:27:25 --> Model Class Initialized
INFO - 2018-02-13 11:27:25 --> Model Class Initialized
INFO - 2018-02-13 11:27:25 --> Model Class Initialized
INFO - 2018-02-13 11:27:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:27:25 --> Final output sent to browser
DEBUG - 2018-02-13 11:27:25 --> Total execution time: 0.1114
INFO - 2018-02-13 05:57:30 --> Config Class Initialized
INFO - 2018-02-13 05:57:30 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:57:30 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:57:30 --> Utf8 Class Initialized
INFO - 2018-02-13 05:57:30 --> URI Class Initialized
INFO - 2018-02-13 05:57:30 --> Router Class Initialized
INFO - 2018-02-13 05:57:30 --> Output Class Initialized
INFO - 2018-02-13 05:57:30 --> Security Class Initialized
DEBUG - 2018-02-13 05:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:57:30 --> Input Class Initialized
INFO - 2018-02-13 05:57:30 --> Language Class Initialized
INFO - 2018-02-13 05:57:30 --> Language Class Initialized
INFO - 2018-02-13 05:57:30 --> Config Class Initialized
INFO - 2018-02-13 05:57:30 --> Loader Class Initialized
INFO - 2018-02-13 11:27:30 --> Helper loaded: url_helper
INFO - 2018-02-13 11:27:30 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:27:30 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:27:30 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:27:30 --> Helper loaded: users_helper
INFO - 2018-02-13 11:27:30 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:27:30 --> Helper loaded: form_helper
INFO - 2018-02-13 11:27:30 --> Form Validation Class Initialized
INFO - 2018-02-13 11:27:30 --> Controller Class Initialized
INFO - 2018-02-13 11:27:30 --> Model Class Initialized
INFO - 2018-02-13 11:27:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:27:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:27:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:27:30 --> Model Class Initialized
INFO - 2018-02-13 11:27:30 --> Model Class Initialized
INFO - 2018-02-13 11:27:30 --> Model Class Initialized
INFO - 2018-02-13 11:27:30 --> Model Class Initialized
INFO - 2018-02-13 11:27:30 --> Model Class Initialized
INFO - 2018-02-13 11:27:30 --> Model Class Initialized
INFO - 2018-02-13 11:27:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:27:30 --> Model Class Initialized
INFO - 2018-02-13 11:27:30 --> Final output sent to browser
DEBUG - 2018-02-13 11:27:30 --> Total execution time: 0.1113
INFO - 2018-02-13 05:57:38 --> Config Class Initialized
INFO - 2018-02-13 05:57:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:57:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:57:38 --> Utf8 Class Initialized
INFO - 2018-02-13 05:57:38 --> URI Class Initialized
INFO - 2018-02-13 05:57:38 --> Router Class Initialized
INFO - 2018-02-13 05:57:38 --> Output Class Initialized
INFO - 2018-02-13 05:57:38 --> Security Class Initialized
DEBUG - 2018-02-13 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:57:38 --> Input Class Initialized
INFO - 2018-02-13 05:57:38 --> Language Class Initialized
INFO - 2018-02-13 05:57:38 --> Language Class Initialized
INFO - 2018-02-13 05:57:38 --> Config Class Initialized
INFO - 2018-02-13 05:57:38 --> Loader Class Initialized
INFO - 2018-02-13 11:27:38 --> Helper loaded: url_helper
INFO - 2018-02-13 11:27:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:27:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:27:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:27:38 --> Helper loaded: users_helper
INFO - 2018-02-13 11:27:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:27:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:27:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:27:38 --> Controller Class Initialized
INFO - 2018-02-13 11:27:38 --> Model Class Initialized
INFO - 2018-02-13 11:27:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:27:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:27:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:27:38 --> Model Class Initialized
INFO - 2018-02-13 11:27:38 --> Model Class Initialized
INFO - 2018-02-13 11:27:38 --> Model Class Initialized
INFO - 2018-02-13 11:27:38 --> Model Class Initialized
INFO - 2018-02-13 11:27:38 --> Model Class Initialized
INFO - 2018-02-13 11:27:38 --> Model Class Initialized
INFO - 2018-02-13 11:27:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:27:38 --> Model Class Initialized
INFO - 2018-02-13 11:27:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:27:38 --> Total execution time: 0.1104
INFO - 2018-02-13 05:57:44 --> Config Class Initialized
INFO - 2018-02-13 05:57:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:57:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:57:44 --> Utf8 Class Initialized
INFO - 2018-02-13 05:57:44 --> URI Class Initialized
INFO - 2018-02-13 05:57:44 --> Router Class Initialized
INFO - 2018-02-13 05:57:44 --> Output Class Initialized
INFO - 2018-02-13 05:57:44 --> Security Class Initialized
DEBUG - 2018-02-13 05:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:57:44 --> Input Class Initialized
INFO - 2018-02-13 05:57:44 --> Language Class Initialized
INFO - 2018-02-13 05:57:44 --> Language Class Initialized
INFO - 2018-02-13 05:57:44 --> Config Class Initialized
INFO - 2018-02-13 05:57:44 --> Loader Class Initialized
INFO - 2018-02-13 11:27:44 --> Helper loaded: url_helper
INFO - 2018-02-13 11:27:44 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:27:44 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:27:44 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:27:44 --> Helper loaded: users_helper
INFO - 2018-02-13 11:27:44 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:27:44 --> Helper loaded: form_helper
INFO - 2018-02-13 11:27:44 --> Form Validation Class Initialized
INFO - 2018-02-13 11:27:44 --> Controller Class Initialized
INFO - 2018-02-13 11:27:44 --> Model Class Initialized
INFO - 2018-02-13 11:27:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:27:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:27:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:27:44 --> Model Class Initialized
INFO - 2018-02-13 11:27:44 --> Model Class Initialized
INFO - 2018-02-13 11:27:44 --> Model Class Initialized
INFO - 2018-02-13 11:27:44 --> Model Class Initialized
INFO - 2018-02-13 11:27:44 --> Model Class Initialized
INFO - 2018-02-13 11:27:44 --> Model Class Initialized
INFO - 2018-02-13 11:27:44 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:27:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-13 11:27:44 --> Final output sent to browser
DEBUG - 2018-02-13 11:27:44 --> Total execution time: 0.1203
INFO - 2018-02-13 05:58:36 --> Config Class Initialized
INFO - 2018-02-13 05:58:36 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:58:36 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:58:36 --> Utf8 Class Initialized
INFO - 2018-02-13 05:58:36 --> URI Class Initialized
INFO - 2018-02-13 05:58:36 --> Router Class Initialized
INFO - 2018-02-13 05:58:36 --> Output Class Initialized
INFO - 2018-02-13 05:58:36 --> Security Class Initialized
DEBUG - 2018-02-13 05:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:58:36 --> Input Class Initialized
INFO - 2018-02-13 05:58:36 --> Language Class Initialized
INFO - 2018-02-13 05:58:36 --> Language Class Initialized
INFO - 2018-02-13 05:58:36 --> Config Class Initialized
INFO - 2018-02-13 05:58:36 --> Loader Class Initialized
INFO - 2018-02-13 11:28:36 --> Helper loaded: url_helper
INFO - 2018-02-13 11:28:36 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:28:36 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:28:36 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:28:36 --> Helper loaded: users_helper
INFO - 2018-02-13 11:28:36 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:28:36 --> Helper loaded: form_helper
INFO - 2018-02-13 11:28:36 --> Form Validation Class Initialized
INFO - 2018-02-13 11:28:36 --> Controller Class Initialized
DEBUG - 2018-02-13 11:28:36 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-13 11:28:36 --> Final output sent to browser
DEBUG - 2018-02-13 11:28:36 --> Total execution time: 0.0797
INFO - 2018-02-13 05:58:54 --> Config Class Initialized
INFO - 2018-02-13 05:58:54 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:58:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:58:54 --> Utf8 Class Initialized
INFO - 2018-02-13 05:58:54 --> URI Class Initialized
INFO - 2018-02-13 05:58:54 --> Router Class Initialized
INFO - 2018-02-13 05:58:54 --> Output Class Initialized
INFO - 2018-02-13 05:58:54 --> Security Class Initialized
DEBUG - 2018-02-13 05:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:58:54 --> Input Class Initialized
INFO - 2018-02-13 05:58:54 --> Language Class Initialized
INFO - 2018-02-13 05:58:54 --> Language Class Initialized
INFO - 2018-02-13 05:58:54 --> Config Class Initialized
INFO - 2018-02-13 05:58:54 --> Loader Class Initialized
INFO - 2018-02-13 11:28:54 --> Helper loaded: url_helper
INFO - 2018-02-13 11:28:54 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:28:54 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:28:54 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:28:54 --> Helper loaded: users_helper
INFO - 2018-02-13 11:28:54 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:28:54 --> Helper loaded: form_helper
INFO - 2018-02-13 11:28:54 --> Form Validation Class Initialized
INFO - 2018-02-13 11:28:54 --> Controller Class Initialized
DEBUG - 2018-02-13 11:28:54 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-13 11:28:54 --> Final output sent to browser
DEBUG - 2018-02-13 11:28:54 --> Total execution time: 0.0748
INFO - 2018-02-13 05:59:40 --> Config Class Initialized
INFO - 2018-02-13 05:59:40 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:59:40 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:59:40 --> Utf8 Class Initialized
INFO - 2018-02-13 05:59:40 --> URI Class Initialized
DEBUG - 2018-02-13 05:59:40 --> No URI present. Default controller set.
INFO - 2018-02-13 05:59:40 --> Router Class Initialized
INFO - 2018-02-13 05:59:40 --> Output Class Initialized
INFO - 2018-02-13 05:59:40 --> Security Class Initialized
DEBUG - 2018-02-13 05:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:59:40 --> Input Class Initialized
INFO - 2018-02-13 05:59:40 --> Language Class Initialized
INFO - 2018-02-13 05:59:40 --> Language Class Initialized
INFO - 2018-02-13 05:59:40 --> Config Class Initialized
INFO - 2018-02-13 05:59:40 --> Loader Class Initialized
INFO - 2018-02-13 11:29:40 --> Helper loaded: url_helper
INFO - 2018-02-13 11:29:40 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:29:40 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:29:40 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:29:40 --> Helper loaded: users_helper
INFO - 2018-02-13 11:29:40 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:29:40 --> Helper loaded: form_helper
INFO - 2018-02-13 11:29:40 --> Form Validation Class Initialized
INFO - 2018-02-13 11:29:40 --> Controller Class Initialized
INFO - 2018-02-13 11:29:40 --> Model Class Initialized
INFO - 2018-02-13 11:29:40 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:29:40 --> Model Class Initialized
DEBUG - 2018-02-13 11:29:40 --> File loaded: /home/pr01004/public_html/application/views/login.php
INFO - 2018-02-13 11:29:40 --> Final output sent to browser
DEBUG - 2018-02-13 11:29:40 --> Total execution time: 0.0774
INFO - 2018-02-13 05:59:48 --> Config Class Initialized
INFO - 2018-02-13 05:59:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:59:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:59:48 --> Utf8 Class Initialized
INFO - 2018-02-13 05:59:48 --> URI Class Initialized
INFO - 2018-02-13 05:59:48 --> Router Class Initialized
INFO - 2018-02-13 05:59:48 --> Output Class Initialized
INFO - 2018-02-13 05:59:48 --> Security Class Initialized
DEBUG - 2018-02-13 05:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:59:48 --> Input Class Initialized
INFO - 2018-02-13 05:59:48 --> Language Class Initialized
INFO - 2018-02-13 05:59:48 --> Language Class Initialized
INFO - 2018-02-13 05:59:48 --> Config Class Initialized
INFO - 2018-02-13 05:59:48 --> Loader Class Initialized
INFO - 2018-02-13 11:29:48 --> Helper loaded: url_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: users_helper
INFO - 2018-02-13 11:29:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:29:48 --> Helper loaded: form_helper
INFO - 2018-02-13 11:29:48 --> Form Validation Class Initialized
INFO - 2018-02-13 11:29:48 --> Controller Class Initialized
INFO - 2018-02-13 11:29:48 --> Model Class Initialized
INFO - 2018-02-13 11:29:48 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:29:48 --> Model Class Initialized
INFO - 2018-02-13 11:29:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-02-13 05:59:48 --> Config Class Initialized
INFO - 2018-02-13 05:59:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:59:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:59:48 --> Utf8 Class Initialized
INFO - 2018-02-13 05:59:48 --> URI Class Initialized
INFO - 2018-02-13 05:59:48 --> Router Class Initialized
INFO - 2018-02-13 05:59:48 --> Output Class Initialized
INFO - 2018-02-13 05:59:48 --> Security Class Initialized
DEBUG - 2018-02-13 05:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:59:48 --> Input Class Initialized
INFO - 2018-02-13 05:59:48 --> Language Class Initialized
INFO - 2018-02-13 05:59:48 --> Language Class Initialized
INFO - 2018-02-13 05:59:48 --> Config Class Initialized
INFO - 2018-02-13 05:59:48 --> Loader Class Initialized
INFO - 2018-02-13 11:29:48 --> Helper loaded: url_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: users_helper
INFO - 2018-02-13 11:29:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:29:48 --> Helper loaded: form_helper
INFO - 2018-02-13 11:29:48 --> Form Validation Class Initialized
INFO - 2018-02-13 11:29:48 --> Controller Class Initialized
INFO - 2018-02-13 05:59:48 --> Config Class Initialized
INFO - 2018-02-13 05:59:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 05:59:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 05:59:48 --> Utf8 Class Initialized
INFO - 2018-02-13 05:59:48 --> URI Class Initialized
INFO - 2018-02-13 11:29:48 --> Model Class Initialized
INFO - 2018-02-13 05:59:48 --> Router Class Initialized
INFO - 2018-02-13 11:29:48 --> Helper loaded: inflector_helper
INFO - 2018-02-13 05:59:48 --> Output Class Initialized
INFO - 2018-02-13 11:29:48 --> Model Class Initialized
INFO - 2018-02-13 05:59:48 --> Security Class Initialized
INFO - 2018-02-13 11:29:48 --> Model Class Initialized
INFO - 2018-02-13 11:29:48 --> Model Class Initialized
INFO - 2018-02-13 11:29:48 --> Model Class Initialized
DEBUG - 2018-02-13 05:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 05:59:48 --> Input Class Initialized
INFO - 2018-02-13 11:29:48 --> Model Class Initialized
INFO - 2018-02-13 05:59:48 --> Language Class Initialized
INFO - 2018-02-13 05:59:48 --> Language Class Initialized
INFO - 2018-02-13 05:59:48 --> Config Class Initialized
INFO - 2018-02-13 05:59:48 --> Loader Class Initialized
DEBUG - 2018-02-13 11:29:48 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:29:48 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-02-13 11:29:48 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:29:48 --> Final output sent to browser
DEBUG - 2018-02-13 11:29:48 --> Total execution time: 0.1198
INFO - 2018-02-13 11:29:48 --> Helper loaded: url_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:29:48 --> Helper loaded: users_helper
INFO - 2018-02-13 11:29:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:29:48 --> Helper loaded: form_helper
INFO - 2018-02-13 11:29:48 --> Form Validation Class Initialized
INFO - 2018-02-13 11:29:48 --> Controller Class Initialized
DEBUG - 2018-02-13 11:29:48 --> File loaded: /home/pr01004/public_html/application/views/err404.php
INFO - 2018-02-13 11:29:48 --> Final output sent to browser
DEBUG - 2018-02-13 11:29:48 --> Total execution time: 0.0747
INFO - 2018-02-13 06:00:11 --> Config Class Initialized
INFO - 2018-02-13 06:00:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:11 --> URI Class Initialized
INFO - 2018-02-13 06:00:11 --> Router Class Initialized
INFO - 2018-02-13 06:00:11 --> Output Class Initialized
INFO - 2018-02-13 06:00:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:11 --> Input Class Initialized
INFO - 2018-02-13 06:00:11 --> Language Class Initialized
INFO - 2018-02-13 06:00:11 --> Language Class Initialized
INFO - 2018-02-13 06:00:11 --> Config Class Initialized
INFO - 2018-02-13 06:00:11 --> Loader Class Initialized
INFO - 2018-02-13 11:30:11 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:11 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:11 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:11 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:11 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:11 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:11 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:11 --> Controller Class Initialized
INFO - 2018-02-13 11:30:11 --> Model Class Initialized
INFO - 2018-02-13 11:30:11 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:11 --> Model Class Initialized
INFO - 2018-02-13 11:30:11 --> Model Class Initialized
DEBUG - 2018-02-13 11:30:11 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:30:11 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-02-13 11:30:11 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:30:11 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:11 --> Total execution time: 0.1137
INFO - 2018-02-13 06:00:20 --> Config Class Initialized
INFO - 2018-02-13 06:00:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:20 --> URI Class Initialized
INFO - 2018-02-13 06:00:20 --> Router Class Initialized
INFO - 2018-02-13 06:00:20 --> Output Class Initialized
INFO - 2018-02-13 06:00:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:20 --> Input Class Initialized
INFO - 2018-02-13 06:00:20 --> Language Class Initialized
INFO - 2018-02-13 06:00:20 --> Language Class Initialized
INFO - 2018-02-13 06:00:20 --> Config Class Initialized
INFO - 2018-02-13 06:00:20 --> Loader Class Initialized
INFO - 2018-02-13 11:30:20 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:20 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:20 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:20 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:20 --> Controller Class Initialized
INFO - 2018-02-13 11:30:20 --> Model Class Initialized
INFO - 2018-02-13 11:30:20 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:20 --> Model Class Initialized
INFO - 2018-02-13 11:30:20 --> Model Class Initialized
INFO - 2018-02-13 11:30:20 --> Model Class Initialized
INFO - 2018-02-13 11:30:20 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:20 --> Total execution time: 0.0859
INFO - 2018-02-13 06:00:29 --> Config Class Initialized
INFO - 2018-02-13 06:00:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:29 --> URI Class Initialized
INFO - 2018-02-13 06:00:29 --> Router Class Initialized
INFO - 2018-02-13 06:00:29 --> Output Class Initialized
INFO - 2018-02-13 06:00:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:29 --> Input Class Initialized
INFO - 2018-02-13 06:00:29 --> Language Class Initialized
INFO - 2018-02-13 06:00:29 --> Language Class Initialized
INFO - 2018-02-13 06:00:29 --> Config Class Initialized
INFO - 2018-02-13 06:00:29 --> Loader Class Initialized
INFO - 2018-02-13 11:30:29 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:29 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:29 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:29 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:29 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:29 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:29 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:29 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:29 --> Controller Class Initialized
INFO - 2018-02-13 11:30:29 --> Model Class Initialized
INFO - 2018-02-13 11:30:29 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:29 --> Model Class Initialized
INFO - 2018-02-13 11:30:29 --> Model Class Initialized
INFO - 2018-02-13 11:30:29 --> Model Class Initialized
DEBUG - 2018-02-13 11:30:29 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:30:29 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-13 11:30:29 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:30:29 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:29 --> Total execution time: 0.0711
INFO - 2018-02-13 06:00:36 --> Config Class Initialized
INFO - 2018-02-13 06:00:36 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:36 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:36 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:36 --> URI Class Initialized
INFO - 2018-02-13 06:00:36 --> Router Class Initialized
INFO - 2018-02-13 06:00:36 --> Output Class Initialized
INFO - 2018-02-13 06:00:36 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:36 --> Input Class Initialized
INFO - 2018-02-13 06:00:36 --> Language Class Initialized
INFO - 2018-02-13 06:00:36 --> Language Class Initialized
INFO - 2018-02-13 06:00:36 --> Config Class Initialized
INFO - 2018-02-13 06:00:36 --> Loader Class Initialized
INFO - 2018-02-13 11:30:36 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:36 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:36 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:36 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:36 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:36 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:36 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:36 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:36 --> Controller Class Initialized
INFO - 2018-02-13 11:30:36 --> Model Class Initialized
INFO - 2018-02-13 11:30:36 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:36 --> Model Class Initialized
INFO - 2018-02-13 11:30:36 --> Model Class Initialized
INFO - 2018-02-13 11:30:36 --> Model Class Initialized
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit j /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit l /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit k /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit g /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
ERROR - 2018-02-13 11:30:37 --> Severity: Warning --> pack(): Type H: illegal hex digit s /home/pr01004/public_html/application/controllers/Notification.php 156
INFO - 2018-02-13 06:00:38 --> Config Class Initialized
INFO - 2018-02-13 06:00:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:38 --> URI Class Initialized
INFO - 2018-02-13 06:00:38 --> Router Class Initialized
INFO - 2018-02-13 06:00:38 --> Output Class Initialized
INFO - 2018-02-13 06:00:38 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:38 --> Input Class Initialized
INFO - 2018-02-13 06:00:38 --> Language Class Initialized
INFO - 2018-02-13 06:00:38 --> Language Class Initialized
INFO - 2018-02-13 06:00:38 --> Config Class Initialized
INFO - 2018-02-13 06:00:38 --> Loader Class Initialized
INFO - 2018-02-13 11:30:38 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:38 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:38 --> Controller Class Initialized
INFO - 2018-02-13 11:30:38 --> Model Class Initialized
INFO - 2018-02-13 11:30:38 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:38 --> Model Class Initialized
INFO - 2018-02-13 11:30:38 --> Model Class Initialized
INFO - 2018-02-13 11:30:38 --> Model Class Initialized
DEBUG - 2018-02-13 11:30:38 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:30:38 --> File loaded: /home/pr01004/public_html/application/views/admin/notifications.php
DEBUG - 2018-02-13 11:30:38 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:30:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:38 --> Total execution time: 0.0790
INFO - 2018-02-13 06:00:46 --> Config Class Initialized
INFO - 2018-02-13 06:00:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:46 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:46 --> URI Class Initialized
INFO - 2018-02-13 06:00:46 --> Router Class Initialized
INFO - 2018-02-13 06:00:46 --> Output Class Initialized
INFO - 2018-02-13 06:00:46 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:46 --> Input Class Initialized
INFO - 2018-02-13 06:00:46 --> Language Class Initialized
INFO - 2018-02-13 06:00:46 --> Language Class Initialized
INFO - 2018-02-13 06:00:46 --> Config Class Initialized
INFO - 2018-02-13 06:00:46 --> Loader Class Initialized
INFO - 2018-02-13 11:30:46 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:46 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:46 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:46 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:46 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:46 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:46 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:46 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:46 --> Controller Class Initialized
INFO - 2018-02-13 11:30:46 --> Model Class Initialized
INFO - 2018-02-13 11:30:46 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:46 --> Model Class Initialized
INFO - 2018-02-13 11:30:46 --> Model Class Initialized
DEBUG - 2018-02-13 11:30:46 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:30:46 --> File loaded: /home/pr01004/public_html/application/views/users/usersList.php
DEBUG - 2018-02-13 11:30:46 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:30:46 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:46 --> Total execution time: 0.0752
INFO - 2018-02-13 06:00:47 --> Config Class Initialized
INFO - 2018-02-13 06:00:47 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:47 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:47 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:47 --> URI Class Initialized
INFO - 2018-02-13 06:00:47 --> Router Class Initialized
INFO - 2018-02-13 06:00:47 --> Output Class Initialized
INFO - 2018-02-13 06:00:47 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:47 --> Input Class Initialized
INFO - 2018-02-13 06:00:47 --> Language Class Initialized
INFO - 2018-02-13 06:00:47 --> Language Class Initialized
INFO - 2018-02-13 06:00:47 --> Config Class Initialized
INFO - 2018-02-13 06:00:47 --> Loader Class Initialized
INFO - 2018-02-13 11:30:47 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:47 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:47 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:47 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:47 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:47 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:47 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:47 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:47 --> Controller Class Initialized
INFO - 2018-02-13 11:30:47 --> Model Class Initialized
INFO - 2018-02-13 11:30:47 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:47 --> Model Class Initialized
INFO - 2018-02-13 11:30:47 --> Model Class Initialized
INFO - 2018-02-13 11:30:47 --> Model Class Initialized
INFO - 2018-02-13 11:30:47 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:47 --> Total execution time: 0.0930
INFO - 2018-02-13 06:00:51 --> Config Class Initialized
INFO - 2018-02-13 06:00:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:51 --> URI Class Initialized
INFO - 2018-02-13 06:00:51 --> Router Class Initialized
INFO - 2018-02-13 06:00:51 --> Output Class Initialized
INFO - 2018-02-13 06:00:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:51 --> Input Class Initialized
INFO - 2018-02-13 06:00:51 --> Language Class Initialized
INFO - 2018-02-13 06:00:51 --> Language Class Initialized
INFO - 2018-02-13 06:00:51 --> Config Class Initialized
INFO - 2018-02-13 06:00:51 --> Loader Class Initialized
INFO - 2018-02-13 11:30:51 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:51 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:51 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:51 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:51 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:51 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:51 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:51 --> Controller Class Initialized
INFO - 2018-02-13 11:30:51 --> Model Class Initialized
INFO - 2018-02-13 11:30:51 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:51 --> Model Class Initialized
INFO - 2018-02-13 11:30:51 --> Model Class Initialized
INFO - 2018-02-13 11:30:51 --> Model Class Initialized
INFO - 2018-02-13 11:30:51 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:51 --> Total execution time: 0.0996
INFO - 2018-02-13 06:00:51 --> Config Class Initialized
INFO - 2018-02-13 06:00:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:51 --> URI Class Initialized
INFO - 2018-02-13 06:00:51 --> Router Class Initialized
INFO - 2018-02-13 06:00:51 --> Output Class Initialized
INFO - 2018-02-13 06:00:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:51 --> Input Class Initialized
INFO - 2018-02-13 06:00:51 --> Language Class Initialized
INFO - 2018-02-13 06:00:51 --> Language Class Initialized
INFO - 2018-02-13 06:00:51 --> Config Class Initialized
INFO - 2018-02-13 06:00:51 --> Loader Class Initialized
INFO - 2018-02-13 11:30:51 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:51 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:51 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:51 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:51 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:51 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:51 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:51 --> Controller Class Initialized
INFO - 2018-02-13 11:30:51 --> Model Class Initialized
INFO - 2018-02-13 11:30:51 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:51 --> Model Class Initialized
INFO - 2018-02-13 11:30:51 --> Model Class Initialized
INFO - 2018-02-13 11:30:51 --> Model Class Initialized
INFO - 2018-02-13 11:30:51 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:51 --> Total execution time: 0.0664
INFO - 2018-02-13 06:00:52 --> Config Class Initialized
INFO - 2018-02-13 06:00:52 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:52 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:52 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:52 --> URI Class Initialized
INFO - 2018-02-13 06:00:52 --> Router Class Initialized
INFO - 2018-02-13 06:00:52 --> Output Class Initialized
INFO - 2018-02-13 06:00:52 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:52 --> Input Class Initialized
INFO - 2018-02-13 06:00:52 --> Language Class Initialized
INFO - 2018-02-13 06:00:52 --> Language Class Initialized
INFO - 2018-02-13 06:00:52 --> Config Class Initialized
INFO - 2018-02-13 06:00:52 --> Loader Class Initialized
INFO - 2018-02-13 11:30:52 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:52 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:52 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:52 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:52 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:52 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:52 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:52 --> Controller Class Initialized
INFO - 2018-02-13 11:30:52 --> Model Class Initialized
INFO - 2018-02-13 11:30:52 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:52 --> Model Class Initialized
INFO - 2018-02-13 11:30:52 --> Model Class Initialized
INFO - 2018-02-13 11:30:52 --> Model Class Initialized
INFO - 2018-02-13 11:30:52 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:52 --> Total execution time: 0.0970
INFO - 2018-02-13 06:00:59 --> Config Class Initialized
INFO - 2018-02-13 06:00:59 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:00:59 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:00:59 --> Utf8 Class Initialized
INFO - 2018-02-13 06:00:59 --> URI Class Initialized
INFO - 2018-02-13 06:00:59 --> Router Class Initialized
INFO - 2018-02-13 06:00:59 --> Output Class Initialized
INFO - 2018-02-13 06:00:59 --> Security Class Initialized
DEBUG - 2018-02-13 06:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:00:59 --> Input Class Initialized
INFO - 2018-02-13 06:00:59 --> Language Class Initialized
INFO - 2018-02-13 06:00:59 --> Language Class Initialized
INFO - 2018-02-13 06:00:59 --> Config Class Initialized
INFO - 2018-02-13 06:00:59 --> Loader Class Initialized
INFO - 2018-02-13 11:30:59 --> Helper loaded: url_helper
INFO - 2018-02-13 11:30:59 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:30:59 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:30:59 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:30:59 --> Helper loaded: users_helper
INFO - 2018-02-13 11:30:59 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:30:59 --> Helper loaded: form_helper
INFO - 2018-02-13 11:30:59 --> Form Validation Class Initialized
INFO - 2018-02-13 11:30:59 --> Controller Class Initialized
INFO - 2018-02-13 11:30:59 --> Model Class Initialized
INFO - 2018-02-13 11:30:59 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:30:59 --> Model Class Initialized
INFO - 2018-02-13 11:30:59 --> Model Class Initialized
INFO - 2018-02-13 11:30:59 --> Model Class Initialized
DEBUG - 2018-02-13 11:30:59 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:30:59 --> File loaded: /home/pr01004/public_html/application/views/users/user_details.php
DEBUG - 2018-02-13 11:30:59 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:30:59 --> Final output sent to browser
DEBUG - 2018-02-13 11:30:59 --> Total execution time: 0.0788
INFO - 2018-02-13 06:01:38 --> Config Class Initialized
INFO - 2018-02-13 06:01:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:01:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:01:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:01:38 --> URI Class Initialized
INFO - 2018-02-13 06:01:38 --> Router Class Initialized
INFO - 2018-02-13 06:01:38 --> Output Class Initialized
INFO - 2018-02-13 06:01:38 --> Security Class Initialized
DEBUG - 2018-02-13 06:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:01:38 --> Input Class Initialized
INFO - 2018-02-13 06:01:38 --> Language Class Initialized
INFO - 2018-02-13 06:01:38 --> Language Class Initialized
INFO - 2018-02-13 06:01:38 --> Config Class Initialized
INFO - 2018-02-13 06:01:38 --> Loader Class Initialized
INFO - 2018-02-13 11:31:38 --> Helper loaded: url_helper
INFO - 2018-02-13 11:31:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:31:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:31:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:31:38 --> Helper loaded: users_helper
INFO - 2018-02-13 11:31:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:31:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:31:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:31:38 --> Controller Class Initialized
INFO - 2018-02-13 11:31:38 --> Model Class Initialized
INFO - 2018-02-13 11:31:38 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:31:38 --> Model Class Initialized
INFO - 2018-02-13 11:31:38 --> Model Class Initialized
DEBUG - 2018-02-13 11:31:38 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:31:38 --> File loaded: /home/pr01004/public_html/application/views/cmspages/cmspages.php
DEBUG - 2018-02-13 11:31:38 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:31:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:31:38 --> Total execution time: 0.1152
INFO - 2018-02-13 06:02:03 --> Config Class Initialized
INFO - 2018-02-13 06:02:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:02:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:02:03 --> Utf8 Class Initialized
INFO - 2018-02-13 06:02:03 --> URI Class Initialized
INFO - 2018-02-13 06:02:03 --> Router Class Initialized
INFO - 2018-02-13 06:02:03 --> Output Class Initialized
INFO - 2018-02-13 06:02:03 --> Security Class Initialized
DEBUG - 2018-02-13 06:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:02:03 --> Input Class Initialized
INFO - 2018-02-13 06:02:03 --> Language Class Initialized
INFO - 2018-02-13 06:02:03 --> Language Class Initialized
INFO - 2018-02-13 06:02:03 --> Config Class Initialized
INFO - 2018-02-13 06:02:03 --> Loader Class Initialized
INFO - 2018-02-13 11:32:03 --> Helper loaded: url_helper
INFO - 2018-02-13 11:32:03 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:32:03 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:32:03 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:32:03 --> Helper loaded: users_helper
INFO - 2018-02-13 11:32:03 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:32:03 --> Helper loaded: form_helper
INFO - 2018-02-13 11:32:03 --> Form Validation Class Initialized
INFO - 2018-02-13 11:32:03 --> Controller Class Initialized
INFO - 2018-02-13 11:32:03 --> Model Class Initialized
INFO - 2018-02-13 11:32:03 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:32:03 --> Model Class Initialized
INFO - 2018-02-13 11:32:03 --> Model Class Initialized
INFO - 2018-02-13 11:32:03 --> Model Class Initialized
INFO - 2018-02-13 11:32:03 --> Model Class Initialized
DEBUG - 2018-02-13 11:32:03 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:32:03 --> File loaded: /home/pr01004/public_html/application/views/admin/settings.php
DEBUG - 2018-02-13 11:32:03 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:32:03 --> Final output sent to browser
DEBUG - 2018-02-13 11:32:03 --> Total execution time: 0.2022
INFO - 2018-02-13 06:02:15 --> Config Class Initialized
INFO - 2018-02-13 06:02:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:02:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:02:15 --> Utf8 Class Initialized
INFO - 2018-02-13 06:02:15 --> URI Class Initialized
INFO - 2018-02-13 06:02:15 --> Router Class Initialized
INFO - 2018-02-13 06:02:15 --> Output Class Initialized
INFO - 2018-02-13 06:02:15 --> Security Class Initialized
DEBUG - 2018-02-13 06:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:02:15 --> Input Class Initialized
INFO - 2018-02-13 06:02:15 --> Language Class Initialized
INFO - 2018-02-13 06:02:15 --> Language Class Initialized
INFO - 2018-02-13 06:02:15 --> Config Class Initialized
INFO - 2018-02-13 06:02:15 --> Loader Class Initialized
INFO - 2018-02-13 11:32:15 --> Helper loaded: url_helper
INFO - 2018-02-13 11:32:15 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:32:15 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:32:15 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:32:15 --> Helper loaded: users_helper
INFO - 2018-02-13 11:32:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:32:15 --> Helper loaded: form_helper
INFO - 2018-02-13 11:32:15 --> Form Validation Class Initialized
INFO - 2018-02-13 11:32:15 --> Controller Class Initialized
INFO - 2018-02-13 11:32:15 --> Model Class Initialized
INFO - 2018-02-13 11:32:15 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:32:15 --> Model Class Initialized
INFO - 2018-02-13 11:32:15 --> Model Class Initialized
INFO - 2018-02-13 11:32:15 --> Model Class Initialized
DEBUG - 2018-02-13 11:32:15 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 11:32:15 --> File loaded: /home/pr01004/public_html/application/views/admin/editprofile.php
DEBUG - 2018-02-13 11:32:15 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 11:32:15 --> Final output sent to browser
DEBUG - 2018-02-13 11:32:15 --> Total execution time: 0.1053
INFO - 2018-02-13 06:04:29 --> Config Class Initialized
INFO - 2018-02-13 06:04:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:04:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:04:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:04:29 --> URI Class Initialized
INFO - 2018-02-13 06:04:29 --> Config Class Initialized
INFO - 2018-02-13 06:04:29 --> Hooks Class Initialized
INFO - 2018-02-13 06:04:29 --> Router Class Initialized
INFO - 2018-02-13 06:04:29 --> Output Class Initialized
DEBUG - 2018-02-13 06:04:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:04:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:04:29 --> URI Class Initialized
INFO - 2018-02-13 06:04:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:04:29 --> Input Class Initialized
INFO - 2018-02-13 06:04:29 --> Language Class Initialized
INFO - 2018-02-13 06:04:29 --> Router Class Initialized
INFO - 2018-02-13 06:04:29 --> Output Class Initialized
INFO - 2018-02-13 06:04:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:04:29 --> Input Class Initialized
INFO - 2018-02-13 06:04:29 --> Language Class Initialized
INFO - 2018-02-13 06:04:29 --> Language Class Initialized
INFO - 2018-02-13 06:04:29 --> Config Class Initialized
INFO - 2018-02-13 06:04:29 --> Loader Class Initialized
INFO - 2018-02-13 11:34:29 --> Helper loaded: url_helper
INFO - 2018-02-13 11:34:29 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:34:29 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:34:29 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:34:29 --> Helper loaded: users_helper
INFO - 2018-02-13 06:04:29 --> Language Class Initialized
INFO - 2018-02-13 06:04:29 --> Config Class Initialized
INFO - 2018-02-13 06:04:29 --> Loader Class Initialized
INFO - 2018-02-13 11:34:29 --> Helper loaded: url_helper
INFO - 2018-02-13 11:34:29 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:34:29 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:34:29 --> Database Driver Class Initialized
INFO - 2018-02-13 11:34:29 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:34:29 --> Helper loaded: users_helper
DEBUG - 2018-02-13 11:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:34:29 --> Helper loaded: form_helper
INFO - 2018-02-13 11:34:29 --> Form Validation Class Initialized
INFO - 2018-02-13 11:34:29 --> Controller Class Initialized
INFO - 2018-02-13 11:34:29 --> Database Driver Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
DEBUG - 2018-02-13 11:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:34:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:34:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:34:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Helper loaded: form_helper
INFO - 2018-02-13 11:34:29 --> Form Validation Class Initialized
INFO - 2018-02-13 11:34:29 --> Controller Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:34:29 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:34:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:34:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Final output sent to browser
DEBUG - 2018-02-13 11:34:30 --> Total execution time: 0.1133
INFO - 2018-02-13 11:34:30 --> Final output sent to browser
DEBUG - 2018-02-13 11:34:30 --> Total execution time: 0.1351
INFO - 2018-02-13 06:04:30 --> Config Class Initialized
INFO - 2018-02-13 06:04:30 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:04:30 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:04:30 --> Utf8 Class Initialized
INFO - 2018-02-13 06:04:30 --> URI Class Initialized
INFO - 2018-02-13 06:04:30 --> Router Class Initialized
INFO - 2018-02-13 06:04:30 --> Output Class Initialized
INFO - 2018-02-13 06:04:30 --> Security Class Initialized
DEBUG - 2018-02-13 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:04:30 --> Input Class Initialized
INFO - 2018-02-13 06:04:30 --> Language Class Initialized
INFO - 2018-02-13 06:04:30 --> Language Class Initialized
INFO - 2018-02-13 06:04:30 --> Config Class Initialized
INFO - 2018-02-13 06:04:30 --> Loader Class Initialized
INFO - 2018-02-13 11:34:30 --> Helper loaded: url_helper
INFO - 2018-02-13 11:34:30 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:34:30 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:34:30 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:34:30 --> Helper loaded: users_helper
INFO - 2018-02-13 11:34:30 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:34:30 --> Helper loaded: form_helper
INFO - 2018-02-13 11:34:30 --> Form Validation Class Initialized
INFO - 2018-02-13 11:34:30 --> Controller Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:34:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:34:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Model Class Initialized
INFO - 2018-02-13 11:34:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:34:30 --> Final output sent to browser
DEBUG - 2018-02-13 11:34:30 --> Total execution time: 0.1143
INFO - 2018-02-13 06:04:38 --> Config Class Initialized
INFO - 2018-02-13 06:04:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:04:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:04:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:04:38 --> URI Class Initialized
INFO - 2018-02-13 06:04:38 --> Router Class Initialized
INFO - 2018-02-13 06:04:38 --> Output Class Initialized
INFO - 2018-02-13 06:04:38 --> Security Class Initialized
DEBUG - 2018-02-13 06:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:04:38 --> Input Class Initialized
INFO - 2018-02-13 06:04:38 --> Language Class Initialized
INFO - 2018-02-13 06:04:38 --> Language Class Initialized
INFO - 2018-02-13 06:04:38 --> Config Class Initialized
INFO - 2018-02-13 06:04:38 --> Loader Class Initialized
INFO - 2018-02-13 11:34:38 --> Helper loaded: url_helper
INFO - 2018-02-13 11:34:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:34:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:34:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:34:38 --> Helper loaded: users_helper
INFO - 2018-02-13 11:34:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:34:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:34:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:34:38 --> Controller Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:34:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:34:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:34:38 --> Model Class Initialized
INFO - 2018-02-13 11:34:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:34:38 --> Total execution time: 0.0923
INFO - 2018-02-13 06:04:41 --> Config Class Initialized
INFO - 2018-02-13 06:04:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:04:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:04:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:04:41 --> URI Class Initialized
INFO - 2018-02-13 06:04:41 --> Router Class Initialized
INFO - 2018-02-13 06:04:41 --> Output Class Initialized
INFO - 2018-02-13 06:04:41 --> Security Class Initialized
DEBUG - 2018-02-13 06:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:04:41 --> Input Class Initialized
INFO - 2018-02-13 06:04:41 --> Language Class Initialized
INFO - 2018-02-13 06:04:41 --> Language Class Initialized
INFO - 2018-02-13 06:04:41 --> Config Class Initialized
INFO - 2018-02-13 06:04:41 --> Loader Class Initialized
INFO - 2018-02-13 11:34:41 --> Helper loaded: url_helper
INFO - 2018-02-13 11:34:41 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:34:41 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:34:41 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:34:41 --> Helper loaded: users_helper
INFO - 2018-02-13 11:34:41 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:34:41 --> Helper loaded: form_helper
INFO - 2018-02-13 11:34:41 --> Form Validation Class Initialized
INFO - 2018-02-13 11:34:41 --> Controller Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:34:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:34:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:34:41 --> Model Class Initialized
INFO - 2018-02-13 11:34:41 --> Final output sent to browser
DEBUG - 2018-02-13 11:34:41 --> Total execution time: 0.1382
INFO - 2018-02-13 06:04:50 --> Config Class Initialized
INFO - 2018-02-13 06:04:50 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:04:50 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:04:50 --> Utf8 Class Initialized
INFO - 2018-02-13 06:04:50 --> URI Class Initialized
INFO - 2018-02-13 06:04:50 --> Router Class Initialized
INFO - 2018-02-13 06:04:50 --> Output Class Initialized
INFO - 2018-02-13 06:04:50 --> Security Class Initialized
DEBUG - 2018-02-13 06:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:04:50 --> Input Class Initialized
INFO - 2018-02-13 06:04:50 --> Language Class Initialized
INFO - 2018-02-13 06:04:50 --> Language Class Initialized
INFO - 2018-02-13 06:04:50 --> Config Class Initialized
INFO - 2018-02-13 06:04:50 --> Loader Class Initialized
INFO - 2018-02-13 11:34:50 --> Helper loaded: url_helper
INFO - 2018-02-13 11:34:50 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:34:50 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:34:50 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:34:50 --> Helper loaded: users_helper
INFO - 2018-02-13 11:34:50 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:34:50 --> Helper loaded: form_helper
INFO - 2018-02-13 11:34:50 --> Form Validation Class Initialized
INFO - 2018-02-13 11:34:50 --> Controller Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:34:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:34:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:34:50 --> Model Class Initialized
INFO - 2018-02-13 11:34:50 --> Final output sent to browser
DEBUG - 2018-02-13 11:34:50 --> Total execution time: 0.0971
INFO - 2018-02-13 06:04:56 --> Config Class Initialized
INFO - 2018-02-13 06:04:56 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:04:56 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:04:56 --> Utf8 Class Initialized
INFO - 2018-02-13 06:04:56 --> URI Class Initialized
INFO - 2018-02-13 06:04:56 --> Router Class Initialized
INFO - 2018-02-13 06:04:56 --> Output Class Initialized
INFO - 2018-02-13 06:04:56 --> Security Class Initialized
DEBUG - 2018-02-13 06:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:04:56 --> Input Class Initialized
INFO - 2018-02-13 06:04:56 --> Language Class Initialized
INFO - 2018-02-13 06:04:56 --> Language Class Initialized
INFO - 2018-02-13 06:04:56 --> Config Class Initialized
INFO - 2018-02-13 06:04:56 --> Loader Class Initialized
INFO - 2018-02-13 11:34:56 --> Helper loaded: url_helper
INFO - 2018-02-13 11:34:56 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:34:56 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:34:56 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:34:56 --> Helper loaded: users_helper
INFO - 2018-02-13 11:34:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:34:56 --> Helper loaded: form_helper
INFO - 2018-02-13 11:34:56 --> Form Validation Class Initialized
INFO - 2018-02-13 11:34:56 --> Controller Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:34:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:34:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:34:56 --> Model Class Initialized
INFO - 2018-02-13 11:34:56 --> Final output sent to browser
DEBUG - 2018-02-13 11:34:56 --> Total execution time: 0.1314
INFO - 2018-02-13 06:05:09 --> Config Class Initialized
INFO - 2018-02-13 06:05:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:09 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:09 --> URI Class Initialized
INFO - 2018-02-13 06:05:09 --> Router Class Initialized
INFO - 2018-02-13 06:05:09 --> Output Class Initialized
INFO - 2018-02-13 06:05:09 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:09 --> Input Class Initialized
INFO - 2018-02-13 06:05:09 --> Language Class Initialized
INFO - 2018-02-13 06:05:09 --> Language Class Initialized
INFO - 2018-02-13 06:05:09 --> Config Class Initialized
INFO - 2018-02-13 06:05:09 --> Loader Class Initialized
INFO - 2018-02-13 11:35:09 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:09 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:09 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:09 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:09 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:09 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:09 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:09 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:09 --> Controller Class Initialized
INFO - 2018-02-13 11:35:09 --> Model Class Initialized
INFO - 2018-02-13 11:35:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:09 --> Model Class Initialized
INFO - 2018-02-13 11:35:09 --> Model Class Initialized
INFO - 2018-02-13 11:35:09 --> Model Class Initialized
INFO - 2018-02-13 11:35:09 --> Model Class Initialized
INFO - 2018-02-13 11:35:09 --> Model Class Initialized
INFO - 2018-02-13 11:35:09 --> Model Class Initialized
INFO - 2018-02-13 11:35:09 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:35:09 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-02-13 11:35:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-02-13 11:35:09 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:09 --> Total execution time: 0.1187
INFO - 2018-02-13 06:05:15 --> Config Class Initialized
INFO - 2018-02-13 06:05:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:15 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:15 --> URI Class Initialized
INFO - 2018-02-13 06:05:15 --> Router Class Initialized
INFO - 2018-02-13 06:05:15 --> Output Class Initialized
INFO - 2018-02-13 06:05:15 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:15 --> Input Class Initialized
INFO - 2018-02-13 06:05:15 --> Language Class Initialized
INFO - 2018-02-13 06:05:15 --> Language Class Initialized
INFO - 2018-02-13 06:05:15 --> Config Class Initialized
INFO - 2018-02-13 06:05:15 --> Loader Class Initialized
INFO - 2018-02-13 11:35:15 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:15 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:15 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:15 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:15 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:15 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:15 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:15 --> Controller Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:15 --> Model Class Initialized
INFO - 2018-02-13 11:35:15 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:15 --> Total execution time: 0.1160
INFO - 2018-02-13 06:05:20 --> Config Class Initialized
INFO - 2018-02-13 06:05:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:20 --> URI Class Initialized
INFO - 2018-02-13 06:05:20 --> Router Class Initialized
INFO - 2018-02-13 06:05:20 --> Output Class Initialized
INFO - 2018-02-13 06:05:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:20 --> Input Class Initialized
INFO - 2018-02-13 06:05:20 --> Language Class Initialized
INFO - 2018-02-13 06:05:20 --> Language Class Initialized
INFO - 2018-02-13 06:05:20 --> Config Class Initialized
INFO - 2018-02-13 06:05:20 --> Loader Class Initialized
INFO - 2018-02-13 11:35:20 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:20 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:20 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:20 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:20 --> Controller Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:20 --> Model Class Initialized
INFO - 2018-02-13 11:35:20 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:20 --> Total execution time: 0.1369
INFO - 2018-02-13 06:05:23 --> Config Class Initialized
INFO - 2018-02-13 06:05:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:23 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:23 --> URI Class Initialized
INFO - 2018-02-13 06:05:23 --> Router Class Initialized
INFO - 2018-02-13 06:05:23 --> Output Class Initialized
INFO - 2018-02-13 06:05:23 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:23 --> Input Class Initialized
INFO - 2018-02-13 06:05:23 --> Language Class Initialized
INFO - 2018-02-13 06:05:23 --> Language Class Initialized
INFO - 2018-02-13 06:05:23 --> Config Class Initialized
INFO - 2018-02-13 06:05:23 --> Loader Class Initialized
INFO - 2018-02-13 11:35:23 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:23 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:23 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:23 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:23 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:23 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:23 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:23 --> Controller Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:23 --> Model Class Initialized
INFO - 2018-02-13 11:35:23 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:23 --> Total execution time: 0.1463
INFO - 2018-02-13 06:05:24 --> Config Class Initialized
INFO - 2018-02-13 06:05:24 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:24 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:24 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:24 --> URI Class Initialized
INFO - 2018-02-13 06:05:24 --> Router Class Initialized
INFO - 2018-02-13 06:05:24 --> Output Class Initialized
INFO - 2018-02-13 06:05:24 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:24 --> Input Class Initialized
INFO - 2018-02-13 06:05:24 --> Language Class Initialized
INFO - 2018-02-13 06:05:24 --> Language Class Initialized
INFO - 2018-02-13 06:05:24 --> Config Class Initialized
INFO - 2018-02-13 06:05:24 --> Loader Class Initialized
INFO - 2018-02-13 11:35:24 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:24 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:24 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:24 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:24 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:24 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:24 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:24 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:24 --> Controller Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:24 --> Model Class Initialized
INFO - 2018-02-13 11:35:24 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:24 --> Total execution time: 0.1109
INFO - 2018-02-13 06:05:28 --> Config Class Initialized
INFO - 2018-02-13 06:05:28 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:28 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:28 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:28 --> URI Class Initialized
INFO - 2018-02-13 06:05:28 --> Router Class Initialized
INFO - 2018-02-13 06:05:28 --> Output Class Initialized
INFO - 2018-02-13 06:05:28 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:28 --> Input Class Initialized
INFO - 2018-02-13 06:05:28 --> Language Class Initialized
INFO - 2018-02-13 06:05:28 --> Language Class Initialized
INFO - 2018-02-13 06:05:28 --> Config Class Initialized
INFO - 2018-02-13 06:05:28 --> Loader Class Initialized
INFO - 2018-02-13 11:35:28 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:28 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:28 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:28 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:28 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:28 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:28 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:28 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:28 --> Controller Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:28 --> Model Class Initialized
INFO - 2018-02-13 11:35:28 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:28 --> Total execution time: 0.1285
INFO - 2018-02-13 06:05:33 --> Config Class Initialized
INFO - 2018-02-13 06:05:33 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:33 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:33 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:33 --> URI Class Initialized
INFO - 2018-02-13 06:05:33 --> Router Class Initialized
INFO - 2018-02-13 06:05:33 --> Output Class Initialized
INFO - 2018-02-13 06:05:33 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:33 --> Input Class Initialized
INFO - 2018-02-13 06:05:33 --> Language Class Initialized
INFO - 2018-02-13 06:05:33 --> Language Class Initialized
INFO - 2018-02-13 06:05:33 --> Config Class Initialized
INFO - 2018-02-13 06:05:33 --> Loader Class Initialized
INFO - 2018-02-13 11:35:33 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:33 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:33 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:33 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:33 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:33 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:33 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:33 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:33 --> Controller Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Model Class Initialized
INFO - 2018-02-13 11:35:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:33 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:33 --> Total execution time: 0.0801
INFO - 2018-02-13 06:05:34 --> Config Class Initialized
INFO - 2018-02-13 06:05:34 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:34 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:34 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:34 --> URI Class Initialized
INFO - 2018-02-13 06:05:34 --> Router Class Initialized
INFO - 2018-02-13 06:05:34 --> Output Class Initialized
INFO - 2018-02-13 06:05:34 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:34 --> Input Class Initialized
INFO - 2018-02-13 06:05:34 --> Language Class Initialized
INFO - 2018-02-13 06:05:34 --> Language Class Initialized
INFO - 2018-02-13 06:05:34 --> Config Class Initialized
INFO - 2018-02-13 06:05:34 --> Loader Class Initialized
INFO - 2018-02-13 11:35:34 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:34 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:34 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:34 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:34 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:34 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:34 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:34 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:34 --> Controller Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Model Class Initialized
INFO - 2018-02-13 11:35:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:34 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:34 --> Total execution time: 0.0828
INFO - 2018-02-13 06:05:35 --> Config Class Initialized
INFO - 2018-02-13 06:05:35 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:35 --> URI Class Initialized
INFO - 2018-02-13 06:05:35 --> Router Class Initialized
INFO - 2018-02-13 06:05:35 --> Output Class Initialized
INFO - 2018-02-13 06:05:35 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:35 --> Input Class Initialized
INFO - 2018-02-13 06:05:35 --> Language Class Initialized
INFO - 2018-02-13 06:05:35 --> Language Class Initialized
INFO - 2018-02-13 06:05:35 --> Config Class Initialized
INFO - 2018-02-13 06:05:35 --> Loader Class Initialized
INFO - 2018-02-13 11:35:35 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:35 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:35 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:35 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:35 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:35 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:35 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:35 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:35 --> Controller Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Model Class Initialized
INFO - 2018-02-13 11:35:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:35 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:35 --> Total execution time: 0.1182
INFO - 2018-02-13 06:05:37 --> Config Class Initialized
INFO - 2018-02-13 06:05:37 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:37 --> URI Class Initialized
INFO - 2018-02-13 06:05:37 --> Router Class Initialized
INFO - 2018-02-13 06:05:37 --> Output Class Initialized
INFO - 2018-02-13 06:05:37 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:37 --> Input Class Initialized
INFO - 2018-02-13 06:05:37 --> Language Class Initialized
INFO - 2018-02-13 06:05:37 --> Language Class Initialized
INFO - 2018-02-13 06:05:37 --> Config Class Initialized
INFO - 2018-02-13 06:05:37 --> Loader Class Initialized
INFO - 2018-02-13 11:35:37 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:37 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:37 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:37 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:37 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:37 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:37 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:37 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:37 --> Controller Class Initialized
INFO - 2018-02-13 11:35:37 --> Model Class Initialized
INFO - 2018-02-13 11:35:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:37 --> Model Class Initialized
INFO - 2018-02-13 11:35:37 --> Model Class Initialized
INFO - 2018-02-13 11:35:37 --> Model Class Initialized
INFO - 2018-02-13 11:35:37 --> Model Class Initialized
INFO - 2018-02-13 11:35:37 --> Model Class Initialized
INFO - 2018-02-13 11:35:37 --> Model Class Initialized
INFO - 2018-02-13 11:35:37 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:37 --> Total execution time: 0.1166
INFO - 2018-02-13 06:05:38 --> Config Class Initialized
INFO - 2018-02-13 06:05:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:38 --> URI Class Initialized
INFO - 2018-02-13 06:05:38 --> Router Class Initialized
INFO - 2018-02-13 06:05:38 --> Config Class Initialized
INFO - 2018-02-13 06:05:38 --> Hooks Class Initialized
INFO - 2018-02-13 06:05:38 --> Output Class Initialized
INFO - 2018-02-13 06:05:38 --> Config Class Initialized
INFO - 2018-02-13 06:05:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:38 --> Security Class Initialized
INFO - 2018-02-13 06:05:38 --> URI Class Initialized
DEBUG - 2018-02-13 06:05:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:38 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:38 --> Input Class Initialized
INFO - 2018-02-13 06:05:38 --> URI Class Initialized
INFO - 2018-02-13 06:05:38 --> Language Class Initialized
INFO - 2018-02-13 06:05:38 --> Router Class Initialized
INFO - 2018-02-13 06:05:38 --> Router Class Initialized
INFO - 2018-02-13 06:05:38 --> Output Class Initialized
INFO - 2018-02-13 06:05:38 --> Output Class Initialized
INFO - 2018-02-13 06:05:38 --> Security Class Initialized
INFO - 2018-02-13 06:05:38 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:38 --> Input Class Initialized
INFO - 2018-02-13 06:05:38 --> Language Class Initialized
DEBUG - 2018-02-13 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:38 --> Input Class Initialized
INFO - 2018-02-13 06:05:38 --> Language Class Initialized
INFO - 2018-02-13 06:05:38 --> Language Class Initialized
INFO - 2018-02-13 06:05:38 --> Config Class Initialized
INFO - 2018-02-13 06:05:38 --> Loader Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: users_helper
INFO - 2018-02-13 06:05:38 --> Language Class Initialized
INFO - 2018-02-13 06:05:38 --> Config Class Initialized
INFO - 2018-02-13 06:05:38 --> Loader Class Initialized
INFO - 2018-02-13 06:05:38 --> Language Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: url_helper
INFO - 2018-02-13 06:05:38 --> Config Class Initialized
INFO - 2018-02-13 06:05:38 --> Loader Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:38 --> Database Driver Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: users_helper
DEBUG - 2018-02-13 11:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:38 --> Database Driver Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:38 --> Controller Class Initialized
INFO - 2018-02-13 11:35:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 11:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:38 --> Total execution time: 0.1050
INFO - 2018-02-13 11:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:38 --> Controller Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:38 --> Total execution time: 0.1316
INFO - 2018-02-13 11:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:38 --> Controller Class Initialized
INFO - 2018-02-13 06:05:38 --> Config Class Initialized
INFO - 2018-02-13 06:05:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:38 --> Utf8 Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: inflector_helper
INFO - 2018-02-13 06:05:38 --> URI Class Initialized
DEBUG - 2018-02-13 11:35:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 06:05:38 --> Router Class Initialized
INFO - 2018-02-13 11:35:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 06:05:38 --> Output Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 06:05:38 --> Security Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:38 --> Total execution time: 0.1628
DEBUG - 2018-02-13 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:38 --> Input Class Initialized
INFO - 2018-02-13 06:05:38 --> Language Class Initialized
INFO - 2018-02-13 06:05:38 --> Language Class Initialized
INFO - 2018-02-13 06:05:38 --> Config Class Initialized
INFO - 2018-02-13 06:05:38 --> Loader Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:38 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:38 --> Controller Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Model Class Initialized
INFO - 2018-02-13 11:35:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:38 --> Total execution time: 0.1093
INFO - 2018-02-13 06:05:39 --> Config Class Initialized
INFO - 2018-02-13 06:05:39 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:39 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:39 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:39 --> URI Class Initialized
INFO - 2018-02-13 06:05:39 --> Router Class Initialized
INFO - 2018-02-13 06:05:39 --> Output Class Initialized
INFO - 2018-02-13 06:05:39 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:39 --> Input Class Initialized
INFO - 2018-02-13 06:05:39 --> Language Class Initialized
INFO - 2018-02-13 06:05:39 --> Language Class Initialized
INFO - 2018-02-13 06:05:39 --> Config Class Initialized
INFO - 2018-02-13 06:05:39 --> Loader Class Initialized
INFO - 2018-02-13 11:35:39 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:39 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:39 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:39 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:39 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:39 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:39 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:39 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:39 --> Controller Class Initialized
INFO - 2018-02-13 11:35:39 --> Model Class Initialized
INFO - 2018-02-13 11:35:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:39 --> Model Class Initialized
INFO - 2018-02-13 11:35:39 --> Model Class Initialized
INFO - 2018-02-13 11:35:39 --> Model Class Initialized
INFO - 2018-02-13 11:35:39 --> Model Class Initialized
INFO - 2018-02-13 11:35:39 --> Model Class Initialized
INFO - 2018-02-13 11:35:39 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:39 --> Total execution time: 0.1153
INFO - 2018-02-13 06:05:41 --> Config Class Initialized
INFO - 2018-02-13 06:05:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:41 --> URI Class Initialized
INFO - 2018-02-13 06:05:41 --> Router Class Initialized
INFO - 2018-02-13 06:05:41 --> Output Class Initialized
INFO - 2018-02-13 06:05:41 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:41 --> Input Class Initialized
INFO - 2018-02-13 06:05:41 --> Language Class Initialized
INFO - 2018-02-13 06:05:41 --> Language Class Initialized
INFO - 2018-02-13 06:05:41 --> Config Class Initialized
INFO - 2018-02-13 06:05:41 --> Loader Class Initialized
INFO - 2018-02-13 11:35:41 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:41 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:41 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:41 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:41 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:41 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:41 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:41 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:41 --> Controller Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Model Class Initialized
INFO - 2018-02-13 11:35:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:41 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:41 --> Total execution time: 0.0933
INFO - 2018-02-13 06:05:42 --> Config Class Initialized
INFO - 2018-02-13 06:05:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:42 --> URI Class Initialized
INFO - 2018-02-13 06:05:42 --> Router Class Initialized
INFO - 2018-02-13 06:05:42 --> Output Class Initialized
INFO - 2018-02-13 06:05:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:42 --> Input Class Initialized
INFO - 2018-02-13 06:05:42 --> Language Class Initialized
INFO - 2018-02-13 06:05:42 --> Language Class Initialized
INFO - 2018-02-13 06:05:42 --> Config Class Initialized
INFO - 2018-02-13 06:05:42 --> Loader Class Initialized
INFO - 2018-02-13 11:35:42 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:42 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:42 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:42 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:42 --> Controller Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:42 --> Model Class Initialized
INFO - 2018-02-13 11:35:42 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:42 --> Total execution time: 0.1019
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:46 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:46 --> URI Class Initialized
INFO - 2018-02-13 06:05:46 --> Router Class Initialized
INFO - 2018-02-13 06:05:46 --> Output Class Initialized
INFO - 2018-02-13 06:05:46 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:46 --> Input Class Initialized
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Loader Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:46 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:46 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:46 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:46 --> Controller Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:46 --> Total execution time: 0.1025
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:46 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:46 --> URI Class Initialized
INFO - 2018-02-13 06:05:46 --> Router Class Initialized
INFO - 2018-02-13 06:05:46 --> Output Class Initialized
INFO - 2018-02-13 06:05:46 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:46 --> Input Class Initialized
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Hooks Class Initialized
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:46 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:05:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:46 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:46 --> URI Class Initialized
INFO - 2018-02-13 06:05:46 --> URI Class Initialized
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Loader Class Initialized
INFO - 2018-02-13 06:05:46 --> Router Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: url_helper
INFO - 2018-02-13 06:05:46 --> Router Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: permission_helper
INFO - 2018-02-13 06:05:46 --> Output Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: users_helper
INFO - 2018-02-13 06:05:46 --> Output Class Initialized
INFO - 2018-02-13 06:05:46 --> Security Class Initialized
INFO - 2018-02-13 06:05:46 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:46 --> Input Class Initialized
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
DEBUG - 2018-02-13 06:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:46 --> Input Class Initialized
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
INFO - 2018-02-13 11:35:46 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Loader Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:46 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:46 --> Controller Class Initialized
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Loader Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Database Driver Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-13 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Database Driver Class Initialized
INFO - 2018-02-13 11:35:46 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:46 --> Total execution time: 0.0851
INFO - 2018-02-13 11:35:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:46 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:46 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:46 --> Controller Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:46 --> Total execution time: 0.0958
INFO - 2018-02-13 11:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:46 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:46 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:46 --> Controller Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:46 --> Total execution time: 0.1223
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:46 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:46 --> URI Class Initialized
INFO - 2018-02-13 06:05:46 --> Router Class Initialized
INFO - 2018-02-13 06:05:46 --> Output Class Initialized
INFO - 2018-02-13 06:05:46 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:46 --> Input Class Initialized
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
INFO - 2018-02-13 06:05:46 --> Language Class Initialized
INFO - 2018-02-13 06:05:46 --> Config Class Initialized
INFO - 2018-02-13 06:05:46 --> Loader Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:46 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:46 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:46 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:46 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:46 --> Controller Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Model Class Initialized
INFO - 2018-02-13 11:35:46 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:46 --> Total execution time: 0.1062
INFO - 2018-02-13 06:05:48 --> Config Class Initialized
INFO - 2018-02-13 06:05:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:48 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:48 --> URI Class Initialized
INFO - 2018-02-13 06:05:48 --> Router Class Initialized
INFO - 2018-02-13 06:05:48 --> Output Class Initialized
INFO - 2018-02-13 06:05:48 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:48 --> Input Class Initialized
INFO - 2018-02-13 06:05:48 --> Language Class Initialized
INFO - 2018-02-13 06:05:48 --> Language Class Initialized
INFO - 2018-02-13 06:05:48 --> Config Class Initialized
INFO - 2018-02-13 06:05:48 --> Loader Class Initialized
INFO - 2018-02-13 11:35:48 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:48 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:48 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:48 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:48 --> Controller Class Initialized
INFO - 2018-02-13 11:35:48 --> Model Class Initialized
INFO - 2018-02-13 11:35:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:48 --> Model Class Initialized
INFO - 2018-02-13 11:35:48 --> Model Class Initialized
INFO - 2018-02-13 11:35:48 --> Model Class Initialized
INFO - 2018-02-13 11:35:48 --> Model Class Initialized
INFO - 2018-02-13 11:35:48 --> Model Class Initialized
INFO - 2018-02-13 11:35:48 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:48 --> Total execution time: 0.0938
INFO - 2018-02-13 06:05:50 --> Config Class Initialized
INFO - 2018-02-13 06:05:50 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:50 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:50 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:50 --> URI Class Initialized
INFO - 2018-02-13 06:05:50 --> Router Class Initialized
INFO - 2018-02-13 06:05:50 --> Output Class Initialized
INFO - 2018-02-13 06:05:50 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:50 --> Input Class Initialized
INFO - 2018-02-13 06:05:50 --> Language Class Initialized
INFO - 2018-02-13 06:05:50 --> Language Class Initialized
INFO - 2018-02-13 06:05:50 --> Config Class Initialized
INFO - 2018-02-13 06:05:50 --> Loader Class Initialized
INFO - 2018-02-13 11:35:50 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:50 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:50 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:50 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:50 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:50 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:50 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:50 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:50 --> Controller Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:50 --> Model Class Initialized
INFO - 2018-02-13 11:35:50 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:50 --> Total execution time: 0.1211
INFO - 2018-02-13 06:05:54 --> Config Class Initialized
INFO - 2018-02-13 06:05:54 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:54 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:54 --> URI Class Initialized
INFO - 2018-02-13 06:05:54 --> Router Class Initialized
INFO - 2018-02-13 06:05:54 --> Output Class Initialized
INFO - 2018-02-13 06:05:54 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:54 --> Input Class Initialized
INFO - 2018-02-13 06:05:54 --> Language Class Initialized
INFO - 2018-02-13 06:05:54 --> Language Class Initialized
INFO - 2018-02-13 06:05:54 --> Config Class Initialized
INFO - 2018-02-13 06:05:54 --> Loader Class Initialized
INFO - 2018-02-13 11:35:54 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:54 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:54 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:54 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:54 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:54 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:54 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:54 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:54 --> Controller Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:54 --> Model Class Initialized
INFO - 2018-02-13 11:35:54 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:54 --> Total execution time: 0.1426
INFO - 2018-02-13 06:05:56 --> Config Class Initialized
INFO - 2018-02-13 06:05:56 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:56 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:56 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:56 --> URI Class Initialized
INFO - 2018-02-13 06:05:56 --> Router Class Initialized
INFO - 2018-02-13 06:05:56 --> Output Class Initialized
INFO - 2018-02-13 06:05:56 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:56 --> Input Class Initialized
INFO - 2018-02-13 06:05:56 --> Language Class Initialized
INFO - 2018-02-13 06:05:56 --> Language Class Initialized
INFO - 2018-02-13 06:05:56 --> Config Class Initialized
INFO - 2018-02-13 06:05:56 --> Loader Class Initialized
INFO - 2018-02-13 11:35:56 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:56 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:56 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:56 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:56 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:56 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:56 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:56 --> Controller Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:56 --> Model Class Initialized
INFO - 2018-02-13 11:35:56 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:56 --> Total execution time: 0.1321
INFO - 2018-02-13 06:05:58 --> Config Class Initialized
INFO - 2018-02-13 06:05:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:05:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:05:58 --> Utf8 Class Initialized
INFO - 2018-02-13 06:05:58 --> URI Class Initialized
INFO - 2018-02-13 06:05:58 --> Router Class Initialized
INFO - 2018-02-13 06:05:58 --> Output Class Initialized
INFO - 2018-02-13 06:05:58 --> Security Class Initialized
DEBUG - 2018-02-13 06:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:05:58 --> Input Class Initialized
INFO - 2018-02-13 06:05:58 --> Language Class Initialized
INFO - 2018-02-13 06:05:58 --> Language Class Initialized
INFO - 2018-02-13 06:05:58 --> Config Class Initialized
INFO - 2018-02-13 06:05:58 --> Loader Class Initialized
INFO - 2018-02-13 11:35:58 --> Helper loaded: url_helper
INFO - 2018-02-13 11:35:58 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:35:58 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:35:58 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:35:58 --> Helper loaded: users_helper
INFO - 2018-02-13 11:35:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:35:58 --> Helper loaded: form_helper
INFO - 2018-02-13 11:35:58 --> Form Validation Class Initialized
INFO - 2018-02-13 11:35:58 --> Controller Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:35:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:35:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:35:58 --> Model Class Initialized
INFO - 2018-02-13 11:35:58 --> Final output sent to browser
DEBUG - 2018-02-13 11:35:58 --> Total execution time: 0.1267
INFO - 2018-02-13 06:06:01 --> Config Class Initialized
INFO - 2018-02-13 06:06:01 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:01 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:01 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:01 --> URI Class Initialized
INFO - 2018-02-13 06:06:01 --> Router Class Initialized
INFO - 2018-02-13 06:06:01 --> Output Class Initialized
INFO - 2018-02-13 06:06:01 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:01 --> Input Class Initialized
INFO - 2018-02-13 06:06:01 --> Language Class Initialized
INFO - 2018-02-13 06:06:01 --> Language Class Initialized
INFO - 2018-02-13 06:06:01 --> Config Class Initialized
INFO - 2018-02-13 06:06:01 --> Loader Class Initialized
INFO - 2018-02-13 11:36:01 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:01 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:01 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:01 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:01 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:01 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:01 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:01 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:01 --> Controller Class Initialized
INFO - 2018-02-13 11:36:01 --> Model Class Initialized
INFO - 2018-02-13 11:36:01 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:01 --> Model Class Initialized
INFO - 2018-02-13 11:36:01 --> Model Class Initialized
INFO - 2018-02-13 11:36:01 --> Model Class Initialized
INFO - 2018-02-13 11:36:01 --> Model Class Initialized
INFO - 2018-02-13 11:36:01 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:01 --> Total execution time: 0.1063
INFO - 2018-02-13 06:06:03 --> Config Class Initialized
INFO - 2018-02-13 06:06:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:03 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:03 --> URI Class Initialized
INFO - 2018-02-13 06:06:03 --> Router Class Initialized
INFO - 2018-02-13 06:06:03 --> Output Class Initialized
INFO - 2018-02-13 06:06:03 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:03 --> Input Class Initialized
INFO - 2018-02-13 06:06:03 --> Language Class Initialized
INFO - 2018-02-13 06:06:03 --> Language Class Initialized
INFO - 2018-02-13 06:06:03 --> Config Class Initialized
INFO - 2018-02-13 06:06:03 --> Loader Class Initialized
INFO - 2018-02-13 11:36:03 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:03 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:03 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:03 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:03 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:03 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:03 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:03 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:03 --> Controller Class Initialized
INFO - 2018-02-13 11:36:03 --> Model Class Initialized
INFO - 2018-02-13 11:36:03 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:03 --> Model Class Initialized
INFO - 2018-02-13 11:36:03 --> Model Class Initialized
INFO - 2018-02-13 11:36:03 --> Model Class Initialized
INFO - 2018-02-13 11:36:03 --> Model Class Initialized
INFO - 2018-02-13 11:36:03 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:03 --> Total execution time: 0.0960
INFO - 2018-02-13 06:06:04 --> Config Class Initialized
INFO - 2018-02-13 06:06:04 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:04 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:04 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:04 --> URI Class Initialized
INFO - 2018-02-13 06:06:04 --> Router Class Initialized
INFO - 2018-02-13 06:06:04 --> Output Class Initialized
INFO - 2018-02-13 06:06:04 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:04 --> Input Class Initialized
INFO - 2018-02-13 06:06:04 --> Language Class Initialized
INFO - 2018-02-13 06:06:04 --> Language Class Initialized
INFO - 2018-02-13 06:06:04 --> Config Class Initialized
INFO - 2018-02-13 06:06:04 --> Loader Class Initialized
INFO - 2018-02-13 11:36:04 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:04 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:04 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:04 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:04 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:04 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:04 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:04 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:04 --> Controller Class Initialized
INFO - 2018-02-13 11:36:04 --> Model Class Initialized
INFO - 2018-02-13 11:36:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:04 --> Model Class Initialized
INFO - 2018-02-13 11:36:04 --> Model Class Initialized
INFO - 2018-02-13 11:36:04 --> Model Class Initialized
INFO - 2018-02-13 11:36:04 --> Model Class Initialized
INFO - 2018-02-13 11:36:04 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:04 --> Total execution time: 0.1062
INFO - 2018-02-13 06:06:12 --> Config Class Initialized
INFO - 2018-02-13 06:06:12 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:12 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:12 --> Config Class Initialized
INFO - 2018-02-13 06:06:12 --> Hooks Class Initialized
INFO - 2018-02-13 06:06:12 --> URI Class Initialized
DEBUG - 2018-02-13 06:06:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:12 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:12 --> Router Class Initialized
INFO - 2018-02-13 06:06:12 --> URI Class Initialized
INFO - 2018-02-13 06:06:12 --> Output Class Initialized
INFO - 2018-02-13 06:06:12 --> Router Class Initialized
INFO - 2018-02-13 06:06:12 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:12 --> Input Class Initialized
INFO - 2018-02-13 06:06:12 --> Output Class Initialized
INFO - 2018-02-13 06:06:12 --> Language Class Initialized
INFO - 2018-02-13 06:06:12 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:12 --> Input Class Initialized
INFO - 2018-02-13 06:06:12 --> Language Class Initialized
INFO - 2018-02-13 06:06:12 --> Language Class Initialized
INFO - 2018-02-13 06:06:12 --> Config Class Initialized
INFO - 2018-02-13 06:06:12 --> Loader Class Initialized
INFO - 2018-02-13 11:36:12 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:12 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:12 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:12 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:12 --> Helper loaded: users_helper
INFO - 2018-02-13 06:06:12 --> Language Class Initialized
INFO - 2018-02-13 06:06:12 --> Config Class Initialized
INFO - 2018-02-13 06:06:12 --> Loader Class Initialized
INFO - 2018-02-13 11:36:12 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:12 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:12 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:12 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:12 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:12 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:12 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:12 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:12 --> Controller Class Initialized
INFO - 2018-02-13 11:36:12 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:12 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:12 --> Total execution time: 0.0965
INFO - 2018-02-13 11:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:12 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:12 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:12 --> Controller Class Initialized
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Model Class Initialized
INFO - 2018-02-13 11:36:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:36:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-13 11:36:12 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:12 --> Total execution time: 0.1292
INFO - 2018-02-13 06:06:20 --> Config Class Initialized
INFO - 2018-02-13 06:06:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:20 --> URI Class Initialized
INFO - 2018-02-13 06:06:20 --> Router Class Initialized
INFO - 2018-02-13 06:06:20 --> Output Class Initialized
INFO - 2018-02-13 06:06:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:20 --> Input Class Initialized
INFO - 2018-02-13 06:06:20 --> Language Class Initialized
INFO - 2018-02-13 06:06:20 --> Language Class Initialized
INFO - 2018-02-13 06:06:20 --> Config Class Initialized
INFO - 2018-02-13 06:06:20 --> Loader Class Initialized
INFO - 2018-02-13 11:36:20 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:20 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:20 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:20 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:20 --> Controller Class Initialized
INFO - 2018-02-13 11:36:20 --> Model Class Initialized
INFO - 2018-02-13 11:36:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:20 --> Model Class Initialized
INFO - 2018-02-13 11:36:20 --> Model Class Initialized
INFO - 2018-02-13 11:36:20 --> Model Class Initialized
INFO - 2018-02-13 11:36:20 --> Model Class Initialized
INFO - 2018-02-13 11:36:20 --> Model Class Initialized
INFO - 2018-02-13 11:36:20 --> Model Class Initialized
INFO - 2018-02-13 11:36:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:20 --> Model Class Initialized
INFO - 2018-02-13 11:36:20 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:20 --> Total execution time: 0.1153
INFO - 2018-02-13 06:06:22 --> Config Class Initialized
INFO - 2018-02-13 06:06:22 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:22 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:22 --> URI Class Initialized
INFO - 2018-02-13 06:06:22 --> Router Class Initialized
INFO - 2018-02-13 06:06:22 --> Output Class Initialized
INFO - 2018-02-13 06:06:22 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:22 --> Input Class Initialized
INFO - 2018-02-13 06:06:22 --> Language Class Initialized
INFO - 2018-02-13 06:06:22 --> Language Class Initialized
INFO - 2018-02-13 06:06:22 --> Config Class Initialized
INFO - 2018-02-13 06:06:22 --> Loader Class Initialized
INFO - 2018-02-13 11:36:22 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:22 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:22 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:22 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:22 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:22 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:22 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:22 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:22 --> Controller Class Initialized
INFO - 2018-02-13 11:36:22 --> Model Class Initialized
INFO - 2018-02-13 11:36:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:22 --> Model Class Initialized
INFO - 2018-02-13 11:36:22 --> Model Class Initialized
INFO - 2018-02-13 11:36:22 --> Model Class Initialized
INFO - 2018-02-13 11:36:22 --> Model Class Initialized
INFO - 2018-02-13 11:36:22 --> Model Class Initialized
INFO - 2018-02-13 11:36:22 --> Model Class Initialized
INFO - 2018-02-13 11:36:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:22 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:22 --> Total execution time: 0.1163
INFO - 2018-02-13 06:06:25 --> Config Class Initialized
INFO - 2018-02-13 06:06:25 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:25 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:25 --> URI Class Initialized
INFO - 2018-02-13 06:06:25 --> Router Class Initialized
INFO - 2018-02-13 06:06:25 --> Output Class Initialized
INFO - 2018-02-13 06:06:25 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:25 --> Input Class Initialized
INFO - 2018-02-13 06:06:25 --> Language Class Initialized
INFO - 2018-02-13 06:06:25 --> Language Class Initialized
INFO - 2018-02-13 06:06:25 --> Config Class Initialized
INFO - 2018-02-13 06:06:25 --> Loader Class Initialized
INFO - 2018-02-13 11:36:25 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:25 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:25 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:25 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:25 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:25 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:25 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:25 --> Controller Class Initialized
INFO - 2018-02-13 11:36:25 --> Model Class Initialized
INFO - 2018-02-13 11:36:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:25 --> Model Class Initialized
INFO - 2018-02-13 11:36:25 --> Model Class Initialized
INFO - 2018-02-13 11:36:25 --> Model Class Initialized
INFO - 2018-02-13 11:36:25 --> Model Class Initialized
INFO - 2018-02-13 11:36:25 --> Model Class Initialized
INFO - 2018-02-13 11:36:25 --> Model Class Initialized
INFO - 2018-02-13 11:36:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:25 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:25 --> Total execution time: 0.1079
INFO - 2018-02-13 06:06:27 --> Config Class Initialized
INFO - 2018-02-13 06:06:27 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:27 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:27 --> URI Class Initialized
INFO - 2018-02-13 06:06:27 --> Router Class Initialized
INFO - 2018-02-13 06:06:27 --> Output Class Initialized
INFO - 2018-02-13 06:06:27 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:27 --> Input Class Initialized
INFO - 2018-02-13 06:06:27 --> Language Class Initialized
INFO - 2018-02-13 06:06:27 --> Language Class Initialized
INFO - 2018-02-13 06:06:27 --> Config Class Initialized
INFO - 2018-02-13 06:06:27 --> Loader Class Initialized
INFO - 2018-02-13 11:36:27 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:27 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:27 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:27 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:27 --> Controller Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:27 --> Total execution time: 0.1200
INFO - 2018-02-13 06:06:27 --> Config Class Initialized
INFO - 2018-02-13 06:06:27 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:27 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:27 --> URI Class Initialized
INFO - 2018-02-13 06:06:27 --> Router Class Initialized
INFO - 2018-02-13 06:06:27 --> Output Class Initialized
INFO - 2018-02-13 06:06:27 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:27 --> Input Class Initialized
INFO - 2018-02-13 06:06:27 --> Language Class Initialized
INFO - 2018-02-13 06:06:27 --> Language Class Initialized
INFO - 2018-02-13 06:06:27 --> Config Class Initialized
INFO - 2018-02-13 06:06:27 --> Loader Class Initialized
INFO - 2018-02-13 11:36:27 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:27 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:27 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:27 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:27 --> Controller Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Model Class Initialized
INFO - 2018-02-13 11:36:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:27 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:27 --> Total execution time: 0.1149
INFO - 2018-02-13 06:06:32 --> Config Class Initialized
INFO - 2018-02-13 06:06:32 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:32 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:32 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:32 --> URI Class Initialized
INFO - 2018-02-13 06:06:32 --> Router Class Initialized
INFO - 2018-02-13 06:06:32 --> Output Class Initialized
INFO - 2018-02-13 06:06:32 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:32 --> Input Class Initialized
INFO - 2018-02-13 06:06:32 --> Language Class Initialized
INFO - 2018-02-13 06:06:32 --> Language Class Initialized
INFO - 2018-02-13 06:06:32 --> Config Class Initialized
INFO - 2018-02-13 06:06:32 --> Loader Class Initialized
INFO - 2018-02-13 11:36:32 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:32 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:32 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:32 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:32 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:32 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:32 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:32 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:32 --> Controller Class Initialized
INFO - 2018-02-13 11:36:32 --> Model Class Initialized
INFO - 2018-02-13 11:36:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:32 --> Model Class Initialized
INFO - 2018-02-13 11:36:32 --> Model Class Initialized
INFO - 2018-02-13 11:36:32 --> Model Class Initialized
INFO - 2018-02-13 11:36:32 --> Model Class Initialized
INFO - 2018-02-13 11:36:32 --> Model Class Initialized
INFO - 2018-02-13 11:36:32 --> Model Class Initialized
INFO - 2018-02-13 11:36:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:32 --> Model Class Initialized
INFO - 2018-02-13 11:36:32 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:32 --> Total execution time: 0.0827
INFO - 2018-02-13 06:06:34 --> Config Class Initialized
INFO - 2018-02-13 06:06:34 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:34 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:34 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:34 --> URI Class Initialized
INFO - 2018-02-13 06:06:34 --> Router Class Initialized
INFO - 2018-02-13 06:06:34 --> Output Class Initialized
INFO - 2018-02-13 06:06:34 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:34 --> Input Class Initialized
INFO - 2018-02-13 06:06:34 --> Language Class Initialized
INFO - 2018-02-13 06:06:34 --> Language Class Initialized
INFO - 2018-02-13 06:06:34 --> Config Class Initialized
INFO - 2018-02-13 06:06:34 --> Loader Class Initialized
INFO - 2018-02-13 11:36:34 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:34 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:34 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:34 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:34 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:34 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:34 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:34 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:34 --> Controller Class Initialized
INFO - 2018-02-13 11:36:34 --> Model Class Initialized
INFO - 2018-02-13 11:36:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:34 --> Model Class Initialized
INFO - 2018-02-13 11:36:34 --> Model Class Initialized
INFO - 2018-02-13 11:36:34 --> Model Class Initialized
INFO - 2018-02-13 11:36:34 --> Model Class Initialized
INFO - 2018-02-13 11:36:34 --> Model Class Initialized
INFO - 2018-02-13 11:36:34 --> Model Class Initialized
INFO - 2018-02-13 11:36:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:34 --> Model Class Initialized
INFO - 2018-02-13 11:36:34 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:34 --> Total execution time: 0.1177
INFO - 2018-02-13 06:06:36 --> Config Class Initialized
INFO - 2018-02-13 06:06:36 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:36 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:36 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:36 --> URI Class Initialized
INFO - 2018-02-13 06:06:36 --> Router Class Initialized
INFO - 2018-02-13 06:06:36 --> Output Class Initialized
INFO - 2018-02-13 06:06:36 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:37 --> Input Class Initialized
INFO - 2018-02-13 06:06:37 --> Language Class Initialized
INFO - 2018-02-13 06:06:37 --> Language Class Initialized
INFO - 2018-02-13 06:06:37 --> Config Class Initialized
INFO - 2018-02-13 06:06:37 --> Loader Class Initialized
INFO - 2018-02-13 11:36:37 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:37 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:37 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:37 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:37 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:37 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:37 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:37 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:37 --> Controller Class Initialized
INFO - 2018-02-13 11:36:37 --> Model Class Initialized
INFO - 2018-02-13 11:36:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:37 --> Model Class Initialized
INFO - 2018-02-13 11:36:37 --> Model Class Initialized
INFO - 2018-02-13 11:36:37 --> Model Class Initialized
INFO - 2018-02-13 11:36:37 --> Model Class Initialized
INFO - 2018-02-13 11:36:37 --> Model Class Initialized
INFO - 2018-02-13 11:36:37 --> Model Class Initialized
INFO - 2018-02-13 11:36:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:37 --> Model Class Initialized
INFO - 2018-02-13 11:36:37 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:37 --> Total execution time: 0.0958
INFO - 2018-02-13 06:06:46 --> Config Class Initialized
INFO - 2018-02-13 06:06:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:46 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:46 --> URI Class Initialized
INFO - 2018-02-13 06:06:46 --> Router Class Initialized
INFO - 2018-02-13 06:06:46 --> Output Class Initialized
INFO - 2018-02-13 06:06:46 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:46 --> Input Class Initialized
INFO - 2018-02-13 06:06:46 --> Language Class Initialized
INFO - 2018-02-13 06:06:46 --> Language Class Initialized
INFO - 2018-02-13 06:06:46 --> Config Class Initialized
INFO - 2018-02-13 06:06:46 --> Loader Class Initialized
INFO - 2018-02-13 11:36:46 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:46 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:46 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:46 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:46 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:46 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:46 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:46 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:46 --> Controller Class Initialized
INFO - 2018-02-13 11:36:46 --> Model Class Initialized
INFO - 2018-02-13 11:36:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:46 --> Model Class Initialized
INFO - 2018-02-13 11:36:46 --> Model Class Initialized
INFO - 2018-02-13 11:36:46 --> Model Class Initialized
INFO - 2018-02-13 11:36:46 --> Model Class Initialized
INFO - 2018-02-13 11:36:46 --> Model Class Initialized
INFO - 2018-02-13 11:36:46 --> Model Class Initialized
INFO - 2018-02-13 11:36:46 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:36:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-13 11:36:46 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:46 --> Total execution time: 0.1152
INFO - 2018-02-13 06:06:51 --> Config Class Initialized
INFO - 2018-02-13 06:06:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:51 --> URI Class Initialized
INFO - 2018-02-13 06:06:51 --> Router Class Initialized
INFO - 2018-02-13 06:06:51 --> Output Class Initialized
INFO - 2018-02-13 06:06:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:51 --> Input Class Initialized
INFO - 2018-02-13 06:06:51 --> Language Class Initialized
INFO - 2018-02-13 06:06:51 --> Language Class Initialized
INFO - 2018-02-13 06:06:51 --> Config Class Initialized
INFO - 2018-02-13 06:06:51 --> Loader Class Initialized
INFO - 2018-02-13 11:36:51 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:51 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:51 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:51 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:51 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:51 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:51 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:51 --> Controller Class Initialized
INFO - 2018-02-13 11:36:51 --> Model Class Initialized
INFO - 2018-02-13 11:36:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:51 --> Model Class Initialized
INFO - 2018-02-13 11:36:51 --> Model Class Initialized
INFO - 2018-02-13 11:36:51 --> Model Class Initialized
INFO - 2018-02-13 11:36:51 --> Model Class Initialized
INFO - 2018-02-13 11:36:51 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:51 --> Total execution time: 0.1047
INFO - 2018-02-13 06:06:52 --> Config Class Initialized
INFO - 2018-02-13 06:06:52 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:52 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:52 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:52 --> URI Class Initialized
INFO - 2018-02-13 06:06:52 --> Router Class Initialized
INFO - 2018-02-13 06:06:52 --> Output Class Initialized
INFO - 2018-02-13 06:06:52 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:52 --> Input Class Initialized
INFO - 2018-02-13 06:06:52 --> Language Class Initialized
INFO - 2018-02-13 06:06:52 --> Language Class Initialized
INFO - 2018-02-13 06:06:52 --> Config Class Initialized
INFO - 2018-02-13 06:06:52 --> Loader Class Initialized
INFO - 2018-02-13 11:36:52 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:52 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:52 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:52 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:52 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:52 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:52 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:52 --> Controller Class Initialized
INFO - 2018-02-13 11:36:52 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:36:53 --> Final output sent to browser
DEBUG - 2018-02-13 11:36:53 --> Total execution time: 0.1103
INFO - 2018-02-13 06:06:53 --> Config Class Initialized
INFO - 2018-02-13 06:06:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:06:53 --> URI Class Initialized
INFO - 2018-02-13 06:06:53 --> Router Class Initialized
INFO - 2018-02-13 06:06:53 --> Output Class Initialized
INFO - 2018-02-13 06:06:53 --> Security Class Initialized
DEBUG - 2018-02-13 06:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:53 --> Input Class Initialized
INFO - 2018-02-13 06:06:53 --> Language Class Initialized
INFO - 2018-02-13 06:06:53 --> Language Class Initialized
INFO - 2018-02-13 06:06:53 --> Config Class Initialized
INFO - 2018-02-13 06:06:53 --> Loader Class Initialized
INFO - 2018-02-13 11:36:53 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:53 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:53 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:53 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:53 --> Helper loaded: users_helper
INFO - 2018-02-13 06:06:53 --> Config Class Initialized
INFO - 2018-02-13 06:06:53 --> Hooks Class Initialized
INFO - 2018-02-13 11:36:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:06:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:06:53 --> Utf8 Class Initialized
DEBUG - 2018-02-13 11:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:06:53 --> URI Class Initialized
INFO - 2018-02-13 06:06:53 --> Router Class Initialized
INFO - 2018-02-13 11:36:53 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:53 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:53 --> Controller Class Initialized
INFO - 2018-02-13 06:06:53 --> Output Class Initialized
INFO - 2018-02-13 06:06:53 --> Security Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 06:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:06:53 --> Input Class Initialized
INFO - 2018-02-13 06:06:53 --> Language Class Initialized
DEBUG - 2018-02-13 11:36:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 06:06:53 --> Language Class Initialized
INFO - 2018-02-13 06:06:53 --> Config Class Initialized
INFO - 2018-02-13 06:06:53 --> Loader Class Initialized
INFO - 2018-02-13 11:36:53 --> Helper loaded: url_helper
INFO - 2018-02-13 11:36:53 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:36:53 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:36:53 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:36:53 --> Helper loaded: users_helper
INFO - 2018-02-13 11:36:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:36:53 --> Helper loaded: form_helper
INFO - 2018-02-13 11:36:53 --> Form Validation Class Initialized
INFO - 2018-02-13 11:36:53 --> Controller Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:36:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:36:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Model Class Initialized
INFO - 2018-02-13 11:36:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 06:08:32 --> Config Class Initialized
INFO - 2018-02-13 06:08:32 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:32 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:32 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:32 --> URI Class Initialized
INFO - 2018-02-13 06:08:32 --> Router Class Initialized
INFO - 2018-02-13 06:08:32 --> Output Class Initialized
INFO - 2018-02-13 06:08:32 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:32 --> Input Class Initialized
INFO - 2018-02-13 06:08:32 --> Language Class Initialized
INFO - 2018-02-13 06:08:32 --> Config Class Initialized
INFO - 2018-02-13 06:08:32 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:32 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:32 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:32 --> URI Class Initialized
INFO - 2018-02-13 06:08:32 --> Router Class Initialized
INFO - 2018-02-13 06:08:32 --> Output Class Initialized
INFO - 2018-02-13 06:08:32 --> Security Class Initialized
INFO - 2018-02-13 06:08:32 --> Language Class Initialized
INFO - 2018-02-13 06:08:32 --> Config Class Initialized
INFO - 2018-02-13 06:08:32 --> Loader Class Initialized
DEBUG - 2018-02-13 06:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:32 --> Input Class Initialized
INFO - 2018-02-13 11:38:32 --> Helper loaded: url_helper
INFO - 2018-02-13 06:08:32 --> Language Class Initialized
INFO - 2018-02-13 11:38:32 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:32 --> Database Driver Class Initialized
INFO - 2018-02-13 06:08:32 --> Language Class Initialized
INFO - 2018-02-13 06:08:32 --> Config Class Initialized
INFO - 2018-02-13 06:08:32 --> Loader Class Initialized
DEBUG - 2018-02-13 11:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:32 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:32 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:32 --> Controller Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:38:32 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
DEBUG - 2018-02-13 11:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:32 --> Total execution time: 0.1418
INFO - 2018-02-13 11:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:32 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:32 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:32 --> Controller Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:32 --> Total execution time: 0.1562
INFO - 2018-02-13 06:08:32 --> Config Class Initialized
INFO - 2018-02-13 06:08:32 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:32 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:32 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:32 --> URI Class Initialized
INFO - 2018-02-13 06:08:32 --> Router Class Initialized
INFO - 2018-02-13 06:08:32 --> Output Class Initialized
INFO - 2018-02-13 06:08:32 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:32 --> Input Class Initialized
INFO - 2018-02-13 06:08:32 --> Language Class Initialized
INFO - 2018-02-13 06:08:32 --> Language Class Initialized
INFO - 2018-02-13 06:08:32 --> Config Class Initialized
INFO - 2018-02-13 06:08:32 --> Loader Class Initialized
INFO - 2018-02-13 11:38:32 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:32 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:32 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:32 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:32 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:32 --> Controller Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Model Class Initialized
INFO - 2018-02-13 11:38:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:32 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:32 --> Total execution time: 0.1211
INFO - 2018-02-13 06:08:34 --> Config Class Initialized
INFO - 2018-02-13 06:08:34 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:34 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:34 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:34 --> Config Class Initialized
INFO - 2018-02-13 06:08:34 --> Hooks Class Initialized
INFO - 2018-02-13 06:08:34 --> URI Class Initialized
DEBUG - 2018-02-13 06:08:34 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:34 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:34 --> URI Class Initialized
INFO - 2018-02-13 06:08:34 --> Router Class Initialized
INFO - 2018-02-13 06:08:34 --> Router Class Initialized
INFO - 2018-02-13 06:08:34 --> Output Class Initialized
INFO - 2018-02-13 06:08:34 --> Security Class Initialized
INFO - 2018-02-13 06:08:34 --> Output Class Initialized
DEBUG - 2018-02-13 06:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:34 --> Input Class Initialized
INFO - 2018-02-13 06:08:34 --> Security Class Initialized
INFO - 2018-02-13 06:08:34 --> Language Class Initialized
DEBUG - 2018-02-13 06:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:34 --> Input Class Initialized
INFO - 2018-02-13 06:08:34 --> Language Class Initialized
INFO - 2018-02-13 06:08:34 --> Language Class Initialized
INFO - 2018-02-13 06:08:34 --> Config Class Initialized
INFO - 2018-02-13 06:08:34 --> Loader Class Initialized
INFO - 2018-02-13 11:38:34 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:34 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:34 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:34 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:34 --> Helper loaded: users_helper
INFO - 2018-02-13 06:08:34 --> Language Class Initialized
INFO - 2018-02-13 06:08:34 --> Config Class Initialized
INFO - 2018-02-13 06:08:34 --> Loader Class Initialized
INFO - 2018-02-13 11:38:34 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:34 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:34 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:34 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:34 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:34 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:34 --> Database Driver Class Initialized
INFO - 2018-02-13 11:38:34 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:34 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:34 --> Controller Class Initialized
DEBUG - 2018-02-13 11:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:34 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:34 --> Total execution time: 0.1030
INFO - 2018-02-13 11:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:34 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:34 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:34 --> Controller Class Initialized
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Model Class Initialized
INFO - 2018-02-13 11:38:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:38:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-13 11:38:34 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:34 --> Total execution time: 0.1347
INFO - 2018-02-13 06:08:37 --> Config Class Initialized
INFO - 2018-02-13 06:08:37 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:37 --> URI Class Initialized
INFO - 2018-02-13 06:08:37 --> Router Class Initialized
INFO - 2018-02-13 06:08:37 --> Output Class Initialized
INFO - 2018-02-13 06:08:37 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:37 --> Input Class Initialized
INFO - 2018-02-13 06:08:37 --> Language Class Initialized
INFO - 2018-02-13 06:08:37 --> Language Class Initialized
INFO - 2018-02-13 06:08:37 --> Config Class Initialized
INFO - 2018-02-13 06:08:37 --> Loader Class Initialized
INFO - 2018-02-13 11:38:37 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:37 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:37 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:37 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:37 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:37 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:37 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:37 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:37 --> Controller Class Initialized
INFO - 2018-02-13 11:38:37 --> Model Class Initialized
INFO - 2018-02-13 11:38:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:37 --> Model Class Initialized
INFO - 2018-02-13 11:38:37 --> Model Class Initialized
INFO - 2018-02-13 11:38:37 --> Model Class Initialized
INFO - 2018-02-13 11:38:37 --> Model Class Initialized
INFO - 2018-02-13 11:38:37 --> Model Class Initialized
INFO - 2018-02-13 11:38:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:37 --> Model Class Initialized
INFO - 2018-02-13 11:38:37 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:37 --> Total execution time: 0.1146
INFO - 2018-02-13 06:08:37 --> Config Class Initialized
INFO - 2018-02-13 06:08:37 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:37 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:37 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:37 --> URI Class Initialized
INFO - 2018-02-13 06:08:37 --> Router Class Initialized
INFO - 2018-02-13 06:08:37 --> Output Class Initialized
INFO - 2018-02-13 06:08:37 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:37 --> Input Class Initialized
INFO - 2018-02-13 06:08:37 --> Language Class Initialized
INFO - 2018-02-13 06:08:37 --> Language Class Initialized
INFO - 2018-02-13 06:08:37 --> Config Class Initialized
INFO - 2018-02-13 06:08:37 --> Loader Class Initialized
INFO - 2018-02-13 11:38:37 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:37 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:37 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:37 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:37 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:38 --> Controller Class Initialized
INFO - 2018-02-13 11:38:38 --> Model Class Initialized
INFO - 2018-02-13 11:38:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:38 --> Model Class Initialized
INFO - 2018-02-13 11:38:38 --> Model Class Initialized
INFO - 2018-02-13 11:38:38 --> Model Class Initialized
INFO - 2018-02-13 11:38:38 --> Model Class Initialized
INFO - 2018-02-13 11:38:38 --> Model Class Initialized
INFO - 2018-02-13 11:38:38 --> Model Class Initialized
INFO - 2018-02-13 11:38:38 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 1413
INFO - 2018-02-13 11:38:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:38 --> Total execution time: 0.1217
INFO - 2018-02-13 06:08:42 --> Config Class Initialized
INFO - 2018-02-13 06:08:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:42 --> URI Class Initialized
INFO - 2018-02-13 06:08:42 --> Router Class Initialized
INFO - 2018-02-13 06:08:42 --> Output Class Initialized
INFO - 2018-02-13 06:08:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:42 --> Input Class Initialized
INFO - 2018-02-13 06:08:42 --> Language Class Initialized
INFO - 2018-02-13 06:08:42 --> Language Class Initialized
INFO - 2018-02-13 06:08:42 --> Config Class Initialized
INFO - 2018-02-13 06:08:42 --> Loader Class Initialized
INFO - 2018-02-13 11:38:42 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:42 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:42 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:42 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:42 --> Controller Class Initialized
INFO - 2018-02-13 11:38:42 --> Model Class Initialized
INFO - 2018-02-13 11:38:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:42 --> Model Class Initialized
INFO - 2018-02-13 11:38:42 --> Model Class Initialized
INFO - 2018-02-13 11:38:42 --> Model Class Initialized
INFO - 2018-02-13 11:38:42 --> Model Class Initialized
INFO - 2018-02-13 11:38:42 --> Model Class Initialized
INFO - 2018-02-13 11:38:42 --> Model Class Initialized
INFO - 2018-02-13 11:38:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:42 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:42 --> Total execution time: 0.1146
INFO - 2018-02-13 06:08:43 --> Config Class Initialized
INFO - 2018-02-13 06:08:43 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:43 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:43 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:43 --> URI Class Initialized
INFO - 2018-02-13 06:08:43 --> Router Class Initialized
INFO - 2018-02-13 06:08:43 --> Output Class Initialized
INFO - 2018-02-13 06:08:43 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:43 --> Input Class Initialized
INFO - 2018-02-13 06:08:43 --> Language Class Initialized
INFO - 2018-02-13 06:08:43 --> Language Class Initialized
INFO - 2018-02-13 06:08:43 --> Config Class Initialized
INFO - 2018-02-13 06:08:43 --> Loader Class Initialized
INFO - 2018-02-13 11:38:43 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:43 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:43 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:43 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:43 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:43 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:43 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:43 --> Controller Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:43 --> Total execution time: 0.0817
INFO - 2018-02-13 06:08:43 --> Config Class Initialized
INFO - 2018-02-13 06:08:43 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:43 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:43 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:43 --> URI Class Initialized
INFO - 2018-02-13 06:08:43 --> Router Class Initialized
INFO - 2018-02-13 06:08:43 --> Output Class Initialized
INFO - 2018-02-13 06:08:43 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:43 --> Input Class Initialized
INFO - 2018-02-13 06:08:43 --> Language Class Initialized
INFO - 2018-02-13 06:08:43 --> Language Class Initialized
INFO - 2018-02-13 06:08:43 --> Config Class Initialized
INFO - 2018-02-13 06:08:43 --> Loader Class Initialized
INFO - 2018-02-13 11:38:43 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:43 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:43 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:43 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:43 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:43 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:43 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:43 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:43 --> Controller Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Model Class Initialized
INFO - 2018-02-13 11:38:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:43 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:43 --> Total execution time: 0.0810
INFO - 2018-02-13 06:08:55 --> Config Class Initialized
INFO - 2018-02-13 06:08:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:55 --> URI Class Initialized
INFO - 2018-02-13 06:08:55 --> Router Class Initialized
INFO - 2018-02-13 06:08:55 --> Output Class Initialized
INFO - 2018-02-13 06:08:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:55 --> Input Class Initialized
INFO - 2018-02-13 06:08:55 --> Language Class Initialized
INFO - 2018-02-13 06:08:55 --> Language Class Initialized
INFO - 2018-02-13 06:08:55 --> Config Class Initialized
INFO - 2018-02-13 06:08:55 --> Loader Class Initialized
INFO - 2018-02-13 11:38:55 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:55 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:55 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:55 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:55 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:55 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:55 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:55 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:55 --> Controller Class Initialized
INFO - 2018-02-13 11:38:55 --> Model Class Initialized
INFO - 2018-02-13 11:38:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:55 --> Model Class Initialized
INFO - 2018-02-13 11:38:55 --> Model Class Initialized
INFO - 2018-02-13 11:38:55 --> Model Class Initialized
INFO - 2018-02-13 11:38:55 --> Model Class Initialized
INFO - 2018-02-13 11:38:55 --> Model Class Initialized
INFO - 2018-02-13 11:38:55 --> Model Class Initialized
INFO - 2018-02-13 11:38:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:55 --> Upload Class Initialized
INFO - 2018-02-13 11:38:55 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:55 --> Total execution time: 0.1277
INFO - 2018-02-13 06:08:55 --> Config Class Initialized
INFO - 2018-02-13 06:08:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:55 --> URI Class Initialized
INFO - 2018-02-13 06:08:55 --> Router Class Initialized
INFO - 2018-02-13 06:08:55 --> Output Class Initialized
INFO - 2018-02-13 06:08:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:55 --> Input Class Initialized
INFO - 2018-02-13 06:08:55 --> Language Class Initialized
INFO - 2018-02-13 06:08:56 --> Language Class Initialized
INFO - 2018-02-13 06:08:56 --> Config Class Initialized
INFO - 2018-02-13 06:08:56 --> Loader Class Initialized
INFO - 2018-02-13 11:38:56 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:56 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:56 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:56 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:56 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:56 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:56 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:56 --> Controller Class Initialized
INFO - 2018-02-13 11:38:56 --> Model Class Initialized
INFO - 2018-02-13 11:38:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:56 --> Model Class Initialized
INFO - 2018-02-13 11:38:56 --> Model Class Initialized
INFO - 2018-02-13 11:38:56 --> Model Class Initialized
INFO - 2018-02-13 11:38:56 --> Model Class Initialized
INFO - 2018-02-13 11:38:56 --> Model Class Initialized
INFO - 2018-02-13 11:38:56 --> Model Class Initialized
INFO - 2018-02-13 11:38:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:56 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:56 --> Total execution time: 0.0826
INFO - 2018-02-13 06:08:57 --> Config Class Initialized
INFO - 2018-02-13 06:08:57 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:08:57 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:08:57 --> Utf8 Class Initialized
INFO - 2018-02-13 06:08:57 --> URI Class Initialized
INFO - 2018-02-13 06:08:57 --> Router Class Initialized
INFO - 2018-02-13 06:08:57 --> Output Class Initialized
INFO - 2018-02-13 06:08:57 --> Security Class Initialized
DEBUG - 2018-02-13 06:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:08:57 --> Input Class Initialized
INFO - 2018-02-13 06:08:57 --> Language Class Initialized
INFO - 2018-02-13 06:08:57 --> Language Class Initialized
INFO - 2018-02-13 06:08:57 --> Config Class Initialized
INFO - 2018-02-13 06:08:57 --> Loader Class Initialized
INFO - 2018-02-13 11:38:57 --> Helper loaded: url_helper
INFO - 2018-02-13 11:38:57 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:38:57 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:38:57 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:38:57 --> Helper loaded: users_helper
INFO - 2018-02-13 11:38:57 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:38:57 --> Helper loaded: form_helper
INFO - 2018-02-13 11:38:57 --> Form Validation Class Initialized
INFO - 2018-02-13 11:38:57 --> Controller Class Initialized
INFO - 2018-02-13 11:38:57 --> Model Class Initialized
INFO - 2018-02-13 11:38:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:38:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:38:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:38:57 --> Model Class Initialized
INFO - 2018-02-13 11:38:57 --> Model Class Initialized
INFO - 2018-02-13 11:38:57 --> Model Class Initialized
INFO - 2018-02-13 11:38:57 --> Model Class Initialized
INFO - 2018-02-13 11:38:57 --> Model Class Initialized
INFO - 2018-02-13 11:38:57 --> Model Class Initialized
INFO - 2018-02-13 11:38:57 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:38:57 --> Final output sent to browser
DEBUG - 2018-02-13 11:38:57 --> Total execution time: 0.1166
INFO - 2018-02-13 06:09:20 --> Config Class Initialized
INFO - 2018-02-13 06:09:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:09:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:09:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:09:20 --> URI Class Initialized
INFO - 2018-02-13 06:09:20 --> Router Class Initialized
INFO - 2018-02-13 06:09:20 --> Output Class Initialized
INFO - 2018-02-13 06:09:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:09:20 --> Input Class Initialized
INFO - 2018-02-13 06:09:20 --> Language Class Initialized
INFO - 2018-02-13 06:09:20 --> Language Class Initialized
INFO - 2018-02-13 06:09:20 --> Config Class Initialized
INFO - 2018-02-13 06:09:20 --> Loader Class Initialized
INFO - 2018-02-13 11:39:20 --> Helper loaded: url_helper
INFO - 2018-02-13 11:39:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:39:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:39:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:39:20 --> Helper loaded: users_helper
INFO - 2018-02-13 11:39:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:39:20 --> Helper loaded: form_helper
INFO - 2018-02-13 11:39:20 --> Form Validation Class Initialized
INFO - 2018-02-13 11:39:20 --> Controller Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:39:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:39:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Final output sent to browser
DEBUG - 2018-02-13 11:39:20 --> Total execution time: 0.1084
INFO - 2018-02-13 06:09:20 --> Config Class Initialized
INFO - 2018-02-13 06:09:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:09:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:09:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:09:20 --> URI Class Initialized
INFO - 2018-02-13 06:09:20 --> Router Class Initialized
INFO - 2018-02-13 06:09:20 --> Output Class Initialized
INFO - 2018-02-13 06:09:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:09:20 --> Input Class Initialized
INFO - 2018-02-13 06:09:20 --> Language Class Initialized
INFO - 2018-02-13 06:09:20 --> Language Class Initialized
INFO - 2018-02-13 06:09:20 --> Config Class Initialized
INFO - 2018-02-13 06:09:20 --> Loader Class Initialized
INFO - 2018-02-13 11:39:20 --> Helper loaded: url_helper
INFO - 2018-02-13 11:39:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:39:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:39:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:39:20 --> Helper loaded: users_helper
INFO - 2018-02-13 11:39:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:39:20 --> Helper loaded: form_helper
INFO - 2018-02-13 11:39:20 --> Form Validation Class Initialized
INFO - 2018-02-13 11:39:20 --> Controller Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:39:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:39:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Model Class Initialized
INFO - 2018-02-13 11:39:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:39:20 --> Final output sent to browser
DEBUG - 2018-02-13 11:39:20 --> Total execution time: 0.0932
INFO - 2018-02-13 06:09:22 --> Config Class Initialized
INFO - 2018-02-13 06:09:22 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:09:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:09:22 --> Utf8 Class Initialized
INFO - 2018-02-13 06:09:22 --> URI Class Initialized
INFO - 2018-02-13 06:09:22 --> Router Class Initialized
INFO - 2018-02-13 06:09:22 --> Output Class Initialized
INFO - 2018-02-13 06:09:22 --> Security Class Initialized
DEBUG - 2018-02-13 06:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:09:22 --> Input Class Initialized
INFO - 2018-02-13 06:09:22 --> Language Class Initialized
INFO - 2018-02-13 06:09:22 --> Language Class Initialized
INFO - 2018-02-13 06:09:22 --> Config Class Initialized
INFO - 2018-02-13 06:09:22 --> Loader Class Initialized
INFO - 2018-02-13 11:39:22 --> Helper loaded: url_helper
INFO - 2018-02-13 11:39:22 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:39:22 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:39:22 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:39:23 --> Helper loaded: users_helper
INFO - 2018-02-13 11:39:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:39:23 --> Helper loaded: form_helper
INFO - 2018-02-13 11:39:23 --> Form Validation Class Initialized
INFO - 2018-02-13 11:39:23 --> Controller Class Initialized
INFO - 2018-02-13 11:39:23 --> Model Class Initialized
INFO - 2018-02-13 11:39:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:39:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:39:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:39:23 --> Model Class Initialized
INFO - 2018-02-13 11:39:23 --> Model Class Initialized
INFO - 2018-02-13 11:39:23 --> Model Class Initialized
INFO - 2018-02-13 11:39:23 --> Model Class Initialized
INFO - 2018-02-13 11:39:23 --> Model Class Initialized
INFO - 2018-02-13 11:39:23 --> Model Class Initialized
INFO - 2018-02-13 11:39:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:39:23 --> Final output sent to browser
DEBUG - 2018-02-13 11:39:23 --> Total execution time: 0.1108
INFO - 2018-02-13 06:10:14 --> Config Class Initialized
INFO - 2018-02-13 06:10:14 --> Config Class Initialized
INFO - 2018-02-13 06:10:14 --> Hooks Class Initialized
INFO - 2018-02-13 06:10:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:14 --> UTF-8 Support Enabled
DEBUG - 2018-02-13 06:10:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:14 --> URI Class Initialized
INFO - 2018-02-13 06:10:14 --> URI Class Initialized
INFO - 2018-02-13 06:10:14 --> Router Class Initialized
INFO - 2018-02-13 06:10:14 --> Output Class Initialized
INFO - 2018-02-13 06:10:14 --> Router Class Initialized
INFO - 2018-02-13 06:10:14 --> Security Class Initialized
INFO - 2018-02-13 06:10:14 --> Output Class Initialized
DEBUG - 2018-02-13 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:14 --> Input Class Initialized
INFO - 2018-02-13 06:10:14 --> Language Class Initialized
INFO - 2018-02-13 06:10:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:14 --> Input Class Initialized
INFO - 2018-02-13 06:10:14 --> Language Class Initialized
INFO - 2018-02-13 06:10:14 --> Language Class Initialized
INFO - 2018-02-13 06:10:14 --> Config Class Initialized
INFO - 2018-02-13 06:10:14 --> Loader Class Initialized
INFO - 2018-02-13 06:10:14 --> Language Class Initialized
INFO - 2018-02-13 06:10:14 --> Config Class Initialized
INFO - 2018-02-13 06:10:14 --> Loader Class Initialized
INFO - 2018-02-13 11:40:14 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:14 --> Database Driver Class Initialized
INFO - 2018-02-13 11:40:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 11:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:14 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:14 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:14 --> Controller Class Initialized
INFO - 2018-02-13 11:40:14 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:14 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:14 --> Controller Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-13 11:40:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:40:14 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:14 --> Total execution time: 0.1567
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:14 --> Total execution time: 0.1643
INFO - 2018-02-13 06:10:14 --> Config Class Initialized
INFO - 2018-02-13 06:10:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:14 --> URI Class Initialized
INFO - 2018-02-13 06:10:14 --> Router Class Initialized
INFO - 2018-02-13 06:10:14 --> Output Class Initialized
INFO - 2018-02-13 06:10:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:14 --> Input Class Initialized
INFO - 2018-02-13 06:10:14 --> Language Class Initialized
INFO - 2018-02-13 06:10:14 --> Language Class Initialized
INFO - 2018-02-13 06:10:14 --> Config Class Initialized
INFO - 2018-02-13 06:10:14 --> Loader Class Initialized
INFO - 2018-02-13 11:40:14 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:14 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:14 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:14 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:14 --> Controller Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Model Class Initialized
INFO - 2018-02-13 11:40:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:40:14 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:14 --> Total execution time: 0.1125
INFO - 2018-02-13 06:10:17 --> Config Class Initialized
INFO - 2018-02-13 06:10:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:17 --> URI Class Initialized
INFO - 2018-02-13 06:10:17 --> Router Class Initialized
INFO - 2018-02-13 06:10:17 --> Output Class Initialized
INFO - 2018-02-13 06:10:17 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:17 --> Input Class Initialized
INFO - 2018-02-13 06:10:17 --> Language Class Initialized
INFO - 2018-02-13 06:10:17 --> Config Class Initialized
INFO - 2018-02-13 06:10:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:17 --> Language Class Initialized
INFO - 2018-02-13 06:10:17 --> Config Class Initialized
INFO - 2018-02-13 06:10:17 --> Loader Class Initialized
INFO - 2018-02-13 06:10:17 --> URI Class Initialized
INFO - 2018-02-13 11:40:17 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:17 --> Helper loaded: users_helper
INFO - 2018-02-13 06:10:17 --> Router Class Initialized
INFO - 2018-02-13 06:10:17 --> Output Class Initialized
INFO - 2018-02-13 06:10:17 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 11:40:17 --> Database Driver Class Initialized
INFO - 2018-02-13 06:10:17 --> Input Class Initialized
INFO - 2018-02-13 06:10:17 --> Language Class Initialized
DEBUG - 2018-02-13 11:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:17 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:17 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:17 --> Controller Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 06:10:17 --> Language Class Initialized
INFO - 2018-02-13 06:10:17 --> Config Class Initialized
INFO - 2018-02-13 06:10:17 --> Loader Class Initialized
INFO - 2018-02-13 11:40:17 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:17 --> Total execution time: 0.1069
INFO - 2018-02-13 11:40:17 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:17 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:17 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:17 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:17 --> Controller Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Model Class Initialized
INFO - 2018-02-13 11:40:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:40:17 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:17 --> Total execution time: 0.1391
INFO - 2018-02-13 06:10:20 --> Config Class Initialized
INFO - 2018-02-13 06:10:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:20 --> URI Class Initialized
INFO - 2018-02-13 06:10:20 --> Router Class Initialized
INFO - 2018-02-13 06:10:20 --> Output Class Initialized
INFO - 2018-02-13 06:10:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:20 --> Input Class Initialized
INFO - 2018-02-13 06:10:20 --> Language Class Initialized
INFO - 2018-02-13 06:10:20 --> Language Class Initialized
INFO - 2018-02-13 06:10:20 --> Config Class Initialized
INFO - 2018-02-13 06:10:20 --> Loader Class Initialized
INFO - 2018-02-13 11:40:20 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:20 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:20 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:20 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:20 --> Controller Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:40:20 --> Model Class Initialized
INFO - 2018-02-13 11:40:20 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:20 --> Total execution time: 0.1142
INFO - 2018-02-13 06:10:22 --> Config Class Initialized
INFO - 2018-02-13 06:10:22 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:22 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:22 --> URI Class Initialized
INFO - 2018-02-13 06:10:22 --> Router Class Initialized
INFO - 2018-02-13 06:10:22 --> Output Class Initialized
INFO - 2018-02-13 06:10:22 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:22 --> Input Class Initialized
INFO - 2018-02-13 06:10:22 --> Language Class Initialized
INFO - 2018-02-13 06:10:22 --> Language Class Initialized
INFO - 2018-02-13 06:10:22 --> Config Class Initialized
INFO - 2018-02-13 06:10:22 --> Loader Class Initialized
INFO - 2018-02-13 11:40:22 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:22 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:22 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:22 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:22 --> Controller Class Initialized
INFO - 2018-02-13 11:40:22 --> Model Class Initialized
INFO - 2018-02-13 11:40:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:22 --> Model Class Initialized
INFO - 2018-02-13 11:40:22 --> Model Class Initialized
INFO - 2018-02-13 11:40:22 --> Model Class Initialized
INFO - 2018-02-13 11:40:22 --> Model Class Initialized
INFO - 2018-02-13 11:40:22 --> Model Class Initialized
INFO - 2018-02-13 11:40:22 --> Model Class Initialized
ERROR - 2018-02-13 11:40:22 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 79
INFO - 2018-02-13 11:40:22 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:22 --> Total execution time: 0.1023
INFO - 2018-02-13 06:10:22 --> Config Class Initialized
INFO - 2018-02-13 06:10:22 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:22 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:22 --> URI Class Initialized
INFO - 2018-02-13 06:10:22 --> Router Class Initialized
INFO - 2018-02-13 06:10:22 --> Config Class Initialized
INFO - 2018-02-13 06:10:22 --> Hooks Class Initialized
INFO - 2018-02-13 06:10:22 --> Output Class Initialized
DEBUG - 2018-02-13 06:10:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:22 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:22 --> Security Class Initialized
INFO - 2018-02-13 06:10:22 --> URI Class Initialized
DEBUG - 2018-02-13 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:22 --> Input Class Initialized
INFO - 2018-02-13 06:10:22 --> Language Class Initialized
INFO - 2018-02-13 06:10:22 --> Router Class Initialized
INFO - 2018-02-13 06:10:22 --> Output Class Initialized
INFO - 2018-02-13 06:10:22 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:22 --> Input Class Initialized
INFO - 2018-02-13 06:10:22 --> Language Class Initialized
INFO - 2018-02-13 06:10:22 --> Language Class Initialized
INFO - 2018-02-13 06:10:22 --> Config Class Initialized
INFO - 2018-02-13 06:10:22 --> Loader Class Initialized
INFO - 2018-02-13 11:40:22 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: users_helper
INFO - 2018-02-13 06:10:22 --> Language Class Initialized
INFO - 2018-02-13 06:10:22 --> Config Class Initialized
INFO - 2018-02-13 06:10:22 --> Loader Class Initialized
INFO - 2018-02-13 11:40:22 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:22 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:22 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:10:22 --> Config Class Initialized
INFO - 2018-02-13 06:10:22 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:22 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:22 --> URI Class Initialized
INFO - 2018-02-13 06:10:22 --> Router Class Initialized
INFO - 2018-02-13 11:40:22 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:22 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:22 --> Controller Class Initialized
INFO - 2018-02-13 11:40:22 --> Database Driver Class Initialized
INFO - 2018-02-13 06:10:22 --> Output Class Initialized
INFO - 2018-02-13 06:10:22 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:22 --> Input Class Initialized
INFO - 2018-02-13 06:10:22 --> Language Class Initialized
DEBUG - 2018-02-13 11:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:22 --> Model Class Initialized
INFO - 2018-02-13 11:40:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 06:10:23 --> Language Class Initialized
INFO - 2018-02-13 06:10:23 --> Config Class Initialized
INFO - 2018-02-13 06:10:23 --> Loader Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:23 --> Helper loaded: settings_helper
ERROR - 2018-02-13 11:40:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 289
INFO - 2018-02-13 11:40:23 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:23 --> Total execution time: 0.1017
INFO - 2018-02-13 11:40:23 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:23 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:23 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:23 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:23 --> Controller Class Initialized
INFO - 2018-02-13 11:40:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
ERROR - 2018-02-13 11:40:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 349
ERROR - 2018-02-13 11:40:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 389
ERROR - 2018-02-13 11:40:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 427
INFO - 2018-02-13 11:40:23 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:23 --> Total execution time: 0.1272
INFO - 2018-02-13 11:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:23 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:23 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:23 --> Controller Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 06:10:23 --> Config Class Initialized
INFO - 2018-02-13 11:40:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 06:10:23 --> Hooks Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
DEBUG - 2018-02-13 06:10:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:23 --> Utf8 Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 06:10:23 --> URI Class Initialized
ERROR - 2018-02-13 11:40:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
ERROR - 2018-02-13 11:40:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
INFO - 2018-02-13 11:40:23 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:23 --> Total execution time: 0.1060
INFO - 2018-02-13 06:10:23 --> Router Class Initialized
INFO - 2018-02-13 06:10:23 --> Output Class Initialized
INFO - 2018-02-13 06:10:23 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:23 --> Input Class Initialized
INFO - 2018-02-13 06:10:23 --> Language Class Initialized
INFO - 2018-02-13 06:10:23 --> Language Class Initialized
INFO - 2018-02-13 06:10:23 --> Config Class Initialized
INFO - 2018-02-13 06:10:23 --> Loader Class Initialized
INFO - 2018-02-13 11:40:23 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:23 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:23 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:23 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:23 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:23 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:23 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:23 --> Controller Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
INFO - 2018-02-13 11:40:23 --> Model Class Initialized
ERROR - 2018-02-13 11:40:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 147
ERROR - 2018-02-13 11:40:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 189
ERROR - 2018-02-13 11:40:23 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 227
INFO - 2018-02-13 11:40:23 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:23 --> Total execution time: 0.1120
INFO - 2018-02-13 06:10:26 --> Config Class Initialized
INFO - 2018-02-13 06:10:26 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:26 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:26 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:26 --> URI Class Initialized
INFO - 2018-02-13 06:10:26 --> Router Class Initialized
INFO - 2018-02-13 06:10:26 --> Output Class Initialized
INFO - 2018-02-13 06:10:26 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:26 --> Input Class Initialized
INFO - 2018-02-13 06:10:26 --> Language Class Initialized
INFO - 2018-02-13 06:10:26 --> Language Class Initialized
INFO - 2018-02-13 06:10:26 --> Config Class Initialized
INFO - 2018-02-13 06:10:26 --> Loader Class Initialized
INFO - 2018-02-13 11:40:26 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:26 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:26 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:26 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:26 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:26 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:26 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:26 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:26 --> Controller Class Initialized
INFO - 2018-02-13 11:40:26 --> Model Class Initialized
INFO - 2018-02-13 11:40:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:26 --> Model Class Initialized
INFO - 2018-02-13 11:40:26 --> Model Class Initialized
INFO - 2018-02-13 11:40:26 --> Model Class Initialized
INFO - 2018-02-13 11:40:26 --> Model Class Initialized
INFO - 2018-02-13 11:40:26 --> Model Class Initialized
INFO - 2018-02-13 11:40:26 --> Model Class Initialized
INFO - 2018-02-13 11:40:26 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:40:26 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:26 --> Total execution time: 0.1179
INFO - 2018-02-13 06:10:27 --> Config Class Initialized
INFO - 2018-02-13 06:10:27 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:27 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:27 --> URI Class Initialized
INFO - 2018-02-13 06:10:27 --> Router Class Initialized
INFO - 2018-02-13 06:10:27 --> Output Class Initialized
INFO - 2018-02-13 06:10:27 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:27 --> Input Class Initialized
INFO - 2018-02-13 06:10:27 --> Language Class Initialized
INFO - 2018-02-13 06:10:27 --> Language Class Initialized
INFO - 2018-02-13 06:10:27 --> Config Class Initialized
INFO - 2018-02-13 06:10:27 --> Loader Class Initialized
INFO - 2018-02-13 11:40:27 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:27 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:27 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:27 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:27 --> Controller Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:27 --> Total execution time: 0.0913
INFO - 2018-02-13 06:10:27 --> Config Class Initialized
INFO - 2018-02-13 06:10:27 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:27 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:27 --> URI Class Initialized
INFO - 2018-02-13 06:10:27 --> Router Class Initialized
INFO - 2018-02-13 06:10:27 --> Output Class Initialized
INFO - 2018-02-13 06:10:27 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:27 --> Input Class Initialized
INFO - 2018-02-13 06:10:27 --> Language Class Initialized
INFO - 2018-02-13 06:10:27 --> Language Class Initialized
INFO - 2018-02-13 06:10:27 --> Config Class Initialized
INFO - 2018-02-13 06:10:27 --> Loader Class Initialized
INFO - 2018-02-13 11:40:27 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:27 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:27 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:27 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:27 --> Controller Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Model Class Initialized
INFO - 2018-02-13 11:40:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:40:27 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:27 --> Total execution time: 0.1212
INFO - 2018-02-13 06:10:56 --> Config Class Initialized
INFO - 2018-02-13 06:10:56 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:10:56 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:10:56 --> Utf8 Class Initialized
INFO - 2018-02-13 06:10:56 --> URI Class Initialized
INFO - 2018-02-13 06:10:56 --> Router Class Initialized
INFO - 2018-02-13 06:10:56 --> Output Class Initialized
INFO - 2018-02-13 06:10:56 --> Security Class Initialized
DEBUG - 2018-02-13 06:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:10:56 --> Input Class Initialized
INFO - 2018-02-13 06:10:56 --> Language Class Initialized
INFO - 2018-02-13 06:10:56 --> Language Class Initialized
INFO - 2018-02-13 06:10:56 --> Config Class Initialized
INFO - 2018-02-13 06:10:56 --> Loader Class Initialized
INFO - 2018-02-13 11:40:56 --> Helper loaded: url_helper
INFO - 2018-02-13 11:40:56 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:40:56 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:40:56 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:40:56 --> Helper loaded: users_helper
INFO - 2018-02-13 11:40:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:40:56 --> Helper loaded: form_helper
INFO - 2018-02-13 11:40:56 --> Form Validation Class Initialized
INFO - 2018-02-13 11:40:56 --> Controller Class Initialized
INFO - 2018-02-13 11:40:56 --> Model Class Initialized
INFO - 2018-02-13 11:40:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:40:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:40:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:40:56 --> Model Class Initialized
INFO - 2018-02-13 11:40:56 --> Model Class Initialized
INFO - 2018-02-13 11:40:56 --> Model Class Initialized
INFO - 2018-02-13 11:40:56 --> Model Class Initialized
INFO - 2018-02-13 11:40:56 --> Model Class Initialized
INFO - 2018-02-13 11:40:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:40:56 --> Final output sent to browser
DEBUG - 2018-02-13 11:40:56 --> Total execution time: 0.0880
INFO - 2018-02-13 06:11:00 --> Config Class Initialized
INFO - 2018-02-13 06:11:00 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:00 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:00 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:00 --> URI Class Initialized
INFO - 2018-02-13 06:11:00 --> Router Class Initialized
INFO - 2018-02-13 06:11:00 --> Output Class Initialized
INFO - 2018-02-13 06:11:00 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:00 --> Input Class Initialized
INFO - 2018-02-13 06:11:00 --> Language Class Initialized
INFO - 2018-02-13 06:11:00 --> Language Class Initialized
INFO - 2018-02-13 06:11:00 --> Config Class Initialized
INFO - 2018-02-13 06:11:00 --> Loader Class Initialized
INFO - 2018-02-13 11:41:00 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:00 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:00 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:00 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:00 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:00 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:00 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:00 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:00 --> Controller Class Initialized
INFO - 2018-02-13 11:41:00 --> Model Class Initialized
INFO - 2018-02-13 11:41:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:00 --> Model Class Initialized
INFO - 2018-02-13 11:41:00 --> Model Class Initialized
INFO - 2018-02-13 11:41:00 --> Model Class Initialized
INFO - 2018-02-13 11:41:00 --> Model Class Initialized
INFO - 2018-02-13 11:41:00 --> Model Class Initialized
INFO - 2018-02-13 11:41:00 --> Model Class Initialized
INFO - 2018-02-13 11:41:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:00 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:00 --> Total execution time: 0.1002
INFO - 2018-02-13 06:11:02 --> Config Class Initialized
INFO - 2018-02-13 06:11:02 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:02 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:02 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:02 --> URI Class Initialized
INFO - 2018-02-13 06:11:02 --> Router Class Initialized
INFO - 2018-02-13 06:11:02 --> Output Class Initialized
INFO - 2018-02-13 06:11:02 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:02 --> Input Class Initialized
INFO - 2018-02-13 06:11:02 --> Language Class Initialized
INFO - 2018-02-13 06:11:02 --> Language Class Initialized
INFO - 2018-02-13 06:11:02 --> Config Class Initialized
INFO - 2018-02-13 06:11:02 --> Loader Class Initialized
INFO - 2018-02-13 11:41:02 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:02 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:02 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:02 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:02 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:02 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:02 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:02 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:02 --> Controller Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:02 --> Model Class Initialized
INFO - 2018-02-13 11:41:03 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:03 --> Total execution time: 0.1345
INFO - 2018-02-13 06:11:10 --> Config Class Initialized
INFO - 2018-02-13 06:11:10 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:10 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:10 --> URI Class Initialized
INFO - 2018-02-13 06:11:10 --> Router Class Initialized
INFO - 2018-02-13 06:11:10 --> Output Class Initialized
INFO - 2018-02-13 06:11:10 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:10 --> Input Class Initialized
INFO - 2018-02-13 06:11:10 --> Language Class Initialized
INFO - 2018-02-13 06:11:10 --> Language Class Initialized
INFO - 2018-02-13 06:11:10 --> Config Class Initialized
INFO - 2018-02-13 06:11:10 --> Loader Class Initialized
INFO - 2018-02-13 11:41:10 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:10 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:10 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:10 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:10 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:10 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:10 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:10 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:10 --> Controller Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:10 --> Model Class Initialized
INFO - 2018-02-13 11:41:10 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:10 --> Total execution time: 0.1282
INFO - 2018-02-13 06:11:18 --> Config Class Initialized
INFO - 2018-02-13 06:11:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:18 --> URI Class Initialized
INFO - 2018-02-13 06:11:18 --> Router Class Initialized
INFO - 2018-02-13 06:11:18 --> Output Class Initialized
INFO - 2018-02-13 06:11:18 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:18 --> Input Class Initialized
INFO - 2018-02-13 06:11:18 --> Language Class Initialized
INFO - 2018-02-13 06:11:18 --> Language Class Initialized
INFO - 2018-02-13 06:11:18 --> Config Class Initialized
INFO - 2018-02-13 06:11:18 --> Loader Class Initialized
INFO - 2018-02-13 11:41:18 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:18 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:18 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:18 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:18 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:18 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:18 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:18 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:18 --> Controller Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Model Class Initialized
INFO - 2018-02-13 11:41:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:18 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:18 --> Total execution time: 0.1336
INFO - 2018-02-13 06:11:25 --> Config Class Initialized
INFO - 2018-02-13 06:11:25 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:25 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:25 --> URI Class Initialized
INFO - 2018-02-13 06:11:25 --> Router Class Initialized
INFO - 2018-02-13 06:11:25 --> Output Class Initialized
INFO - 2018-02-13 06:11:25 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:25 --> Input Class Initialized
INFO - 2018-02-13 06:11:25 --> Language Class Initialized
INFO - 2018-02-13 06:11:25 --> Language Class Initialized
INFO - 2018-02-13 06:11:25 --> Config Class Initialized
INFO - 2018-02-13 06:11:25 --> Loader Class Initialized
INFO - 2018-02-13 11:41:25 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:25 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:25 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:25 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:25 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:25 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:25 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:25 --> Controller Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Model Class Initialized
INFO - 2018-02-13 11:41:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:25 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:25 --> Total execution time: 0.1334
INFO - 2018-02-13 06:11:30 --> Config Class Initialized
INFO - 2018-02-13 06:11:30 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:30 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:30 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:30 --> URI Class Initialized
INFO - 2018-02-13 06:11:30 --> Router Class Initialized
INFO - 2018-02-13 06:11:30 --> Output Class Initialized
INFO - 2018-02-13 06:11:30 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:30 --> Input Class Initialized
INFO - 2018-02-13 06:11:30 --> Language Class Initialized
INFO - 2018-02-13 06:11:31 --> Language Class Initialized
INFO - 2018-02-13 06:11:31 --> Config Class Initialized
INFO - 2018-02-13 06:11:31 --> Loader Class Initialized
INFO - 2018-02-13 11:41:31 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:31 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:31 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:31 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:31 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:31 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:31 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:31 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:31 --> Controller Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Model Class Initialized
INFO - 2018-02-13 11:41:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:31 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:31 --> Total execution time: 0.1169
INFO - 2018-02-13 06:11:42 --> Config Class Initialized
INFO - 2018-02-13 06:11:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:42 --> URI Class Initialized
INFO - 2018-02-13 06:11:42 --> Router Class Initialized
INFO - 2018-02-13 06:11:42 --> Output Class Initialized
INFO - 2018-02-13 06:11:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:42 --> Input Class Initialized
INFO - 2018-02-13 06:11:42 --> Language Class Initialized
INFO - 2018-02-13 06:11:42 --> Language Class Initialized
INFO - 2018-02-13 06:11:42 --> Config Class Initialized
INFO - 2018-02-13 06:11:42 --> Loader Class Initialized
INFO - 2018-02-13 11:41:42 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:42 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:43 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:43 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:43 --> Controller Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:43 --> Model Class Initialized
INFO - 2018-02-13 11:41:43 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:43 --> Total execution time: 0.1501
INFO - 2018-02-13 06:11:48 --> Config Class Initialized
INFO - 2018-02-13 06:11:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:48 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:48 --> URI Class Initialized
INFO - 2018-02-13 06:11:48 --> Router Class Initialized
INFO - 2018-02-13 06:11:48 --> Output Class Initialized
INFO - 2018-02-13 06:11:48 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:48 --> Input Class Initialized
INFO - 2018-02-13 06:11:48 --> Language Class Initialized
INFO - 2018-02-13 06:11:48 --> Language Class Initialized
INFO - 2018-02-13 06:11:48 --> Config Class Initialized
INFO - 2018-02-13 06:11:48 --> Loader Class Initialized
INFO - 2018-02-13 11:41:48 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:48 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:48 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:48 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:48 --> Controller Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:48 --> Model Class Initialized
INFO - 2018-02-13 11:41:48 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:48 --> Total execution time: 0.1343
INFO - 2018-02-13 06:11:53 --> Config Class Initialized
INFO - 2018-02-13 06:11:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:53 --> URI Class Initialized
INFO - 2018-02-13 06:11:53 --> Router Class Initialized
INFO - 2018-02-13 06:11:53 --> Output Class Initialized
INFO - 2018-02-13 06:11:53 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:54 --> Input Class Initialized
INFO - 2018-02-13 06:11:54 --> Language Class Initialized
INFO - 2018-02-13 06:11:54 --> Config Class Initialized
INFO - 2018-02-13 06:11:54 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:54 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:54 --> URI Class Initialized
INFO - 2018-02-13 06:11:54 --> Router Class Initialized
INFO - 2018-02-13 06:11:54 --> Output Class Initialized
INFO - 2018-02-13 06:11:54 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:54 --> Input Class Initialized
INFO - 2018-02-13 06:11:54 --> Language Class Initialized
INFO - 2018-02-13 06:11:54 --> Language Class Initialized
INFO - 2018-02-13 06:11:54 --> Config Class Initialized
INFO - 2018-02-13 06:11:54 --> Loader Class Initialized
INFO - 2018-02-13 11:41:54 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: users_helper
INFO - 2018-02-13 06:11:54 --> Language Class Initialized
INFO - 2018-02-13 06:11:54 --> Config Class Initialized
INFO - 2018-02-13 06:11:54 --> Loader Class Initialized
INFO - 2018-02-13 11:41:54 --> Database Driver Class Initialized
INFO - 2018-02-13 11:41:54 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: users_helper
DEBUG - 2018-02-13 11:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:54 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:54 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:54 --> Controller Class Initialized
INFO - 2018-02-13 11:41:54 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:54 --> Total execution time: 0.1422
INFO - 2018-02-13 11:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:54 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:54 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:54 --> Controller Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:54 --> Total execution time: 0.1571
INFO - 2018-02-13 06:11:54 --> Config Class Initialized
INFO - 2018-02-13 06:11:54 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:54 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:54 --> URI Class Initialized
INFO - 2018-02-13 06:11:54 --> Router Class Initialized
INFO - 2018-02-13 06:11:54 --> Output Class Initialized
INFO - 2018-02-13 06:11:54 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:54 --> Input Class Initialized
INFO - 2018-02-13 06:11:54 --> Language Class Initialized
INFO - 2018-02-13 06:11:54 --> Language Class Initialized
INFO - 2018-02-13 06:11:54 --> Config Class Initialized
INFO - 2018-02-13 06:11:54 --> Loader Class Initialized
INFO - 2018-02-13 11:41:54 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:54 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:54 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:54 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:54 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:54 --> Controller Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Model Class Initialized
INFO - 2018-02-13 11:41:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:54 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:54 --> Total execution time: 0.1034
INFO - 2018-02-13 06:11:55 --> Config Class Initialized
INFO - 2018-02-13 06:11:55 --> Hooks Class Initialized
INFO - 2018-02-13 06:11:55 --> Config Class Initialized
INFO - 2018-02-13 06:11:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:55 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:11:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:55 --> URI Class Initialized
INFO - 2018-02-13 06:11:55 --> URI Class Initialized
INFO - 2018-02-13 06:11:55 --> Router Class Initialized
INFO - 2018-02-13 06:11:55 --> Router Class Initialized
INFO - 2018-02-13 06:11:55 --> Output Class Initialized
INFO - 2018-02-13 06:11:55 --> Output Class Initialized
INFO - 2018-02-13 06:11:55 --> Security Class Initialized
INFO - 2018-02-13 06:11:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:55 --> Input Class Initialized
INFO - 2018-02-13 06:11:55 --> Language Class Initialized
DEBUG - 2018-02-13 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:55 --> Input Class Initialized
INFO - 2018-02-13 06:11:55 --> Language Class Initialized
INFO - 2018-02-13 06:11:55 --> Language Class Initialized
INFO - 2018-02-13 06:11:55 --> Config Class Initialized
INFO - 2018-02-13 06:11:55 --> Loader Class Initialized
INFO - 2018-02-13 11:41:55 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:55 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:55 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:55 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:55 --> Helper loaded: users_helper
INFO - 2018-02-13 06:11:55 --> Language Class Initialized
INFO - 2018-02-13 06:11:55 --> Config Class Initialized
INFO - 2018-02-13 06:11:55 --> Loader Class Initialized
INFO - 2018-02-13 11:41:56 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:56 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:56 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:56 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:56 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:56 --> Database Driver Class Initialized
INFO - 2018-02-13 11:41:56 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:56 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:56 --> Controller Class Initialized
DEBUG - 2018-02-13 11:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:56 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:56 --> Total execution time: 0.1005
INFO - 2018-02-13 11:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:56 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:56 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:56 --> Controller Class Initialized
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Model Class Initialized
INFO - 2018-02-13 11:41:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:56 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:56 --> Total execution time: 0.1998
INFO - 2018-02-13 06:11:59 --> Config Class Initialized
INFO - 2018-02-13 06:11:59 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:11:59 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:11:59 --> Utf8 Class Initialized
INFO - 2018-02-13 06:11:59 --> URI Class Initialized
INFO - 2018-02-13 06:11:59 --> Router Class Initialized
INFO - 2018-02-13 06:11:59 --> Output Class Initialized
INFO - 2018-02-13 06:11:59 --> Security Class Initialized
DEBUG - 2018-02-13 06:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:11:59 --> Input Class Initialized
INFO - 2018-02-13 06:11:59 --> Language Class Initialized
INFO - 2018-02-13 06:11:59 --> Language Class Initialized
INFO - 2018-02-13 06:11:59 --> Config Class Initialized
INFO - 2018-02-13 06:11:59 --> Loader Class Initialized
INFO - 2018-02-13 11:41:59 --> Helper loaded: url_helper
INFO - 2018-02-13 11:41:59 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:41:59 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:41:59 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:41:59 --> Helper loaded: users_helper
INFO - 2018-02-13 11:41:59 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:41:59 --> Helper loaded: form_helper
INFO - 2018-02-13 11:41:59 --> Form Validation Class Initialized
INFO - 2018-02-13 11:41:59 --> Controller Class Initialized
INFO - 2018-02-13 11:41:59 --> Model Class Initialized
INFO - 2018-02-13 11:41:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:41:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:41:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:41:59 --> Model Class Initialized
INFO - 2018-02-13 11:41:59 --> Model Class Initialized
INFO - 2018-02-13 11:41:59 --> Model Class Initialized
INFO - 2018-02-13 11:41:59 --> Model Class Initialized
INFO - 2018-02-13 11:41:59 --> Model Class Initialized
INFO - 2018-02-13 11:41:59 --> Model Class Initialized
INFO - 2018-02-13 11:41:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:41:59 --> Final output sent to browser
DEBUG - 2018-02-13 11:41:59 --> Total execution time: 0.1024
INFO - 2018-02-13 06:12:00 --> Config Class Initialized
INFO - 2018-02-13 06:12:00 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:12:00 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:12:00 --> Utf8 Class Initialized
INFO - 2018-02-13 06:12:00 --> URI Class Initialized
INFO - 2018-02-13 06:12:00 --> Router Class Initialized
INFO - 2018-02-13 06:12:00 --> Output Class Initialized
INFO - 2018-02-13 06:12:00 --> Security Class Initialized
DEBUG - 2018-02-13 06:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:12:00 --> Input Class Initialized
INFO - 2018-02-13 06:12:00 --> Language Class Initialized
INFO - 2018-02-13 06:12:00 --> Language Class Initialized
INFO - 2018-02-13 06:12:00 --> Config Class Initialized
INFO - 2018-02-13 06:12:00 --> Loader Class Initialized
INFO - 2018-02-13 11:42:00 --> Helper loaded: url_helper
INFO - 2018-02-13 11:42:00 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:42:00 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:42:00 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:42:00 --> Helper loaded: users_helper
INFO - 2018-02-13 11:42:00 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:42:00 --> Helper loaded: form_helper
INFO - 2018-02-13 11:42:00 --> Form Validation Class Initialized
INFO - 2018-02-13 11:42:00 --> Controller Class Initialized
INFO - 2018-02-13 11:42:00 --> Model Class Initialized
INFO - 2018-02-13 11:42:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:42:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:42:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:42:00 --> Model Class Initialized
INFO - 2018-02-13 11:42:00 --> Model Class Initialized
INFO - 2018-02-13 11:42:00 --> Model Class Initialized
INFO - 2018-02-13 11:42:00 --> Model Class Initialized
INFO - 2018-02-13 11:42:00 --> Model Class Initialized
INFO - 2018-02-13 11:42:00 --> Model Class Initialized
INFO - 2018-02-13 11:42:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:42:00 --> Final output sent to browser
DEBUG - 2018-02-13 11:42:00 --> Total execution time: 0.0897
INFO - 2018-02-13 06:12:03 --> Config Class Initialized
INFO - 2018-02-13 06:12:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:12:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:12:03 --> Utf8 Class Initialized
INFO - 2018-02-13 06:12:03 --> URI Class Initialized
INFO - 2018-02-13 06:12:03 --> Router Class Initialized
INFO - 2018-02-13 06:12:03 --> Output Class Initialized
INFO - 2018-02-13 06:12:03 --> Security Class Initialized
DEBUG - 2018-02-13 06:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:12:03 --> Input Class Initialized
INFO - 2018-02-13 06:12:03 --> Language Class Initialized
INFO - 2018-02-13 06:12:03 --> Language Class Initialized
INFO - 2018-02-13 06:12:03 --> Config Class Initialized
INFO - 2018-02-13 06:12:03 --> Loader Class Initialized
INFO - 2018-02-13 11:42:03 --> Helper loaded: url_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: users_helper
INFO - 2018-02-13 11:42:03 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:42:03 --> Helper loaded: form_helper
INFO - 2018-02-13 11:42:03 --> Form Validation Class Initialized
INFO - 2018-02-13 11:42:03 --> Controller Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:42:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:42:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:42:03 --> Final output sent to browser
DEBUG - 2018-02-13 11:42:03 --> Total execution time: 0.1175
INFO - 2018-02-13 06:12:03 --> Config Class Initialized
INFO - 2018-02-13 06:12:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:12:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:12:03 --> Utf8 Class Initialized
INFO - 2018-02-13 06:12:03 --> URI Class Initialized
INFO - 2018-02-13 06:12:03 --> Router Class Initialized
INFO - 2018-02-13 06:12:03 --> Output Class Initialized
INFO - 2018-02-13 06:12:03 --> Security Class Initialized
DEBUG - 2018-02-13 06:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:12:03 --> Input Class Initialized
INFO - 2018-02-13 06:12:03 --> Language Class Initialized
INFO - 2018-02-13 06:12:03 --> Language Class Initialized
INFO - 2018-02-13 06:12:03 --> Config Class Initialized
INFO - 2018-02-13 06:12:03 --> Loader Class Initialized
INFO - 2018-02-13 11:42:03 --> Helper loaded: url_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: users_helper
INFO - 2018-02-13 06:12:03 --> Config Class Initialized
INFO - 2018-02-13 06:12:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:12:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:12:03 --> Utf8 Class Initialized
INFO - 2018-02-13 06:12:03 --> URI Class Initialized
INFO - 2018-02-13 06:12:03 --> Router Class Initialized
INFO - 2018-02-13 11:42:03 --> Database Driver Class Initialized
INFO - 2018-02-13 06:12:03 --> Output Class Initialized
INFO - 2018-02-13 06:12:03 --> Security Class Initialized
DEBUG - 2018-02-13 11:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:42:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 06:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:12:03 --> Input Class Initialized
INFO - 2018-02-13 06:12:03 --> Language Class Initialized
INFO - 2018-02-13 11:42:03 --> Helper loaded: form_helper
INFO - 2018-02-13 11:42:03 --> Form Validation Class Initialized
INFO - 2018-02-13 11:42:03 --> Controller Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:42:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:42:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 06:12:03 --> Language Class Initialized
INFO - 2018-02-13 06:12:03 --> Config Class Initialized
INFO - 2018-02-13 06:12:03 --> Loader Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Helper loaded: url_helper
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:42:03 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:42:03 --> Helper loaded: users_helper
INFO - 2018-02-13 11:42:03 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:42:03 --> Helper loaded: form_helper
INFO - 2018-02-13 11:42:03 --> Form Validation Class Initialized
INFO - 2018-02-13 11:42:03 --> Controller Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:42:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:42:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Model Class Initialized
INFO - 2018-02-13 11:42:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 06:12:08 --> Config Class Initialized
INFO - 2018-02-13 06:12:08 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:12:08 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:12:08 --> Utf8 Class Initialized
INFO - 2018-02-13 06:12:08 --> URI Class Initialized
INFO - 2018-02-13 06:12:08 --> Router Class Initialized
INFO - 2018-02-13 06:12:08 --> Output Class Initialized
INFO - 2018-02-13 06:12:08 --> Security Class Initialized
DEBUG - 2018-02-13 06:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:12:08 --> Input Class Initialized
INFO - 2018-02-13 06:12:08 --> Language Class Initialized
INFO - 2018-02-13 06:12:08 --> Language Class Initialized
INFO - 2018-02-13 06:12:08 --> Config Class Initialized
INFO - 2018-02-13 06:12:08 --> Loader Class Initialized
INFO - 2018-02-13 11:42:08 --> Helper loaded: url_helper
INFO - 2018-02-13 11:42:08 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:42:08 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:42:08 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:42:08 --> Helper loaded: users_helper
INFO - 2018-02-13 11:42:08 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:42:08 --> Helper loaded: form_helper
INFO - 2018-02-13 11:42:08 --> Form Validation Class Initialized
INFO - 2018-02-13 11:42:08 --> Controller Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:42:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:42:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:42:08 --> Model Class Initialized
INFO - 2018-02-13 11:42:08 --> Final output sent to browser
DEBUG - 2018-02-13 11:42:08 --> Total execution time: 0.1412
INFO - 2018-02-13 06:12:11 --> Config Class Initialized
INFO - 2018-02-13 06:12:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:12:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:12:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:12:11 --> URI Class Initialized
INFO - 2018-02-13 06:12:11 --> Router Class Initialized
INFO - 2018-02-13 06:12:11 --> Output Class Initialized
INFO - 2018-02-13 06:12:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:12:11 --> Input Class Initialized
INFO - 2018-02-13 06:12:11 --> Language Class Initialized
INFO - 2018-02-13 06:12:11 --> Language Class Initialized
INFO - 2018-02-13 06:12:11 --> Config Class Initialized
INFO - 2018-02-13 06:12:11 --> Loader Class Initialized
INFO - 2018-02-13 11:42:11 --> Helper loaded: url_helper
INFO - 2018-02-13 11:42:11 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:42:11 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:42:11 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:42:11 --> Helper loaded: users_helper
INFO - 2018-02-13 11:42:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:42:11 --> Helper loaded: form_helper
INFO - 2018-02-13 11:42:11 --> Form Validation Class Initialized
INFO - 2018-02-13 11:42:11 --> Controller Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:42:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:42:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:42:11 --> Model Class Initialized
INFO - 2018-02-13 11:42:11 --> Final output sent to browser
DEBUG - 2018-02-13 11:42:11 --> Total execution time: 0.1296
INFO - 2018-02-13 06:18:10 --> Config Class Initialized
INFO - 2018-02-13 06:18:10 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:18:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:18:10 --> Utf8 Class Initialized
INFO - 2018-02-13 06:18:10 --> URI Class Initialized
INFO - 2018-02-13 06:18:10 --> Router Class Initialized
INFO - 2018-02-13 06:18:10 --> Config Class Initialized
INFO - 2018-02-13 06:18:10 --> Hooks Class Initialized
INFO - 2018-02-13 06:18:10 --> Output Class Initialized
DEBUG - 2018-02-13 06:18:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:18:10 --> Utf8 Class Initialized
INFO - 2018-02-13 06:18:10 --> Security Class Initialized
INFO - 2018-02-13 06:18:10 --> URI Class Initialized
DEBUG - 2018-02-13 06:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:18:10 --> Input Class Initialized
INFO - 2018-02-13 06:18:10 --> Language Class Initialized
INFO - 2018-02-13 06:18:10 --> Router Class Initialized
INFO - 2018-02-13 06:18:10 --> Output Class Initialized
INFO - 2018-02-13 06:18:10 --> Security Class Initialized
DEBUG - 2018-02-13 06:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:18:10 --> Input Class Initialized
INFO - 2018-02-13 06:18:10 --> Language Class Initialized
INFO - 2018-02-13 06:18:10 --> Language Class Initialized
INFO - 2018-02-13 06:18:10 --> Config Class Initialized
INFO - 2018-02-13 06:18:10 --> Loader Class Initialized
INFO - 2018-02-13 11:48:10 --> Helper loaded: url_helper
INFO - 2018-02-13 11:48:10 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:48:10 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:48:10 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:48:10 --> Helper loaded: users_helper
INFO - 2018-02-13 06:18:10 --> Language Class Initialized
INFO - 2018-02-13 06:18:10 --> Config Class Initialized
INFO - 2018-02-13 06:18:10 --> Loader Class Initialized
INFO - 2018-02-13 11:48:10 --> Database Driver Class Initialized
INFO - 2018-02-13 11:48:10 --> Helper loaded: url_helper
INFO - 2018-02-13 11:48:10 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:48:10 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:48:10 --> Helper loaded: permission_helper
DEBUG - 2018-02-13 11:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:48:10 --> Helper loaded: users_helper
INFO - 2018-02-13 11:48:10 --> Helper loaded: form_helper
INFO - 2018-02-13 11:48:10 --> Form Validation Class Initialized
INFO - 2018-02-13 11:48:10 --> Controller Class Initialized
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:10 --> Helper loaded: inflector_helper
INFO - 2018-02-13 11:48:10 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:48:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:48:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
DEBUG - 2018-02-13 11:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:10 --> Final output sent to browser
DEBUG - 2018-02-13 11:48:10 --> Total execution time: 0.0877
INFO - 2018-02-13 11:48:10 --> Helper loaded: form_helper
INFO - 2018-02-13 11:48:10 --> Form Validation Class Initialized
INFO - 2018-02-13 11:48:10 --> Controller Class Initialized
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:48:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:48:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:10 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:48:11 --> Model Class Initialized
INFO - 2018-02-13 11:48:11 --> Final output sent to browser
DEBUG - 2018-02-13 11:48:11 --> Total execution time: 0.1301
INFO - 2018-02-13 06:20:18 --> Config Class Initialized
INFO - 2018-02-13 06:20:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:20:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:20:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:20:18 --> URI Class Initialized
INFO - 2018-02-13 06:20:18 --> Router Class Initialized
INFO - 2018-02-13 06:20:18 --> Output Class Initialized
INFO - 2018-02-13 06:20:18 --> Security Class Initialized
DEBUG - 2018-02-13 06:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:20:18 --> Input Class Initialized
INFO - 2018-02-13 06:20:18 --> Language Class Initialized
INFO - 2018-02-13 06:20:18 --> Language Class Initialized
INFO - 2018-02-13 06:20:18 --> Config Class Initialized
INFO - 2018-02-13 06:20:18 --> Loader Class Initialized
INFO - 2018-02-13 11:50:18 --> Helper loaded: url_helper
INFO - 2018-02-13 11:50:18 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:50:18 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:50:18 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:50:18 --> Helper loaded: users_helper
INFO - 2018-02-13 11:50:18 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:50:18 --> Helper loaded: form_helper
INFO - 2018-02-13 11:50:18 --> Form Validation Class Initialized
INFO - 2018-02-13 11:50:18 --> Controller Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:50:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:50:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Final output sent to browser
DEBUG - 2018-02-13 11:50:19 --> Total execution time: 0.1460
INFO - 2018-02-13 06:20:19 --> Config Class Initialized
INFO - 2018-02-13 06:20:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:20:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:20:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:20:19 --> URI Class Initialized
INFO - 2018-02-13 06:20:19 --> Router Class Initialized
INFO - 2018-02-13 06:20:19 --> Output Class Initialized
INFO - 2018-02-13 06:20:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:20:19 --> Input Class Initialized
INFO - 2018-02-13 06:20:19 --> Language Class Initialized
INFO - 2018-02-13 06:20:19 --> Language Class Initialized
INFO - 2018-02-13 06:20:19 --> Config Class Initialized
INFO - 2018-02-13 06:20:19 --> Loader Class Initialized
INFO - 2018-02-13 11:50:19 --> Helper loaded: url_helper
INFO - 2018-02-13 11:50:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:50:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:50:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:50:19 --> Helper loaded: users_helper
INFO - 2018-02-13 11:50:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:50:19 --> Helper loaded: form_helper
INFO - 2018-02-13 11:50:19 --> Form Validation Class Initialized
INFO - 2018-02-13 11:50:19 --> Controller Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:50:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:50:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:50:19 --> Model Class Initialized
INFO - 2018-02-13 11:50:19 --> Final output sent to browser
DEBUG - 2018-02-13 11:50:19 --> Total execution time: 0.1089
INFO - 2018-02-13 06:20:27 --> Config Class Initialized
INFO - 2018-02-13 06:20:27 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:20:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:20:27 --> Utf8 Class Initialized
INFO - 2018-02-13 06:20:27 --> URI Class Initialized
INFO - 2018-02-13 06:20:27 --> Router Class Initialized
INFO - 2018-02-13 06:20:27 --> Output Class Initialized
INFO - 2018-02-13 06:20:27 --> Security Class Initialized
DEBUG - 2018-02-13 06:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:20:27 --> Input Class Initialized
INFO - 2018-02-13 06:20:27 --> Language Class Initialized
INFO - 2018-02-13 06:20:27 --> Language Class Initialized
INFO - 2018-02-13 06:20:27 --> Config Class Initialized
INFO - 2018-02-13 06:20:27 --> Loader Class Initialized
INFO - 2018-02-13 11:50:27 --> Helper loaded: url_helper
INFO - 2018-02-13 11:50:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:50:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:50:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:50:27 --> Helper loaded: users_helper
INFO - 2018-02-13 11:50:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:50:27 --> Helper loaded: form_helper
INFO - 2018-02-13 11:50:27 --> Form Validation Class Initialized
INFO - 2018-02-13 11:50:27 --> Controller Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:50:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:50:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:50:27 --> Model Class Initialized
INFO - 2018-02-13 11:50:27 --> Final output sent to browser
DEBUG - 2018-02-13 11:50:27 --> Total execution time: 0.1182
INFO - 2018-02-13 06:20:32 --> Config Class Initialized
INFO - 2018-02-13 06:20:32 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:20:32 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:20:32 --> Utf8 Class Initialized
INFO - 2018-02-13 06:20:32 --> URI Class Initialized
INFO - 2018-02-13 06:20:32 --> Router Class Initialized
INFO - 2018-02-13 06:20:32 --> Output Class Initialized
INFO - 2018-02-13 06:20:32 --> Security Class Initialized
DEBUG - 2018-02-13 06:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:20:32 --> Input Class Initialized
INFO - 2018-02-13 06:20:32 --> Language Class Initialized
INFO - 2018-02-13 06:20:32 --> Language Class Initialized
INFO - 2018-02-13 06:20:32 --> Config Class Initialized
INFO - 2018-02-13 06:20:32 --> Loader Class Initialized
INFO - 2018-02-13 11:50:32 --> Helper loaded: url_helper
INFO - 2018-02-13 11:50:32 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:50:32 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:50:32 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:50:32 --> Helper loaded: users_helper
INFO - 2018-02-13 11:50:32 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:50:32 --> Helper loaded: form_helper
INFO - 2018-02-13 11:50:32 --> Form Validation Class Initialized
INFO - 2018-02-13 11:50:32 --> Controller Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:50:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:50:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:50:32 --> Model Class Initialized
INFO - 2018-02-13 11:50:32 --> Final output sent to browser
DEBUG - 2018-02-13 11:50:32 --> Total execution time: 0.1255
INFO - 2018-02-13 06:20:36 --> Config Class Initialized
INFO - 2018-02-13 06:20:36 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:20:36 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:20:36 --> Utf8 Class Initialized
INFO - 2018-02-13 06:20:36 --> URI Class Initialized
INFO - 2018-02-13 06:20:36 --> Router Class Initialized
INFO - 2018-02-13 06:20:36 --> Output Class Initialized
INFO - 2018-02-13 06:20:36 --> Security Class Initialized
DEBUG - 2018-02-13 06:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:20:36 --> Input Class Initialized
INFO - 2018-02-13 06:20:36 --> Language Class Initialized
INFO - 2018-02-13 06:20:36 --> Language Class Initialized
INFO - 2018-02-13 06:20:36 --> Config Class Initialized
INFO - 2018-02-13 06:20:36 --> Loader Class Initialized
INFO - 2018-02-13 11:50:36 --> Helper loaded: url_helper
INFO - 2018-02-13 11:50:36 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:50:36 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:50:36 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:50:36 --> Helper loaded: users_helper
INFO - 2018-02-13 11:50:36 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:50:36 --> Helper loaded: form_helper
INFO - 2018-02-13 11:50:36 --> Form Validation Class Initialized
INFO - 2018-02-13 11:50:36 --> Controller Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:50:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:50:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:50:36 --> Model Class Initialized
INFO - 2018-02-13 11:50:36 --> Final output sent to browser
DEBUG - 2018-02-13 11:50:36 --> Total execution time: 0.1412
INFO - 2018-02-13 06:20:39 --> Config Class Initialized
INFO - 2018-02-13 06:20:39 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:20:39 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:20:39 --> Utf8 Class Initialized
INFO - 2018-02-13 06:20:39 --> URI Class Initialized
INFO - 2018-02-13 06:20:39 --> Router Class Initialized
INFO - 2018-02-13 06:20:39 --> Output Class Initialized
INFO - 2018-02-13 06:20:39 --> Security Class Initialized
DEBUG - 2018-02-13 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:20:39 --> Input Class Initialized
INFO - 2018-02-13 06:20:39 --> Language Class Initialized
INFO - 2018-02-13 06:20:39 --> Language Class Initialized
INFO - 2018-02-13 06:20:39 --> Config Class Initialized
INFO - 2018-02-13 06:20:39 --> Loader Class Initialized
INFO - 2018-02-13 11:50:39 --> Helper loaded: url_helper
INFO - 2018-02-13 11:50:39 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:50:39 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:50:39 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:50:39 --> Helper loaded: users_helper
INFO - 2018-02-13 11:50:39 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:50:39 --> Helper loaded: form_helper
INFO - 2018-02-13 11:50:39 --> Form Validation Class Initialized
INFO - 2018-02-13 11:50:39 --> Controller Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:50:39 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:50:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Model Class Initialized
INFO - 2018-02-13 11:50:39 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:50:39 --> Final output sent to browser
DEBUG - 2018-02-13 11:50:39 --> Total execution time: 0.1387
INFO - 2018-02-13 06:20:41 --> Config Class Initialized
INFO - 2018-02-13 06:20:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:20:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:20:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:20:41 --> URI Class Initialized
INFO - 2018-02-13 06:20:41 --> Router Class Initialized
INFO - 2018-02-13 06:20:41 --> Output Class Initialized
INFO - 2018-02-13 06:20:41 --> Security Class Initialized
DEBUG - 2018-02-13 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:20:41 --> Input Class Initialized
INFO - 2018-02-13 06:20:41 --> Language Class Initialized
INFO - 2018-02-13 06:20:41 --> Language Class Initialized
INFO - 2018-02-13 06:20:41 --> Config Class Initialized
INFO - 2018-02-13 06:20:41 --> Loader Class Initialized
INFO - 2018-02-13 11:50:41 --> Helper loaded: url_helper
INFO - 2018-02-13 11:50:41 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:50:41 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:50:41 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:50:41 --> Helper loaded: users_helper
INFO - 2018-02-13 11:50:41 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:50:42 --> Helper loaded: form_helper
INFO - 2018-02-13 11:50:42 --> Form Validation Class Initialized
INFO - 2018-02-13 11:50:42 --> Controller Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:50:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:50:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Model Class Initialized
INFO - 2018-02-13 11:50:42 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:50:42 --> Final output sent to browser
DEBUG - 2018-02-13 11:50:42 --> Total execution time: 0.1222
INFO - 2018-02-13 06:20:47 --> Config Class Initialized
INFO - 2018-02-13 06:20:47 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:20:47 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:20:47 --> Utf8 Class Initialized
INFO - 2018-02-13 06:20:47 --> URI Class Initialized
INFO - 2018-02-13 06:20:47 --> Router Class Initialized
INFO - 2018-02-13 06:20:47 --> Output Class Initialized
INFO - 2018-02-13 06:20:47 --> Security Class Initialized
DEBUG - 2018-02-13 06:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:20:47 --> Input Class Initialized
INFO - 2018-02-13 06:20:47 --> Language Class Initialized
INFO - 2018-02-13 06:20:47 --> Language Class Initialized
INFO - 2018-02-13 06:20:47 --> Config Class Initialized
INFO - 2018-02-13 06:20:47 --> Loader Class Initialized
INFO - 2018-02-13 11:50:47 --> Helper loaded: url_helper
INFO - 2018-02-13 11:50:47 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:50:47 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:50:47 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:50:47 --> Helper loaded: users_helper
INFO - 2018-02-13 11:50:47 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:50:47 --> Helper loaded: form_helper
INFO - 2018-02-13 11:50:47 --> Form Validation Class Initialized
INFO - 2018-02-13 11:50:47 --> Controller Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:50:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:50:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Model Class Initialized
INFO - 2018-02-13 11:50:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:50:47 --> Final output sent to browser
DEBUG - 2018-02-13 11:50:47 --> Total execution time: 0.1142
INFO - 2018-02-13 06:20:54 --> Config Class Initialized
INFO - 2018-02-13 06:20:54 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:20:54 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:20:54 --> Utf8 Class Initialized
INFO - 2018-02-13 06:20:54 --> URI Class Initialized
INFO - 2018-02-13 06:20:54 --> Router Class Initialized
INFO - 2018-02-13 06:20:54 --> Output Class Initialized
INFO - 2018-02-13 06:20:54 --> Security Class Initialized
DEBUG - 2018-02-13 06:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:20:54 --> Input Class Initialized
INFO - 2018-02-13 06:20:54 --> Language Class Initialized
INFO - 2018-02-13 06:20:54 --> Language Class Initialized
INFO - 2018-02-13 06:20:54 --> Config Class Initialized
INFO - 2018-02-13 06:20:54 --> Loader Class Initialized
INFO - 2018-02-13 11:50:54 --> Helper loaded: url_helper
INFO - 2018-02-13 11:50:54 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:50:54 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:50:54 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:50:54 --> Helper loaded: users_helper
INFO - 2018-02-13 11:50:54 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:50:54 --> Helper loaded: form_helper
INFO - 2018-02-13 11:50:54 --> Form Validation Class Initialized
INFO - 2018-02-13 11:50:54 --> Controller Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:50:54 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:50:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:50:54 --> Model Class Initialized
INFO - 2018-02-13 11:50:54 --> Final output sent to browser
DEBUG - 2018-02-13 11:50:54 --> Total execution time: 0.0966
INFO - 2018-02-13 06:21:06 --> Config Class Initialized
INFO - 2018-02-13 06:21:06 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:21:06 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:06 --> Utf8 Class Initialized
INFO - 2018-02-13 06:21:06 --> URI Class Initialized
INFO - 2018-02-13 06:21:06 --> Router Class Initialized
INFO - 2018-02-13 06:21:06 --> Output Class Initialized
INFO - 2018-02-13 06:21:06 --> Security Class Initialized
INFO - 2018-02-13 06:21:06 --> Config Class Initialized
INFO - 2018-02-13 06:21:06 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:06 --> Input Class Initialized
INFO - 2018-02-13 06:21:06 --> Language Class Initialized
DEBUG - 2018-02-13 06:21:06 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:06 --> Utf8 Class Initialized
INFO - 2018-02-13 06:21:06 --> URI Class Initialized
INFO - 2018-02-13 06:21:06 --> Router Class Initialized
INFO - 2018-02-13 06:21:06 --> Output Class Initialized
INFO - 2018-02-13 06:21:06 --> Security Class Initialized
DEBUG - 2018-02-13 06:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:06 --> Input Class Initialized
INFO - 2018-02-13 06:21:06 --> Language Class Initialized
INFO - 2018-02-13 06:21:06 --> Language Class Initialized
INFO - 2018-02-13 06:21:06 --> Config Class Initialized
INFO - 2018-02-13 06:21:06 --> Loader Class Initialized
INFO - 2018-02-13 11:51:06 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: users_helper
INFO - 2018-02-13 06:21:06 --> Language Class Initialized
INFO - 2018-02-13 06:21:06 --> Config Class Initialized
INFO - 2018-02-13 06:21:06 --> Loader Class Initialized
INFO - 2018-02-13 11:51:06 --> Database Driver Class Initialized
INFO - 2018-02-13 11:51:06 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: users_helper
DEBUG - 2018-02-13 11:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:51:06 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:06 --> Form Validation Class Initialized
INFO - 2018-02-13 11:51:06 --> Controller Class Initialized
INFO - 2018-02-13 11:51:06 --> Database Driver Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 11:51:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:51:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:06 --> Form Validation Class Initialized
INFO - 2018-02-13 06:21:06 --> Config Class Initialized
INFO - 2018-02-13 11:51:06 --> Controller Class Initialized
INFO - 2018-02-13 06:21:06 --> Hooks Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
DEBUG - 2018-02-13 06:21:06 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:06 --> Utf8 Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 06:21:06 --> URI Class Initialized
INFO - 2018-02-13 06:21:06 --> Router Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Helper loaded: inflector_helper
INFO - 2018-02-13 06:21:06 --> Output Class Initialized
DEBUG - 2018-02-13 11:51:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 06:21:06 --> Security Class Initialized
INFO - 2018-02-13 11:51:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
DEBUG - 2018-02-13 06:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:06 --> Input Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 06:21:06 --> Language Class Initialized
INFO - 2018-02-13 11:51:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:06 --> Total execution time: 0.1122
INFO - 2018-02-13 11:51:06 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:06 --> Total execution time: 0.1396
INFO - 2018-02-13 06:21:06 --> Language Class Initialized
INFO - 2018-02-13 06:21:06 --> Config Class Initialized
INFO - 2018-02-13 06:21:06 --> Loader Class Initialized
INFO - 2018-02-13 11:51:06 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:06 --> Helper loaded: users_helper
INFO - 2018-02-13 11:51:06 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:51:06 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:06 --> Form Validation Class Initialized
INFO - 2018-02-13 11:51:06 --> Controller Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:51:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:51:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Model Class Initialized
INFO - 2018-02-13 11:51:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:51:06 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:06 --> Total execution time: 0.1159
INFO - 2018-02-13 06:21:13 --> Config Class Initialized
INFO - 2018-02-13 06:21:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:21:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:13 --> Utf8 Class Initialized
INFO - 2018-02-13 06:21:13 --> URI Class Initialized
INFO - 2018-02-13 06:21:13 --> Router Class Initialized
INFO - 2018-02-13 06:21:13 --> Output Class Initialized
INFO - 2018-02-13 06:21:13 --> Security Class Initialized
DEBUG - 2018-02-13 06:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:13 --> Input Class Initialized
INFO - 2018-02-13 06:21:13 --> Language Class Initialized
INFO - 2018-02-13 06:21:13 --> Language Class Initialized
INFO - 2018-02-13 06:21:13 --> Config Class Initialized
INFO - 2018-02-13 06:21:13 --> Loader Class Initialized
INFO - 2018-02-13 11:51:13 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:13 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:13 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:13 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:13 --> Helper loaded: users_helper
INFO - 2018-02-13 11:51:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:51:13 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:13 --> Form Validation Class Initialized
INFO - 2018-02-13 11:51:13 --> Controller Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:51:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:51:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Model Class Initialized
INFO - 2018-02-13 11:51:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:51:13 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:13 --> Total execution time: 0.1282
INFO - 2018-02-13 06:21:15 --> Config Class Initialized
INFO - 2018-02-13 06:21:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:21:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:15 --> Utf8 Class Initialized
INFO - 2018-02-13 06:21:15 --> URI Class Initialized
INFO - 2018-02-13 06:21:15 --> Router Class Initialized
INFO - 2018-02-13 06:21:15 --> Output Class Initialized
INFO - 2018-02-13 06:21:15 --> Security Class Initialized
DEBUG - 2018-02-13 06:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:15 --> Input Class Initialized
INFO - 2018-02-13 06:21:15 --> Language Class Initialized
INFO - 2018-02-13 06:21:15 --> Language Class Initialized
INFO - 2018-02-13 06:21:15 --> Config Class Initialized
INFO - 2018-02-13 06:21:15 --> Loader Class Initialized
INFO - 2018-02-13 11:51:15 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:15 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:15 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:15 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:15 --> Helper loaded: users_helper
INFO - 2018-02-13 11:51:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:51:15 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:15 --> Form Validation Class Initialized
INFO - 2018-02-13 11:51:15 --> Controller Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:51:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:51:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Model Class Initialized
INFO - 2018-02-13 11:51:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:51:15 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:15 --> Total execution time: 0.1304
INFO - 2018-02-13 06:21:20 --> Config Class Initialized
INFO - 2018-02-13 06:21:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:21:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:21:20 --> URI Class Initialized
INFO - 2018-02-13 06:21:20 --> Router Class Initialized
INFO - 2018-02-13 06:21:20 --> Output Class Initialized
INFO - 2018-02-13 06:21:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:20 --> Input Class Initialized
INFO - 2018-02-13 06:21:20 --> Language Class Initialized
INFO - 2018-02-13 06:21:20 --> Language Class Initialized
INFO - 2018-02-13 06:21:20 --> Config Class Initialized
INFO - 2018-02-13 06:21:20 --> Loader Class Initialized
INFO - 2018-02-13 11:51:20 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:20 --> Helper loaded: users_helper
INFO - 2018-02-13 11:51:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:51:20 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:20 --> Form Validation Class Initialized
INFO - 2018-02-13 11:51:20 --> Controller Class Initialized
INFO - 2018-02-13 11:51:20 --> Model Class Initialized
INFO - 2018-02-13 11:51:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:51:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:51:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:20 --> Model Class Initialized
INFO - 2018-02-13 11:51:20 --> Model Class Initialized
INFO - 2018-02-13 11:51:20 --> Model Class Initialized
INFO - 2018-02-13 11:51:20 --> Model Class Initialized
INFO - 2018-02-13 11:51:20 --> Model Class Initialized
INFO - 2018-02-13 11:51:20 --> Model Class Initialized
INFO - 2018-02-13 11:51:20 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:51:20 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:20 --> Total execution time: 0.0852
INFO - 2018-02-13 06:21:25 --> Config Class Initialized
INFO - 2018-02-13 06:21:25 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:21:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:25 --> Utf8 Class Initialized
INFO - 2018-02-13 06:21:25 --> URI Class Initialized
INFO - 2018-02-13 06:21:25 --> Router Class Initialized
INFO - 2018-02-13 06:21:25 --> Output Class Initialized
INFO - 2018-02-13 06:21:25 --> Security Class Initialized
DEBUG - 2018-02-13 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:25 --> Input Class Initialized
INFO - 2018-02-13 06:21:25 --> Language Class Initialized
INFO - 2018-02-13 06:21:25 --> Language Class Initialized
INFO - 2018-02-13 06:21:25 --> Config Class Initialized
INFO - 2018-02-13 06:21:25 --> Loader Class Initialized
INFO - 2018-02-13 11:51:25 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:25 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:25 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:25 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:25 --> Helper loaded: users_helper
INFO - 2018-02-13 11:51:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:51:25 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:25 --> Form Validation Class Initialized
INFO - 2018-02-13 11:51:25 --> Controller Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:51:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:51:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Model Class Initialized
INFO - 2018-02-13 11:51:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:51:25 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:25 --> Total execution time: 0.1261
INFO - 2018-02-13 06:21:28 --> Config Class Initialized
INFO - 2018-02-13 06:21:28 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:21:28 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:28 --> Utf8 Class Initialized
INFO - 2018-02-13 06:21:28 --> URI Class Initialized
INFO - 2018-02-13 06:21:28 --> Router Class Initialized
INFO - 2018-02-13 06:21:28 --> Output Class Initialized
INFO - 2018-02-13 06:21:28 --> Security Class Initialized
DEBUG - 2018-02-13 06:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:28 --> Input Class Initialized
INFO - 2018-02-13 06:21:28 --> Language Class Initialized
INFO - 2018-02-13 06:21:28 --> Language Class Initialized
INFO - 2018-02-13 06:21:28 --> Config Class Initialized
INFO - 2018-02-13 06:21:28 --> Loader Class Initialized
INFO - 2018-02-13 11:51:28 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:28 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:28 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:28 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:28 --> Helper loaded: users_helper
INFO - 2018-02-13 11:51:28 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:51:28 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:28 --> Form Validation Class Initialized
INFO - 2018-02-13 11:51:28 --> Controller Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:51:28 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:51:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Model Class Initialized
INFO - 2018-02-13 11:51:28 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:51:28 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:28 --> Total execution time: 0.1370
INFO - 2018-02-13 06:21:32 --> Config Class Initialized
INFO - 2018-02-13 06:21:32 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:21:32 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:32 --> Utf8 Class Initialized
INFO - 2018-02-13 06:21:32 --> URI Class Initialized
INFO - 2018-02-13 06:21:32 --> Router Class Initialized
INFO - 2018-02-13 06:21:32 --> Output Class Initialized
INFO - 2018-02-13 06:21:32 --> Security Class Initialized
DEBUG - 2018-02-13 06:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:32 --> Input Class Initialized
INFO - 2018-02-13 06:21:32 --> Language Class Initialized
INFO - 2018-02-13 06:21:32 --> Language Class Initialized
INFO - 2018-02-13 06:21:32 --> Config Class Initialized
INFO - 2018-02-13 06:21:32 --> Loader Class Initialized
INFO - 2018-02-13 11:51:32 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:32 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:32 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:32 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:32 --> Helper loaded: users_helper
INFO - 2018-02-13 11:51:32 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:51:32 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:32 --> Form Validation Class Initialized
INFO - 2018-02-13 11:51:32 --> Controller Class Initialized
INFO - 2018-02-13 11:51:32 --> Model Class Initialized
INFO - 2018-02-13 11:51:32 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:51:32 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:51:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:32 --> Model Class Initialized
INFO - 2018-02-13 11:51:32 --> Model Class Initialized
INFO - 2018-02-13 11:51:32 --> Model Class Initialized
INFO - 2018-02-13 11:51:32 --> Model Class Initialized
INFO - 2018-02-13 11:51:32 --> Model Class Initialized
INFO - 2018-02-13 11:51:32 --> Model Class Initialized
INFO - 2018-02-13 11:51:32 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:51:32 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-02-13 11:51:32 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:32 --> Total execution time: 0.1190
INFO - 2018-02-13 06:21:34 --> Config Class Initialized
INFO - 2018-02-13 06:21:34 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:21:34 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:21:34 --> Utf8 Class Initialized
INFO - 2018-02-13 06:21:34 --> URI Class Initialized
INFO - 2018-02-13 06:21:34 --> Router Class Initialized
INFO - 2018-02-13 06:21:34 --> Output Class Initialized
INFO - 2018-02-13 06:21:34 --> Security Class Initialized
DEBUG - 2018-02-13 06:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:21:34 --> Input Class Initialized
INFO - 2018-02-13 06:21:34 --> Language Class Initialized
INFO - 2018-02-13 06:21:35 --> Language Class Initialized
INFO - 2018-02-13 06:21:35 --> Config Class Initialized
INFO - 2018-02-13 06:21:35 --> Loader Class Initialized
INFO - 2018-02-13 11:51:35 --> Helper loaded: url_helper
INFO - 2018-02-13 11:51:35 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:51:35 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:51:35 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:51:35 --> Helper loaded: users_helper
INFO - 2018-02-13 11:51:35 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:51:35 --> Helper loaded: form_helper
INFO - 2018-02-13 11:51:35 --> Form Validation Class Initialized
INFO - 2018-02-13 11:51:35 --> Controller Class Initialized
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:51:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:51:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Model Class Initialized
INFO - 2018-02-13 11:51:35 --> Final output sent to browser
DEBUG - 2018-02-13 11:51:35 --> Total execution time: 0.3358
INFO - 2018-02-13 06:22:00 --> Config Class Initialized
INFO - 2018-02-13 06:22:00 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:00 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:00 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:00 --> URI Class Initialized
INFO - 2018-02-13 06:22:00 --> Router Class Initialized
INFO - 2018-02-13 06:22:00 --> Output Class Initialized
INFO - 2018-02-13 06:22:00 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:00 --> Input Class Initialized
INFO - 2018-02-13 06:22:00 --> Language Class Initialized
INFO - 2018-02-13 06:22:00 --> Language Class Initialized
INFO - 2018-02-13 06:22:00 --> Config Class Initialized
INFO - 2018-02-13 06:22:00 --> Loader Class Initialized
INFO - 2018-02-13 11:52:00 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:00 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:00 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:00 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:00 --> Controller Class Initialized
INFO - 2018-02-13 06:22:00 --> Config Class Initialized
INFO - 2018-02-13 06:22:00 --> Hooks Class Initialized
INFO - 2018-02-13 06:22:00 --> Config Class Initialized
INFO - 2018-02-13 06:22:00 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:00 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:00 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:22:00 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:00 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:00 --> URI Class Initialized
INFO - 2018-02-13 06:22:00 --> URI Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Helper loaded: inflector_helper
INFO - 2018-02-13 06:22:00 --> Router Class Initialized
INFO - 2018-02-13 06:22:00 --> Router Class Initialized
DEBUG - 2018-02-13 11:52:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 06:22:00 --> Output Class Initialized
INFO - 2018-02-13 06:22:00 --> Output Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 06:22:00 --> Security Class Initialized
INFO - 2018-02-13 06:22:00 --> Security Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-13 06:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:00 --> Input Class Initialized
DEBUG - 2018-02-13 06:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:00 --> Input Class Initialized
INFO - 2018-02-13 06:22:00 --> Language Class Initialized
INFO - 2018-02-13 06:22:00 --> Language Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:00 --> Total execution time: 0.1156
INFO - 2018-02-13 06:22:00 --> Language Class Initialized
INFO - 2018-02-13 06:22:00 --> Config Class Initialized
INFO - 2018-02-13 06:22:00 --> Loader Class Initialized
INFO - 2018-02-13 11:52:00 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: settings_helper
INFO - 2018-02-13 06:22:00 --> Language Class Initialized
INFO - 2018-02-13 06:22:00 --> Config Class Initialized
INFO - 2018-02-13 06:22:00 --> Loader Class Initialized
INFO - 2018-02-13 11:52:00 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:00 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:00 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:00 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:00 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:00 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:00 --> Controller Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:00 --> Total execution time: 0.1355
INFO - 2018-02-13 11:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:00 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:00 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:00 --> Controller Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Model Class Initialized
INFO - 2018-02-13 11:52:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:00 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:00 --> Total execution time: 0.1727
INFO - 2018-02-13 06:22:03 --> Config Class Initialized
INFO - 2018-02-13 06:22:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:03 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:03 --> URI Class Initialized
INFO - 2018-02-13 06:22:03 --> Router Class Initialized
INFO - 2018-02-13 06:22:03 --> Output Class Initialized
INFO - 2018-02-13 06:22:03 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:03 --> Input Class Initialized
INFO - 2018-02-13 06:22:03 --> Language Class Initialized
INFO - 2018-02-13 06:22:03 --> Language Class Initialized
INFO - 2018-02-13 06:22:03 --> Config Class Initialized
INFO - 2018-02-13 06:22:03 --> Loader Class Initialized
INFO - 2018-02-13 11:52:03 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:03 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:03 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:03 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:03 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:03 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:03 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:03 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:03 --> Controller Class Initialized
INFO - 2018-02-13 11:52:03 --> Model Class Initialized
INFO - 2018-02-13 11:52:03 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:03 --> Model Class Initialized
INFO - 2018-02-13 11:52:03 --> Model Class Initialized
INFO - 2018-02-13 11:52:03 --> Model Class Initialized
INFO - 2018-02-13 11:52:03 --> Model Class Initialized
INFO - 2018-02-13 11:52:03 --> Model Class Initialized
INFO - 2018-02-13 11:52:03 --> Model Class Initialized
INFO - 2018-02-13 11:52:03 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:03 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:03 --> Total execution time: 0.1013
INFO - 2018-02-13 06:22:04 --> Config Class Initialized
INFO - 2018-02-13 06:22:04 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:04 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:04 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:04 --> URI Class Initialized
INFO - 2018-02-13 06:22:04 --> Router Class Initialized
INFO - 2018-02-13 06:22:04 --> Output Class Initialized
INFO - 2018-02-13 06:22:04 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:04 --> Input Class Initialized
INFO - 2018-02-13 06:22:04 --> Language Class Initialized
INFO - 2018-02-13 06:22:04 --> Language Class Initialized
INFO - 2018-02-13 06:22:04 --> Config Class Initialized
INFO - 2018-02-13 06:22:04 --> Loader Class Initialized
INFO - 2018-02-13 11:52:04 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:04 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:04 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:04 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:04 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:04 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:04 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:04 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:04 --> Controller Class Initialized
INFO - 2018-02-13 11:52:04 --> Model Class Initialized
INFO - 2018-02-13 11:52:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:04 --> Model Class Initialized
INFO - 2018-02-13 11:52:04 --> Model Class Initialized
INFO - 2018-02-13 11:52:04 --> Model Class Initialized
INFO - 2018-02-13 11:52:04 --> Model Class Initialized
INFO - 2018-02-13 11:52:04 --> Model Class Initialized
INFO - 2018-02-13 11:52:04 --> Model Class Initialized
INFO - 2018-02-13 11:52:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:04 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:04 --> Total execution time: 0.1054
INFO - 2018-02-13 06:22:04 --> Config Class Initialized
INFO - 2018-02-13 06:22:04 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:04 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:04 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:04 --> URI Class Initialized
INFO - 2018-02-13 06:22:04 --> Router Class Initialized
INFO - 2018-02-13 06:22:04 --> Output Class Initialized
INFO - 2018-02-13 06:22:04 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:04 --> Input Class Initialized
INFO - 2018-02-13 06:22:04 --> Language Class Initialized
INFO - 2018-02-13 06:22:04 --> Language Class Initialized
INFO - 2018-02-13 06:22:04 --> Config Class Initialized
INFO - 2018-02-13 06:22:04 --> Loader Class Initialized
INFO - 2018-02-13 11:52:04 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:04 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:04 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:04 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:04 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:04 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:22:04 --> Config Class Initialized
INFO - 2018-02-13 06:22:04 --> Hooks Class Initialized
INFO - 2018-02-13 11:52:04 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:04 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:04 --> Controller Class Initialized
DEBUG - 2018-02-13 06:22:04 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:04 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:04 --> URI Class Initialized
INFO - 2018-02-13 06:22:04 --> Router Class Initialized
INFO - 2018-02-13 06:22:05 --> Output Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Helper loaded: inflector_helper
INFO - 2018-02-13 06:22:05 --> Security Class Initialized
DEBUG - 2018-02-13 11:52:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-13 06:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:05 --> Input Class Initialized
INFO - 2018-02-13 06:22:05 --> Language Class Initialized
INFO - 2018-02-13 11:52:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:05 --> Total execution time: 0.1199
INFO - 2018-02-13 06:22:05 --> Language Class Initialized
INFO - 2018-02-13 06:22:05 --> Config Class Initialized
INFO - 2018-02-13 06:22:05 --> Loader Class Initialized
INFO - 2018-02-13 11:52:05 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:05 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:05 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:05 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:05 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:05 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:05 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:05 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:05 --> Controller Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Model Class Initialized
INFO - 2018-02-13 11:52:05 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:05 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:05 --> Total execution time: 0.1136
INFO - 2018-02-13 06:22:07 --> Config Class Initialized
INFO - 2018-02-13 06:22:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:07 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:07 --> URI Class Initialized
INFO - 2018-02-13 06:22:07 --> Router Class Initialized
INFO - 2018-02-13 06:22:07 --> Output Class Initialized
INFO - 2018-02-13 06:22:07 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:07 --> Input Class Initialized
INFO - 2018-02-13 06:22:07 --> Language Class Initialized
INFO - 2018-02-13 06:22:07 --> Language Class Initialized
INFO - 2018-02-13 06:22:07 --> Config Class Initialized
INFO - 2018-02-13 06:22:07 --> Loader Class Initialized
INFO - 2018-02-13 11:52:07 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:07 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:07 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:07 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:07 --> Controller Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:07 --> Model Class Initialized
INFO - 2018-02-13 11:52:07 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:07 --> Total execution time: 0.1490
INFO - 2018-02-13 06:22:11 --> Config Class Initialized
INFO - 2018-02-13 06:22:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:11 --> URI Class Initialized
INFO - 2018-02-13 06:22:11 --> Router Class Initialized
INFO - 2018-02-13 06:22:11 --> Output Class Initialized
INFO - 2018-02-13 06:22:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:11 --> Input Class Initialized
INFO - 2018-02-13 06:22:11 --> Language Class Initialized
INFO - 2018-02-13 06:22:11 --> Config Class Initialized
INFO - 2018-02-13 06:22:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:11 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:11 --> Language Class Initialized
INFO - 2018-02-13 06:22:11 --> Config Class Initialized
INFO - 2018-02-13 06:22:11 --> Loader Class Initialized
INFO - 2018-02-13 06:22:11 --> URI Class Initialized
INFO - 2018-02-13 11:52:11 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:11 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:11 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:11 --> Helper loaded: permission_helper
INFO - 2018-02-13 06:22:11 --> Router Class Initialized
INFO - 2018-02-13 11:52:11 --> Helper loaded: users_helper
INFO - 2018-02-13 06:22:11 --> Output Class Initialized
INFO - 2018-02-13 06:22:11 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:11 --> Input Class Initialized
INFO - 2018-02-13 06:22:11 --> Language Class Initialized
INFO - 2018-02-13 11:52:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:11 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:11 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:11 --> Controller Class Initialized
INFO - 2018-02-13 06:22:11 --> Language Class Initialized
INFO - 2018-02-13 06:22:11 --> Config Class Initialized
INFO - 2018-02-13 06:22:11 --> Loader Class Initialized
INFO - 2018-02-13 11:52:11 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:11 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:11 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:11 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:11 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:11 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:11 --> Total execution time: 0.0995
INFO - 2018-02-13 11:52:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:11 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:11 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:11 --> Controller Class Initialized
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Model Class Initialized
INFO - 2018-02-13 11:52:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:11 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:11 --> Total execution time: 0.1067
INFO - 2018-02-13 06:22:17 --> Config Class Initialized
INFO - 2018-02-13 06:22:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:17 --> URI Class Initialized
INFO - 2018-02-13 06:22:17 --> Router Class Initialized
INFO - 2018-02-13 06:22:17 --> Output Class Initialized
INFO - 2018-02-13 06:22:17 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:17 --> Input Class Initialized
INFO - 2018-02-13 06:22:17 --> Language Class Initialized
INFO - 2018-02-13 06:22:17 --> Language Class Initialized
INFO - 2018-02-13 06:22:17 --> Config Class Initialized
INFO - 2018-02-13 06:22:17 --> Loader Class Initialized
INFO - 2018-02-13 11:52:17 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:17 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:17 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:17 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:17 --> Controller Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:17 --> Model Class Initialized
INFO - 2018-02-13 11:52:17 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:17 --> Total execution time: 0.1481
INFO - 2018-02-13 06:22:23 --> Config Class Initialized
INFO - 2018-02-13 06:22:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:23 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:23 --> URI Class Initialized
INFO - 2018-02-13 06:22:23 --> Router Class Initialized
INFO - 2018-02-13 06:22:23 --> Output Class Initialized
INFO - 2018-02-13 06:22:23 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:23 --> Input Class Initialized
INFO - 2018-02-13 06:22:23 --> Language Class Initialized
INFO - 2018-02-13 06:22:23 --> Language Class Initialized
INFO - 2018-02-13 06:22:23 --> Config Class Initialized
INFO - 2018-02-13 06:22:23 --> Loader Class Initialized
INFO - 2018-02-13 11:52:23 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:23 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:23 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:23 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:23 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:23 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:23 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:23 --> Controller Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:23 --> Model Class Initialized
INFO - 2018-02-13 11:52:23 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:23 --> Total execution time: 0.1614
INFO - 2018-02-13 06:22:27 --> Config Class Initialized
INFO - 2018-02-13 06:22:27 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:27 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:27 --> URI Class Initialized
INFO - 2018-02-13 06:22:27 --> Router Class Initialized
INFO - 2018-02-13 06:22:27 --> Output Class Initialized
INFO - 2018-02-13 06:22:27 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:27 --> Input Class Initialized
INFO - 2018-02-13 06:22:27 --> Language Class Initialized
INFO - 2018-02-13 06:22:27 --> Language Class Initialized
INFO - 2018-02-13 06:22:27 --> Config Class Initialized
INFO - 2018-02-13 06:22:27 --> Loader Class Initialized
INFO - 2018-02-13 11:52:27 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:27 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:27 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:27 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:27 --> Controller Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:27 --> Model Class Initialized
INFO - 2018-02-13 11:52:27 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:27 --> Total execution time: 0.1446
INFO - 2018-02-13 06:22:31 --> Config Class Initialized
INFO - 2018-02-13 06:22:31 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:31 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:31 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:31 --> URI Class Initialized
INFO - 2018-02-13 06:22:31 --> Router Class Initialized
INFO - 2018-02-13 06:22:31 --> Output Class Initialized
INFO - 2018-02-13 06:22:31 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:31 --> Input Class Initialized
INFO - 2018-02-13 06:22:31 --> Language Class Initialized
INFO - 2018-02-13 06:22:31 --> Language Class Initialized
INFO - 2018-02-13 06:22:31 --> Config Class Initialized
INFO - 2018-02-13 06:22:31 --> Loader Class Initialized
INFO - 2018-02-13 11:52:31 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:31 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:31 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:31 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:31 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:31 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:31 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:31 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:31 --> Controller Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:31 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:31 --> Model Class Initialized
INFO - 2018-02-13 11:52:31 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:31 --> Total execution time: 0.1209
INFO - 2018-02-13 06:22:38 --> Config Class Initialized
INFO - 2018-02-13 06:22:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:38 --> URI Class Initialized
INFO - 2018-02-13 06:22:38 --> Router Class Initialized
INFO - 2018-02-13 06:22:38 --> Output Class Initialized
INFO - 2018-02-13 06:22:38 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:38 --> Input Class Initialized
INFO - 2018-02-13 06:22:38 --> Language Class Initialized
INFO - 2018-02-13 06:22:38 --> Language Class Initialized
INFO - 2018-02-13 06:22:38 --> Config Class Initialized
INFO - 2018-02-13 06:22:38 --> Loader Class Initialized
INFO - 2018-02-13 11:52:38 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:38 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:38 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:38 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:38 --> Controller Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:38 --> Model Class Initialized
INFO - 2018-02-13 11:52:38 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:38 --> Total execution time: 0.1439
INFO - 2018-02-13 06:22:41 --> Config Class Initialized
INFO - 2018-02-13 06:22:41 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:41 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:41 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:41 --> URI Class Initialized
INFO - 2018-02-13 06:22:41 --> Router Class Initialized
INFO - 2018-02-13 06:22:41 --> Output Class Initialized
INFO - 2018-02-13 06:22:41 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:41 --> Input Class Initialized
INFO - 2018-02-13 06:22:41 --> Language Class Initialized
INFO - 2018-02-13 06:22:41 --> Language Class Initialized
INFO - 2018-02-13 06:22:41 --> Config Class Initialized
INFO - 2018-02-13 06:22:41 --> Loader Class Initialized
INFO - 2018-02-13 11:52:41 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:41 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:41 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:41 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:41 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:41 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:41 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:41 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:41 --> Controller Class Initialized
INFO - 2018-02-13 11:52:41 --> Model Class Initialized
INFO - 2018-02-13 11:52:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:41 --> Model Class Initialized
INFO - 2018-02-13 11:52:41 --> Model Class Initialized
INFO - 2018-02-13 11:52:41 --> Model Class Initialized
INFO - 2018-02-13 11:52:41 --> Model Class Initialized
INFO - 2018-02-13 11:52:41 --> Model Class Initialized
INFO - 2018-02-13 11:52:41 --> Model Class Initialized
INFO - 2018-02-13 11:52:41 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:52:41 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-02-13 11:52:41 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:41 --> Total execution time: 0.1211
INFO - 2018-02-13 06:22:48 --> Config Class Initialized
INFO - 2018-02-13 06:22:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:48 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:48 --> URI Class Initialized
INFO - 2018-02-13 06:22:48 --> Router Class Initialized
INFO - 2018-02-13 06:22:48 --> Output Class Initialized
INFO - 2018-02-13 06:22:48 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:48 --> Input Class Initialized
INFO - 2018-02-13 06:22:48 --> Language Class Initialized
INFO - 2018-02-13 06:22:48 --> Language Class Initialized
INFO - 2018-02-13 06:22:48 --> Config Class Initialized
INFO - 2018-02-13 06:22:48 --> Loader Class Initialized
INFO - 2018-02-13 11:52:48 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:48 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:48 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:48 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:48 --> Controller Class Initialized
INFO - 2018-02-13 11:52:48 --> Model Class Initialized
INFO - 2018-02-13 11:52:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:48 --> Model Class Initialized
INFO - 2018-02-13 11:52:48 --> Model Class Initialized
INFO - 2018-02-13 11:52:48 --> Model Class Initialized
INFO - 2018-02-13 11:52:48 --> Model Class Initialized
INFO - 2018-02-13 11:52:48 --> Model Class Initialized
INFO - 2018-02-13 11:52:48 --> Model Class Initialized
INFO - 2018-02-13 11:52:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:52:48 --> Model Class Initialized
INFO - 2018-02-13 11:52:48 --> Model Class Initialized
INFO - 2018-02-13 11:52:48 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:48 --> Total execution time: 0.1315
INFO - 2018-02-13 06:22:57 --> Config Class Initialized
INFO - 2018-02-13 06:22:57 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:57 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:57 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:57 --> URI Class Initialized
INFO - 2018-02-13 06:22:57 --> Router Class Initialized
INFO - 2018-02-13 06:22:57 --> Output Class Initialized
INFO - 2018-02-13 06:22:57 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:57 --> Input Class Initialized
INFO - 2018-02-13 06:22:57 --> Language Class Initialized
INFO - 2018-02-13 06:22:57 --> Language Class Initialized
INFO - 2018-02-13 06:22:57 --> Config Class Initialized
INFO - 2018-02-13 06:22:57 --> Loader Class Initialized
INFO - 2018-02-13 11:52:57 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:57 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:57 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:57 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:57 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:57 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:57 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:57 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:57 --> Controller Class Initialized
INFO - 2018-02-13 11:52:57 --> Model Class Initialized
INFO - 2018-02-13 11:52:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:57 --> Model Class Initialized
INFO - 2018-02-13 11:52:57 --> Model Class Initialized
INFO - 2018-02-13 11:52:57 --> Model Class Initialized
INFO - 2018-02-13 11:52:57 --> Model Class Initialized
INFO - 2018-02-13 11:52:57 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:57 --> Total execution time: 0.1118
INFO - 2018-02-13 06:22:58 --> Config Class Initialized
INFO - 2018-02-13 06:22:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:22:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:22:58 --> Utf8 Class Initialized
INFO - 2018-02-13 06:22:58 --> URI Class Initialized
INFO - 2018-02-13 06:22:58 --> Router Class Initialized
INFO - 2018-02-13 06:22:58 --> Output Class Initialized
INFO - 2018-02-13 06:22:58 --> Security Class Initialized
DEBUG - 2018-02-13 06:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:22:58 --> Input Class Initialized
INFO - 2018-02-13 06:22:58 --> Language Class Initialized
INFO - 2018-02-13 06:22:58 --> Language Class Initialized
INFO - 2018-02-13 06:22:58 --> Config Class Initialized
INFO - 2018-02-13 06:22:58 --> Loader Class Initialized
INFO - 2018-02-13 11:52:58 --> Helper loaded: url_helper
INFO - 2018-02-13 11:52:58 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:52:58 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:52:58 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:52:58 --> Helper loaded: users_helper
INFO - 2018-02-13 11:52:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:52:58 --> Helper loaded: form_helper
INFO - 2018-02-13 11:52:58 --> Form Validation Class Initialized
INFO - 2018-02-13 11:52:58 --> Controller Class Initialized
INFO - 2018-02-13 11:52:58 --> Model Class Initialized
INFO - 2018-02-13 11:52:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:52:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:52:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:52:58 --> Model Class Initialized
INFO - 2018-02-13 11:52:58 --> Model Class Initialized
INFO - 2018-02-13 11:52:58 --> Model Class Initialized
INFO - 2018-02-13 11:52:58 --> Model Class Initialized
INFO - 2018-02-13 11:52:58 --> Final output sent to browser
DEBUG - 2018-02-13 11:52:58 --> Total execution time: 0.1058
INFO - 2018-02-13 06:23:02 --> Config Class Initialized
INFO - 2018-02-13 06:23:02 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:02 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:02 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:02 --> URI Class Initialized
INFO - 2018-02-13 06:23:02 --> Router Class Initialized
INFO - 2018-02-13 06:23:02 --> Output Class Initialized
INFO - 2018-02-13 06:23:02 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:02 --> Input Class Initialized
INFO - 2018-02-13 06:23:02 --> Language Class Initialized
INFO - 2018-02-13 06:23:02 --> Language Class Initialized
INFO - 2018-02-13 06:23:02 --> Config Class Initialized
INFO - 2018-02-13 06:23:02 --> Loader Class Initialized
INFO - 2018-02-13 11:53:02 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:02 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:02 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:02 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:02 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:02 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:02 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:02 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:02 --> Controller Class Initialized
INFO - 2018-02-13 11:53:02 --> Model Class Initialized
INFO - 2018-02-13 11:53:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:02 --> Model Class Initialized
INFO - 2018-02-13 11:53:02 --> Model Class Initialized
INFO - 2018-02-13 11:53:02 --> Model Class Initialized
INFO - 2018-02-13 11:53:02 --> Model Class Initialized
INFO - 2018-02-13 11:53:02 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:02 --> Total execution time: 0.1060
INFO - 2018-02-13 06:23:03 --> Config Class Initialized
INFO - 2018-02-13 06:23:03 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:03 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:03 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:03 --> URI Class Initialized
INFO - 2018-02-13 06:23:03 --> Router Class Initialized
INFO - 2018-02-13 06:23:03 --> Output Class Initialized
INFO - 2018-02-13 06:23:03 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:03 --> Input Class Initialized
INFO - 2018-02-13 06:23:03 --> Language Class Initialized
INFO - 2018-02-13 06:23:04 --> Language Class Initialized
INFO - 2018-02-13 06:23:04 --> Config Class Initialized
INFO - 2018-02-13 06:23:04 --> Loader Class Initialized
INFO - 2018-02-13 11:53:04 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:04 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:04 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:04 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:04 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:04 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:04 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:04 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:04 --> Controller Class Initialized
INFO - 2018-02-13 11:53:04 --> Model Class Initialized
INFO - 2018-02-13 11:53:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:04 --> Model Class Initialized
INFO - 2018-02-13 11:53:04 --> Model Class Initialized
INFO - 2018-02-13 11:53:04 --> Model Class Initialized
INFO - 2018-02-13 11:53:04 --> Model Class Initialized
INFO - 2018-02-13 11:53:04 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:04 --> Total execution time: 0.1059
INFO - 2018-02-13 06:23:06 --> Config Class Initialized
INFO - 2018-02-13 06:23:06 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:06 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:06 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:06 --> URI Class Initialized
INFO - 2018-02-13 06:23:06 --> Router Class Initialized
INFO - 2018-02-13 06:23:06 --> Output Class Initialized
INFO - 2018-02-13 06:23:06 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:06 --> Input Class Initialized
INFO - 2018-02-13 06:23:06 --> Language Class Initialized
INFO - 2018-02-13 06:23:06 --> Language Class Initialized
INFO - 2018-02-13 06:23:06 --> Config Class Initialized
INFO - 2018-02-13 06:23:06 --> Loader Class Initialized
INFO - 2018-02-13 11:53:06 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:06 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:06 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:06 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:06 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:06 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:06 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:06 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:06 --> Controller Class Initialized
INFO - 2018-02-13 11:53:06 --> Model Class Initialized
INFO - 2018-02-13 11:53:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:06 --> Model Class Initialized
INFO - 2018-02-13 11:53:06 --> Model Class Initialized
INFO - 2018-02-13 11:53:06 --> Model Class Initialized
INFO - 2018-02-13 11:53:06 --> Model Class Initialized
INFO - 2018-02-13 11:53:06 --> Model Class Initialized
INFO - 2018-02-13 11:53:06 --> Model Class Initialized
INFO - 2018-02-13 11:53:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:53:06 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:06 --> Total execution time: 0.1092
INFO - 2018-02-13 06:23:07 --> Config Class Initialized
INFO - 2018-02-13 06:23:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:07 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:07 --> URI Class Initialized
INFO - 2018-02-13 06:23:07 --> Router Class Initialized
INFO - 2018-02-13 06:23:07 --> Output Class Initialized
INFO - 2018-02-13 06:23:07 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:07 --> Input Class Initialized
INFO - 2018-02-13 06:23:07 --> Language Class Initialized
INFO - 2018-02-13 06:23:07 --> Language Class Initialized
INFO - 2018-02-13 06:23:07 --> Config Class Initialized
INFO - 2018-02-13 06:23:07 --> Loader Class Initialized
INFO - 2018-02-13 11:53:07 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:07 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:07 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:07 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:07 --> Controller Class Initialized
INFO - 2018-02-13 11:53:07 --> Model Class Initialized
INFO - 2018-02-13 11:53:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:07 --> Model Class Initialized
INFO - 2018-02-13 11:53:07 --> Model Class Initialized
INFO - 2018-02-13 11:53:07 --> Model Class Initialized
INFO - 2018-02-13 11:53:07 --> Model Class Initialized
INFO - 2018-02-13 11:53:07 --> Model Class Initialized
INFO - 2018-02-13 11:53:07 --> Model Class Initialized
INFO - 2018-02-13 11:53:07 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 11:53:07 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-02-13 11:53:07 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:07 --> Total execution time: 0.1097
INFO - 2018-02-13 06:23:09 --> Config Class Initialized
INFO - 2018-02-13 06:23:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:09 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:09 --> URI Class Initialized
INFO - 2018-02-13 06:23:09 --> Router Class Initialized
INFO - 2018-02-13 06:23:09 --> Output Class Initialized
INFO - 2018-02-13 06:23:09 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:09 --> Input Class Initialized
INFO - 2018-02-13 06:23:09 --> Language Class Initialized
INFO - 2018-02-13 06:23:09 --> Language Class Initialized
INFO - 2018-02-13 06:23:09 --> Config Class Initialized
INFO - 2018-02-13 06:23:09 --> Loader Class Initialized
INFO - 2018-02-13 11:53:09 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:09 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:09 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:09 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:09 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:09 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:09 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:09 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:09 --> Controller Class Initialized
INFO - 2018-02-13 11:53:09 --> Model Class Initialized
INFO - 2018-02-13 11:53:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:09 --> Model Class Initialized
INFO - 2018-02-13 11:53:09 --> Model Class Initialized
INFO - 2018-02-13 11:53:09 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:09 --> Total execution time: 0.0800
INFO - 2018-02-13 06:23:20 --> Config Class Initialized
INFO - 2018-02-13 06:23:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:20 --> URI Class Initialized
INFO - 2018-02-13 06:23:20 --> Router Class Initialized
INFO - 2018-02-13 06:23:20 --> Output Class Initialized
INFO - 2018-02-13 06:23:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:20 --> Input Class Initialized
INFO - 2018-02-13 06:23:20 --> Language Class Initialized
INFO - 2018-02-13 06:23:20 --> Language Class Initialized
INFO - 2018-02-13 06:23:20 --> Config Class Initialized
INFO - 2018-02-13 06:23:20 --> Loader Class Initialized
INFO - 2018-02-13 11:53:20 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:20 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:20 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:20 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:20 --> Controller Class Initialized
INFO - 2018-02-13 11:53:20 --> Model Class Initialized
INFO - 2018-02-13 11:53:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:20 --> Model Class Initialized
INFO - 2018-02-13 11:53:20 --> Model Class Initialized
INFO - 2018-02-13 11:53:20 --> Model Class Initialized
INFO - 2018-02-13 11:53:20 --> Model Class Initialized
INFO - 2018-02-13 11:53:20 --> Model Class Initialized
INFO - 2018-02-13 11:53:20 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:20 --> Total execution time: 0.4162
INFO - 2018-02-13 06:23:24 --> Config Class Initialized
INFO - 2018-02-13 06:23:24 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:24 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:24 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:24 --> URI Class Initialized
INFO - 2018-02-13 06:23:24 --> Router Class Initialized
INFO - 2018-02-13 06:23:24 --> Output Class Initialized
INFO - 2018-02-13 06:23:24 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:24 --> Input Class Initialized
INFO - 2018-02-13 06:23:24 --> Language Class Initialized
INFO - 2018-02-13 06:23:24 --> Language Class Initialized
INFO - 2018-02-13 06:23:24 --> Config Class Initialized
INFO - 2018-02-13 06:23:24 --> Loader Class Initialized
INFO - 2018-02-13 11:53:24 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:24 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:24 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:24 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:24 --> Controller Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:24 --> Total execution time: 0.1115
INFO - 2018-02-13 06:23:24 --> Config Class Initialized
INFO - 2018-02-13 06:23:24 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:24 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:24 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:24 --> URI Class Initialized
INFO - 2018-02-13 06:23:24 --> Router Class Initialized
INFO - 2018-02-13 06:23:24 --> Output Class Initialized
INFO - 2018-02-13 06:23:24 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:24 --> Input Class Initialized
INFO - 2018-02-13 06:23:24 --> Language Class Initialized
INFO - 2018-02-13 06:23:24 --> Language Class Initialized
INFO - 2018-02-13 06:23:24 --> Config Class Initialized
INFO - 2018-02-13 06:23:24 --> Loader Class Initialized
INFO - 2018-02-13 11:53:24 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:24 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:24 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:24 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:24 --> Controller Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:24 --> Total execution time: 0.0891
INFO - 2018-02-13 06:23:24 --> Config Class Initialized
INFO - 2018-02-13 06:23:24 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:24 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:24 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:24 --> URI Class Initialized
INFO - 2018-02-13 06:23:24 --> Config Class Initialized
INFO - 2018-02-13 06:23:24 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:24 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:24 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:24 --> Router Class Initialized
INFO - 2018-02-13 06:23:24 --> URI Class Initialized
INFO - 2018-02-13 06:23:24 --> Output Class Initialized
INFO - 2018-02-13 06:23:24 --> Security Class Initialized
INFO - 2018-02-13 06:23:24 --> Router Class Initialized
DEBUG - 2018-02-13 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:24 --> Input Class Initialized
INFO - 2018-02-13 06:23:24 --> Output Class Initialized
INFO - 2018-02-13 06:23:24 --> Language Class Initialized
INFO - 2018-02-13 06:23:24 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:24 --> Input Class Initialized
INFO - 2018-02-13 06:23:24 --> Language Class Initialized
INFO - 2018-02-13 06:23:24 --> Language Class Initialized
INFO - 2018-02-13 06:23:24 --> Config Class Initialized
INFO - 2018-02-13 06:23:24 --> Loader Class Initialized
INFO - 2018-02-13 11:53:24 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: permission_helper
INFO - 2018-02-13 06:23:24 --> Language Class Initialized
INFO - 2018-02-13 06:23:24 --> Config Class Initialized
INFO - 2018-02-13 06:23:24 --> Loader Class Initialized
INFO - 2018-02-13 11:53:24 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:24 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:24 --> Database Driver Class Initialized
INFO - 2018-02-13 11:53:24 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 11:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:24 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:24 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:24 --> Controller Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:24 --> Total execution time: 0.1157
INFO - 2018-02-13 11:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:24 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:24 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:24 --> Controller Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:24 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Model Class Initialized
INFO - 2018-02-13 11:53:24 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:53:24 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:24 --> Total execution time: 0.1437
INFO - 2018-02-13 06:23:47 --> Config Class Initialized
INFO - 2018-02-13 06:23:47 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:47 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:47 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:47 --> URI Class Initialized
INFO - 2018-02-13 06:23:47 --> Router Class Initialized
INFO - 2018-02-13 06:23:47 --> Output Class Initialized
INFO - 2018-02-13 06:23:47 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:47 --> Input Class Initialized
INFO - 2018-02-13 06:23:47 --> Language Class Initialized
INFO - 2018-02-13 06:23:47 --> Language Class Initialized
INFO - 2018-02-13 06:23:47 --> Config Class Initialized
INFO - 2018-02-13 06:23:47 --> Loader Class Initialized
INFO - 2018-02-13 11:53:47 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:47 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:47 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:47 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:47 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:47 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:47 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:47 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:47 --> Controller Class Initialized
INFO - 2018-02-13 11:53:47 --> Model Class Initialized
INFO - 2018-02-13 11:53:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:47 --> Model Class Initialized
INFO - 2018-02-13 11:53:47 --> Model Class Initialized
INFO - 2018-02-13 11:53:47 --> Model Class Initialized
INFO - 2018-02-13 11:53:47 --> Model Class Initialized
INFO - 2018-02-13 11:53:47 --> Model Class Initialized
INFO - 2018-02-13 11:53:47 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:47 --> Total execution time: 0.4113
INFO - 2018-02-13 06:23:48 --> Config Class Initialized
INFO - 2018-02-13 06:23:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:48 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:48 --> URI Class Initialized
INFO - 2018-02-13 06:23:48 --> Router Class Initialized
INFO - 2018-02-13 06:23:48 --> Output Class Initialized
INFO - 2018-02-13 06:23:48 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:48 --> Input Class Initialized
INFO - 2018-02-13 06:23:48 --> Language Class Initialized
INFO - 2018-02-13 06:23:48 --> Language Class Initialized
INFO - 2018-02-13 06:23:48 --> Config Class Initialized
INFO - 2018-02-13 06:23:48 --> Loader Class Initialized
INFO - 2018-02-13 11:53:48 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:48 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:48 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:48 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:48 --> Controller Class Initialized
INFO - 2018-02-13 11:53:48 --> Model Class Initialized
INFO - 2018-02-13 11:53:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:48 --> Model Class Initialized
INFO - 2018-02-13 11:53:48 --> Model Class Initialized
INFO - 2018-02-13 11:53:48 --> Model Class Initialized
INFO - 2018-02-13 11:53:48 --> Model Class Initialized
INFO - 2018-02-13 11:53:48 --> Model Class Initialized
INFO - 2018-02-13 11:53:48 --> Model Class Initialized
INFO - 2018-02-13 11:53:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:53:48 --> Model Class Initialized
INFO - 2018-02-13 11:53:48 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:48 --> Total execution time: 0.1159
INFO - 2018-02-13 06:23:50 --> Config Class Initialized
INFO - 2018-02-13 06:23:50 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:50 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:50 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:50 --> URI Class Initialized
INFO - 2018-02-13 06:23:50 --> Router Class Initialized
INFO - 2018-02-13 06:23:50 --> Output Class Initialized
INFO - 2018-02-13 06:23:50 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:50 --> Input Class Initialized
INFO - 2018-02-13 06:23:50 --> Language Class Initialized
INFO - 2018-02-13 06:23:51 --> Language Class Initialized
INFO - 2018-02-13 06:23:51 --> Config Class Initialized
INFO - 2018-02-13 06:23:51 --> Loader Class Initialized
INFO - 2018-02-13 11:53:51 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:51 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:51 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:51 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:51 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:51 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:51 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:51 --> Controller Class Initialized
INFO - 2018-02-13 11:53:51 --> Model Class Initialized
INFO - 2018-02-13 11:53:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:51 --> Model Class Initialized
INFO - 2018-02-13 11:53:51 --> Model Class Initialized
INFO - 2018-02-13 11:53:51 --> Model Class Initialized
INFO - 2018-02-13 11:53:51 --> Model Class Initialized
INFO - 2018-02-13 11:53:51 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:51 --> Total execution time: 0.0867
INFO - 2018-02-13 06:23:52 --> Config Class Initialized
INFO - 2018-02-13 06:23:52 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:23:52 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:23:52 --> Utf8 Class Initialized
INFO - 2018-02-13 06:23:52 --> URI Class Initialized
INFO - 2018-02-13 06:23:52 --> Router Class Initialized
INFO - 2018-02-13 06:23:52 --> Output Class Initialized
INFO - 2018-02-13 06:23:52 --> Security Class Initialized
DEBUG - 2018-02-13 06:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:23:52 --> Input Class Initialized
INFO - 2018-02-13 06:23:52 --> Language Class Initialized
INFO - 2018-02-13 06:23:52 --> Language Class Initialized
INFO - 2018-02-13 06:23:52 --> Config Class Initialized
INFO - 2018-02-13 06:23:52 --> Loader Class Initialized
INFO - 2018-02-13 11:53:52 --> Helper loaded: url_helper
INFO - 2018-02-13 11:53:52 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:53:52 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:53:52 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:53:52 --> Helper loaded: users_helper
INFO - 2018-02-13 11:53:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:53:52 --> Helper loaded: form_helper
INFO - 2018-02-13 11:53:52 --> Form Validation Class Initialized
INFO - 2018-02-13 11:53:52 --> Controller Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:53:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:53:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:53:52 --> Model Class Initialized
INFO - 2018-02-13 11:53:52 --> Final output sent to browser
DEBUG - 2018-02-13 11:53:52 --> Total execution time: 0.1232
INFO - 2018-02-13 06:24:04 --> Config Class Initialized
INFO - 2018-02-13 06:24:04 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:24:04 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:24:04 --> Utf8 Class Initialized
INFO - 2018-02-13 06:24:04 --> URI Class Initialized
INFO - 2018-02-13 06:24:04 --> Router Class Initialized
INFO - 2018-02-13 06:24:04 --> Output Class Initialized
INFO - 2018-02-13 06:24:04 --> Security Class Initialized
DEBUG - 2018-02-13 06:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:24:04 --> Input Class Initialized
INFO - 2018-02-13 06:24:04 --> Language Class Initialized
INFO - 2018-02-13 06:24:04 --> Language Class Initialized
INFO - 2018-02-13 06:24:04 --> Config Class Initialized
INFO - 2018-02-13 06:24:04 --> Loader Class Initialized
INFO - 2018-02-13 11:54:04 --> Helper loaded: url_helper
INFO - 2018-02-13 11:54:04 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:54:04 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:54:04 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:54:04 --> Helper loaded: users_helper
INFO - 2018-02-13 11:54:04 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:54:04 --> Helper loaded: form_helper
INFO - 2018-02-13 11:54:04 --> Form Validation Class Initialized
INFO - 2018-02-13 11:54:04 --> Controller Class Initialized
INFO - 2018-02-13 11:54:04 --> Model Class Initialized
INFO - 2018-02-13 11:54:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:54:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:54:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:54:05 --> Model Class Initialized
INFO - 2018-02-13 11:54:05 --> Model Class Initialized
INFO - 2018-02-13 11:54:05 --> Model Class Initialized
INFO - 2018-02-13 11:54:05 --> Model Class Initialized
INFO - 2018-02-13 11:54:05 --> Model Class Initialized
INFO - 2018-02-13 11:54:05 --> Final output sent to browser
DEBUG - 2018-02-13 11:54:05 --> Total execution time: 0.4329
INFO - 2018-02-13 06:24:06 --> Config Class Initialized
INFO - 2018-02-13 06:24:06 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:24:06 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:24:06 --> Utf8 Class Initialized
INFO - 2018-02-13 06:24:06 --> URI Class Initialized
INFO - 2018-02-13 06:24:06 --> Router Class Initialized
INFO - 2018-02-13 06:24:06 --> Output Class Initialized
INFO - 2018-02-13 06:24:06 --> Security Class Initialized
DEBUG - 2018-02-13 06:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:24:06 --> Input Class Initialized
INFO - 2018-02-13 06:24:06 --> Language Class Initialized
INFO - 2018-02-13 06:24:06 --> Language Class Initialized
INFO - 2018-02-13 06:24:06 --> Config Class Initialized
INFO - 2018-02-13 06:24:06 --> Loader Class Initialized
INFO - 2018-02-13 11:54:06 --> Helper loaded: url_helper
INFO - 2018-02-13 11:54:06 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:54:06 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:54:06 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:54:06 --> Helper loaded: users_helper
INFO - 2018-02-13 11:54:06 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:54:06 --> Helper loaded: form_helper
INFO - 2018-02-13 11:54:06 --> Form Validation Class Initialized
INFO - 2018-02-13 11:54:06 --> Controller Class Initialized
INFO - 2018-02-13 11:54:06 --> Model Class Initialized
INFO - 2018-02-13 11:54:06 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:54:06 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:54:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:54:06 --> Model Class Initialized
INFO - 2018-02-13 11:54:06 --> Model Class Initialized
INFO - 2018-02-13 11:54:06 --> Model Class Initialized
INFO - 2018-02-13 11:54:06 --> Model Class Initialized
INFO - 2018-02-13 11:54:06 --> Model Class Initialized
INFO - 2018-02-13 11:54:06 --> Model Class Initialized
INFO - 2018-02-13 11:54:06 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:54:06 --> Model Class Initialized
INFO - 2018-02-13 11:54:06 --> Final output sent to browser
DEBUG - 2018-02-13 11:54:06 --> Total execution time: 0.0903
INFO - 2018-02-13 06:24:07 --> Config Class Initialized
INFO - 2018-02-13 06:24:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:24:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:24:07 --> Utf8 Class Initialized
INFO - 2018-02-13 06:24:07 --> URI Class Initialized
INFO - 2018-02-13 06:24:07 --> Router Class Initialized
INFO - 2018-02-13 06:24:07 --> Output Class Initialized
INFO - 2018-02-13 06:24:07 --> Security Class Initialized
DEBUG - 2018-02-13 06:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:24:07 --> Input Class Initialized
INFO - 2018-02-13 06:24:07 --> Language Class Initialized
INFO - 2018-02-13 06:24:07 --> Language Class Initialized
INFO - 2018-02-13 06:24:07 --> Config Class Initialized
INFO - 2018-02-13 06:24:07 --> Loader Class Initialized
INFO - 2018-02-13 11:54:07 --> Helper loaded: url_helper
INFO - 2018-02-13 11:54:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:54:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:54:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:54:07 --> Helper loaded: users_helper
INFO - 2018-02-13 11:54:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:54:07 --> Helper loaded: form_helper
INFO - 2018-02-13 11:54:07 --> Form Validation Class Initialized
INFO - 2018-02-13 11:54:07 --> Controller Class Initialized
INFO - 2018-02-13 11:54:07 --> Model Class Initialized
INFO - 2018-02-13 11:54:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:54:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:54:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:54:07 --> Model Class Initialized
INFO - 2018-02-13 11:54:07 --> Model Class Initialized
INFO - 2018-02-13 11:54:07 --> Final output sent to browser
DEBUG - 2018-02-13 11:54:07 --> Total execution time: 0.1004
INFO - 2018-02-13 06:24:10 --> Config Class Initialized
INFO - 2018-02-13 06:24:10 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:24:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:24:10 --> Utf8 Class Initialized
INFO - 2018-02-13 06:24:10 --> URI Class Initialized
INFO - 2018-02-13 06:24:10 --> Router Class Initialized
INFO - 2018-02-13 06:24:10 --> Output Class Initialized
INFO - 2018-02-13 06:24:10 --> Security Class Initialized
DEBUG - 2018-02-13 06:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:24:10 --> Input Class Initialized
INFO - 2018-02-13 06:24:10 --> Language Class Initialized
INFO - 2018-02-13 06:24:10 --> Language Class Initialized
INFO - 2018-02-13 06:24:10 --> Config Class Initialized
INFO - 2018-02-13 06:24:10 --> Loader Class Initialized
INFO - 2018-02-13 11:54:10 --> Helper loaded: url_helper
INFO - 2018-02-13 11:54:10 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:54:10 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:54:10 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:54:10 --> Helper loaded: users_helper
INFO - 2018-02-13 11:54:10 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:54:10 --> Helper loaded: form_helper
INFO - 2018-02-13 11:54:10 --> Form Validation Class Initialized
INFO - 2018-02-13 11:54:10 --> Controller Class Initialized
INFO - 2018-02-13 11:54:10 --> Model Class Initialized
INFO - 2018-02-13 11:54:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:54:10 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:54:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:54:10 --> Model Class Initialized
INFO - 2018-02-13 11:54:10 --> Model Class Initialized
INFO - 2018-02-13 11:54:10 --> Model Class Initialized
INFO - 2018-02-13 11:54:10 --> Model Class Initialized
INFO - 2018-02-13 11:54:10 --> Model Class Initialized
INFO - 2018-02-13 11:54:10 --> Model Class Initialized
INFO - 2018-02-13 11:54:10 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:54:10 --> Final output sent to browser
DEBUG - 2018-02-13 11:54:10 --> Total execution time: 0.1145
INFO - 2018-02-13 06:24:10 --> Config Class Initialized
INFO - 2018-02-13 06:24:10 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:24:10 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:24:10 --> Utf8 Class Initialized
INFO - 2018-02-13 06:24:10 --> URI Class Initialized
INFO - 2018-02-13 06:24:10 --> Router Class Initialized
INFO - 2018-02-13 06:24:10 --> Output Class Initialized
INFO - 2018-02-13 06:24:10 --> Security Class Initialized
DEBUG - 2018-02-13 06:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:24:10 --> Input Class Initialized
INFO - 2018-02-13 06:24:10 --> Language Class Initialized
INFO - 2018-02-13 06:24:10 --> Language Class Initialized
INFO - 2018-02-13 06:24:10 --> Config Class Initialized
INFO - 2018-02-13 06:24:10 --> Loader Class Initialized
INFO - 2018-02-13 11:54:10 --> Helper loaded: url_helper
INFO - 2018-02-13 11:54:10 --> Helper loaded: notification_helper
INFO - 2018-02-13 11:54:10 --> Helper loaded: settings_helper
INFO - 2018-02-13 11:54:10 --> Helper loaded: permission_helper
INFO - 2018-02-13 11:54:10 --> Helper loaded: users_helper
INFO - 2018-02-13 11:54:10 --> Database Driver Class Initialized
DEBUG - 2018-02-13 11:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 11:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 11:54:11 --> Helper loaded: form_helper
INFO - 2018-02-13 11:54:11 --> Form Validation Class Initialized
INFO - 2018-02-13 11:54:11 --> Controller Class Initialized
INFO - 2018-02-13 11:54:11 --> Model Class Initialized
INFO - 2018-02-13 11:54:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 11:54:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 11:54:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 11:54:11 --> Model Class Initialized
INFO - 2018-02-13 11:54:11 --> Model Class Initialized
INFO - 2018-02-13 11:54:11 --> Model Class Initialized
INFO - 2018-02-13 11:54:11 --> Model Class Initialized
INFO - 2018-02-13 11:54:11 --> Model Class Initialized
INFO - 2018-02-13 11:54:11 --> Model Class Initialized
INFO - 2018-02-13 11:54:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 11:54:11 --> Final output sent to browser
DEBUG - 2018-02-13 11:54:11 --> Total execution time: 0.1207
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:32:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:12 --> Utf8 Class Initialized
INFO - 2018-02-13 06:32:12 --> URI Class Initialized
INFO - 2018-02-13 06:32:12 --> Router Class Initialized
INFO - 2018-02-13 06:32:12 --> Output Class Initialized
INFO - 2018-02-13 06:32:12 --> Security Class Initialized
DEBUG - 2018-02-13 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:12 --> Input Class Initialized
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Hooks Class Initialized
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:32:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:12 --> Utf8 Class Initialized
INFO - 2018-02-13 06:32:12 --> URI Class Initialized
DEBUG - 2018-02-13 06:32:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:12 --> Utf8 Class Initialized
INFO - 2018-02-13 06:32:12 --> URI Class Initialized
INFO - 2018-02-13 06:32:12 --> Router Class Initialized
INFO - 2018-02-13 06:32:12 --> Output Class Initialized
INFO - 2018-02-13 06:32:12 --> Router Class Initialized
INFO - 2018-02-13 06:32:12 --> Security Class Initialized
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Loader Class Initialized
DEBUG - 2018-02-13 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:12 --> Input Class Initialized
INFO - 2018-02-13 06:32:12 --> Output Class Initialized
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: url_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: notification_helper
INFO - 2018-02-13 06:32:12 --> Security Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: users_helper
DEBUG - 2018-02-13 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:12 --> Input Class Initialized
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Loader Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: url_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:02:12 --> Database Driver Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: users_helper
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:32:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:12 --> Utf8 Class Initialized
INFO - 2018-02-13 06:32:12 --> URI Class Initialized
DEBUG - 2018-02-13 12:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Loader Class Initialized
INFO - 2018-02-13 06:32:12 --> Router Class Initialized
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Hooks Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: url_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: settings_helper
INFO - 2018-02-13 06:32:12 --> Output Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: permission_helper
DEBUG - 2018-02-13 06:32:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:12 --> Utf8 Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: users_helper
INFO - 2018-02-13 06:32:12 --> Security Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:12 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:12 --> Controller Class Initialized
INFO - 2018-02-13 06:32:12 --> URI Class Initialized
INFO - 2018-02-13 12:02:12 --> Database Driver Class Initialized
DEBUG - 2018-02-13 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:12 --> Input Class Initialized
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
INFO - 2018-02-13 06:32:12 --> Router Class Initialized
DEBUG - 2018-02-13 12:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:32:12 --> Output Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 06:32:12 --> Security Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:12 --> Input Class Initialized
INFO - 2018-02-13 12:02:12 --> Database Driver Class Initialized
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
DEBUG - 2018-02-13 12:02:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:02:12 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:12 --> Controller Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Loader Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
DEBUG - 2018-02-13 12:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:02:12 --> Helper loaded: url_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: users_helper
INFO - 2018-02-13 12:02:12 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:12 --> Total execution time: 0.1143
INFO - 2018-02-13 12:02:12 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:12 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:12 --> Controller Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:02:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 06:32:12 --> Language Class Initialized
INFO - 2018-02-13 06:32:12 --> Config Class Initialized
INFO - 2018-02-13 06:32:12 --> Loader Class Initialized
INFO - 2018-02-13 12:02:12 --> Database Driver Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: url_helper
INFO - 2018-02-13 12:02:12 --> Helper loaded: inflector_helper
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: permission_helper
DEBUG - 2018-02-13 12:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: users_helper
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
DEBUG - 2018-02-13 12:02:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:12 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:12 --> Controller Class Initialized
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:12 --> Total execution time: 0.1093
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:12 --> Total execution time: 0.1155
INFO - 2018-02-13 12:02:12 --> Helper loaded: inflector_helper
INFO - 2018-02-13 12:02:12 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:02:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
DEBUG - 2018-02-13 12:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:12 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:12 --> Controller Class Initialized
INFO - 2018-02-13 12:02:12 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:12 --> Total execution time: 0.0981
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:02:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:02:12 --> Model Class Initialized
INFO - 2018-02-13 12:02:12 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:12 --> Total execution time: 0.1136
INFO - 2018-02-13 06:32:14 --> Config Class Initialized
INFO - 2018-02-13 06:32:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:32:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:32:14 --> URI Class Initialized
INFO - 2018-02-13 06:32:14 --> Router Class Initialized
INFO - 2018-02-13 06:32:14 --> Output Class Initialized
INFO - 2018-02-13 06:32:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:14 --> Input Class Initialized
INFO - 2018-02-13 06:32:14 --> Language Class Initialized
INFO - 2018-02-13 06:32:14 --> Language Class Initialized
INFO - 2018-02-13 06:32:14 --> Config Class Initialized
INFO - 2018-02-13 06:32:14 --> Loader Class Initialized
INFO - 2018-02-13 12:02:14 --> Helper loaded: url_helper
INFO - 2018-02-13 12:02:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:02:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:02:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 06:32:14 --> Config Class Initialized
INFO - 2018-02-13 06:32:14 --> Hooks Class Initialized
INFO - 2018-02-13 12:02:14 --> Helper loaded: users_helper
DEBUG - 2018-02-13 06:32:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:32:14 --> URI Class Initialized
INFO - 2018-02-13 06:32:14 --> Router Class Initialized
INFO - 2018-02-13 06:32:14 --> Output Class Initialized
INFO - 2018-02-13 12:02:14 --> Database Driver Class Initialized
INFO - 2018-02-13 06:32:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:14 --> Input Class Initialized
INFO - 2018-02-13 06:32:14 --> Language Class Initialized
DEBUG - 2018-02-13 12:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:02:14 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:14 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:14 --> Controller Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Helper loaded: inflector_helper
INFO - 2018-02-13 06:32:14 --> Language Class Initialized
INFO - 2018-02-13 06:32:14 --> Config Class Initialized
INFO - 2018-02-13 06:32:14 --> Loader Class Initialized
INFO - 2018-02-13 12:02:14 --> Helper loaded: url_helper
DEBUG - 2018-02-13 12:02:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:02:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:02:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:02:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Helper loaded: users_helper
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:14 --> Total execution time: 0.1118
INFO - 2018-02-13 12:02:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:02:14 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:14 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:14 --> Controller Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:02:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Model Class Initialized
INFO - 2018-02-13 12:02:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:02:14 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:14 --> Total execution time: 0.1233
INFO - 2018-02-13 06:32:15 --> Config Class Initialized
INFO - 2018-02-13 06:32:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:32:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:15 --> Utf8 Class Initialized
INFO - 2018-02-13 06:32:15 --> URI Class Initialized
INFO - 2018-02-13 06:32:15 --> Router Class Initialized
INFO - 2018-02-13 06:32:15 --> Output Class Initialized
INFO - 2018-02-13 06:32:15 --> Config Class Initialized
INFO - 2018-02-13 06:32:15 --> Hooks Class Initialized
INFO - 2018-02-13 06:32:15 --> Security Class Initialized
DEBUG - 2018-02-13 06:32:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:15 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:15 --> Input Class Initialized
INFO - 2018-02-13 06:32:15 --> Language Class Initialized
INFO - 2018-02-13 06:32:15 --> URI Class Initialized
INFO - 2018-02-13 06:32:15 --> Router Class Initialized
INFO - 2018-02-13 06:32:15 --> Output Class Initialized
INFO - 2018-02-13 06:32:15 --> Security Class Initialized
DEBUG - 2018-02-13 06:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:15 --> Input Class Initialized
INFO - 2018-02-13 06:32:15 --> Language Class Initialized
INFO - 2018-02-13 06:32:15 --> Language Class Initialized
INFO - 2018-02-13 06:32:15 --> Config Class Initialized
INFO - 2018-02-13 06:32:15 --> Loader Class Initialized
INFO - 2018-02-13 12:02:15 --> Helper loaded: url_helper
INFO - 2018-02-13 12:02:15 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:02:15 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:02:15 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:02:15 --> Helper loaded: users_helper
INFO - 2018-02-13 06:32:15 --> Language Class Initialized
INFO - 2018-02-13 06:32:15 --> Config Class Initialized
INFO - 2018-02-13 06:32:15 --> Loader Class Initialized
INFO - 2018-02-13 12:02:15 --> Helper loaded: url_helper
INFO - 2018-02-13 12:02:15 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:02:15 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:02:15 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:02:15 --> Helper loaded: users_helper
INFO - 2018-02-13 12:02:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:02:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:02:15 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:15 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:15 --> Controller Class Initialized
INFO - 2018-02-13 12:02:15 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:15 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:15 --> Controller Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:02:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Helper loaded: inflector_helper
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Language file loaded: language/english/message_lang.php
DEBUG - 2018-02-13 12:02:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:15 --> Total execution time: 0.1147
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:02:15 --> Model Class Initialized
INFO - 2018-02-13 12:02:15 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:15 --> Total execution time: 0.1148
INFO - 2018-02-13 06:32:17 --> Config Class Initialized
INFO - 2018-02-13 06:32:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:32:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:32:17 --> Utf8 Class Initialized
INFO - 2018-02-13 06:32:17 --> URI Class Initialized
INFO - 2018-02-13 06:32:17 --> Router Class Initialized
INFO - 2018-02-13 06:32:17 --> Output Class Initialized
INFO - 2018-02-13 06:32:17 --> Security Class Initialized
DEBUG - 2018-02-13 06:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:32:17 --> Input Class Initialized
INFO - 2018-02-13 06:32:17 --> Language Class Initialized
INFO - 2018-02-13 06:32:17 --> Language Class Initialized
INFO - 2018-02-13 06:32:17 --> Config Class Initialized
INFO - 2018-02-13 06:32:17 --> Loader Class Initialized
INFO - 2018-02-13 12:02:17 --> Helper loaded: url_helper
INFO - 2018-02-13 12:02:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:02:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:02:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:02:17 --> Helper loaded: users_helper
INFO - 2018-02-13 12:02:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:02:17 --> Helper loaded: form_helper
INFO - 2018-02-13 12:02:17 --> Form Validation Class Initialized
INFO - 2018-02-13 12:02:17 --> Controller Class Initialized
INFO - 2018-02-13 12:02:17 --> Model Class Initialized
INFO - 2018-02-13 12:02:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:02:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:02:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:02:17 --> Model Class Initialized
INFO - 2018-02-13 12:02:17 --> Model Class Initialized
INFO - 2018-02-13 12:02:17 --> Model Class Initialized
INFO - 2018-02-13 12:02:17 --> Model Class Initialized
INFO - 2018-02-13 12:02:17 --> Model Class Initialized
INFO - 2018-02-13 12:02:17 --> Model Class Initialized
INFO - 2018-02-13 12:02:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:02:17 --> Final output sent to browser
DEBUG - 2018-02-13 12:02:17 --> Total execution time: 0.1183
INFO - 2018-02-13 06:33:30 --> Config Class Initialized
INFO - 2018-02-13 06:33:30 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:33:30 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:33:30 --> Utf8 Class Initialized
INFO - 2018-02-13 06:33:30 --> URI Class Initialized
INFO - 2018-02-13 06:33:30 --> Router Class Initialized
INFO - 2018-02-13 06:33:30 --> Output Class Initialized
INFO - 2018-02-13 06:33:30 --> Security Class Initialized
DEBUG - 2018-02-13 06:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:33:30 --> Input Class Initialized
INFO - 2018-02-13 06:33:30 --> Language Class Initialized
INFO - 2018-02-13 06:33:30 --> Language Class Initialized
INFO - 2018-02-13 06:33:30 --> Config Class Initialized
INFO - 2018-02-13 06:33:30 --> Loader Class Initialized
INFO - 2018-02-13 12:03:30 --> Helper loaded: url_helper
INFO - 2018-02-13 12:03:30 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:03:30 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:03:30 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:03:30 --> Helper loaded: users_helper
INFO - 2018-02-13 12:03:30 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:03:30 --> Helper loaded: form_helper
INFO - 2018-02-13 12:03:30 --> Form Validation Class Initialized
INFO - 2018-02-13 12:03:30 --> Controller Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:03:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:03:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Final output sent to browser
DEBUG - 2018-02-13 12:03:30 --> Total execution time: 0.1261
INFO - 2018-02-13 06:33:30 --> Config Class Initialized
INFO - 2018-02-13 06:33:30 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:33:30 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:33:30 --> Utf8 Class Initialized
INFO - 2018-02-13 06:33:30 --> URI Class Initialized
INFO - 2018-02-13 06:33:30 --> Router Class Initialized
INFO - 2018-02-13 06:33:30 --> Output Class Initialized
INFO - 2018-02-13 06:33:30 --> Security Class Initialized
DEBUG - 2018-02-13 06:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:33:30 --> Input Class Initialized
INFO - 2018-02-13 06:33:30 --> Language Class Initialized
INFO - 2018-02-13 06:33:30 --> Language Class Initialized
INFO - 2018-02-13 06:33:30 --> Config Class Initialized
INFO - 2018-02-13 06:33:30 --> Loader Class Initialized
INFO - 2018-02-13 12:03:30 --> Helper loaded: url_helper
INFO - 2018-02-13 12:03:30 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:03:30 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:03:30 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:03:30 --> Helper loaded: users_helper
INFO - 2018-02-13 12:03:30 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:03:30 --> Helper loaded: form_helper
INFO - 2018-02-13 12:03:30 --> Form Validation Class Initialized
INFO - 2018-02-13 12:03:30 --> Controller Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:03:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:03:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:03:30 --> Model Class Initialized
INFO - 2018-02-13 12:03:30 --> Final output sent to browser
DEBUG - 2018-02-13 12:03:30 --> Total execution time: 0.0836
INFO - 2018-02-13 06:37:15 --> Config Class Initialized
INFO - 2018-02-13 06:37:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:37:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:37:15 --> Utf8 Class Initialized
INFO - 2018-02-13 06:37:15 --> URI Class Initialized
INFO - 2018-02-13 06:37:15 --> Router Class Initialized
INFO - 2018-02-13 06:37:15 --> Output Class Initialized
INFO - 2018-02-13 06:37:15 --> Security Class Initialized
DEBUG - 2018-02-13 06:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:37:15 --> Input Class Initialized
INFO - 2018-02-13 06:37:15 --> Language Class Initialized
INFO - 2018-02-13 06:37:15 --> Language Class Initialized
INFO - 2018-02-13 06:37:15 --> Config Class Initialized
INFO - 2018-02-13 06:37:15 --> Loader Class Initialized
INFO - 2018-02-13 12:07:15 --> Helper loaded: url_helper
INFO - 2018-02-13 12:07:15 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:07:15 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:07:15 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:07:15 --> Helper loaded: users_helper
INFO - 2018-02-13 12:07:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:07:15 --> Helper loaded: form_helper
INFO - 2018-02-13 12:07:15 --> Form Validation Class Initialized
INFO - 2018-02-13 12:07:15 --> Controller Class Initialized
INFO - 2018-02-13 12:07:15 --> Model Class Initialized
INFO - 2018-02-13 12:07:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:07:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:07:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:07:15 --> Model Class Initialized
INFO - 2018-02-13 12:07:15 --> Model Class Initialized
INFO - 2018-02-13 12:07:15 --> Model Class Initialized
INFO - 2018-02-13 12:07:15 --> Model Class Initialized
INFO - 2018-02-13 12:07:15 --> Model Class Initialized
INFO - 2018-02-13 12:07:15 --> Model Class Initialized
INFO - 2018-02-13 12:07:15 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 12:07:15 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
ERROR - 2018-02-13 12:07:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/pr01004/public_html/application/controllers/api/Users.php 784
INFO - 2018-02-13 12:07:15 --> Final output sent to browser
DEBUG - 2018-02-13 12:07:15 --> Total execution time: 0.0787
INFO - 2018-02-13 06:37:19 --> Config Class Initialized
INFO - 2018-02-13 06:37:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:37:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:37:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:37:19 --> URI Class Initialized
INFO - 2018-02-13 06:37:19 --> Router Class Initialized
INFO - 2018-02-13 06:37:19 --> Output Class Initialized
INFO - 2018-02-13 06:37:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:37:19 --> Input Class Initialized
INFO - 2018-02-13 06:37:19 --> Language Class Initialized
INFO - 2018-02-13 06:37:19 --> Language Class Initialized
INFO - 2018-02-13 06:37:19 --> Config Class Initialized
INFO - 2018-02-13 06:37:19 --> Loader Class Initialized
INFO - 2018-02-13 12:07:19 --> Helper loaded: url_helper
INFO - 2018-02-13 12:07:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:07:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:07:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:07:19 --> Helper loaded: users_helper
INFO - 2018-02-13 12:07:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:07:19 --> Helper loaded: form_helper
INFO - 2018-02-13 12:07:19 --> Form Validation Class Initialized
INFO - 2018-02-13 12:07:19 --> Controller Class Initialized
INFO - 2018-02-13 12:07:19 --> Model Class Initialized
INFO - 2018-02-13 12:07:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:07:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:07:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:07:19 --> Model Class Initialized
INFO - 2018-02-13 12:07:19 --> Model Class Initialized
INFO - 2018-02-13 12:07:19 --> Model Class Initialized
INFO - 2018-02-13 12:07:19 --> Model Class Initialized
INFO - 2018-02-13 12:07:19 --> Final output sent to browser
DEBUG - 2018-02-13 12:07:19 --> Total execution time: 0.1002
INFO - 2018-02-13 06:37:20 --> Config Class Initialized
INFO - 2018-02-13 06:37:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:37:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:37:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:37:20 --> URI Class Initialized
INFO - 2018-02-13 06:37:20 --> Router Class Initialized
INFO - 2018-02-13 06:37:20 --> Output Class Initialized
INFO - 2018-02-13 06:37:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:37:20 --> Input Class Initialized
INFO - 2018-02-13 06:37:20 --> Language Class Initialized
INFO - 2018-02-13 06:37:20 --> Language Class Initialized
INFO - 2018-02-13 06:37:20 --> Config Class Initialized
INFO - 2018-02-13 06:37:20 --> Loader Class Initialized
INFO - 2018-02-13 12:07:20 --> Helper loaded: url_helper
INFO - 2018-02-13 12:07:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:07:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:07:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:07:20 --> Helper loaded: users_helper
INFO - 2018-02-13 12:07:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:07:20 --> Helper loaded: form_helper
INFO - 2018-02-13 12:07:20 --> Form Validation Class Initialized
INFO - 2018-02-13 12:07:20 --> Controller Class Initialized
INFO - 2018-02-13 12:07:20 --> Model Class Initialized
INFO - 2018-02-13 12:07:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:07:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:07:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:07:20 --> Model Class Initialized
INFO - 2018-02-13 12:07:20 --> Model Class Initialized
INFO - 2018-02-13 12:07:20 --> Model Class Initialized
INFO - 2018-02-13 12:07:20 --> Model Class Initialized
INFO - 2018-02-13 12:07:20 --> Final output sent to browser
DEBUG - 2018-02-13 12:07:20 --> Total execution time: 0.0746
INFO - 2018-02-13 06:37:21 --> Config Class Initialized
INFO - 2018-02-13 06:37:21 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:37:21 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:37:21 --> Utf8 Class Initialized
INFO - 2018-02-13 06:37:21 --> URI Class Initialized
INFO - 2018-02-13 06:37:21 --> Router Class Initialized
INFO - 2018-02-13 06:37:21 --> Output Class Initialized
INFO - 2018-02-13 06:37:21 --> Security Class Initialized
DEBUG - 2018-02-13 06:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:37:21 --> Input Class Initialized
INFO - 2018-02-13 06:37:21 --> Language Class Initialized
INFO - 2018-02-13 06:37:21 --> Language Class Initialized
INFO - 2018-02-13 06:37:21 --> Config Class Initialized
INFO - 2018-02-13 06:37:21 --> Loader Class Initialized
INFO - 2018-02-13 12:07:21 --> Helper loaded: url_helper
INFO - 2018-02-13 12:07:21 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:07:21 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:07:21 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:07:21 --> Helper loaded: users_helper
INFO - 2018-02-13 12:07:21 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:07:21 --> Helper loaded: form_helper
INFO - 2018-02-13 12:07:21 --> Form Validation Class Initialized
INFO - 2018-02-13 12:07:21 --> Controller Class Initialized
INFO - 2018-02-13 12:07:21 --> Model Class Initialized
INFO - 2018-02-13 12:07:21 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:07:21 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:07:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:07:21 --> Model Class Initialized
INFO - 2018-02-13 12:07:21 --> Model Class Initialized
INFO - 2018-02-13 12:07:21 --> Model Class Initialized
INFO - 2018-02-13 12:07:21 --> Model Class Initialized
INFO - 2018-02-13 12:07:21 --> Model Class Initialized
INFO - 2018-02-13 12:07:21 --> Model Class Initialized
INFO - 2018-02-13 12:07:21 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 12:07:21 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-02-13 12:07:21 --> Final output sent to browser
DEBUG - 2018-02-13 12:07:21 --> Total execution time: 0.1058
INFO - 2018-02-13 06:37:48 --> Config Class Initialized
INFO - 2018-02-13 06:37:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:37:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:37:48 --> Utf8 Class Initialized
INFO - 2018-02-13 06:37:48 --> URI Class Initialized
INFO - 2018-02-13 06:37:48 --> Router Class Initialized
INFO - 2018-02-13 06:37:48 --> Output Class Initialized
INFO - 2018-02-13 06:37:48 --> Security Class Initialized
DEBUG - 2018-02-13 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:37:48 --> Input Class Initialized
INFO - 2018-02-13 06:37:48 --> Language Class Initialized
INFO - 2018-02-13 06:37:48 --> Language Class Initialized
INFO - 2018-02-13 06:37:48 --> Config Class Initialized
INFO - 2018-02-13 06:37:48 --> Loader Class Initialized
INFO - 2018-02-13 12:07:48 --> Helper loaded: url_helper
INFO - 2018-02-13 12:07:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:07:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:07:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:07:48 --> Helper loaded: users_helper
INFO - 2018-02-13 12:07:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:07:48 --> Helper loaded: form_helper
INFO - 2018-02-13 12:07:48 --> Form Validation Class Initialized
INFO - 2018-02-13 12:07:48 --> Controller Class Initialized
INFO - 2018-02-13 12:07:48 --> Model Class Initialized
INFO - 2018-02-13 12:07:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:07:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:07:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:07:48 --> Model Class Initialized
INFO - 2018-02-13 12:07:48 --> Model Class Initialized
INFO - 2018-02-13 12:07:48 --> Model Class Initialized
INFO - 2018-02-13 12:07:48 --> Model Class Initialized
INFO - 2018-02-13 12:07:48 --> Final output sent to browser
DEBUG - 2018-02-13 12:07:48 --> Total execution time: 0.1097
INFO - 2018-02-13 06:37:49 --> Config Class Initialized
INFO - 2018-02-13 06:37:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:37:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:37:49 --> Utf8 Class Initialized
INFO - 2018-02-13 06:37:49 --> URI Class Initialized
INFO - 2018-02-13 06:37:49 --> Router Class Initialized
INFO - 2018-02-13 06:37:49 --> Output Class Initialized
INFO - 2018-02-13 06:37:49 --> Security Class Initialized
DEBUG - 2018-02-13 06:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:37:49 --> Input Class Initialized
INFO - 2018-02-13 06:37:49 --> Language Class Initialized
INFO - 2018-02-13 06:37:50 --> Language Class Initialized
INFO - 2018-02-13 06:37:50 --> Config Class Initialized
INFO - 2018-02-13 06:37:50 --> Loader Class Initialized
INFO - 2018-02-13 12:07:50 --> Helper loaded: url_helper
INFO - 2018-02-13 12:07:50 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:07:50 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:07:50 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:07:50 --> Helper loaded: users_helper
INFO - 2018-02-13 12:07:50 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:07:50 --> Helper loaded: form_helper
INFO - 2018-02-13 12:07:50 --> Form Validation Class Initialized
INFO - 2018-02-13 12:07:50 --> Controller Class Initialized
INFO - 2018-02-13 12:07:50 --> Model Class Initialized
INFO - 2018-02-13 12:07:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:07:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:07:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:07:50 --> Model Class Initialized
INFO - 2018-02-13 12:07:50 --> Model Class Initialized
INFO - 2018-02-13 12:07:50 --> Model Class Initialized
INFO - 2018-02-13 12:07:50 --> Model Class Initialized
INFO - 2018-02-13 12:07:50 --> Final output sent to browser
DEBUG - 2018-02-13 12:07:50 --> Total execution time: 0.1121
INFO - 2018-02-13 06:38:40 --> Config Class Initialized
INFO - 2018-02-13 06:38:40 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:40 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:40 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:40 --> URI Class Initialized
INFO - 2018-02-13 06:38:40 --> Router Class Initialized
INFO - 2018-02-13 06:38:40 --> Config Class Initialized
INFO - 2018-02-13 06:38:40 --> Hooks Class Initialized
INFO - 2018-02-13 06:38:40 --> Output Class Initialized
INFO - 2018-02-13 06:38:40 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:40 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:40 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:40 --> URI Class Initialized
DEBUG - 2018-02-13 06:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:40 --> Input Class Initialized
INFO - 2018-02-13 06:38:40 --> Language Class Initialized
INFO - 2018-02-13 06:38:40 --> Router Class Initialized
INFO - 2018-02-13 06:38:40 --> Output Class Initialized
INFO - 2018-02-13 06:38:40 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:40 --> Input Class Initialized
INFO - 2018-02-13 06:38:40 --> Language Class Initialized
INFO - 2018-02-13 06:38:40 --> Language Class Initialized
INFO - 2018-02-13 06:38:40 --> Config Class Initialized
INFO - 2018-02-13 06:38:40 --> Loader Class Initialized
INFO - 2018-02-13 12:08:40 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:40 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:40 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:40 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:40 --> Helper loaded: users_helper
INFO - 2018-02-13 06:38:40 --> Language Class Initialized
INFO - 2018-02-13 06:38:40 --> Config Class Initialized
INFO - 2018-02-13 06:38:40 --> Loader Class Initialized
INFO - 2018-02-13 12:08:40 --> Database Driver Class Initialized
INFO - 2018-02-13 12:08:40 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:40 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:40 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:40 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:40 --> Helper loaded: users_helper
DEBUG - 2018-02-13 12:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:40 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:40 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:40 --> Controller Class Initialized
INFO - 2018-02-13 12:08:40 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:40 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:40 --> Controller Class Initialized
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:40 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:40 --> Total execution time: 0.1078
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:40 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Model Class Initialized
INFO - 2018-02-13 12:08:40 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:40 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:40 --> Total execution time: 0.1166
INFO - 2018-02-13 06:38:45 --> Config Class Initialized
INFO - 2018-02-13 06:38:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:45 --> URI Class Initialized
INFO - 2018-02-13 06:38:45 --> Router Class Initialized
INFO - 2018-02-13 06:38:45 --> Output Class Initialized
INFO - 2018-02-13 06:38:45 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:45 --> Input Class Initialized
INFO - 2018-02-13 06:38:45 --> Language Class Initialized
INFO - 2018-02-13 06:38:45 --> Language Class Initialized
INFO - 2018-02-13 06:38:45 --> Config Class Initialized
INFO - 2018-02-13 06:38:45 --> Loader Class Initialized
INFO - 2018-02-13 12:08:45 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:45 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:45 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:45 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:45 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:45 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:45 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:45 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:45 --> Controller Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:45 --> Model Class Initialized
INFO - 2018-02-13 12:08:45 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:45 --> Total execution time: 0.1533
INFO - 2018-02-13 06:38:46 --> Config Class Initialized
INFO - 2018-02-13 06:38:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:46 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:46 --> URI Class Initialized
INFO - 2018-02-13 06:38:46 --> Router Class Initialized
INFO - 2018-02-13 06:38:46 --> Output Class Initialized
INFO - 2018-02-13 06:38:46 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:46 --> Input Class Initialized
INFO - 2018-02-13 06:38:46 --> Language Class Initialized
INFO - 2018-02-13 06:38:46 --> Language Class Initialized
INFO - 2018-02-13 06:38:46 --> Config Class Initialized
INFO - 2018-02-13 06:38:46 --> Loader Class Initialized
INFO - 2018-02-13 12:08:46 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:46 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:46 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:46 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:46 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:46 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:46 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:46 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:46 --> Controller Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:46 --> Model Class Initialized
INFO - 2018-02-13 12:08:46 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:46 --> Total execution time: 0.1362
INFO - 2018-02-13 06:38:48 --> Config Class Initialized
INFO - 2018-02-13 06:38:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:48 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:48 --> URI Class Initialized
INFO - 2018-02-13 06:38:48 --> Router Class Initialized
INFO - 2018-02-13 06:38:48 --> Output Class Initialized
INFO - 2018-02-13 06:38:48 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:48 --> Input Class Initialized
INFO - 2018-02-13 06:38:48 --> Language Class Initialized
INFO - 2018-02-13 06:38:48 --> Language Class Initialized
INFO - 2018-02-13 06:38:48 --> Config Class Initialized
INFO - 2018-02-13 06:38:48 --> Loader Class Initialized
INFO - 2018-02-13 12:08:48 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:48 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:48 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:48 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:48 --> Controller Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:48 --> Model Class Initialized
INFO - 2018-02-13 12:08:48 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:48 --> Total execution time: 0.1337
INFO - 2018-02-13 06:38:50 --> Config Class Initialized
INFO - 2018-02-13 06:38:50 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:50 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:50 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:50 --> URI Class Initialized
INFO - 2018-02-13 06:38:50 --> Router Class Initialized
INFO - 2018-02-13 06:38:50 --> Output Class Initialized
INFO - 2018-02-13 06:38:50 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:50 --> Input Class Initialized
INFO - 2018-02-13 06:38:50 --> Language Class Initialized
INFO - 2018-02-13 06:38:50 --> Language Class Initialized
INFO - 2018-02-13 06:38:50 --> Config Class Initialized
INFO - 2018-02-13 06:38:50 --> Loader Class Initialized
INFO - 2018-02-13 12:08:50 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:50 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:50 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:50 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:50 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:50 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:50 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:50 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:50 --> Controller Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:50 --> Model Class Initialized
INFO - 2018-02-13 12:08:50 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:50 --> Total execution time: 0.1239
INFO - 2018-02-13 06:38:51 --> Config Class Initialized
INFO - 2018-02-13 06:38:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:51 --> URI Class Initialized
INFO - 2018-02-13 06:38:51 --> Router Class Initialized
INFO - 2018-02-13 06:38:51 --> Output Class Initialized
INFO - 2018-02-13 06:38:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:51 --> Input Class Initialized
INFO - 2018-02-13 06:38:51 --> Language Class Initialized
INFO - 2018-02-13 06:38:51 --> Language Class Initialized
INFO - 2018-02-13 06:38:51 --> Config Class Initialized
INFO - 2018-02-13 06:38:51 --> Loader Class Initialized
INFO - 2018-02-13 12:08:51 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:51 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:51 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:51 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:51 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:51 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:51 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:51 --> Controller Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:51 --> Model Class Initialized
INFO - 2018-02-13 12:08:51 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:51 --> Total execution time: 0.1179
INFO - 2018-02-13 06:38:52 --> Config Class Initialized
INFO - 2018-02-13 06:38:52 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:52 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:52 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:52 --> URI Class Initialized
INFO - 2018-02-13 06:38:52 --> Router Class Initialized
INFO - 2018-02-13 06:38:52 --> Output Class Initialized
INFO - 2018-02-13 06:38:52 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:52 --> Input Class Initialized
INFO - 2018-02-13 06:38:52 --> Language Class Initialized
INFO - 2018-02-13 06:38:52 --> Language Class Initialized
INFO - 2018-02-13 06:38:52 --> Config Class Initialized
INFO - 2018-02-13 06:38:52 --> Loader Class Initialized
INFO - 2018-02-13 12:08:52 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:52 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:52 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:52 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:52 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:52 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:52 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:52 --> Controller Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:52 --> Model Class Initialized
INFO - 2018-02-13 12:08:52 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:52 --> Total execution time: 0.1312
INFO - 2018-02-13 06:38:53 --> Config Class Initialized
INFO - 2018-02-13 06:38:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:53 --> URI Class Initialized
INFO - 2018-02-13 06:38:53 --> Router Class Initialized
INFO - 2018-02-13 06:38:53 --> Output Class Initialized
INFO - 2018-02-13 06:38:53 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:53 --> Input Class Initialized
INFO - 2018-02-13 06:38:53 --> Language Class Initialized
INFO - 2018-02-13 06:38:53 --> Language Class Initialized
INFO - 2018-02-13 06:38:53 --> Config Class Initialized
INFO - 2018-02-13 06:38:53 --> Loader Class Initialized
INFO - 2018-02-13 12:08:53 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:53 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:53 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:53 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:53 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:53 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:53 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:53 --> Controller Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:53 --> Model Class Initialized
INFO - 2018-02-13 12:08:53 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:53 --> Total execution time: 0.1226
INFO - 2018-02-13 06:38:56 --> Config Class Initialized
INFO - 2018-02-13 06:38:56 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:56 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:56 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:56 --> URI Class Initialized
INFO - 2018-02-13 06:38:56 --> Router Class Initialized
INFO - 2018-02-13 06:38:56 --> Output Class Initialized
INFO - 2018-02-13 06:38:56 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:56 --> Input Class Initialized
INFO - 2018-02-13 06:38:56 --> Language Class Initialized
INFO - 2018-02-13 06:38:56 --> Language Class Initialized
INFO - 2018-02-13 06:38:56 --> Config Class Initialized
INFO - 2018-02-13 06:38:56 --> Loader Class Initialized
INFO - 2018-02-13 12:08:56 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:56 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:56 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:56 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:56 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:56 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:56 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:56 --> Controller Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:56 --> Model Class Initialized
INFO - 2018-02-13 12:08:56 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:56 --> Total execution time: 0.1275
INFO - 2018-02-13 06:38:58 --> Config Class Initialized
INFO - 2018-02-13 06:38:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:58 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:58 --> URI Class Initialized
INFO - 2018-02-13 06:38:58 --> Router Class Initialized
INFO - 2018-02-13 06:38:58 --> Output Class Initialized
INFO - 2018-02-13 06:38:58 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:58 --> Input Class Initialized
INFO - 2018-02-13 06:38:58 --> Language Class Initialized
INFO - 2018-02-13 06:38:58 --> Language Class Initialized
INFO - 2018-02-13 06:38:58 --> Config Class Initialized
INFO - 2018-02-13 06:38:58 --> Loader Class Initialized
INFO - 2018-02-13 12:08:58 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:58 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:58 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:58 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:58 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:58 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:58 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:58 --> Controller Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:58 --> Model Class Initialized
INFO - 2018-02-13 12:08:58 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:58 --> Total execution time: 0.1227
INFO - 2018-02-13 06:38:59 --> Config Class Initialized
INFO - 2018-02-13 06:38:59 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:38:59 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:38:59 --> Utf8 Class Initialized
INFO - 2018-02-13 06:38:59 --> URI Class Initialized
INFO - 2018-02-13 06:38:59 --> Router Class Initialized
INFO - 2018-02-13 06:38:59 --> Output Class Initialized
INFO - 2018-02-13 06:38:59 --> Security Class Initialized
DEBUG - 2018-02-13 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:38:59 --> Input Class Initialized
INFO - 2018-02-13 06:38:59 --> Language Class Initialized
INFO - 2018-02-13 06:38:59 --> Language Class Initialized
INFO - 2018-02-13 06:38:59 --> Config Class Initialized
INFO - 2018-02-13 06:38:59 --> Loader Class Initialized
INFO - 2018-02-13 12:08:59 --> Helper loaded: url_helper
INFO - 2018-02-13 12:08:59 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:08:59 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:08:59 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:08:59 --> Helper loaded: users_helper
INFO - 2018-02-13 12:08:59 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:08:59 --> Helper loaded: form_helper
INFO - 2018-02-13 12:08:59 --> Form Validation Class Initialized
INFO - 2018-02-13 12:08:59 --> Controller Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:08:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:08:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:08:59 --> Model Class Initialized
INFO - 2018-02-13 12:08:59 --> Final output sent to browser
DEBUG - 2018-02-13 12:08:59 --> Total execution time: 0.0955
INFO - 2018-02-13 06:39:00 --> Config Class Initialized
INFO - 2018-02-13 06:39:00 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:00 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:00 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:00 --> URI Class Initialized
INFO - 2018-02-13 06:39:00 --> Router Class Initialized
INFO - 2018-02-13 06:39:00 --> Output Class Initialized
INFO - 2018-02-13 06:39:00 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:00 --> Input Class Initialized
INFO - 2018-02-13 06:39:00 --> Language Class Initialized
INFO - 2018-02-13 06:39:00 --> Language Class Initialized
INFO - 2018-02-13 06:39:00 --> Config Class Initialized
INFO - 2018-02-13 06:39:00 --> Loader Class Initialized
INFO - 2018-02-13 12:09:00 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:00 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:00 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:00 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:00 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:00 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:00 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:00 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:00 --> Controller Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:00 --> Model Class Initialized
INFO - 2018-02-13 12:09:00 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:00 --> Total execution time: 0.1280
INFO - 2018-02-13 06:39:01 --> Config Class Initialized
INFO - 2018-02-13 06:39:01 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:01 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:01 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:01 --> URI Class Initialized
INFO - 2018-02-13 06:39:01 --> Router Class Initialized
INFO - 2018-02-13 06:39:01 --> Output Class Initialized
INFO - 2018-02-13 06:39:01 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:01 --> Input Class Initialized
INFO - 2018-02-13 06:39:01 --> Language Class Initialized
INFO - 2018-02-13 06:39:01 --> Language Class Initialized
INFO - 2018-02-13 06:39:01 --> Config Class Initialized
INFO - 2018-02-13 06:39:01 --> Loader Class Initialized
INFO - 2018-02-13 12:09:01 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:01 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:01 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:01 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:01 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:01 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:01 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:01 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:01 --> Controller Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:01 --> Model Class Initialized
INFO - 2018-02-13 12:09:01 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:01 --> Total execution time: 0.1252
INFO - 2018-02-13 06:39:02 --> Config Class Initialized
INFO - 2018-02-13 06:39:02 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:02 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:02 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:02 --> URI Class Initialized
INFO - 2018-02-13 06:39:02 --> Router Class Initialized
INFO - 2018-02-13 06:39:02 --> Output Class Initialized
INFO - 2018-02-13 06:39:02 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:02 --> Input Class Initialized
INFO - 2018-02-13 06:39:02 --> Language Class Initialized
INFO - 2018-02-13 06:39:02 --> Language Class Initialized
INFO - 2018-02-13 06:39:02 --> Config Class Initialized
INFO - 2018-02-13 06:39:02 --> Loader Class Initialized
INFO - 2018-02-13 12:09:02 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:02 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:02 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:02 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:02 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:02 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:02 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:02 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:02 --> Controller Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Model Class Initialized
INFO - 2018-02-13 12:09:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:02 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:02 --> Total execution time: 0.1342
INFO - 2018-02-13 06:39:12 --> Config Class Initialized
INFO - 2018-02-13 06:39:12 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:12 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:12 --> URI Class Initialized
INFO - 2018-02-13 06:39:12 --> Router Class Initialized
INFO - 2018-02-13 06:39:12 --> Output Class Initialized
INFO - 2018-02-13 06:39:12 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:12 --> Input Class Initialized
INFO - 2018-02-13 06:39:12 --> Language Class Initialized
INFO - 2018-02-13 06:39:12 --> Language Class Initialized
INFO - 2018-02-13 06:39:12 --> Config Class Initialized
INFO - 2018-02-13 06:39:12 --> Loader Class Initialized
INFO - 2018-02-13 12:09:12 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:12 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:12 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:12 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:12 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:12 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:12 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:12 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:12 --> Controller Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:12 --> Model Class Initialized
INFO - 2018-02-13 12:09:12 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:12 --> Total execution time: 0.1335
INFO - 2018-02-13 06:39:15 --> Config Class Initialized
INFO - 2018-02-13 06:39:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:15 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:15 --> URI Class Initialized
INFO - 2018-02-13 06:39:15 --> Router Class Initialized
INFO - 2018-02-13 06:39:15 --> Output Class Initialized
INFO - 2018-02-13 06:39:15 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:15 --> Input Class Initialized
INFO - 2018-02-13 06:39:15 --> Language Class Initialized
INFO - 2018-02-13 06:39:15 --> Language Class Initialized
INFO - 2018-02-13 06:39:15 --> Config Class Initialized
INFO - 2018-02-13 06:39:15 --> Loader Class Initialized
INFO - 2018-02-13 12:09:15 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:15 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:15 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:15 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:15 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:15 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:15 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:15 --> Controller Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:15 --> Model Class Initialized
INFO - 2018-02-13 12:09:15 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:15 --> Total execution time: 0.1301
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:19 --> URI Class Initialized
INFO - 2018-02-13 06:39:19 --> Router Class Initialized
INFO - 2018-02-13 06:39:19 --> Output Class Initialized
INFO - 2018-02-13 06:39:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:19 --> Input Class Initialized
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Loader Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:19 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:19 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:19 --> Controller Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 79
INFO - 2018-02-13 12:09:19 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:19 --> Total execution time: 0.1178
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Hooks Class Initialized
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:19 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:39:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:19 --> URI Class Initialized
INFO - 2018-02-13 06:39:19 --> URI Class Initialized
INFO - 2018-02-13 06:39:19 --> Router Class Initialized
INFO - 2018-02-13 06:39:19 --> Router Class Initialized
INFO - 2018-02-13 06:39:19 --> Output Class Initialized
INFO - 2018-02-13 06:39:19 --> Output Class Initialized
INFO - 2018-02-13 06:39:19 --> Security Class Initialized
INFO - 2018-02-13 06:39:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:19 --> Input Class Initialized
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:19 --> Input Class Initialized
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
DEBUG - 2018-02-13 06:39:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:19 --> URI Class Initialized
INFO - 2018-02-13 06:39:19 --> Router Class Initialized
INFO - 2018-02-13 06:39:19 --> Output Class Initialized
INFO - 2018-02-13 06:39:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:19 --> Input Class Initialized
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Loader Class Initialized
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Loader Class Initialized
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: users_helper
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Loader Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:19 --> Database Driver Class Initialized
INFO - 2018-02-13 12:09:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 12:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:19 --> Database Driver Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:19 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:19 --> Controller Class Initialized
DEBUG - 2018-02-13 12:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 289
INFO - 2018-02-13 12:09:19 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:19 --> Total execution time: 0.1076
INFO - 2018-02-13 12:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:19 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:19 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:19 --> Controller Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 147
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 189
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 227
INFO - 2018-02-13 12:09:19 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:19 --> Total execution time: 0.1472
INFO - 2018-02-13 12:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:19 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:19 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:19 --> Controller Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: inflector_helper
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 12:09:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:19 --> Language file loaded: language/english/rest_controller_lang.php
DEBUG - 2018-02-13 06:39:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:19 --> Utf8 Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 06:39:19 --> URI Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 06:39:19 --> Router Class Initialized
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 349
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 389
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 427
INFO - 2018-02-13 12:09:19 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:19 --> Total execution time: 0.1608
INFO - 2018-02-13 06:39:19 --> Output Class Initialized
INFO - 2018-02-13 06:39:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:19 --> Input Class Initialized
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
INFO - 2018-02-13 06:39:19 --> Language Class Initialized
INFO - 2018-02-13 06:39:19 --> Config Class Initialized
INFO - 2018-02-13 06:39:19 --> Loader Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:19 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:19 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:19 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:19 --> Controller Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
INFO - 2018-02-13 12:09:19 --> Model Class Initialized
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
ERROR - 2018-02-13 12:09:19 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/FilterOption.php 625
INFO - 2018-02-13 12:09:19 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:19 --> Total execution time: 0.0849
INFO - 2018-02-13 06:39:20 --> Config Class Initialized
INFO - 2018-02-13 06:39:20 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:20 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:20 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:20 --> URI Class Initialized
INFO - 2018-02-13 06:39:20 --> Router Class Initialized
INFO - 2018-02-13 06:39:20 --> Output Class Initialized
INFO - 2018-02-13 06:39:20 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:20 --> Input Class Initialized
INFO - 2018-02-13 06:39:20 --> Language Class Initialized
INFO - 2018-02-13 06:39:20 --> Language Class Initialized
INFO - 2018-02-13 06:39:20 --> Config Class Initialized
INFO - 2018-02-13 06:39:20 --> Loader Class Initialized
INFO - 2018-02-13 12:09:20 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:20 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:20 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:20 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:20 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:20 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:20 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:20 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:20 --> Controller Class Initialized
INFO - 2018-02-13 12:09:20 --> Model Class Initialized
INFO - 2018-02-13 12:09:20 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:20 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:20 --> Model Class Initialized
INFO - 2018-02-13 12:09:20 --> Model Class Initialized
INFO - 2018-02-13 12:09:20 --> Model Class Initialized
INFO - 2018-02-13 12:09:20 --> Model Class Initialized
INFO - 2018-02-13 12:09:20 --> Model Class Initialized
INFO - 2018-02-13 12:09:20 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:20 --> Total execution time: 0.1081
INFO - 2018-02-13 06:39:22 --> Config Class Initialized
INFO - 2018-02-13 06:39:22 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:22 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:22 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:22 --> URI Class Initialized
INFO - 2018-02-13 06:39:22 --> Router Class Initialized
INFO - 2018-02-13 06:39:22 --> Output Class Initialized
INFO - 2018-02-13 06:39:22 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:22 --> Input Class Initialized
INFO - 2018-02-13 06:39:22 --> Language Class Initialized
INFO - 2018-02-13 06:39:22 --> Language Class Initialized
INFO - 2018-02-13 06:39:22 --> Config Class Initialized
INFO - 2018-02-13 06:39:22 --> Loader Class Initialized
INFO - 2018-02-13 12:09:22 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:22 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:22 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:22 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:22 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:22 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:22 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:22 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:22 --> Controller Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:22 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:22 --> Model Class Initialized
INFO - 2018-02-13 12:09:22 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:22 --> Total execution time: 0.1278
INFO - 2018-02-13 06:39:23 --> Config Class Initialized
INFO - 2018-02-13 06:39:23 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:23 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:23 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:23 --> URI Class Initialized
INFO - 2018-02-13 06:39:23 --> Router Class Initialized
INFO - 2018-02-13 06:39:23 --> Output Class Initialized
INFO - 2018-02-13 06:39:23 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:23 --> Input Class Initialized
INFO - 2018-02-13 06:39:23 --> Language Class Initialized
INFO - 2018-02-13 06:39:23 --> Language Class Initialized
INFO - 2018-02-13 06:39:23 --> Config Class Initialized
INFO - 2018-02-13 06:39:23 --> Loader Class Initialized
INFO - 2018-02-13 12:09:23 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:23 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:23 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:23 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:23 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:23 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:23 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:23 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:23 --> Controller Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:23 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:23 --> Model Class Initialized
INFO - 2018-02-13 12:09:23 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:23 --> Total execution time: 0.1307
INFO - 2018-02-13 06:39:25 --> Config Class Initialized
INFO - 2018-02-13 06:39:25 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:25 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:25 --> URI Class Initialized
INFO - 2018-02-13 06:39:25 --> Router Class Initialized
INFO - 2018-02-13 06:39:25 --> Output Class Initialized
INFO - 2018-02-13 06:39:25 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:25 --> Input Class Initialized
INFO - 2018-02-13 06:39:25 --> Language Class Initialized
INFO - 2018-02-13 06:39:25 --> Language Class Initialized
INFO - 2018-02-13 06:39:25 --> Config Class Initialized
INFO - 2018-02-13 06:39:25 --> Loader Class Initialized
INFO - 2018-02-13 12:09:25 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:25 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:25 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:25 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:25 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:25 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:25 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:25 --> Controller Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:25 --> Model Class Initialized
INFO - 2018-02-13 12:09:25 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:25 --> Total execution time: 0.1228
INFO - 2018-02-13 06:39:26 --> Config Class Initialized
INFO - 2018-02-13 06:39:26 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:27 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:27 --> URI Class Initialized
INFO - 2018-02-13 06:39:27 --> Router Class Initialized
INFO - 2018-02-13 06:39:27 --> Output Class Initialized
INFO - 2018-02-13 06:39:27 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:27 --> Input Class Initialized
INFO - 2018-02-13 06:39:27 --> Language Class Initialized
INFO - 2018-02-13 06:39:27 --> Language Class Initialized
INFO - 2018-02-13 06:39:27 --> Config Class Initialized
INFO - 2018-02-13 06:39:27 --> Loader Class Initialized
INFO - 2018-02-13 12:09:27 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:27 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:27 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:27 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:27 --> Controller Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:27 --> Total execution time: 0.1294
INFO - 2018-02-13 06:39:27 --> Config Class Initialized
INFO - 2018-02-13 06:39:27 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:27 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:27 --> URI Class Initialized
INFO - 2018-02-13 06:39:27 --> Router Class Initialized
INFO - 2018-02-13 06:39:27 --> Output Class Initialized
INFO - 2018-02-13 06:39:27 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:27 --> Input Class Initialized
INFO - 2018-02-13 06:39:27 --> Language Class Initialized
INFO - 2018-02-13 06:39:27 --> Language Class Initialized
INFO - 2018-02-13 06:39:27 --> Config Class Initialized
INFO - 2018-02-13 06:39:27 --> Loader Class Initialized
INFO - 2018-02-13 12:09:27 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:27 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:27 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:27 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:27 --> Controller Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:27 --> Model Class Initialized
INFO - 2018-02-13 12:09:28 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:28 --> Total execution time: 0.1241
INFO - 2018-02-13 06:39:29 --> Config Class Initialized
INFO - 2018-02-13 06:39:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:29 --> URI Class Initialized
INFO - 2018-02-13 06:39:29 --> Router Class Initialized
INFO - 2018-02-13 06:39:29 --> Output Class Initialized
INFO - 2018-02-13 06:39:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:29 --> Input Class Initialized
INFO - 2018-02-13 06:39:29 --> Language Class Initialized
INFO - 2018-02-13 06:39:29 --> Language Class Initialized
INFO - 2018-02-13 06:39:29 --> Config Class Initialized
INFO - 2018-02-13 06:39:29 --> Loader Class Initialized
INFO - 2018-02-13 12:09:29 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:29 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:29 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:29 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:29 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:29 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:29 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:29 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:29 --> Controller Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Model Class Initialized
INFO - 2018-02-13 12:09:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:29 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:29 --> Total execution time: 0.1256
INFO - 2018-02-13 06:39:30 --> Config Class Initialized
INFO - 2018-02-13 06:39:30 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:30 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:30 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:30 --> URI Class Initialized
INFO - 2018-02-13 06:39:30 --> Router Class Initialized
INFO - 2018-02-13 06:39:30 --> Output Class Initialized
INFO - 2018-02-13 06:39:30 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:30 --> Input Class Initialized
INFO - 2018-02-13 06:39:30 --> Language Class Initialized
INFO - 2018-02-13 06:39:30 --> Language Class Initialized
INFO - 2018-02-13 06:39:30 --> Config Class Initialized
INFO - 2018-02-13 06:39:30 --> Loader Class Initialized
INFO - 2018-02-13 12:09:30 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:30 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:30 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:30 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:30 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:30 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:30 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:30 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:30 --> Controller Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:30 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Model Class Initialized
INFO - 2018-02-13 12:09:30 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:30 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:30 --> Total execution time: 0.1182
INFO - 2018-02-13 06:39:33 --> Config Class Initialized
INFO - 2018-02-13 06:39:33 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:33 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:33 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:33 --> URI Class Initialized
INFO - 2018-02-13 06:39:33 --> Router Class Initialized
INFO - 2018-02-13 06:39:33 --> Output Class Initialized
INFO - 2018-02-13 06:39:33 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:33 --> Input Class Initialized
INFO - 2018-02-13 06:39:33 --> Language Class Initialized
INFO - 2018-02-13 06:39:33 --> Language Class Initialized
INFO - 2018-02-13 06:39:33 --> Config Class Initialized
INFO - 2018-02-13 06:39:33 --> Loader Class Initialized
INFO - 2018-02-13 12:09:33 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:33 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:33 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:33 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:33 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:33 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:33 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:33 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:33 --> Controller Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:33 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Model Class Initialized
INFO - 2018-02-13 12:09:33 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:33 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:33 --> Total execution time: 0.1195
INFO - 2018-02-13 06:39:35 --> Config Class Initialized
INFO - 2018-02-13 06:39:35 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:35 --> URI Class Initialized
INFO - 2018-02-13 06:39:35 --> Router Class Initialized
INFO - 2018-02-13 06:39:35 --> Output Class Initialized
INFO - 2018-02-13 06:39:35 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:35 --> Input Class Initialized
INFO - 2018-02-13 06:39:35 --> Language Class Initialized
INFO - 2018-02-13 06:39:36 --> Language Class Initialized
INFO - 2018-02-13 06:39:36 --> Config Class Initialized
INFO - 2018-02-13 06:39:36 --> Loader Class Initialized
INFO - 2018-02-13 12:09:36 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:36 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:36 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:36 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:36 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:36 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:36 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:36 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:36 --> Controller Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:36 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Model Class Initialized
INFO - 2018-02-13 12:09:36 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:36 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:36 --> Total execution time: 0.0957
INFO - 2018-02-13 06:39:36 --> Config Class Initialized
INFO - 2018-02-13 06:39:36 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:36 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:36 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:36 --> URI Class Initialized
INFO - 2018-02-13 06:39:36 --> Router Class Initialized
INFO - 2018-02-13 06:39:36 --> Output Class Initialized
INFO - 2018-02-13 06:39:36 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:36 --> Input Class Initialized
INFO - 2018-02-13 06:39:36 --> Language Class Initialized
INFO - 2018-02-13 06:39:36 --> Language Class Initialized
INFO - 2018-02-13 06:39:36 --> Config Class Initialized
INFO - 2018-02-13 06:39:36 --> Loader Class Initialized
INFO - 2018-02-13 12:09:36 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:36 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:36 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:36 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:36 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:37 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:37 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:37 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:37 --> Controller Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:37 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Model Class Initialized
INFO - 2018-02-13 12:09:37 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:37 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:37 --> Total execution time: 0.1304
INFO - 2018-02-13 06:39:38 --> Config Class Initialized
INFO - 2018-02-13 06:39:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:38 --> URI Class Initialized
INFO - 2018-02-13 06:39:38 --> Router Class Initialized
INFO - 2018-02-13 06:39:38 --> Output Class Initialized
INFO - 2018-02-13 06:39:38 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:38 --> Input Class Initialized
INFO - 2018-02-13 06:39:38 --> Language Class Initialized
INFO - 2018-02-13 06:39:38 --> Language Class Initialized
INFO - 2018-02-13 06:39:38 --> Config Class Initialized
INFO - 2018-02-13 06:39:38 --> Loader Class Initialized
INFO - 2018-02-13 12:09:38 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:38 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:38 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:38 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:38 --> Controller Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Model Class Initialized
INFO - 2018-02-13 12:09:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:38 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:38 --> Total execution time: 0.1076
INFO - 2018-02-13 06:39:40 --> Config Class Initialized
INFO - 2018-02-13 06:39:40 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:40 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:40 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:40 --> URI Class Initialized
INFO - 2018-02-13 06:39:40 --> Router Class Initialized
INFO - 2018-02-13 06:39:40 --> Output Class Initialized
INFO - 2018-02-13 06:39:40 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:40 --> Input Class Initialized
INFO - 2018-02-13 06:39:40 --> Language Class Initialized
INFO - 2018-02-13 06:39:40 --> Language Class Initialized
INFO - 2018-02-13 06:39:40 --> Config Class Initialized
INFO - 2018-02-13 06:39:40 --> Loader Class Initialized
INFO - 2018-02-13 12:09:40 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:40 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:40 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:40 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:40 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:40 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:41 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:41 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:41 --> Controller Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:41 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Model Class Initialized
INFO - 2018-02-13 12:09:41 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:41 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:41 --> Total execution time: 0.1233
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:42 --> URI Class Initialized
INFO - 2018-02-13 06:39:42 --> Router Class Initialized
INFO - 2018-02-13 06:39:42 --> Output Class Initialized
INFO - 2018-02-13 06:39:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:42 --> Input Class Initialized
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Loader Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:42 --> Controller Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:42 --> Total execution time: 0.1062
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:42 --> URI Class Initialized
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:42 --> Router Class Initialized
INFO - 2018-02-13 06:39:42 --> URI Class Initialized
INFO - 2018-02-13 06:39:42 --> Output Class Initialized
INFO - 2018-02-13 06:39:42 --> Security Class Initialized
INFO - 2018-02-13 06:39:42 --> Router Class Initialized
DEBUG - 2018-02-13 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:42 --> Input Class Initialized
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 06:39:42 --> Output Class Initialized
INFO - 2018-02-13 06:39:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:42 --> Input Class Initialized
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:42 --> URI Class Initialized
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Loader Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 06:39:42 --> Router Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: users_helper
INFO - 2018-02-13 06:39:42 --> Output Class Initialized
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Loader Class Initialized
INFO - 2018-02-13 06:39:42 --> Security Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: settings_helper
DEBUG - 2018-02-13 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:42 --> Input Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:42 --> Database Driver Class Initialized
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Loader Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:42 --> Controller Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: settings_helper
DEBUG - 2018-02-13 12:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:42 --> Total execution time: 0.0973
INFO - 2018-02-13 12:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:42 --> Controller Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:42 --> Total execution time: 0.1281
INFO - 2018-02-13 12:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Hooks Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:42 --> Controller Class Initialized
DEBUG - 2018-02-13 06:39:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:42 --> URI Class Initialized
INFO - 2018-02-13 06:39:42 --> Router Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 06:39:42 --> Output Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: inflector_helper
INFO - 2018-02-13 06:39:42 --> Security Class Initialized
DEBUG - 2018-02-13 12:09:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-13 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:42 --> Input Class Initialized
INFO - 2018-02-13 12:09:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:42 --> Total execution time: 0.1413
INFO - 2018-02-13 06:39:42 --> Language Class Initialized
INFO - 2018-02-13 06:39:42 --> Config Class Initialized
INFO - 2018-02-13 06:39:42 --> Loader Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:42 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:42 --> Controller Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Model Class Initialized
INFO - 2018-02-13 12:09:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:42 --> Total execution time: 0.0912
INFO - 2018-02-13 06:39:49 --> Config Class Initialized
INFO - 2018-02-13 06:39:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:49 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:49 --> URI Class Initialized
INFO - 2018-02-13 06:39:49 --> Router Class Initialized
INFO - 2018-02-13 06:39:49 --> Output Class Initialized
INFO - 2018-02-13 06:39:49 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:49 --> Input Class Initialized
INFO - 2018-02-13 06:39:49 --> Language Class Initialized
INFO - 2018-02-13 06:39:49 --> Language Class Initialized
INFO - 2018-02-13 06:39:49 --> Config Class Initialized
INFO - 2018-02-13 06:39:49 --> Loader Class Initialized
INFO - 2018-02-13 12:09:49 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:49 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:49 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:49 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:49 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:49 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:49 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:49 --> Controller Class Initialized
INFO - 2018-02-13 12:09:49 --> Model Class Initialized
INFO - 2018-02-13 12:09:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:49 --> Model Class Initialized
INFO - 2018-02-13 12:09:49 --> Model Class Initialized
INFO - 2018-02-13 12:09:49 --> Model Class Initialized
INFO - 2018-02-13 12:09:49 --> Model Class Initialized
INFO - 2018-02-13 12:09:49 --> Model Class Initialized
INFO - 2018-02-13 12:09:49 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:49 --> Total execution time: 0.1229
INFO - 2018-02-13 06:39:51 --> Config Class Initialized
INFO - 2018-02-13 06:39:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:51 --> URI Class Initialized
INFO - 2018-02-13 06:39:51 --> Router Class Initialized
INFO - 2018-02-13 06:39:51 --> Output Class Initialized
INFO - 2018-02-13 06:39:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:51 --> Input Class Initialized
INFO - 2018-02-13 06:39:51 --> Language Class Initialized
INFO - 2018-02-13 06:39:51 --> Language Class Initialized
INFO - 2018-02-13 06:39:51 --> Config Class Initialized
INFO - 2018-02-13 06:39:51 --> Loader Class Initialized
INFO - 2018-02-13 12:09:51 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:51 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:51 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:51 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:51 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:51 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:51 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:51 --> Controller Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Model Class Initialized
INFO - 2018-02-13 12:09:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:51 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:51 --> Total execution time: 0.0937
INFO - 2018-02-13 06:39:52 --> Config Class Initialized
INFO - 2018-02-13 06:39:52 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:52 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:52 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:52 --> URI Class Initialized
INFO - 2018-02-13 06:39:52 --> Router Class Initialized
INFO - 2018-02-13 06:39:52 --> Output Class Initialized
INFO - 2018-02-13 06:39:52 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:52 --> Input Class Initialized
INFO - 2018-02-13 06:39:52 --> Language Class Initialized
INFO - 2018-02-13 06:39:52 --> Language Class Initialized
INFO - 2018-02-13 06:39:52 --> Config Class Initialized
INFO - 2018-02-13 06:39:52 --> Loader Class Initialized
INFO - 2018-02-13 12:09:52 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:52 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:52 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:52 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:52 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:52 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:52 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:52 --> Controller Class Initialized
INFO - 2018-02-13 12:09:52 --> Model Class Initialized
INFO - 2018-02-13 12:09:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:53 --> Total execution time: 0.1014
INFO - 2018-02-13 06:39:53 --> Config Class Initialized
INFO - 2018-02-13 06:39:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:53 --> URI Class Initialized
INFO - 2018-02-13 06:39:53 --> Router Class Initialized
INFO - 2018-02-13 06:39:53 --> Output Class Initialized
INFO - 2018-02-13 06:39:53 --> Config Class Initialized
INFO - 2018-02-13 06:39:53 --> Hooks Class Initialized
INFO - 2018-02-13 06:39:53 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:53 --> Input Class Initialized
DEBUG - 2018-02-13 06:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:53 --> Language Class Initialized
INFO - 2018-02-13 06:39:53 --> URI Class Initialized
INFO - 2018-02-13 06:39:53 --> Config Class Initialized
INFO - 2018-02-13 06:39:53 --> Hooks Class Initialized
INFO - 2018-02-13 06:39:53 --> Router Class Initialized
DEBUG - 2018-02-13 06:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:53 --> URI Class Initialized
INFO - 2018-02-13 06:39:53 --> Output Class Initialized
INFO - 2018-02-13 06:39:53 --> Security Class Initialized
INFO - 2018-02-13 06:39:53 --> Router Class Initialized
DEBUG - 2018-02-13 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:53 --> Input Class Initialized
INFO - 2018-02-13 06:39:53 --> Language Class Initialized
INFO - 2018-02-13 06:39:53 --> Language Class Initialized
INFO - 2018-02-13 06:39:53 --> Config Class Initialized
INFO - 2018-02-13 06:39:53 --> Loader Class Initialized
INFO - 2018-02-13 06:39:53 --> Output Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: url_helper
INFO - 2018-02-13 06:39:53 --> Security Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: permission_helper
DEBUG - 2018-02-13 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:53 --> Input Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: users_helper
INFO - 2018-02-13 06:39:53 --> Language Class Initialized
INFO - 2018-02-13 06:39:53 --> Language Class Initialized
INFO - 2018-02-13 06:39:53 --> Config Class Initialized
INFO - 2018-02-13 06:39:53 --> Loader Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:53 --> Database Driver Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: notification_helper
INFO - 2018-02-13 06:39:53 --> Language Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: settings_helper
INFO - 2018-02-13 06:39:53 --> Config Class Initialized
INFO - 2018-02-13 06:39:53 --> Loader Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: notification_helper
DEBUG - 2018-02-13 12:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:53 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:53 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:53 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:53 --> Controller Class Initialized
INFO - 2018-02-13 12:09:53 --> Database Driver Class Initialized
INFO - 2018-02-13 12:09:53 --> Database Driver Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 12:09:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-13 12:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:53 --> Total execution time: 0.1093
INFO - 2018-02-13 12:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:53 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:53 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:53 --> Controller Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:53 --> Total execution time: 0.1298
INFO - 2018-02-13 12:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:53 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:53 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:53 --> Controller Class Initialized
INFO - 2018-02-13 06:39:53 --> Config Class Initialized
INFO - 2018-02-13 06:39:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:53 --> URI Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: inflector_helper
INFO - 2018-02-13 06:39:53 --> Router Class Initialized
DEBUG - 2018-02-13 12:09:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 06:39:53 --> Output Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 06:39:53 --> Security Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
DEBUG - 2018-02-13 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:53 --> Input Class Initialized
INFO - 2018-02-13 12:09:53 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:53 --> Total execution time: 0.1554
INFO - 2018-02-13 06:39:53 --> Language Class Initialized
INFO - 2018-02-13 06:39:53 --> Language Class Initialized
INFO - 2018-02-13 06:39:53 --> Config Class Initialized
INFO - 2018-02-13 06:39:53 --> Loader Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:53 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:53 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:53 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:53 --> Controller Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Model Class Initialized
INFO - 2018-02-13 12:09:53 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:53 --> Total execution time: 0.1094
INFO - 2018-02-13 06:39:57 --> Config Class Initialized
INFO - 2018-02-13 06:39:57 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:57 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:57 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:57 --> URI Class Initialized
INFO - 2018-02-13 06:39:57 --> Router Class Initialized
INFO - 2018-02-13 06:39:57 --> Output Class Initialized
INFO - 2018-02-13 06:39:57 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:57 --> Input Class Initialized
INFO - 2018-02-13 06:39:57 --> Language Class Initialized
INFO - 2018-02-13 06:39:57 --> Language Class Initialized
INFO - 2018-02-13 06:39:57 --> Config Class Initialized
INFO - 2018-02-13 06:39:57 --> Loader Class Initialized
INFO - 2018-02-13 12:09:57 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:57 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:57 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:57 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:57 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:57 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:57 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:57 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:57 --> Controller Class Initialized
INFO - 2018-02-13 12:09:57 --> Model Class Initialized
INFO - 2018-02-13 12:09:57 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:57 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:57 --> Model Class Initialized
INFO - 2018-02-13 12:09:57 --> Model Class Initialized
INFO - 2018-02-13 12:09:57 --> Model Class Initialized
INFO - 2018-02-13 12:09:57 --> Model Class Initialized
INFO - 2018-02-13 12:09:57 --> Model Class Initialized
INFO - 2018-02-13 12:09:57 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:57 --> Total execution time: 0.0980
INFO - 2018-02-13 06:39:59 --> Config Class Initialized
INFO - 2018-02-13 06:39:59 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:39:59 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:39:59 --> Utf8 Class Initialized
INFO - 2018-02-13 06:39:59 --> URI Class Initialized
INFO - 2018-02-13 06:39:59 --> Router Class Initialized
INFO - 2018-02-13 06:39:59 --> Output Class Initialized
INFO - 2018-02-13 06:39:59 --> Security Class Initialized
DEBUG - 2018-02-13 06:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:39:59 --> Input Class Initialized
INFO - 2018-02-13 06:39:59 --> Language Class Initialized
INFO - 2018-02-13 06:39:59 --> Language Class Initialized
INFO - 2018-02-13 06:39:59 --> Config Class Initialized
INFO - 2018-02-13 06:39:59 --> Loader Class Initialized
INFO - 2018-02-13 12:09:59 --> Helper loaded: url_helper
INFO - 2018-02-13 12:09:59 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:09:59 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:09:59 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:09:59 --> Helper loaded: users_helper
INFO - 2018-02-13 12:09:59 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:09:59 --> Helper loaded: form_helper
INFO - 2018-02-13 12:09:59 --> Form Validation Class Initialized
INFO - 2018-02-13 12:09:59 --> Controller Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:09:59 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:09:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Model Class Initialized
INFO - 2018-02-13 12:09:59 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:09:59 --> Final output sent to browser
DEBUG - 2018-02-13 12:09:59 --> Total execution time: 0.1305
INFO - 2018-02-13 06:40:00 --> Config Class Initialized
INFO - 2018-02-13 06:40:00 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:00 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:00 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:00 --> URI Class Initialized
INFO - 2018-02-13 06:40:00 --> Router Class Initialized
INFO - 2018-02-13 06:40:00 --> Output Class Initialized
INFO - 2018-02-13 06:40:00 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:00 --> Input Class Initialized
INFO - 2018-02-13 06:40:00 --> Language Class Initialized
INFO - 2018-02-13 06:40:00 --> Language Class Initialized
INFO - 2018-02-13 06:40:00 --> Config Class Initialized
INFO - 2018-02-13 06:40:00 --> Loader Class Initialized
INFO - 2018-02-13 12:10:00 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:00 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:00 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:00 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:00 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:00 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:00 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:00 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:00 --> Controller Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:00 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Model Class Initialized
INFO - 2018-02-13 12:10:00 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:10:00 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:00 --> Total execution time: 0.1082
INFO - 2018-02-13 06:40:01 --> Config Class Initialized
INFO - 2018-02-13 06:40:01 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:01 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:01 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:01 --> URI Class Initialized
INFO - 2018-02-13 06:40:01 --> Router Class Initialized
INFO - 2018-02-13 06:40:01 --> Output Class Initialized
INFO - 2018-02-13 06:40:01 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:01 --> Input Class Initialized
INFO - 2018-02-13 06:40:01 --> Language Class Initialized
INFO - 2018-02-13 06:40:01 --> Language Class Initialized
INFO - 2018-02-13 06:40:01 --> Config Class Initialized
INFO - 2018-02-13 06:40:01 --> Loader Class Initialized
INFO - 2018-02-13 12:10:01 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:01 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:01 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:01 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:01 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:01 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:01 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:01 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:01 --> Controller Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:10:01 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:02 --> Total execution time: 0.1405
INFO - 2018-02-13 06:40:02 --> Config Class Initialized
INFO - 2018-02-13 06:40:02 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:02 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:02 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:02 --> URI Class Initialized
INFO - 2018-02-13 06:40:02 --> Router Class Initialized
INFO - 2018-02-13 06:40:02 --> Output Class Initialized
INFO - 2018-02-13 06:40:02 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:02 --> Input Class Initialized
INFO - 2018-02-13 06:40:02 --> Language Class Initialized
INFO - 2018-02-13 06:40:02 --> Language Class Initialized
INFO - 2018-02-13 06:40:02 --> Config Class Initialized
INFO - 2018-02-13 06:40:02 --> Loader Class Initialized
INFO - 2018-02-13 12:10:02 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:02 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:02 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:02 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:02 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:02 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:02 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:02 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:02 --> Controller Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:02 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:10:02 --> Model Class Initialized
INFO - 2018-02-13 12:10:02 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:02 --> Total execution time: 0.1262
INFO - 2018-02-13 06:40:04 --> Config Class Initialized
INFO - 2018-02-13 06:40:04 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:04 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:04 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:04 --> URI Class Initialized
INFO - 2018-02-13 06:40:04 --> Router Class Initialized
INFO - 2018-02-13 06:40:04 --> Output Class Initialized
INFO - 2018-02-13 06:40:04 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:04 --> Input Class Initialized
INFO - 2018-02-13 06:40:04 --> Language Class Initialized
INFO - 2018-02-13 06:40:04 --> Language Class Initialized
INFO - 2018-02-13 06:40:04 --> Config Class Initialized
INFO - 2018-02-13 06:40:04 --> Loader Class Initialized
INFO - 2018-02-13 12:10:04 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:04 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:04 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:04 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:04 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:04 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:04 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:04 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:04 --> Controller Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:04 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:10:04 --> Model Class Initialized
INFO - 2018-02-13 12:10:04 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:04 --> Total execution time: 0.1333
INFO - 2018-02-13 06:40:07 --> Config Class Initialized
INFO - 2018-02-13 06:40:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:07 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:07 --> URI Class Initialized
INFO - 2018-02-13 06:40:07 --> Router Class Initialized
INFO - 2018-02-13 06:40:07 --> Output Class Initialized
INFO - 2018-02-13 06:40:07 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:07 --> Input Class Initialized
INFO - 2018-02-13 06:40:07 --> Language Class Initialized
INFO - 2018-02-13 06:40:07 --> Language Class Initialized
INFO - 2018-02-13 06:40:07 --> Config Class Initialized
INFO - 2018-02-13 06:40:07 --> Loader Class Initialized
INFO - 2018-02-13 12:10:07 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:07 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:07 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:07 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:07 --> Controller Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:10:07 --> Model Class Initialized
INFO - 2018-02-13 12:10:07 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:07 --> Total execution time: 0.0977
INFO - 2018-02-13 06:40:12 --> Config Class Initialized
INFO - 2018-02-13 06:40:12 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:12 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:12 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:12 --> URI Class Initialized
INFO - 2018-02-13 06:40:12 --> Router Class Initialized
INFO - 2018-02-13 06:40:12 --> Output Class Initialized
INFO - 2018-02-13 06:40:12 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:12 --> Input Class Initialized
INFO - 2018-02-13 06:40:12 --> Language Class Initialized
INFO - 2018-02-13 06:40:12 --> Language Class Initialized
INFO - 2018-02-13 06:40:12 --> Config Class Initialized
INFO - 2018-02-13 06:40:12 --> Loader Class Initialized
INFO - 2018-02-13 12:10:12 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:12 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:12 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:12 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:12 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:12 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:12 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:12 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:12 --> Controller Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:12 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:10:12 --> Model Class Initialized
INFO - 2018-02-13 12:10:12 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:12 --> Total execution time: 0.1431
INFO - 2018-02-13 06:40:13 --> Config Class Initialized
INFO - 2018-02-13 06:40:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:13 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:13 --> URI Class Initialized
INFO - 2018-02-13 06:40:13 --> Router Class Initialized
INFO - 2018-02-13 06:40:13 --> Output Class Initialized
INFO - 2018-02-13 06:40:13 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:13 --> Input Class Initialized
INFO - 2018-02-13 06:40:13 --> Language Class Initialized
INFO - 2018-02-13 06:40:13 --> Language Class Initialized
INFO - 2018-02-13 06:40:13 --> Config Class Initialized
INFO - 2018-02-13 06:40:13 --> Loader Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:13 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:13 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:13 --> Controller Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:13 --> Total execution time: 0.1064
INFO - 2018-02-13 06:40:13 --> Config Class Initialized
INFO - 2018-02-13 06:40:13 --> Hooks Class Initialized
INFO - 2018-02-13 06:40:13 --> Config Class Initialized
INFO - 2018-02-13 06:40:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:13 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:13 --> URI Class Initialized
DEBUG - 2018-02-13 06:40:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:13 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:13 --> URI Class Initialized
INFO - 2018-02-13 06:40:13 --> Router Class Initialized
INFO - 2018-02-13 06:40:13 --> Router Class Initialized
INFO - 2018-02-13 06:40:13 --> Output Class Initialized
INFO - 2018-02-13 06:40:13 --> Output Class Initialized
INFO - 2018-02-13 06:40:13 --> Security Class Initialized
INFO - 2018-02-13 06:40:13 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:13 --> Input Class Initialized
INFO - 2018-02-13 06:40:13 --> Language Class Initialized
DEBUG - 2018-02-13 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:13 --> Input Class Initialized
INFO - 2018-02-13 06:40:13 --> Language Class Initialized
INFO - 2018-02-13 06:40:13 --> Config Class Initialized
INFO - 2018-02-13 06:40:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:13 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:13 --> URI Class Initialized
INFO - 2018-02-13 06:40:13 --> Language Class Initialized
INFO - 2018-02-13 06:40:13 --> Config Class Initialized
INFO - 2018-02-13 06:40:13 --> Loader Class Initialized
INFO - 2018-02-13 06:40:13 --> Router Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: url_helper
INFO - 2018-02-13 06:40:13 --> Language Class Initialized
INFO - 2018-02-13 06:40:13 --> Config Class Initialized
INFO - 2018-02-13 06:40:13 --> Loader Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: settings_helper
INFO - 2018-02-13 06:40:13 --> Output Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: url_helper
INFO - 2018-02-13 06:40:13 --> Security Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: permission_helper
DEBUG - 2018-02-13 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:13 --> Input Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: users_helper
INFO - 2018-02-13 06:40:13 --> Language Class Initialized
INFO - 2018-02-13 12:10:13 --> Database Driver Class Initialized
INFO - 2018-02-13 12:10:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:40:13 --> Language Class Initialized
INFO - 2018-02-13 06:40:13 --> Config Class Initialized
INFO - 2018-02-13 06:40:13 --> Loader Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: url_helper
DEBUG - 2018-02-13 12:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:13 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:13 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:13 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:13 --> Controller Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:13 --> Database Driver Class Initialized
INFO - 2018-02-13 12:10:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
DEBUG - 2018-02-13 12:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:13 --> Total execution time: 0.1047
INFO - 2018-02-13 12:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:13 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:13 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:13 --> Controller Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:13 --> Total execution time: 0.1405
INFO - 2018-02-13 12:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:13 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:13 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:13 --> Controller Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Model Class Initialized
INFO - 2018-02-13 12:10:13 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:13 --> Total execution time: 0.1477
INFO - 2018-02-13 06:40:13 --> Config Class Initialized
INFO - 2018-02-13 06:40:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:13 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:13 --> URI Class Initialized
INFO - 2018-02-13 06:40:13 --> Router Class Initialized
INFO - 2018-02-13 06:40:13 --> Output Class Initialized
INFO - 2018-02-13 06:40:13 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:13 --> Input Class Initialized
INFO - 2018-02-13 06:40:14 --> Language Class Initialized
INFO - 2018-02-13 06:40:14 --> Language Class Initialized
INFO - 2018-02-13 06:40:14 --> Config Class Initialized
INFO - 2018-02-13 06:40:14 --> Loader Class Initialized
INFO - 2018-02-13 12:10:14 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:14 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:14 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:14 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:14 --> Controller Class Initialized
INFO - 2018-02-13 12:10:14 --> Model Class Initialized
INFO - 2018-02-13 12:10:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:14 --> Model Class Initialized
INFO - 2018-02-13 12:10:14 --> Model Class Initialized
INFO - 2018-02-13 12:10:14 --> Model Class Initialized
INFO - 2018-02-13 12:10:14 --> Model Class Initialized
INFO - 2018-02-13 12:10:14 --> Model Class Initialized
INFO - 2018-02-13 12:10:14 --> Model Class Initialized
INFO - 2018-02-13 12:10:14 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:14 --> Total execution time: 0.1034
INFO - 2018-02-13 06:40:44 --> Config Class Initialized
INFO - 2018-02-13 06:40:44 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:44 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:44 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:44 --> URI Class Initialized
INFO - 2018-02-13 06:40:44 --> Router Class Initialized
INFO - 2018-02-13 06:40:44 --> Output Class Initialized
INFO - 2018-02-13 06:40:44 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:44 --> Input Class Initialized
INFO - 2018-02-13 06:40:44 --> Language Class Initialized
INFO - 2018-02-13 06:40:44 --> Language Class Initialized
INFO - 2018-02-13 06:40:44 --> Config Class Initialized
INFO - 2018-02-13 06:40:44 --> Loader Class Initialized
INFO - 2018-02-13 12:10:44 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:44 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:44 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:44 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:44 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:44 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:44 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:44 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:44 --> Controller Class Initialized
INFO - 2018-02-13 12:10:44 --> Model Class Initialized
INFO - 2018-02-13 12:10:44 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:44 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:44 --> Model Class Initialized
INFO - 2018-02-13 12:10:44 --> Model Class Initialized
INFO - 2018-02-13 12:10:44 --> Model Class Initialized
INFO - 2018-02-13 12:10:44 --> Model Class Initialized
INFO - 2018-02-13 12:10:44 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:44 --> Total execution time: 0.1093
INFO - 2018-02-13 06:40:47 --> Config Class Initialized
INFO - 2018-02-13 06:40:47 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:47 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:47 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:47 --> URI Class Initialized
INFO - 2018-02-13 06:40:47 --> Router Class Initialized
INFO - 2018-02-13 06:40:47 --> Output Class Initialized
INFO - 2018-02-13 06:40:47 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:47 --> Input Class Initialized
INFO - 2018-02-13 06:40:47 --> Language Class Initialized
INFO - 2018-02-13 06:40:47 --> Language Class Initialized
INFO - 2018-02-13 06:40:47 --> Config Class Initialized
INFO - 2018-02-13 06:40:47 --> Loader Class Initialized
INFO - 2018-02-13 12:10:47 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:47 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:47 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:47 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:47 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:47 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:47 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:47 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:47 --> Controller Class Initialized
INFO - 2018-02-13 12:10:47 --> Model Class Initialized
INFO - 2018-02-13 12:10:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:47 --> Model Class Initialized
INFO - 2018-02-13 12:10:47 --> Model Class Initialized
INFO - 2018-02-13 12:10:47 --> Model Class Initialized
INFO - 2018-02-13 12:10:47 --> Model Class Initialized
INFO - 2018-02-13 12:10:47 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:47 --> Total execution time: 0.1158
INFO - 2018-02-13 06:40:49 --> Config Class Initialized
INFO - 2018-02-13 06:40:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:49 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:49 --> URI Class Initialized
INFO - 2018-02-13 06:40:49 --> Router Class Initialized
INFO - 2018-02-13 06:40:49 --> Output Class Initialized
INFO - 2018-02-13 06:40:49 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:49 --> Input Class Initialized
INFO - 2018-02-13 06:40:49 --> Language Class Initialized
INFO - 2018-02-13 06:40:49 --> Language Class Initialized
INFO - 2018-02-13 06:40:49 --> Config Class Initialized
INFO - 2018-02-13 06:40:49 --> Loader Class Initialized
INFO - 2018-02-13 12:10:49 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:49 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:49 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:49 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:49 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:49 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:49 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:49 --> Controller Class Initialized
INFO - 2018-02-13 12:10:49 --> Model Class Initialized
INFO - 2018-02-13 12:10:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:49 --> Model Class Initialized
INFO - 2018-02-13 12:10:49 --> Model Class Initialized
INFO - 2018-02-13 12:10:49 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:49 --> Total execution time: 0.1033
INFO - 2018-02-13 06:40:56 --> Config Class Initialized
INFO - 2018-02-13 06:40:56 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:40:56 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:40:56 --> Utf8 Class Initialized
INFO - 2018-02-13 06:40:56 --> URI Class Initialized
INFO - 2018-02-13 06:40:56 --> Router Class Initialized
INFO - 2018-02-13 06:40:56 --> Output Class Initialized
INFO - 2018-02-13 06:40:56 --> Security Class Initialized
DEBUG - 2018-02-13 06:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:40:56 --> Input Class Initialized
INFO - 2018-02-13 06:40:56 --> Language Class Initialized
INFO - 2018-02-13 06:40:56 --> Language Class Initialized
INFO - 2018-02-13 06:40:56 --> Config Class Initialized
INFO - 2018-02-13 06:40:56 --> Loader Class Initialized
INFO - 2018-02-13 12:10:56 --> Helper loaded: url_helper
INFO - 2018-02-13 12:10:56 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:10:56 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:10:56 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:10:56 --> Helper loaded: users_helper
INFO - 2018-02-13 12:10:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:10:56 --> Helper loaded: form_helper
INFO - 2018-02-13 12:10:56 --> Form Validation Class Initialized
INFO - 2018-02-13 12:10:56 --> Controller Class Initialized
INFO - 2018-02-13 12:10:56 --> Model Class Initialized
INFO - 2018-02-13 12:10:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:10:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:10:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:10:56 --> Model Class Initialized
INFO - 2018-02-13 12:10:56 --> Model Class Initialized
INFO - 2018-02-13 12:10:56 --> Model Class Initialized
INFO - 2018-02-13 12:10:56 --> Model Class Initialized
INFO - 2018-02-13 12:10:56 --> Model Class Initialized
INFO - 2018-02-13 12:10:56 --> Model Class Initialized
INFO - 2018-02-13 12:10:56 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 12:10:56 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-02-13 12:10:56 --> Final output sent to browser
DEBUG - 2018-02-13 12:10:56 --> Total execution time: 0.1263
INFO - 2018-02-13 06:41:05 --> Config Class Initialized
INFO - 2018-02-13 06:41:05 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:05 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:05 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:05 --> URI Class Initialized
INFO - 2018-02-13 06:41:05 --> Router Class Initialized
INFO - 2018-02-13 06:41:05 --> Output Class Initialized
INFO - 2018-02-13 06:41:05 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:05 --> Input Class Initialized
INFO - 2018-02-13 06:41:05 --> Language Class Initialized
INFO - 2018-02-13 06:41:05 --> Language Class Initialized
INFO - 2018-02-13 06:41:05 --> Config Class Initialized
INFO - 2018-02-13 06:41:05 --> Loader Class Initialized
INFO - 2018-02-13 12:11:05 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:05 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:05 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:05 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:05 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:05 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:05 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:05 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:05 --> Controller Class Initialized
INFO - 2018-02-13 12:11:05 --> Model Class Initialized
INFO - 2018-02-13 12:11:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:05 --> Model Class Initialized
INFO - 2018-02-13 12:11:05 --> Model Class Initialized
INFO - 2018-02-13 12:11:05 --> Model Class Initialized
INFO - 2018-02-13 12:11:05 --> Model Class Initialized
INFO - 2018-02-13 12:11:05 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:05 --> Total execution time: 0.1347
INFO - 2018-02-13 06:41:08 --> Config Class Initialized
INFO - 2018-02-13 06:41:08 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:08 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:08 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:08 --> URI Class Initialized
INFO - 2018-02-13 06:41:08 --> Router Class Initialized
INFO - 2018-02-13 06:41:08 --> Output Class Initialized
INFO - 2018-02-13 06:41:08 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:08 --> Input Class Initialized
INFO - 2018-02-13 06:41:08 --> Language Class Initialized
INFO - 2018-02-13 06:41:08 --> Language Class Initialized
INFO - 2018-02-13 06:41:08 --> Config Class Initialized
INFO - 2018-02-13 06:41:08 --> Loader Class Initialized
INFO - 2018-02-13 12:11:08 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:08 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:08 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:08 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:08 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:08 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:08 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:08 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:08 --> Controller Class Initialized
INFO - 2018-02-13 12:11:08 --> Model Class Initialized
INFO - 2018-02-13 12:11:08 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:08 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:08 --> Model Class Initialized
INFO - 2018-02-13 12:11:08 --> Model Class Initialized
INFO - 2018-02-13 12:11:08 --> Model Class Initialized
INFO - 2018-02-13 12:11:08 --> Model Class Initialized
INFO - 2018-02-13 12:11:08 --> Model Class Initialized
INFO - 2018-02-13 12:11:08 --> Model Class Initialized
INFO - 2018-02-13 12:11:08 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:11:08 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:08 --> Total execution time: 0.1070
INFO - 2018-02-13 06:41:25 --> Config Class Initialized
INFO - 2018-02-13 06:41:25 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:25 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:25 --> URI Class Initialized
INFO - 2018-02-13 06:41:25 --> Router Class Initialized
INFO - 2018-02-13 06:41:25 --> Output Class Initialized
INFO - 2018-02-13 06:41:25 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:25 --> Input Class Initialized
INFO - 2018-02-13 06:41:25 --> Language Class Initialized
INFO - 2018-02-13 06:41:25 --> Language Class Initialized
INFO - 2018-02-13 06:41:25 --> Config Class Initialized
INFO - 2018-02-13 06:41:25 --> Loader Class Initialized
INFO - 2018-02-13 12:11:25 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:25 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:25 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:25 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:25 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:25 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:25 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:25 --> Controller Class Initialized
INFO - 2018-02-13 12:11:25 --> Model Class Initialized
INFO - 2018-02-13 12:11:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:25 --> Model Class Initialized
INFO - 2018-02-13 12:11:25 --> Model Class Initialized
INFO - 2018-02-13 12:11:25 --> Model Class Initialized
INFO - 2018-02-13 12:11:25 --> Model Class Initialized
INFO - 2018-02-13 12:11:25 --> Model Class Initialized
INFO - 2018-02-13 12:11:25 --> Model Class Initialized
INFO - 2018-02-13 12:11:25 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:11:25 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:25 --> Total execution time: 0.1161
INFO - 2018-02-13 06:41:42 --> Config Class Initialized
INFO - 2018-02-13 06:41:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:42 --> URI Class Initialized
INFO - 2018-02-13 06:41:42 --> Router Class Initialized
INFO - 2018-02-13 06:41:42 --> Output Class Initialized
INFO - 2018-02-13 06:41:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:42 --> Input Class Initialized
INFO - 2018-02-13 06:41:42 --> Language Class Initialized
INFO - 2018-02-13 06:41:42 --> Config Class Initialized
INFO - 2018-02-13 06:41:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:42 --> Config Class Initialized
INFO - 2018-02-13 06:41:42 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:42 --> URI Class Initialized
INFO - 2018-02-13 06:41:42 --> Language Class Initialized
INFO - 2018-02-13 06:41:42 --> Config Class Initialized
INFO - 2018-02-13 06:41:42 --> Loader Class Initialized
DEBUG - 2018-02-13 06:41:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:42 --> Utf8 Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: url_helper
INFO - 2018-02-13 06:41:42 --> Router Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 06:41:42 --> URI Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: users_helper
INFO - 2018-02-13 06:41:42 --> Output Class Initialized
INFO - 2018-02-13 06:41:42 --> Config Class Initialized
INFO - 2018-02-13 06:41:42 --> Hooks Class Initialized
INFO - 2018-02-13 06:41:42 --> Router Class Initialized
INFO - 2018-02-13 06:41:42 --> Security Class Initialized
INFO - 2018-02-13 06:41:42 --> Output Class Initialized
DEBUG - 2018-02-13 06:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:42 --> Input Class Initialized
INFO - 2018-02-13 06:41:42 --> Language Class Initialized
INFO - 2018-02-13 06:41:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:42 --> Input Class Initialized
INFO - 2018-02-13 06:41:42 --> Language Class Initialized
DEBUG - 2018-02-13 06:41:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:42 --> Utf8 Class Initialized
INFO - 2018-02-13 12:11:42 --> Database Driver Class Initialized
INFO - 2018-02-13 06:41:42 --> URI Class Initialized
DEBUG - 2018-02-13 12:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 06:41:42 --> Language Class Initialized
INFO - 2018-02-13 06:41:42 --> Config Class Initialized
INFO - 2018-02-13 06:41:42 --> Loader Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:42 --> Controller Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 06:41:42 --> Language Class Initialized
INFO - 2018-02-13 06:41:42 --> Config Class Initialized
INFO - 2018-02-13 06:41:42 --> Loader Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 06:41:42 --> Router Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 06:41:42 --> Output Class Initialized
INFO - 2018-02-13 12:11:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 06:41:42 --> Security Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Database Driver Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
DEBUG - 2018-02-13 06:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:42 --> Input Class Initialized
INFO - 2018-02-13 06:41:42 --> Language Class Initialized
INFO - 2018-02-13 12:11:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:42 --> Total execution time: 0.0990
INFO - 2018-02-13 12:11:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 12:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:42 --> Controller Class Initialized
INFO - 2018-02-13 06:41:42 --> Language Class Initialized
INFO - 2018-02-13 06:41:42 --> Config Class Initialized
INFO - 2018-02-13 06:41:42 --> Loader Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:42 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: inflector_helper
INFO - 2018-02-13 12:11:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:42 --> Total execution time: 0.1255
INFO - 2018-02-13 12:11:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 12:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:42 --> Controller Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:42 --> Total execution time: 0.1598
INFO - 2018-02-13 12:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:42 --> Controller Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Model Class Initialized
INFO - 2018-02-13 12:11:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:42 --> Total execution time: 0.1988
INFO - 2018-02-13 06:41:43 --> Config Class Initialized
INFO - 2018-02-13 06:41:43 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:43 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:43 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:43 --> URI Class Initialized
INFO - 2018-02-13 06:41:43 --> Router Class Initialized
INFO - 2018-02-13 06:41:43 --> Output Class Initialized
INFO - 2018-02-13 06:41:43 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:43 --> Input Class Initialized
INFO - 2018-02-13 06:41:43 --> Language Class Initialized
INFO - 2018-02-13 06:41:43 --> Language Class Initialized
INFO - 2018-02-13 06:41:43 --> Config Class Initialized
INFO - 2018-02-13 06:41:43 --> Loader Class Initialized
INFO - 2018-02-13 12:11:43 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:43 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:43 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:43 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:43 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:43 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:43 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:43 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:43 --> Controller Class Initialized
INFO - 2018-02-13 12:11:43 --> Model Class Initialized
INFO - 2018-02-13 12:11:43 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:43 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:43 --> Model Class Initialized
INFO - 2018-02-13 12:11:43 --> Model Class Initialized
INFO - 2018-02-13 12:11:43 --> Model Class Initialized
INFO - 2018-02-13 12:11:43 --> Model Class Initialized
INFO - 2018-02-13 12:11:43 --> Model Class Initialized
INFO - 2018-02-13 12:11:43 --> Model Class Initialized
INFO - 2018-02-13 12:11:43 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:43 --> Total execution time: 0.0996
INFO - 2018-02-13 06:41:45 --> Config Class Initialized
INFO - 2018-02-13 06:41:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:45 --> URI Class Initialized
INFO - 2018-02-13 06:41:45 --> Router Class Initialized
INFO - 2018-02-13 06:41:45 --> Output Class Initialized
INFO - 2018-02-13 06:41:45 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:45 --> Input Class Initialized
INFO - 2018-02-13 06:41:45 --> Language Class Initialized
INFO - 2018-02-13 06:41:45 --> Language Class Initialized
INFO - 2018-02-13 06:41:45 --> Config Class Initialized
INFO - 2018-02-13 06:41:45 --> Loader Class Initialized
INFO - 2018-02-13 12:11:45 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:45 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:45 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:45 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:45 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:45 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:45 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:45 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:45 --> Controller Class Initialized
INFO - 2018-02-13 12:11:46 --> Model Class Initialized
INFO - 2018-02-13 12:11:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:46 --> Model Class Initialized
INFO - 2018-02-13 12:11:46 --> Model Class Initialized
INFO - 2018-02-13 12:11:46 --> Model Class Initialized
INFO - 2018-02-13 12:11:46 --> Model Class Initialized
INFO - 2018-02-13 12:11:46 --> Model Class Initialized
INFO - 2018-02-13 12:11:46 --> Model Class Initialized
INFO - 2018-02-13 12:11:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:11:46 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:46 --> Total execution time: 0.0901
INFO - 2018-02-13 06:41:49 --> Config Class Initialized
INFO - 2018-02-13 06:41:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:49 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:49 --> URI Class Initialized
INFO - 2018-02-13 06:41:49 --> Router Class Initialized
INFO - 2018-02-13 06:41:49 --> Output Class Initialized
INFO - 2018-02-13 06:41:49 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:49 --> Input Class Initialized
INFO - 2018-02-13 06:41:49 --> Language Class Initialized
INFO - 2018-02-13 06:41:49 --> Language Class Initialized
INFO - 2018-02-13 06:41:49 --> Config Class Initialized
INFO - 2018-02-13 06:41:49 --> Loader Class Initialized
INFO - 2018-02-13 12:11:49 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:49 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:49 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:49 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:49 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:49 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:49 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:49 --> Controller Class Initialized
INFO - 2018-02-13 12:11:49 --> Model Class Initialized
INFO - 2018-02-13 12:11:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:49 --> Model Class Initialized
INFO - 2018-02-13 12:11:49 --> Model Class Initialized
INFO - 2018-02-13 12:11:49 --> Model Class Initialized
INFO - 2018-02-13 12:11:49 --> Model Class Initialized
INFO - 2018-02-13 12:11:49 --> Model Class Initialized
INFO - 2018-02-13 12:11:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:11:49 --> Model Class Initialized
INFO - 2018-02-13 12:11:49 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:49 --> Total execution time: 0.1117
INFO - 2018-02-13 06:41:50 --> Config Class Initialized
INFO - 2018-02-13 06:41:50 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:50 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:50 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:50 --> URI Class Initialized
INFO - 2018-02-13 06:41:50 --> Router Class Initialized
INFO - 2018-02-13 06:41:50 --> Output Class Initialized
INFO - 2018-02-13 06:41:50 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:50 --> Input Class Initialized
INFO - 2018-02-13 06:41:50 --> Language Class Initialized
INFO - 2018-02-13 06:41:50 --> Language Class Initialized
INFO - 2018-02-13 06:41:50 --> Config Class Initialized
INFO - 2018-02-13 06:41:50 --> Loader Class Initialized
INFO - 2018-02-13 12:11:50 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:50 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:50 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:50 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:50 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:50 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:50 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:50 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:50 --> Controller Class Initialized
INFO - 2018-02-13 12:11:50 --> Model Class Initialized
INFO - 2018-02-13 12:11:50 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:50 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:50 --> Model Class Initialized
INFO - 2018-02-13 12:11:50 --> Model Class Initialized
INFO - 2018-02-13 12:11:50 --> Model Class Initialized
INFO - 2018-02-13 12:11:50 --> Model Class Initialized
INFO - 2018-02-13 12:11:50 --> Model Class Initialized
INFO - 2018-02-13 12:11:50 --> Model Class Initialized
INFO - 2018-02-13 12:11:50 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:11:50 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:50 --> Total execution time: 0.1208
INFO - 2018-02-13 06:41:56 --> Config Class Initialized
INFO - 2018-02-13 06:41:56 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:56 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:56 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:56 --> URI Class Initialized
INFO - 2018-02-13 06:41:56 --> Router Class Initialized
INFO - 2018-02-13 06:41:56 --> Output Class Initialized
INFO - 2018-02-13 06:41:56 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:56 --> Input Class Initialized
INFO - 2018-02-13 06:41:56 --> Language Class Initialized
INFO - 2018-02-13 06:41:56 --> Language Class Initialized
INFO - 2018-02-13 06:41:56 --> Config Class Initialized
INFO - 2018-02-13 06:41:56 --> Loader Class Initialized
INFO - 2018-02-13 12:11:56 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:56 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:56 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:56 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:56 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:56 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:56 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:56 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:56 --> Controller Class Initialized
INFO - 2018-02-13 12:11:56 --> Model Class Initialized
INFO - 2018-02-13 12:11:56 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:56 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:56 --> Model Class Initialized
INFO - 2018-02-13 12:11:56 --> Model Class Initialized
INFO - 2018-02-13 12:11:56 --> Model Class Initialized
INFO - 2018-02-13 12:11:56 --> Model Class Initialized
INFO - 2018-02-13 12:11:56 --> Model Class Initialized
INFO - 2018-02-13 12:11:56 --> Model Class Initialized
INFO - 2018-02-13 12:11:56 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:11:56 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:56 --> Total execution time: 0.1010
INFO - 2018-02-13 06:41:58 --> Config Class Initialized
INFO - 2018-02-13 06:41:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:41:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:41:58 --> Utf8 Class Initialized
INFO - 2018-02-13 06:41:58 --> URI Class Initialized
INFO - 2018-02-13 06:41:58 --> Router Class Initialized
INFO - 2018-02-13 06:41:58 --> Output Class Initialized
INFO - 2018-02-13 06:41:58 --> Security Class Initialized
DEBUG - 2018-02-13 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:41:58 --> Input Class Initialized
INFO - 2018-02-13 06:41:58 --> Language Class Initialized
INFO - 2018-02-13 06:41:58 --> Language Class Initialized
INFO - 2018-02-13 06:41:58 --> Config Class Initialized
INFO - 2018-02-13 06:41:58 --> Loader Class Initialized
INFO - 2018-02-13 12:11:58 --> Helper loaded: url_helper
INFO - 2018-02-13 12:11:58 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:11:58 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:11:58 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:11:58 --> Helper loaded: users_helper
INFO - 2018-02-13 12:11:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:11:58 --> Helper loaded: form_helper
INFO - 2018-02-13 12:11:58 --> Form Validation Class Initialized
INFO - 2018-02-13 12:11:58 --> Controller Class Initialized
INFO - 2018-02-13 12:11:58 --> Model Class Initialized
INFO - 2018-02-13 12:11:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:11:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:11:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:11:58 --> Model Class Initialized
INFO - 2018-02-13 12:11:58 --> Model Class Initialized
INFO - 2018-02-13 12:11:58 --> Model Class Initialized
INFO - 2018-02-13 12:11:58 --> Model Class Initialized
INFO - 2018-02-13 12:11:58 --> Model Class Initialized
INFO - 2018-02-13 12:11:58 --> Model Class Initialized
INFO - 2018-02-13 12:11:58 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:11:58 --> Model Class Initialized
INFO - 2018-02-13 12:11:58 --> Final output sent to browser
DEBUG - 2018-02-13 12:11:58 --> Total execution time: 0.0944
INFO - 2018-02-13 06:42:07 --> Config Class Initialized
INFO - 2018-02-13 06:42:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:07 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:07 --> URI Class Initialized
INFO - 2018-02-13 06:42:07 --> Router Class Initialized
INFO - 2018-02-13 06:42:07 --> Output Class Initialized
INFO - 2018-02-13 06:42:07 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:07 --> Input Class Initialized
INFO - 2018-02-13 06:42:07 --> Config Class Initialized
INFO - 2018-02-13 06:42:07 --> Language Class Initialized
INFO - 2018-02-13 06:42:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:07 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:07 --> URI Class Initialized
INFO - 2018-02-13 06:42:07 --> Router Class Initialized
INFO - 2018-02-13 06:42:07 --> Output Class Initialized
INFO - 2018-02-13 06:42:07 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:07 --> Input Class Initialized
INFO - 2018-02-13 06:42:07 --> Language Class Initialized
INFO - 2018-02-13 06:42:07 --> Language Class Initialized
INFO - 2018-02-13 06:42:07 --> Config Class Initialized
INFO - 2018-02-13 06:42:07 --> Loader Class Initialized
INFO - 2018-02-13 12:12:07 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: users_helper
INFO - 2018-02-13 06:42:07 --> Language Class Initialized
INFO - 2018-02-13 06:42:07 --> Config Class Initialized
INFO - 2018-02-13 06:42:07 --> Loader Class Initialized
INFO - 2018-02-13 12:12:07 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:07 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:07 --> Database Driver Class Initialized
INFO - 2018-02-13 12:12:07 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:07 --> Controller Class Initialized
DEBUG - 2018-02-13 12:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:07 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:07 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:07 --> Controller Class Initialized
INFO - 2018-02-13 12:12:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:07 --> Helper loaded: inflector_helper
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
DEBUG - 2018-02-13 12:12:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:07 --> Total execution time: 0.1088
INFO - 2018-02-13 12:12:07 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:07 --> Total execution time: 0.1446
INFO - 2018-02-13 06:42:07 --> Config Class Initialized
INFO - 2018-02-13 06:42:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:07 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:07 --> URI Class Initialized
INFO - 2018-02-13 06:42:07 --> Router Class Initialized
INFO - 2018-02-13 06:42:07 --> Output Class Initialized
INFO - 2018-02-13 06:42:07 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:07 --> Input Class Initialized
INFO - 2018-02-13 06:42:07 --> Language Class Initialized
INFO - 2018-02-13 06:42:07 --> Language Class Initialized
INFO - 2018-02-13 06:42:07 --> Config Class Initialized
INFO - 2018-02-13 06:42:07 --> Loader Class Initialized
INFO - 2018-02-13 12:12:07 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:07 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:07 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:07 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:07 --> Controller Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Model Class Initialized
INFO - 2018-02-13 12:12:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:07 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:07 --> Total execution time: 0.1134
INFO - 2018-02-13 06:42:09 --> Config Class Initialized
INFO - 2018-02-13 06:42:09 --> Hooks Class Initialized
INFO - 2018-02-13 06:42:09 --> Config Class Initialized
INFO - 2018-02-13 06:42:09 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:09 --> Utf8 Class Initialized
DEBUG - 2018-02-13 06:42:09 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:09 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:09 --> URI Class Initialized
INFO - 2018-02-13 06:42:09 --> URI Class Initialized
INFO - 2018-02-13 06:42:09 --> Router Class Initialized
INFO - 2018-02-13 06:42:09 --> Router Class Initialized
INFO - 2018-02-13 06:42:09 --> Output Class Initialized
INFO - 2018-02-13 06:42:09 --> Output Class Initialized
INFO - 2018-02-13 06:42:09 --> Security Class Initialized
INFO - 2018-02-13 06:42:09 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:09 --> Input Class Initialized
DEBUG - 2018-02-13 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:09 --> Input Class Initialized
INFO - 2018-02-13 06:42:09 --> Language Class Initialized
INFO - 2018-02-13 06:42:09 --> Language Class Initialized
INFO - 2018-02-13 06:42:09 --> Language Class Initialized
INFO - 2018-02-13 06:42:09 --> Config Class Initialized
INFO - 2018-02-13 06:42:09 --> Loader Class Initialized
INFO - 2018-02-13 12:12:09 --> Helper loaded: url_helper
INFO - 2018-02-13 06:42:09 --> Language Class Initialized
INFO - 2018-02-13 06:42:09 --> Config Class Initialized
INFO - 2018-02-13 06:42:09 --> Loader Class Initialized
INFO - 2018-02-13 12:12:09 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:09 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:09 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:09 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:09 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:09 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:09 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:09 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:09 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:09 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:09 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:09 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:09 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:09 --> Controller Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:09 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:09 --> Total execution time: 0.1037
INFO - 2018-02-13 12:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:09 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:09 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:09 --> Controller Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:09 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Model Class Initialized
INFO - 2018-02-13 12:12:09 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:09 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:09 --> Total execution time: 0.1278
INFO - 2018-02-13 06:42:13 --> Config Class Initialized
INFO - 2018-02-13 06:42:13 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:13 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:13 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:13 --> URI Class Initialized
INFO - 2018-02-13 06:42:13 --> Router Class Initialized
INFO - 2018-02-13 06:42:13 --> Output Class Initialized
INFO - 2018-02-13 06:42:13 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:13 --> Input Class Initialized
INFO - 2018-02-13 06:42:13 --> Language Class Initialized
INFO - 2018-02-13 06:42:13 --> Language Class Initialized
INFO - 2018-02-13 06:42:13 --> Config Class Initialized
INFO - 2018-02-13 06:42:13 --> Loader Class Initialized
INFO - 2018-02-13 12:12:13 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:13 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:13 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:13 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:13 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:13 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:13 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:13 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:13 --> Controller Class Initialized
INFO - 2018-02-13 12:12:13 --> Model Class Initialized
INFO - 2018-02-13 12:12:13 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:13 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:13 --> Model Class Initialized
INFO - 2018-02-13 12:12:13 --> Model Class Initialized
INFO - 2018-02-13 12:12:13 --> Model Class Initialized
INFO - 2018-02-13 12:12:13 --> Model Class Initialized
INFO - 2018-02-13 12:12:13 --> Model Class Initialized
INFO - 2018-02-13 12:12:13 --> Model Class Initialized
INFO - 2018-02-13 12:12:13 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:13 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:13 --> Total execution time: 0.1179
INFO - 2018-02-13 06:42:14 --> Config Class Initialized
INFO - 2018-02-13 06:42:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:14 --> URI Class Initialized
INFO - 2018-02-13 06:42:14 --> Router Class Initialized
INFO - 2018-02-13 06:42:14 --> Output Class Initialized
INFO - 2018-02-13 06:42:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:14 --> Input Class Initialized
INFO - 2018-02-13 06:42:14 --> Language Class Initialized
INFO - 2018-02-13 06:42:14 --> Language Class Initialized
INFO - 2018-02-13 06:42:14 --> Config Class Initialized
INFO - 2018-02-13 06:42:14 --> Loader Class Initialized
INFO - 2018-02-13 12:12:14 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:14 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:14 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:14 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:14 --> Controller Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:14 --> Total execution time: 0.1039
INFO - 2018-02-13 06:42:14 --> Config Class Initialized
INFO - 2018-02-13 06:42:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:14 --> URI Class Initialized
INFO - 2018-02-13 06:42:14 --> Router Class Initialized
INFO - 2018-02-13 06:42:14 --> Output Class Initialized
INFO - 2018-02-13 06:42:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:14 --> Input Class Initialized
INFO - 2018-02-13 06:42:14 --> Language Class Initialized
INFO - 2018-02-13 06:42:14 --> Language Class Initialized
INFO - 2018-02-13 06:42:14 --> Config Class Initialized
INFO - 2018-02-13 06:42:14 --> Loader Class Initialized
INFO - 2018-02-13 12:12:14 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:14 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:14 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:14 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:14 --> Controller Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Model Class Initialized
INFO - 2018-02-13 12:12:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:14 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:14 --> Total execution time: 0.1052
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:18 --> URI Class Initialized
INFO - 2018-02-13 06:42:18 --> Router Class Initialized
INFO - 2018-02-13 06:42:18 --> Output Class Initialized
INFO - 2018-02-13 06:42:18 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:18 --> Input Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
INFO - 2018-02-13 06:42:18 --> Language Class Initialized
INFO - 2018-02-13 06:42:18 --> Config Class Initialized
INFO - 2018-02-13 06:42:18 --> Loader Class Initialized
INFO - 2018-02-13 12:12:18 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:18 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:18 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:18 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:18 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:18 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:18 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:18 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:18 --> Controller Class Initialized
INFO - 2018-02-13 12:12:18 --> Model Class Initialized
INFO - 2018-02-13 12:12:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:18 --> Model Class Initialized
INFO - 2018-02-13 12:12:18 --> Model Class Initialized
INFO - 2018-02-13 12:12:18 --> Model Class Initialized
INFO - 2018-02-13 12:12:18 --> Model Class Initialized
INFO - 2018-02-13 12:12:18 --> Model Class Initialized
INFO - 2018-02-13 12:12:18 --> Model Class Initialized
INFO - 2018-02-13 12:12:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:18 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:18 --> Total execution time: 0.1192
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:19 --> URI Class Initialized
INFO - 2018-02-13 06:42:19 --> Router Class Initialized
INFO - 2018-02-13 06:42:19 --> Output Class Initialized
INFO - 2018-02-13 06:42:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:19 --> Input Class Initialized
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
INFO - 2018-02-13 06:42:19 --> Language Class Initialized
INFO - 2018-02-13 06:42:19 --> Config Class Initialized
INFO - 2018-02-13 06:42:19 --> Loader Class Initialized
INFO - 2018-02-13 12:12:19 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:19 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:19 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:19 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:19 --> Controller Class Initialized
INFO - 2018-02-13 12:12:19 --> Model Class Initialized
INFO - 2018-02-13 12:12:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:19 --> Model Class Initialized
INFO - 2018-02-13 12:12:19 --> Model Class Initialized
INFO - 2018-02-13 12:12:19 --> Model Class Initialized
INFO - 2018-02-13 12:12:19 --> Model Class Initialized
INFO - 2018-02-13 12:12:19 --> Model Class Initialized
INFO - 2018-02-13 12:12:19 --> Model Class Initialized
INFO - 2018-02-13 12:12:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:19 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:19 --> Total execution time: 0.1169
INFO - 2018-02-13 06:42:34 --> Config Class Initialized
INFO - 2018-02-13 06:42:34 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:34 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:34 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:34 --> URI Class Initialized
INFO - 2018-02-13 06:42:34 --> Router Class Initialized
INFO - 2018-02-13 06:42:34 --> Output Class Initialized
INFO - 2018-02-13 06:42:34 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:34 --> Input Class Initialized
INFO - 2018-02-13 06:42:34 --> Language Class Initialized
INFO - 2018-02-13 06:42:34 --> Language Class Initialized
INFO - 2018-02-13 06:42:34 --> Config Class Initialized
INFO - 2018-02-13 06:42:34 --> Loader Class Initialized
INFO - 2018-02-13 12:12:34 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:34 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:34 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:34 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:34 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:34 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:34 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:34 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:34 --> Controller Class Initialized
INFO - 2018-02-13 12:12:34 --> Model Class Initialized
INFO - 2018-02-13 12:12:34 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:34 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:34 --> Model Class Initialized
INFO - 2018-02-13 12:12:34 --> Model Class Initialized
INFO - 2018-02-13 12:12:34 --> Model Class Initialized
INFO - 2018-02-13 12:12:34 --> Model Class Initialized
INFO - 2018-02-13 12:12:34 --> Model Class Initialized
INFO - 2018-02-13 12:12:34 --> Model Class Initialized
INFO - 2018-02-13 12:12:34 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:34 --> Upload Class Initialized
INFO - 2018-02-13 12:12:34 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:34 --> Total execution time: 0.1166
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:35 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:35 --> URI Class Initialized
INFO - 2018-02-13 06:42:35 --> Router Class Initialized
INFO - 2018-02-13 06:42:35 --> Output Class Initialized
INFO - 2018-02-13 06:42:35 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:35 --> Input Class Initialized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
INFO - 2018-02-13 06:42:35 --> Language Class Initialized
INFO - 2018-02-13 06:42:35 --> Config Class Initialized
INFO - 2018-02-13 06:42:35 --> Loader Class Initialized
INFO - 2018-02-13 12:12:35 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:35 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:35 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:35 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:35 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:35 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:35 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:35 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:35 --> Controller Class Initialized
INFO - 2018-02-13 12:12:35 --> Model Class Initialized
INFO - 2018-02-13 12:12:35 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:35 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:35 --> Model Class Initialized
INFO - 2018-02-13 12:12:35 --> Model Class Initialized
INFO - 2018-02-13 12:12:35 --> Model Class Initialized
INFO - 2018-02-13 12:12:35 --> Model Class Initialized
INFO - 2018-02-13 12:12:35 --> Model Class Initialized
INFO - 2018-02-13 12:12:35 --> Model Class Initialized
INFO - 2018-02-13 12:12:35 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:35 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:35 --> Total execution time: 0.0871
INFO - 2018-02-13 06:42:38 --> Config Class Initialized
INFO - 2018-02-13 06:42:38 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:38 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:38 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:38 --> URI Class Initialized
INFO - 2018-02-13 06:42:38 --> Router Class Initialized
INFO - 2018-02-13 06:42:38 --> Output Class Initialized
INFO - 2018-02-13 06:42:38 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:38 --> Input Class Initialized
INFO - 2018-02-13 06:42:38 --> Language Class Initialized
INFO - 2018-02-13 06:42:38 --> Language Class Initialized
INFO - 2018-02-13 06:42:38 --> Config Class Initialized
INFO - 2018-02-13 06:42:38 --> Loader Class Initialized
INFO - 2018-02-13 12:12:38 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:38 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:38 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:38 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:38 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:38 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:38 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:38 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:38 --> Controller Class Initialized
INFO - 2018-02-13 12:12:38 --> Model Class Initialized
INFO - 2018-02-13 12:12:38 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:38 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:38 --> Model Class Initialized
INFO - 2018-02-13 12:12:38 --> Model Class Initialized
INFO - 2018-02-13 12:12:38 --> Model Class Initialized
INFO - 2018-02-13 12:12:38 --> Model Class Initialized
INFO - 2018-02-13 12:12:38 --> Model Class Initialized
INFO - 2018-02-13 12:12:38 --> Model Class Initialized
INFO - 2018-02-13 12:12:38 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:38 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:38 --> Total execution time: 0.1128
INFO - 2018-02-13 06:42:48 --> Config Class Initialized
INFO - 2018-02-13 06:42:48 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:48 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:48 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:48 --> URI Class Initialized
INFO - 2018-02-13 06:42:48 --> Router Class Initialized
INFO - 2018-02-13 06:42:48 --> Output Class Initialized
INFO - 2018-02-13 06:42:48 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:48 --> Input Class Initialized
INFO - 2018-02-13 06:42:48 --> Language Class Initialized
INFO - 2018-02-13 06:42:48 --> Language Class Initialized
INFO - 2018-02-13 06:42:48 --> Config Class Initialized
INFO - 2018-02-13 06:42:48 --> Loader Class Initialized
INFO - 2018-02-13 12:12:48 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:48 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:48 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:48 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:48 --> Controller Class Initialized
INFO - 2018-02-13 12:12:48 --> Model Class Initialized
INFO - 2018-02-13 12:12:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:48 --> Model Class Initialized
INFO - 2018-02-13 12:12:48 --> Model Class Initialized
INFO - 2018-02-13 12:12:48 --> Model Class Initialized
INFO - 2018-02-13 12:12:48 --> Model Class Initialized
INFO - 2018-02-13 12:12:48 --> Model Class Initialized
INFO - 2018-02-13 12:12:48 --> Model Class Initialized
INFO - 2018-02-13 12:12:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:48 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:48 --> Total execution time: 0.1209
INFO - 2018-02-13 06:42:52 --> Config Class Initialized
INFO - 2018-02-13 06:42:52 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:52 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:52 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:52 --> URI Class Initialized
INFO - 2018-02-13 06:42:52 --> Router Class Initialized
INFO - 2018-02-13 06:42:52 --> Output Class Initialized
INFO - 2018-02-13 06:42:52 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:52 --> Input Class Initialized
INFO - 2018-02-13 06:42:52 --> Language Class Initialized
INFO - 2018-02-13 06:42:52 --> Language Class Initialized
INFO - 2018-02-13 06:42:52 --> Config Class Initialized
INFO - 2018-02-13 06:42:52 --> Loader Class Initialized
INFO - 2018-02-13 12:12:52 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:52 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:52 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:52 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:52 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:52 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:52 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:52 --> Controller Class Initialized
INFO - 2018-02-13 12:12:52 --> Model Class Initialized
INFO - 2018-02-13 12:12:52 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:52 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:52 --> Model Class Initialized
INFO - 2018-02-13 12:12:52 --> Model Class Initialized
INFO - 2018-02-13 12:12:52 --> Model Class Initialized
INFO - 2018-02-13 12:12:52 --> Model Class Initialized
INFO - 2018-02-13 12:12:52 --> Model Class Initialized
INFO - 2018-02-13 12:12:52 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:52 --> Model Class Initialized
INFO - 2018-02-13 12:12:52 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:52 --> Total execution time: 0.1129
INFO - 2018-02-13 06:42:53 --> Config Class Initialized
INFO - 2018-02-13 06:42:53 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:53 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:53 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:53 --> URI Class Initialized
INFO - 2018-02-13 06:42:53 --> Router Class Initialized
INFO - 2018-02-13 06:42:53 --> Output Class Initialized
INFO - 2018-02-13 06:42:53 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:53 --> Input Class Initialized
INFO - 2018-02-13 06:42:53 --> Language Class Initialized
INFO - 2018-02-13 06:42:53 --> Language Class Initialized
INFO - 2018-02-13 06:42:53 --> Config Class Initialized
INFO - 2018-02-13 06:42:53 --> Loader Class Initialized
INFO - 2018-02-13 12:12:53 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:53 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:53 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:53 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:53 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:53 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:53 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:53 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:53 --> Controller Class Initialized
INFO - 2018-02-13 12:12:53 --> Model Class Initialized
INFO - 2018-02-13 12:12:53 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:53 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:53 --> Model Class Initialized
INFO - 2018-02-13 12:12:53 --> Model Class Initialized
INFO - 2018-02-13 12:12:53 --> Model Class Initialized
INFO - 2018-02-13 12:12:53 --> Model Class Initialized
INFO - 2018-02-13 12:12:53 --> Model Class Initialized
INFO - 2018-02-13 12:12:53 --> Model Class Initialized
INFO - 2018-02-13 12:12:53 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:53 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:53 --> Total execution time: 0.0946
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:42:55 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:42:55 --> Utf8 Class Initialized
INFO - 2018-02-13 06:42:55 --> URI Class Initialized
INFO - 2018-02-13 06:42:55 --> Router Class Initialized
INFO - 2018-02-13 06:42:55 --> Output Class Initialized
INFO - 2018-02-13 06:42:55 --> Security Class Initialized
DEBUG - 2018-02-13 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:42:55 --> Input Class Initialized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
INFO - 2018-02-13 06:42:55 --> Language Class Initialized
INFO - 2018-02-13 06:42:55 --> Config Class Initialized
INFO - 2018-02-13 06:42:55 --> Loader Class Initialized
INFO - 2018-02-13 12:12:55 --> Helper loaded: url_helper
INFO - 2018-02-13 12:12:55 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:12:55 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:12:55 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:12:55 --> Helper loaded: users_helper
INFO - 2018-02-13 12:12:55 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:12:55 --> Helper loaded: form_helper
INFO - 2018-02-13 12:12:55 --> Form Validation Class Initialized
INFO - 2018-02-13 12:12:55 --> Controller Class Initialized
INFO - 2018-02-13 12:12:55 --> Model Class Initialized
INFO - 2018-02-13 12:12:55 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:12:55 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:12:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:12:55 --> Model Class Initialized
INFO - 2018-02-13 12:12:55 --> Model Class Initialized
INFO - 2018-02-13 12:12:55 --> Model Class Initialized
INFO - 2018-02-13 12:12:55 --> Model Class Initialized
INFO - 2018-02-13 12:12:55 --> Model Class Initialized
INFO - 2018-02-13 12:12:55 --> Model Class Initialized
INFO - 2018-02-13 12:12:55 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:12:55 --> Final output sent to browser
DEBUG - 2018-02-13 12:12:55 --> Total execution time: 0.1104
INFO - 2018-02-13 06:43:19 --> Config Class Initialized
INFO - 2018-02-13 06:43:19 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:43:19 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:19 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:19 --> URI Class Initialized
INFO - 2018-02-13 06:43:19 --> Router Class Initialized
INFO - 2018-02-13 06:43:19 --> Output Class Initialized
INFO - 2018-02-13 06:43:19 --> Security Class Initialized
DEBUG - 2018-02-13 06:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:19 --> Input Class Initialized
INFO - 2018-02-13 06:43:19 --> Language Class Initialized
INFO - 2018-02-13 06:43:19 --> Language Class Initialized
INFO - 2018-02-13 06:43:19 --> Config Class Initialized
INFO - 2018-02-13 06:43:19 --> Loader Class Initialized
INFO - 2018-02-13 12:13:19 --> Helper loaded: url_helper
INFO - 2018-02-13 12:13:19 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:13:19 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:13:19 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:13:19 --> Helper loaded: users_helper
INFO - 2018-02-13 12:13:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:13:19 --> Helper loaded: form_helper
INFO - 2018-02-13 12:13:19 --> Form Validation Class Initialized
INFO - 2018-02-13 12:13:19 --> Controller Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:13:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:13:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Model Class Initialized
INFO - 2018-02-13 12:13:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:13:19 --> Final output sent to browser
DEBUG - 2018-02-13 12:13:19 --> Total execution time: 0.1014
INFO - 2018-02-13 06:43:25 --> Config Class Initialized
INFO - 2018-02-13 06:43:25 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:43:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:43:25 --> Utf8 Class Initialized
INFO - 2018-02-13 06:43:25 --> URI Class Initialized
INFO - 2018-02-13 06:43:25 --> Router Class Initialized
INFO - 2018-02-13 06:43:25 --> Output Class Initialized
INFO - 2018-02-13 06:43:25 --> Security Class Initialized
DEBUG - 2018-02-13 06:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:43:25 --> Input Class Initialized
INFO - 2018-02-13 06:43:25 --> Language Class Initialized
INFO - 2018-02-13 06:43:25 --> Language Class Initialized
INFO - 2018-02-13 06:43:25 --> Config Class Initialized
INFO - 2018-02-13 06:43:25 --> Loader Class Initialized
INFO - 2018-02-13 12:13:25 --> Helper loaded: url_helper
INFO - 2018-02-13 12:13:25 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:13:25 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:13:25 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:13:25 --> Helper loaded: users_helper
INFO - 2018-02-13 12:13:25 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:13:25 --> Helper loaded: form_helper
INFO - 2018-02-13 12:13:25 --> Form Validation Class Initialized
INFO - 2018-02-13 12:13:25 --> Controller Class Initialized
INFO - 2018-02-13 12:13:25 --> Model Class Initialized
INFO - 2018-02-13 12:13:25 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:13:25 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:13:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:13:25 --> Model Class Initialized
INFO - 2018-02-13 12:13:25 --> Model Class Initialized
INFO - 2018-02-13 12:13:25 --> Model Class Initialized
INFO - 2018-02-13 12:13:25 --> Model Class Initialized
INFO - 2018-02-13 12:13:25 --> Model Class Initialized
INFO - 2018-02-13 12:13:25 --> Model Class Initialized
INFO - 2018-02-13 12:13:25 --> Language file loaded: language/english/message_lang.php
ERROR - 2018-02-13 12:13:25 --> Severity: Warning --> Creating default object from empty value /home/pr01004/public_html/application/controllers/api/Users.php 774
INFO - 2018-02-13 12:13:25 --> Final output sent to browser
DEBUG - 2018-02-13 12:13:25 --> Total execution time: 0.1170
INFO - 2018-02-13 06:44:07 --> Config Class Initialized
INFO - 2018-02-13 06:44:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:07 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:07 --> URI Class Initialized
INFO - 2018-02-13 06:44:07 --> Router Class Initialized
INFO - 2018-02-13 06:44:07 --> Output Class Initialized
INFO - 2018-02-13 06:44:07 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:07 --> Input Class Initialized
INFO - 2018-02-13 06:44:07 --> Language Class Initialized
INFO - 2018-02-13 06:44:07 --> Language Class Initialized
INFO - 2018-02-13 06:44:07 --> Config Class Initialized
INFO - 2018-02-13 06:44:07 --> Loader Class Initialized
INFO - 2018-02-13 12:14:07 --> Helper loaded: url_helper
INFO - 2018-02-13 12:14:07 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:14:07 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:14:07 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:14:07 --> Helper loaded: users_helper
INFO - 2018-02-13 12:14:07 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:14:07 --> Helper loaded: form_helper
INFO - 2018-02-13 12:14:07 --> Form Validation Class Initialized
INFO - 2018-02-13 12:14:07 --> Controller Class Initialized
INFO - 2018-02-13 12:14:07 --> Model Class Initialized
INFO - 2018-02-13 12:14:07 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:14:07 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:14:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:14:07 --> Model Class Initialized
INFO - 2018-02-13 12:14:07 --> Model Class Initialized
INFO - 2018-02-13 12:14:07 --> Model Class Initialized
INFO - 2018-02-13 12:14:07 --> Model Class Initialized
INFO - 2018-02-13 12:14:07 --> Model Class Initialized
INFO - 2018-02-13 12:14:07 --> Model Class Initialized
INFO - 2018-02-13 12:14:07 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:14:07 --> Model Class Initialized
INFO - 2018-02-13 12:14:07 --> Final output sent to browser
DEBUG - 2018-02-13 12:14:07 --> Total execution time: 0.1324
INFO - 2018-02-13 06:44:14 --> Config Class Initialized
INFO - 2018-02-13 06:44:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:14 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:14 --> URI Class Initialized
INFO - 2018-02-13 06:44:14 --> Router Class Initialized
INFO - 2018-02-13 06:44:14 --> Output Class Initialized
INFO - 2018-02-13 06:44:14 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:14 --> Input Class Initialized
INFO - 2018-02-13 06:44:14 --> Language Class Initialized
INFO - 2018-02-13 06:44:14 --> Language Class Initialized
INFO - 2018-02-13 06:44:14 --> Config Class Initialized
INFO - 2018-02-13 06:44:14 --> Loader Class Initialized
INFO - 2018-02-13 12:14:14 --> Helper loaded: url_helper
INFO - 2018-02-13 12:14:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:14:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:14:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:14:14 --> Helper loaded: users_helper
INFO - 2018-02-13 12:14:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:14:14 --> Helper loaded: form_helper
INFO - 2018-02-13 12:14:14 --> Form Validation Class Initialized
INFO - 2018-02-13 12:14:14 --> Controller Class Initialized
INFO - 2018-02-13 12:14:14 --> Model Class Initialized
INFO - 2018-02-13 12:14:14 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:14:14 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:14:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:14:14 --> Model Class Initialized
INFO - 2018-02-13 12:14:14 --> Model Class Initialized
INFO - 2018-02-13 12:14:14 --> Model Class Initialized
INFO - 2018-02-13 12:14:14 --> Model Class Initialized
INFO - 2018-02-13 12:14:14 --> Model Class Initialized
INFO - 2018-02-13 12:14:14 --> Model Class Initialized
INFO - 2018-02-13 12:14:14 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:14:14 --> Final output sent to browser
DEBUG - 2018-02-13 12:14:14 --> Total execution time: 0.1147
INFO - 2018-02-13 06:44:18 --> Config Class Initialized
INFO - 2018-02-13 06:44:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:18 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:18 --> URI Class Initialized
INFO - 2018-02-13 06:44:18 --> Router Class Initialized
INFO - 2018-02-13 06:44:18 --> Output Class Initialized
INFO - 2018-02-13 06:44:18 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:18 --> Input Class Initialized
INFO - 2018-02-13 06:44:18 --> Language Class Initialized
INFO - 2018-02-13 06:44:18 --> Language Class Initialized
INFO - 2018-02-13 06:44:18 --> Config Class Initialized
INFO - 2018-02-13 06:44:18 --> Loader Class Initialized
INFO - 2018-02-13 12:14:18 --> Helper loaded: url_helper
INFO - 2018-02-13 12:14:18 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:14:18 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:14:18 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:14:18 --> Helper loaded: users_helper
INFO - 2018-02-13 12:14:19 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:14:19 --> Helper loaded: form_helper
INFO - 2018-02-13 12:14:19 --> Form Validation Class Initialized
INFO - 2018-02-13 12:14:19 --> Controller Class Initialized
INFO - 2018-02-13 12:14:19 --> Model Class Initialized
INFO - 2018-02-13 12:14:19 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:14:19 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:14:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:14:19 --> Model Class Initialized
INFO - 2018-02-13 12:14:19 --> Model Class Initialized
INFO - 2018-02-13 12:14:19 --> Model Class Initialized
INFO - 2018-02-13 12:14:19 --> Model Class Initialized
INFO - 2018-02-13 12:14:19 --> Model Class Initialized
INFO - 2018-02-13 12:14:19 --> Model Class Initialized
INFO - 2018-02-13 12:14:19 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:14:19 --> Model Class Initialized
INFO - 2018-02-13 12:14:19 --> Final output sent to browser
DEBUG - 2018-02-13 12:14:19 --> Total execution time: 0.1122
INFO - 2018-02-13 06:44:29 --> Config Class Initialized
INFO - 2018-02-13 06:44:29 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:29 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:29 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:29 --> URI Class Initialized
INFO - 2018-02-13 06:44:29 --> Router Class Initialized
INFO - 2018-02-13 06:44:29 --> Output Class Initialized
INFO - 2018-02-13 06:44:29 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:29 --> Input Class Initialized
INFO - 2018-02-13 06:44:29 --> Language Class Initialized
INFO - 2018-02-13 06:44:29 --> Language Class Initialized
INFO - 2018-02-13 06:44:29 --> Config Class Initialized
INFO - 2018-02-13 06:44:29 --> Loader Class Initialized
INFO - 2018-02-13 12:14:29 --> Helper loaded: url_helper
INFO - 2018-02-13 12:14:29 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:14:29 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:14:29 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:14:29 --> Helper loaded: users_helper
INFO - 2018-02-13 12:14:29 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:14:29 --> Helper loaded: form_helper
INFO - 2018-02-13 12:14:29 --> Form Validation Class Initialized
INFO - 2018-02-13 12:14:29 --> Controller Class Initialized
INFO - 2018-02-13 12:14:29 --> Model Class Initialized
INFO - 2018-02-13 12:14:29 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:14:29 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:14:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:14:29 --> Model Class Initialized
INFO - 2018-02-13 12:14:29 --> Model Class Initialized
INFO - 2018-02-13 12:14:29 --> Model Class Initialized
INFO - 2018-02-13 12:14:29 --> Model Class Initialized
INFO - 2018-02-13 12:14:29 --> Model Class Initialized
INFO - 2018-02-13 12:14:29 --> Model Class Initialized
INFO - 2018-02-13 12:14:29 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:14:29 --> Final output sent to browser
DEBUG - 2018-02-13 12:14:29 --> Total execution time: 0.1119
INFO - 2018-02-13 06:44:42 --> Config Class Initialized
INFO - 2018-02-13 06:44:42 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:42 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:42 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:42 --> URI Class Initialized
INFO - 2018-02-13 06:44:42 --> Router Class Initialized
INFO - 2018-02-13 06:44:42 --> Output Class Initialized
INFO - 2018-02-13 06:44:42 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:42 --> Input Class Initialized
INFO - 2018-02-13 06:44:42 --> Language Class Initialized
INFO - 2018-02-13 06:44:42 --> Language Class Initialized
INFO - 2018-02-13 06:44:42 --> Config Class Initialized
INFO - 2018-02-13 06:44:42 --> Loader Class Initialized
INFO - 2018-02-13 12:14:42 --> Helper loaded: url_helper
INFO - 2018-02-13 12:14:42 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:14:42 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:14:42 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:14:42 --> Helper loaded: users_helper
INFO - 2018-02-13 12:14:42 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:14:42 --> Helper loaded: form_helper
INFO - 2018-02-13 12:14:42 --> Form Validation Class Initialized
INFO - 2018-02-13 12:14:42 --> Controller Class Initialized
INFO - 2018-02-13 12:14:42 --> Model Class Initialized
INFO - 2018-02-13 12:14:42 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:14:42 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:14:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:14:42 --> Model Class Initialized
INFO - 2018-02-13 12:14:42 --> Model Class Initialized
INFO - 2018-02-13 12:14:42 --> Model Class Initialized
INFO - 2018-02-13 12:14:42 --> Model Class Initialized
INFO - 2018-02-13 12:14:42 --> Final output sent to browser
DEBUG - 2018-02-13 12:14:42 --> Total execution time: 0.0951
INFO - 2018-02-13 06:44:45 --> Config Class Initialized
INFO - 2018-02-13 06:44:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:45 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:45 --> URI Class Initialized
INFO - 2018-02-13 06:44:45 --> Router Class Initialized
INFO - 2018-02-13 06:44:45 --> Output Class Initialized
INFO - 2018-02-13 06:44:45 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:45 --> Input Class Initialized
INFO - 2018-02-13 06:44:45 --> Language Class Initialized
INFO - 2018-02-13 06:44:45 --> Language Class Initialized
INFO - 2018-02-13 06:44:45 --> Config Class Initialized
INFO - 2018-02-13 06:44:45 --> Loader Class Initialized
INFO - 2018-02-13 12:14:45 --> Helper loaded: url_helper
INFO - 2018-02-13 12:14:45 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:14:45 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:14:45 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:14:45 --> Helper loaded: users_helper
INFO - 2018-02-13 12:14:45 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:14:45 --> Helper loaded: form_helper
INFO - 2018-02-13 12:14:45 --> Form Validation Class Initialized
INFO - 2018-02-13 12:14:45 --> Controller Class Initialized
INFO - 2018-02-13 12:14:45 --> Model Class Initialized
INFO - 2018-02-13 12:14:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:14:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:14:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:14:45 --> Model Class Initialized
INFO - 2018-02-13 12:14:45 --> Model Class Initialized
INFO - 2018-02-13 12:14:45 --> Model Class Initialized
INFO - 2018-02-13 12:14:45 --> Model Class Initialized
INFO - 2018-02-13 12:14:45 --> Final output sent to browser
DEBUG - 2018-02-13 12:14:45 --> Total execution time: 0.1085
INFO - 2018-02-13 06:44:47 --> Config Class Initialized
INFO - 2018-02-13 06:44:47 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:47 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:47 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:47 --> URI Class Initialized
INFO - 2018-02-13 06:44:47 --> Router Class Initialized
INFO - 2018-02-13 06:44:47 --> Output Class Initialized
INFO - 2018-02-13 06:44:47 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:47 --> Input Class Initialized
INFO - 2018-02-13 06:44:47 --> Language Class Initialized
INFO - 2018-02-13 06:44:47 --> Language Class Initialized
INFO - 2018-02-13 06:44:47 --> Config Class Initialized
INFO - 2018-02-13 06:44:47 --> Loader Class Initialized
INFO - 2018-02-13 12:14:47 --> Helper loaded: url_helper
INFO - 2018-02-13 12:14:47 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:14:47 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:14:47 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:14:47 --> Helper loaded: users_helper
INFO - 2018-02-13 12:14:47 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:14:47 --> Helper loaded: form_helper
INFO - 2018-02-13 12:14:47 --> Form Validation Class Initialized
INFO - 2018-02-13 12:14:47 --> Controller Class Initialized
INFO - 2018-02-13 12:14:47 --> Model Class Initialized
INFO - 2018-02-13 12:14:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:14:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:14:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:14:47 --> Model Class Initialized
INFO - 2018-02-13 12:14:47 --> Model Class Initialized
INFO - 2018-02-13 12:14:47 --> Model Class Initialized
INFO - 2018-02-13 12:14:47 --> Model Class Initialized
INFO - 2018-02-13 12:14:47 --> Final output sent to browser
DEBUG - 2018-02-13 12:14:47 --> Total execution time: 0.1049
INFO - 2018-02-13 06:44:49 --> Config Class Initialized
INFO - 2018-02-13 06:44:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:44:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:44:49 --> Utf8 Class Initialized
INFO - 2018-02-13 06:44:49 --> URI Class Initialized
INFO - 2018-02-13 06:44:49 --> Router Class Initialized
INFO - 2018-02-13 06:44:49 --> Output Class Initialized
INFO - 2018-02-13 06:44:49 --> Security Class Initialized
DEBUG - 2018-02-13 06:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:44:49 --> Input Class Initialized
INFO - 2018-02-13 06:44:49 --> Language Class Initialized
INFO - 2018-02-13 06:44:49 --> Language Class Initialized
INFO - 2018-02-13 06:44:49 --> Config Class Initialized
INFO - 2018-02-13 06:44:49 --> Loader Class Initialized
INFO - 2018-02-13 12:14:49 --> Helper loaded: url_helper
INFO - 2018-02-13 12:14:49 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:14:49 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:14:49 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:14:49 --> Helper loaded: users_helper
INFO - 2018-02-13 12:14:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:14:49 --> Helper loaded: form_helper
INFO - 2018-02-13 12:14:49 --> Form Validation Class Initialized
INFO - 2018-02-13 12:14:49 --> Controller Class Initialized
INFO - 2018-02-13 12:14:49 --> Model Class Initialized
INFO - 2018-02-13 12:14:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:14:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:14:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:14:49 --> Model Class Initialized
INFO - 2018-02-13 12:14:49 --> Model Class Initialized
INFO - 2018-02-13 12:14:49 --> Model Class Initialized
INFO - 2018-02-13 12:14:49 --> Model Class Initialized
INFO - 2018-02-13 12:14:49 --> Model Class Initialized
INFO - 2018-02-13 12:14:49 --> Model Class Initialized
INFO - 2018-02-13 12:14:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:14:49 --> Final output sent to browser
DEBUG - 2018-02-13 12:14:49 --> Total execution time: 0.0883
INFO - 2018-02-13 06:45:58 --> Config Class Initialized
INFO - 2018-02-13 06:45:58 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:45:58 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:45:58 --> Utf8 Class Initialized
INFO - 2018-02-13 06:45:58 --> URI Class Initialized
INFO - 2018-02-13 06:45:58 --> Router Class Initialized
INFO - 2018-02-13 06:45:58 --> Output Class Initialized
INFO - 2018-02-13 06:45:58 --> Security Class Initialized
DEBUG - 2018-02-13 06:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:45:58 --> Input Class Initialized
INFO - 2018-02-13 06:45:58 --> Language Class Initialized
INFO - 2018-02-13 06:45:58 --> Language Class Initialized
INFO - 2018-02-13 06:45:58 --> Config Class Initialized
INFO - 2018-02-13 06:45:58 --> Loader Class Initialized
INFO - 2018-02-13 12:15:58 --> Helper loaded: url_helper
INFO - 2018-02-13 12:15:58 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:15:58 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:15:58 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:15:58 --> Helper loaded: users_helper
INFO - 2018-02-13 12:15:58 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:15:58 --> Helper loaded: form_helper
INFO - 2018-02-13 12:15:58 --> Form Validation Class Initialized
INFO - 2018-02-13 12:15:58 --> Controller Class Initialized
INFO - 2018-02-13 12:15:58 --> Model Class Initialized
INFO - 2018-02-13 12:15:58 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:15:58 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:15:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:15:58 --> Model Class Initialized
INFO - 2018-02-13 12:15:58 --> Model Class Initialized
INFO - 2018-02-13 12:15:58 --> Model Class Initialized
INFO - 2018-02-13 12:15:58 --> Model Class Initialized
INFO - 2018-02-13 12:15:58 --> Final output sent to browser
DEBUG - 2018-02-13 12:15:58 --> Total execution time: 0.0991
INFO - 2018-02-13 06:46:01 --> Config Class Initialized
INFO - 2018-02-13 06:46:01 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:46:01 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:46:01 --> Utf8 Class Initialized
INFO - 2018-02-13 06:46:01 --> URI Class Initialized
INFO - 2018-02-13 06:46:01 --> Router Class Initialized
INFO - 2018-02-13 06:46:01 --> Output Class Initialized
INFO - 2018-02-13 06:46:01 --> Security Class Initialized
DEBUG - 2018-02-13 06:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:46:01 --> Input Class Initialized
INFO - 2018-02-13 06:46:01 --> Language Class Initialized
INFO - 2018-02-13 06:46:01 --> Language Class Initialized
INFO - 2018-02-13 06:46:01 --> Config Class Initialized
INFO - 2018-02-13 06:46:01 --> Loader Class Initialized
INFO - 2018-02-13 12:16:01 --> Helper loaded: url_helper
INFO - 2018-02-13 12:16:01 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:16:01 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:16:01 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:16:01 --> Helper loaded: users_helper
INFO - 2018-02-13 12:16:01 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:16:01 --> Helper loaded: form_helper
INFO - 2018-02-13 12:16:01 --> Form Validation Class Initialized
INFO - 2018-02-13 12:16:01 --> Controller Class Initialized
INFO - 2018-02-13 12:16:01 --> Model Class Initialized
INFO - 2018-02-13 12:16:01 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:16:01 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:16:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:16:01 --> Model Class Initialized
INFO - 2018-02-13 12:16:01 --> Model Class Initialized
INFO - 2018-02-13 12:16:01 --> Model Class Initialized
INFO - 2018-02-13 12:16:01 --> Model Class Initialized
INFO - 2018-02-13 12:16:01 --> Model Class Initialized
INFO - 2018-02-13 12:16:01 --> Model Class Initialized
INFO - 2018-02-13 12:16:01 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:16:01 --> Final output sent to browser
DEBUG - 2018-02-13 12:16:01 --> Total execution time: 0.1168
INFO - 2018-02-13 06:50:51 --> Config Class Initialized
INFO - 2018-02-13 06:50:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:50:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:50:51 --> Utf8 Class Initialized
INFO - 2018-02-13 06:50:51 --> URI Class Initialized
DEBUG - 2018-02-13 06:50:51 --> No URI present. Default controller set.
INFO - 2018-02-13 06:50:51 --> Router Class Initialized
INFO - 2018-02-13 06:50:51 --> Output Class Initialized
INFO - 2018-02-13 06:50:51 --> Security Class Initialized
DEBUG - 2018-02-13 06:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:50:51 --> Input Class Initialized
INFO - 2018-02-13 06:50:51 --> Language Class Initialized
INFO - 2018-02-13 06:50:51 --> Language Class Initialized
INFO - 2018-02-13 06:50:51 --> Config Class Initialized
INFO - 2018-02-13 06:50:51 --> Loader Class Initialized
INFO - 2018-02-13 12:20:51 --> Helper loaded: url_helper
INFO - 2018-02-13 12:20:51 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:20:51 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:20:51 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:20:51 --> Helper loaded: users_helper
INFO - 2018-02-13 12:20:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:20:51 --> Helper loaded: form_helper
INFO - 2018-02-13 12:20:51 --> Form Validation Class Initialized
INFO - 2018-02-13 12:20:51 --> Controller Class Initialized
INFO - 2018-02-13 12:20:51 --> Model Class Initialized
INFO - 2018-02-13 12:20:51 --> Helper loaded: inflector_helper
INFO - 2018-02-13 12:20:51 --> Model Class Initialized
INFO - 2018-02-13 12:20:51 --> Model Class Initialized
INFO - 2018-02-13 06:50:52 --> Config Class Initialized
INFO - 2018-02-13 06:50:52 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:50:52 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:50:52 --> Utf8 Class Initialized
INFO - 2018-02-13 06:50:52 --> URI Class Initialized
INFO - 2018-02-13 06:50:52 --> Router Class Initialized
INFO - 2018-02-13 06:50:52 --> Output Class Initialized
INFO - 2018-02-13 06:50:52 --> Security Class Initialized
DEBUG - 2018-02-13 06:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 06:50:52 --> Input Class Initialized
INFO - 2018-02-13 06:50:52 --> Language Class Initialized
INFO - 2018-02-13 06:50:52 --> Language Class Initialized
INFO - 2018-02-13 06:50:52 --> Config Class Initialized
INFO - 2018-02-13 06:50:52 --> Loader Class Initialized
INFO - 2018-02-13 12:20:52 --> Helper loaded: url_helper
INFO - 2018-02-13 12:20:52 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:20:52 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:20:52 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:20:52 --> Helper loaded: users_helper
INFO - 2018-02-13 12:20:52 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:20:52 --> Helper loaded: form_helper
INFO - 2018-02-13 12:20:52 --> Form Validation Class Initialized
INFO - 2018-02-13 12:20:52 --> Controller Class Initialized
INFO - 2018-02-13 12:20:52 --> Model Class Initialized
INFO - 2018-02-13 12:20:52 --> Helper loaded: inflector_helper
INFO - 2018-02-13 12:20:52 --> Model Class Initialized
INFO - 2018-02-13 12:20:52 --> Model Class Initialized
INFO - 2018-02-13 12:20:52 --> Model Class Initialized
INFO - 2018-02-13 12:20:52 --> Model Class Initialized
INFO - 2018-02-13 12:20:52 --> Model Class Initialized
DEBUG - 2018-02-13 12:20:52 --> File loaded: /home/pr01004/public_html/application/views/admin/header.php
DEBUG - 2018-02-13 12:20:52 --> File loaded: /home/pr01004/public_html/application/views/admin/dashboard.php
DEBUG - 2018-02-13 12:20:52 --> File loaded: /home/pr01004/public_html/application/views/admin/footer.php
INFO - 2018-02-13 12:20:52 --> Final output sent to browser
DEBUG - 2018-02-13 12:20:52 --> Total execution time: 0.1095
INFO - 2018-02-13 06:51:07 --> Config Class Initialized
INFO - 2018-02-13 06:51:07 --> Hooks Class Initialized
DEBUG - 2018-02-13 06:51:07 --> UTF-8 Support Enabled
INFO - 2018-02-13 06:51:07 --> Utf8 Class Initialized
INFO - 2018-02-13 07:17:47 --> Config Class Initialized
INFO - 2018-02-13 07:17:47 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:17:47 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:17:47 --> Utf8 Class Initialized
INFO - 2018-02-13 07:17:47 --> URI Class Initialized
INFO - 2018-02-13 07:17:47 --> Router Class Initialized
INFO - 2018-02-13 07:17:47 --> Output Class Initialized
INFO - 2018-02-13 07:17:47 --> Security Class Initialized
DEBUG - 2018-02-13 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:17:47 --> Input Class Initialized
INFO - 2018-02-13 07:17:47 --> Language Class Initialized
INFO - 2018-02-13 07:17:47 --> Language Class Initialized
INFO - 2018-02-13 07:17:47 --> Config Class Initialized
INFO - 2018-02-13 07:17:47 --> Loader Class Initialized
INFO - 2018-02-13 12:47:47 --> Helper loaded: url_helper
INFO - 2018-02-13 12:47:47 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:47:47 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:47:47 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:47:47 --> Helper loaded: users_helper
INFO - 2018-02-13 12:47:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:47:48 --> Helper loaded: form_helper
INFO - 2018-02-13 12:47:48 --> Form Validation Class Initialized
INFO - 2018-02-13 12:47:48 --> Controller Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:47:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:47:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:47:48 --> Model Class Initialized
INFO - 2018-02-13 12:47:48 --> Final output sent to browser
DEBUG - 2018-02-13 12:47:48 --> Total execution time: 0.1378
INFO - 2018-02-13 07:17:49 --> Config Class Initialized
INFO - 2018-02-13 07:17:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:17:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:17:49 --> Utf8 Class Initialized
INFO - 2018-02-13 07:17:49 --> URI Class Initialized
INFO - 2018-02-13 07:17:49 --> Router Class Initialized
INFO - 2018-02-13 07:17:49 --> Output Class Initialized
INFO - 2018-02-13 07:17:49 --> Security Class Initialized
DEBUG - 2018-02-13 07:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:17:49 --> Input Class Initialized
INFO - 2018-02-13 07:17:49 --> Language Class Initialized
INFO - 2018-02-13 07:17:49 --> Language Class Initialized
INFO - 2018-02-13 07:17:49 --> Config Class Initialized
INFO - 2018-02-13 07:17:49 --> Loader Class Initialized
INFO - 2018-02-13 12:47:49 --> Helper loaded: url_helper
INFO - 2018-02-13 12:47:49 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:47:49 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:47:49 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:47:49 --> Helper loaded: users_helper
INFO - 2018-02-13 12:47:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:47:49 --> Helper loaded: form_helper
INFO - 2018-02-13 12:47:49 --> Form Validation Class Initialized
INFO - 2018-02-13 12:47:49 --> Controller Class Initialized
INFO - 2018-02-13 12:47:49 --> Model Class Initialized
INFO - 2018-02-13 12:47:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:47:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:47:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:47:49 --> Model Class Initialized
INFO - 2018-02-13 12:47:49 --> Model Class Initialized
INFO - 2018-02-13 12:47:49 --> Model Class Initialized
INFO - 2018-02-13 12:47:49 --> Model Class Initialized
INFO - 2018-02-13 12:47:49 --> Model Class Initialized
INFO - 2018-02-13 12:47:49 --> Model Class Initialized
INFO - 2018-02-13 12:47:49 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:47:49 --> Model Class Initialized
INFO - 2018-02-13 12:47:49 --> Final output sent to browser
DEBUG - 2018-02-13 12:47:49 --> Total execution time: 0.1015
INFO - 2018-02-13 07:18:02 --> Config Class Initialized
INFO - 2018-02-13 07:18:02 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:18:02 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:18:02 --> Utf8 Class Initialized
INFO - 2018-02-13 07:18:02 --> URI Class Initialized
INFO - 2018-02-13 07:18:02 --> Router Class Initialized
INFO - 2018-02-13 07:18:02 --> Output Class Initialized
INFO - 2018-02-13 07:18:02 --> Security Class Initialized
DEBUG - 2018-02-13 07:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:18:02 --> Input Class Initialized
INFO - 2018-02-13 07:18:02 --> Language Class Initialized
INFO - 2018-02-13 07:18:02 --> Language Class Initialized
INFO - 2018-02-13 07:18:02 --> Config Class Initialized
INFO - 2018-02-13 07:18:02 --> Loader Class Initialized
INFO - 2018-02-13 12:48:02 --> Helper loaded: url_helper
INFO - 2018-02-13 12:48:02 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:48:02 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:48:02 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:48:02 --> Helper loaded: users_helper
INFO - 2018-02-13 12:48:02 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:48:02 --> Helper loaded: form_helper
INFO - 2018-02-13 12:48:02 --> Form Validation Class Initialized
INFO - 2018-02-13 12:48:02 --> Controller Class Initialized
INFO - 2018-02-13 12:48:02 --> Model Class Initialized
INFO - 2018-02-13 12:48:02 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:48:03 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:48:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:48:03 --> Model Class Initialized
INFO - 2018-02-13 12:48:03 --> Model Class Initialized
INFO - 2018-02-13 12:48:03 --> Model Class Initialized
INFO - 2018-02-13 12:48:03 --> Model Class Initialized
INFO - 2018-02-13 12:48:03 --> Final output sent to browser
DEBUG - 2018-02-13 12:48:03 --> Total execution time: 0.1085
INFO - 2018-02-13 07:18:05 --> Config Class Initialized
INFO - 2018-02-13 07:18:05 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:18:05 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:18:05 --> Utf8 Class Initialized
INFO - 2018-02-13 07:18:05 --> URI Class Initialized
INFO - 2018-02-13 07:18:05 --> Router Class Initialized
INFO - 2018-02-13 07:18:05 --> Output Class Initialized
INFO - 2018-02-13 07:18:05 --> Security Class Initialized
DEBUG - 2018-02-13 07:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:18:05 --> Input Class Initialized
INFO - 2018-02-13 07:18:05 --> Language Class Initialized
INFO - 2018-02-13 07:18:05 --> Language Class Initialized
INFO - 2018-02-13 07:18:05 --> Config Class Initialized
INFO - 2018-02-13 07:18:05 --> Loader Class Initialized
INFO - 2018-02-13 12:48:05 --> Helper loaded: url_helper
INFO - 2018-02-13 12:48:05 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:48:05 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:48:05 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:48:05 --> Helper loaded: users_helper
INFO - 2018-02-13 12:48:05 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:48:05 --> Helper loaded: form_helper
INFO - 2018-02-13 12:48:05 --> Form Validation Class Initialized
INFO - 2018-02-13 12:48:05 --> Controller Class Initialized
INFO - 2018-02-13 12:48:05 --> Model Class Initialized
INFO - 2018-02-13 12:48:05 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:48:05 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:48:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:48:05 --> Model Class Initialized
INFO - 2018-02-13 12:48:05 --> Model Class Initialized
INFO - 2018-02-13 12:48:05 --> Final output sent to browser
DEBUG - 2018-02-13 12:48:05 --> Total execution time: 0.1062
INFO - 2018-02-13 07:18:25 --> Config Class Initialized
INFO - 2018-02-13 07:18:25 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:18:25 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:18:25 --> Utf8 Class Initialized
INFO - 2018-02-13 07:18:25 --> URI Class Initialized
INFO - 2018-02-13 07:18:25 --> Router Class Initialized
INFO - 2018-02-13 07:18:25 --> Output Class Initialized
INFO - 2018-02-13 07:18:25 --> Security Class Initialized
DEBUG - 2018-02-13 07:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:18:25 --> Input Class Initialized
INFO - 2018-02-13 07:18:25 --> Language Class Initialized
INFO - 2018-02-13 07:18:25 --> Language Class Initialized
INFO - 2018-02-13 07:18:25 --> Config Class Initialized
INFO - 2018-02-13 07:18:25 --> Loader Class Initialized
INFO - 2018-02-13 12:48:25 --> Helper loaded: url_helper
INFO - 2018-02-13 12:48:25 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:48:25 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:48:25 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:48:25 --> Helper loaded: users_helper
INFO - 2018-02-13 12:48:26 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:48:26 --> Helper loaded: form_helper
INFO - 2018-02-13 12:48:26 --> Form Validation Class Initialized
INFO - 2018-02-13 12:48:26 --> Controller Class Initialized
INFO - 2018-02-13 12:48:26 --> Model Class Initialized
INFO - 2018-02-13 12:48:26 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:48:26 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:48:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:48:26 --> Model Class Initialized
INFO - 2018-02-13 12:48:26 --> Model Class Initialized
INFO - 2018-02-13 12:48:26 --> Model Class Initialized
INFO - 2018-02-13 12:48:26 --> Model Class Initialized
INFO - 2018-02-13 12:48:26 --> Final output sent to browser
DEBUG - 2018-02-13 12:48:26 --> Total execution time: 0.0925
INFO - 2018-02-13 07:18:27 --> Config Class Initialized
INFO - 2018-02-13 07:18:27 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:18:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:18:27 --> Utf8 Class Initialized
INFO - 2018-02-13 07:18:27 --> URI Class Initialized
INFO - 2018-02-13 07:18:27 --> Router Class Initialized
INFO - 2018-02-13 07:18:27 --> Output Class Initialized
INFO - 2018-02-13 07:18:27 --> Security Class Initialized
DEBUG - 2018-02-13 07:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:18:27 --> Input Class Initialized
INFO - 2018-02-13 07:18:27 --> Language Class Initialized
INFO - 2018-02-13 07:18:27 --> Language Class Initialized
INFO - 2018-02-13 07:18:27 --> Config Class Initialized
INFO - 2018-02-13 07:18:27 --> Loader Class Initialized
INFO - 2018-02-13 12:48:27 --> Helper loaded: url_helper
INFO - 2018-02-13 12:48:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:48:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:48:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:48:27 --> Helper loaded: users_helper
INFO - 2018-02-13 12:48:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:48:27 --> Helper loaded: form_helper
INFO - 2018-02-13 12:48:27 --> Form Validation Class Initialized
INFO - 2018-02-13 12:48:27 --> Controller Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:48:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:48:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:48:27 --> Final output sent to browser
DEBUG - 2018-02-13 12:48:27 --> Total execution time: 0.1073
INFO - 2018-02-13 07:18:27 --> Config Class Initialized
INFO - 2018-02-13 07:18:27 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:18:27 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:18:27 --> Utf8 Class Initialized
INFO - 2018-02-13 07:18:27 --> URI Class Initialized
INFO - 2018-02-13 07:18:27 --> Router Class Initialized
INFO - 2018-02-13 07:18:27 --> Output Class Initialized
INFO - 2018-02-13 07:18:27 --> Security Class Initialized
DEBUG - 2018-02-13 07:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:18:27 --> Input Class Initialized
INFO - 2018-02-13 07:18:27 --> Language Class Initialized
INFO - 2018-02-13 07:18:27 --> Language Class Initialized
INFO - 2018-02-13 07:18:27 --> Config Class Initialized
INFO - 2018-02-13 07:18:27 --> Loader Class Initialized
INFO - 2018-02-13 12:48:27 --> Helper loaded: url_helper
INFO - 2018-02-13 12:48:27 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:48:27 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:48:27 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:48:27 --> Helper loaded: users_helper
INFO - 2018-02-13 12:48:27 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:48:27 --> Helper loaded: form_helper
INFO - 2018-02-13 12:48:27 --> Form Validation Class Initialized
INFO - 2018-02-13 12:48:27 --> Controller Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:48:27 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:48:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Model Class Initialized
INFO - 2018-02-13 12:48:27 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:48:27 --> Final output sent to browser
DEBUG - 2018-02-13 12:48:27 --> Total execution time: 0.1176
INFO - 2018-02-13 07:19:11 --> Config Class Initialized
INFO - 2018-02-13 07:19:11 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:19:11 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:19:11 --> Utf8 Class Initialized
INFO - 2018-02-13 07:19:11 --> URI Class Initialized
INFO - 2018-02-13 07:19:11 --> Router Class Initialized
INFO - 2018-02-13 07:19:11 --> Output Class Initialized
INFO - 2018-02-13 07:19:11 --> Security Class Initialized
DEBUG - 2018-02-13 07:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:19:11 --> Input Class Initialized
INFO - 2018-02-13 07:19:11 --> Language Class Initialized
INFO - 2018-02-13 07:19:11 --> Language Class Initialized
INFO - 2018-02-13 07:19:11 --> Config Class Initialized
INFO - 2018-02-13 07:19:11 --> Loader Class Initialized
INFO - 2018-02-13 12:49:11 --> Helper loaded: url_helper
INFO - 2018-02-13 12:49:11 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:49:11 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:49:11 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:49:11 --> Helper loaded: users_helper
INFO - 2018-02-13 12:49:11 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:49:11 --> Helper loaded: form_helper
INFO - 2018-02-13 12:49:11 --> Form Validation Class Initialized
INFO - 2018-02-13 12:49:11 --> Controller Class Initialized
INFO - 2018-02-13 12:49:11 --> Model Class Initialized
INFO - 2018-02-13 12:49:11 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:49:11 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:49:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:49:11 --> Model Class Initialized
INFO - 2018-02-13 12:49:11 --> Model Class Initialized
INFO - 2018-02-13 12:49:11 --> Model Class Initialized
INFO - 2018-02-13 12:49:11 --> Model Class Initialized
INFO - 2018-02-13 12:49:11 --> Model Class Initialized
INFO - 2018-02-13 12:49:11 --> Model Class Initialized
INFO - 2018-02-13 12:49:11 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:49:11 --> Final output sent to browser
DEBUG - 2018-02-13 12:49:11 --> Total execution time: 0.1127
INFO - 2018-02-13 07:19:14 --> Config Class Initialized
INFO - 2018-02-13 07:19:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:19:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:19:14 --> Utf8 Class Initialized
INFO - 2018-02-13 07:19:14 --> URI Class Initialized
INFO - 2018-02-13 07:19:14 --> Router Class Initialized
INFO - 2018-02-13 07:19:14 --> Output Class Initialized
INFO - 2018-02-13 07:19:14 --> Security Class Initialized
DEBUG - 2018-02-13 07:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:19:14 --> Input Class Initialized
INFO - 2018-02-13 07:19:14 --> Language Class Initialized
INFO - 2018-02-13 07:19:14 --> Language Class Initialized
INFO - 2018-02-13 07:19:14 --> Config Class Initialized
INFO - 2018-02-13 07:19:14 --> Loader Class Initialized
INFO - 2018-02-13 12:49:14 --> Helper loaded: url_helper
INFO - 2018-02-13 12:49:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:49:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:49:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:49:14 --> Helper loaded: users_helper
INFO - 2018-02-13 12:49:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:49:15 --> Helper loaded: form_helper
INFO - 2018-02-13 12:49:15 --> Form Validation Class Initialized
INFO - 2018-02-13 12:49:15 --> Controller Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:49:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:49:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Final output sent to browser
DEBUG - 2018-02-13 12:49:15 --> Total execution time: 0.1170
INFO - 2018-02-13 07:19:15 --> Config Class Initialized
INFO - 2018-02-13 07:19:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:19:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:19:15 --> Utf8 Class Initialized
INFO - 2018-02-13 07:19:15 --> URI Class Initialized
INFO - 2018-02-13 07:19:15 --> Router Class Initialized
INFO - 2018-02-13 07:19:15 --> Output Class Initialized
INFO - 2018-02-13 07:19:15 --> Security Class Initialized
DEBUG - 2018-02-13 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:19:15 --> Input Class Initialized
INFO - 2018-02-13 07:19:15 --> Language Class Initialized
INFO - 2018-02-13 07:19:15 --> Language Class Initialized
INFO - 2018-02-13 07:19:15 --> Config Class Initialized
INFO - 2018-02-13 07:19:15 --> Loader Class Initialized
INFO - 2018-02-13 12:49:15 --> Helper loaded: url_helper
INFO - 2018-02-13 12:49:15 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:49:15 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:49:15 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:49:15 --> Helper loaded: users_helper
INFO - 2018-02-13 12:49:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:49:15 --> Helper loaded: form_helper
INFO - 2018-02-13 12:49:15 --> Form Validation Class Initialized
INFO - 2018-02-13 12:49:15 --> Controller Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:49:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:49:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Model Class Initialized
INFO - 2018-02-13 12:49:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:49:15 --> Final output sent to browser
DEBUG - 2018-02-13 12:49:15 --> Total execution time: 0.0993
INFO - 2018-02-13 07:19:46 --> Config Class Initialized
INFO - 2018-02-13 07:19:46 --> Hooks Class Initialized
DEBUG - 2018-02-13 07:19:46 --> UTF-8 Support Enabled
INFO - 2018-02-13 07:19:46 --> Utf8 Class Initialized
INFO - 2018-02-13 07:19:46 --> URI Class Initialized
INFO - 2018-02-13 07:19:46 --> Router Class Initialized
INFO - 2018-02-13 07:19:46 --> Output Class Initialized
INFO - 2018-02-13 07:19:46 --> Security Class Initialized
DEBUG - 2018-02-13 07:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 07:19:46 --> Input Class Initialized
INFO - 2018-02-13 07:19:46 --> Language Class Initialized
INFO - 2018-02-13 07:19:46 --> Language Class Initialized
INFO - 2018-02-13 07:19:46 --> Config Class Initialized
INFO - 2018-02-13 07:19:46 --> Loader Class Initialized
INFO - 2018-02-13 12:49:46 --> Helper loaded: url_helper
INFO - 2018-02-13 12:49:46 --> Helper loaded: notification_helper
INFO - 2018-02-13 12:49:46 --> Helper loaded: settings_helper
INFO - 2018-02-13 12:49:46 --> Helper loaded: permission_helper
INFO - 2018-02-13 12:49:46 --> Helper loaded: users_helper
INFO - 2018-02-13 12:49:46 --> Database Driver Class Initialized
DEBUG - 2018-02-13 12:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 12:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 12:49:46 --> Helper loaded: form_helper
INFO - 2018-02-13 12:49:46 --> Form Validation Class Initialized
INFO - 2018-02-13 12:49:46 --> Controller Class Initialized
INFO - 2018-02-13 12:49:46 --> Model Class Initialized
INFO - 2018-02-13 12:49:46 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 12:49:46 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 12:49:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 12:49:46 --> Model Class Initialized
INFO - 2018-02-13 12:49:46 --> Model Class Initialized
INFO - 2018-02-13 12:49:46 --> Model Class Initialized
INFO - 2018-02-13 12:49:46 --> Model Class Initialized
INFO - 2018-02-13 12:49:46 --> Model Class Initialized
INFO - 2018-02-13 12:49:46 --> Model Class Initialized
INFO - 2018-02-13 12:49:46 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 12:49:46 --> Final output sent to browser
DEBUG - 2018-02-13 12:49:46 --> Total execution time: 0.0873
INFO - 2018-02-13 08:35:14 --> Config Class Initialized
INFO - 2018-02-13 08:35:14 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:35:14 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:35:14 --> Utf8 Class Initialized
INFO - 2018-02-13 08:35:14 --> URI Class Initialized
INFO - 2018-02-13 08:35:14 --> Router Class Initialized
INFO - 2018-02-13 08:35:14 --> Output Class Initialized
INFO - 2018-02-13 08:35:14 --> Security Class Initialized
DEBUG - 2018-02-13 08:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:35:14 --> Input Class Initialized
INFO - 2018-02-13 08:35:14 --> Language Class Initialized
INFO - 2018-02-13 08:35:14 --> Language Class Initialized
INFO - 2018-02-13 08:35:14 --> Config Class Initialized
INFO - 2018-02-13 08:35:14 --> Loader Class Initialized
INFO - 2018-02-13 14:05:14 --> Helper loaded: url_helper
INFO - 2018-02-13 14:05:14 --> Helper loaded: notification_helper
INFO - 2018-02-13 14:05:14 --> Helper loaded: settings_helper
INFO - 2018-02-13 14:05:14 --> Helper loaded: permission_helper
INFO - 2018-02-13 14:05:14 --> Helper loaded: users_helper
INFO - 2018-02-13 14:05:14 --> Database Driver Class Initialized
DEBUG - 2018-02-13 14:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 14:05:14 --> Helper loaded: form_helper
INFO - 2018-02-13 14:05:14 --> Form Validation Class Initialized
INFO - 2018-02-13 14:05:14 --> Controller Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 14:05:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 14:05:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 14:05:15 --> Final output sent to browser
DEBUG - 2018-02-13 14:05:15 --> Total execution time: 0.1212
INFO - 2018-02-13 08:35:15 --> Config Class Initialized
INFO - 2018-02-13 08:35:15 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:35:15 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:35:15 --> Utf8 Class Initialized
INFO - 2018-02-13 08:35:15 --> URI Class Initialized
INFO - 2018-02-13 08:35:15 --> Router Class Initialized
INFO - 2018-02-13 08:35:15 --> Output Class Initialized
INFO - 2018-02-13 08:35:15 --> Security Class Initialized
DEBUG - 2018-02-13 08:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:35:15 --> Input Class Initialized
INFO - 2018-02-13 08:35:15 --> Language Class Initialized
INFO - 2018-02-13 08:35:15 --> Language Class Initialized
INFO - 2018-02-13 08:35:15 --> Config Class Initialized
INFO - 2018-02-13 08:35:15 --> Loader Class Initialized
INFO - 2018-02-13 14:05:15 --> Helper loaded: url_helper
INFO - 2018-02-13 14:05:15 --> Helper loaded: notification_helper
INFO - 2018-02-13 14:05:15 --> Helper loaded: settings_helper
INFO - 2018-02-13 14:05:15 --> Helper loaded: permission_helper
INFO - 2018-02-13 14:05:15 --> Helper loaded: users_helper
INFO - 2018-02-13 14:05:15 --> Database Driver Class Initialized
DEBUG - 2018-02-13 14:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 14:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 14:05:15 --> Helper loaded: form_helper
INFO - 2018-02-13 14:05:15 --> Form Validation Class Initialized
INFO - 2018-02-13 14:05:15 --> Controller Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 14:05:15 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 14:05:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Model Class Initialized
INFO - 2018-02-13 14:05:15 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 14:05:15 --> Final output sent to browser
DEBUG - 2018-02-13 14:05:15 --> Total execution time: 0.1052
INFO - 2018-02-13 08:35:16 --> Config Class Initialized
INFO - 2018-02-13 08:35:16 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:35:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:35:16 --> Utf8 Class Initialized
INFO - 2018-02-13 08:35:16 --> URI Class Initialized
INFO - 2018-02-13 08:35:16 --> Router Class Initialized
INFO - 2018-02-13 08:35:16 --> Output Class Initialized
INFO - 2018-02-13 08:35:16 --> Security Class Initialized
INFO - 2018-02-13 08:35:16 --> Config Class Initialized
INFO - 2018-02-13 08:35:16 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:35:16 --> Input Class Initialized
INFO - 2018-02-13 08:35:16 --> Language Class Initialized
DEBUG - 2018-02-13 08:35:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:35:16 --> Utf8 Class Initialized
INFO - 2018-02-13 08:35:16 --> URI Class Initialized
INFO - 2018-02-13 08:35:16 --> Router Class Initialized
INFO - 2018-02-13 08:35:16 --> Output Class Initialized
INFO - 2018-02-13 08:35:16 --> Security Class Initialized
DEBUG - 2018-02-13 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:35:16 --> Input Class Initialized
INFO - 2018-02-13 08:35:16 --> Language Class Initialized
INFO - 2018-02-13 08:35:16 --> Config Class Initialized
INFO - 2018-02-13 08:35:16 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:35:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:35:16 --> Utf8 Class Initialized
INFO - 2018-02-13 08:35:16 --> Language Class Initialized
INFO - 2018-02-13 08:35:16 --> Config Class Initialized
INFO - 2018-02-13 08:35:16 --> Loader Class Initialized
INFO - 2018-02-13 08:35:16 --> URI Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: url_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: notification_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: settings_helper
INFO - 2018-02-13 08:35:16 --> Config Class Initialized
INFO - 2018-02-13 08:35:16 --> Hooks Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: permission_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: users_helper
INFO - 2018-02-13 08:35:16 --> Router Class Initialized
DEBUG - 2018-02-13 08:35:16 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:35:16 --> Utf8 Class Initialized
INFO - 2018-02-13 08:35:16 --> Language Class Initialized
INFO - 2018-02-13 08:35:16 --> Config Class Initialized
INFO - 2018-02-13 08:35:16 --> Loader Class Initialized
INFO - 2018-02-13 08:35:16 --> Output Class Initialized
INFO - 2018-02-13 08:35:16 --> URI Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: url_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: notification_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: settings_helper
INFO - 2018-02-13 08:35:16 --> Security Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: permission_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: users_helper
INFO - 2018-02-13 08:35:16 --> Router Class Initialized
DEBUG - 2018-02-13 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:35:16 --> Input Class Initialized
INFO - 2018-02-13 08:35:16 --> Language Class Initialized
INFO - 2018-02-13 08:35:16 --> Output Class Initialized
INFO - 2018-02-13 08:35:16 --> Security Class Initialized
INFO - 2018-02-13 14:05:16 --> Database Driver Class Initialized
DEBUG - 2018-02-13 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:35:16 --> Input Class Initialized
INFO - 2018-02-13 08:35:16 --> Language Class Initialized
INFO - 2018-02-13 14:05:16 --> Database Driver Class Initialized
DEBUG - 2018-02-13 14:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 14:05:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 14:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 14:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 14:05:16 --> Helper loaded: form_helper
INFO - 2018-02-13 14:05:16 --> Form Validation Class Initialized
INFO - 2018-02-13 14:05:16 --> Controller Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: form_helper
INFO - 2018-02-13 14:05:16 --> Form Validation Class Initialized
INFO - 2018-02-13 14:05:16 --> Controller Class Initialized
INFO - 2018-02-13 08:35:16 --> Language Class Initialized
INFO - 2018-02-13 08:35:16 --> Config Class Initialized
INFO - 2018-02-13 08:35:16 --> Loader Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: url_helper
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: notification_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: inflector_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: settings_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: permission_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: users_helper
DEBUG - 2018-02-13 14:05:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 08:35:16 --> Language Class Initialized
INFO - 2018-02-13 08:35:16 --> Config Class Initialized
INFO - 2018-02-13 08:35:16 --> Loader Class Initialized
INFO - 2018-02-13 14:05:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: inflector_helper
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: url_helper
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
DEBUG - 2018-02-13 14:05:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 14:05:16 --> Helper loaded: notification_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: settings_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: permission_helper
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 14:05:16 --> Helper loaded: users_helper
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Database Driver Class Initialized
INFO - 2018-02-13 14:05:16 --> Final output sent to browser
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
DEBUG - 2018-02-13 14:05:16 --> Total execution time: 0.0909
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
DEBUG - 2018-02-13 14:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 14:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 14:05:16 --> Database Driver Class Initialized
INFO - 2018-02-13 14:05:16 --> Final output sent to browser
DEBUG - 2018-02-13 14:05:16 --> Total execution time: 0.1206
INFO - 2018-02-13 14:05:16 --> Helper loaded: form_helper
INFO - 2018-02-13 14:05:16 --> Form Validation Class Initialized
INFO - 2018-02-13 14:05:16 --> Controller Class Initialized
DEBUG - 2018-02-13 14:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 14:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: inflector_helper
INFO - 2018-02-13 14:05:16 --> Helper loaded: form_helper
INFO - 2018-02-13 14:05:16 --> Form Validation Class Initialized
INFO - 2018-02-13 14:05:16 --> Controller Class Initialized
DEBUG - 2018-02-13 14:05:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 14:05:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Helper loaded: inflector_helper
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Final output sent to browser
DEBUG - 2018-02-13 14:05:16 --> Total execution time: 0.1077
DEBUG - 2018-02-13 14:05:16 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 14:05:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 14:05:16 --> Model Class Initialized
INFO - 2018-02-13 14:05:16 --> Final output sent to browser
DEBUG - 2018-02-13 14:05:16 --> Total execution time: 0.1075
INFO - 2018-02-13 08:35:17 --> Config Class Initialized
INFO - 2018-02-13 08:35:17 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:35:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:35:17 --> Utf8 Class Initialized
INFO - 2018-02-13 08:35:17 --> URI Class Initialized
INFO - 2018-02-13 08:35:17 --> Router Class Initialized
INFO - 2018-02-13 08:35:17 --> Config Class Initialized
INFO - 2018-02-13 08:35:17 --> Hooks Class Initialized
INFO - 2018-02-13 08:35:17 --> Output Class Initialized
INFO - 2018-02-13 08:35:17 --> Security Class Initialized
DEBUG - 2018-02-13 08:35:17 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:35:17 --> Utf8 Class Initialized
INFO - 2018-02-13 08:35:17 --> URI Class Initialized
DEBUG - 2018-02-13 08:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:35:17 --> Input Class Initialized
INFO - 2018-02-13 08:35:17 --> Language Class Initialized
INFO - 2018-02-13 08:35:17 --> Router Class Initialized
INFO - 2018-02-13 08:35:17 --> Output Class Initialized
INFO - 2018-02-13 08:35:17 --> Security Class Initialized
DEBUG - 2018-02-13 08:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:35:17 --> Input Class Initialized
INFO - 2018-02-13 08:35:17 --> Language Class Initialized
INFO - 2018-02-13 08:35:17 --> Language Class Initialized
INFO - 2018-02-13 08:35:17 --> Config Class Initialized
INFO - 2018-02-13 08:35:17 --> Loader Class Initialized
INFO - 2018-02-13 14:05:17 --> Helper loaded: url_helper
INFO - 2018-02-13 14:05:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 14:05:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 14:05:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 14:05:17 --> Helper loaded: users_helper
INFO - 2018-02-13 08:35:17 --> Language Class Initialized
INFO - 2018-02-13 08:35:17 --> Config Class Initialized
INFO - 2018-02-13 08:35:17 --> Loader Class Initialized
INFO - 2018-02-13 14:05:17 --> Helper loaded: url_helper
INFO - 2018-02-13 14:05:17 --> Helper loaded: notification_helper
INFO - 2018-02-13 14:05:17 --> Helper loaded: settings_helper
INFO - 2018-02-13 14:05:17 --> Helper loaded: permission_helper
INFO - 2018-02-13 14:05:17 --> Database Driver Class Initialized
INFO - 2018-02-13 14:05:17 --> Helper loaded: users_helper
DEBUG - 2018-02-13 14:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 14:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 14:05:17 --> Helper loaded: form_helper
INFO - 2018-02-13 14:05:17 --> Form Validation Class Initialized
INFO - 2018-02-13 14:05:17 --> Controller Class Initialized
INFO - 2018-02-13 14:05:17 --> Database Driver Class Initialized
DEBUG - 2018-02-13 14:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 14:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Helper loaded: inflector_helper
INFO - 2018-02-13 14:05:17 --> Helper loaded: form_helper
INFO - 2018-02-13 14:05:17 --> Form Validation Class Initialized
INFO - 2018-02-13 14:05:17 --> Controller Class Initialized
DEBUG - 2018-02-13 14:05:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 14:05:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 14:05:17 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 14:05:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Model Class Initialized
INFO - 2018-02-13 14:05:17 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 14:05:17 --> Final output sent to browser
DEBUG - 2018-02-13 14:05:17 --> Total execution time: 0.1259
INFO - 2018-02-13 14:05:17 --> Final output sent to browser
DEBUG - 2018-02-13 14:05:17 --> Total execution time: 0.1140
INFO - 2018-02-13 08:35:18 --> Config Class Initialized
INFO - 2018-02-13 08:35:18 --> Hooks Class Initialized
DEBUG - 2018-02-13 08:35:18 --> UTF-8 Support Enabled
INFO - 2018-02-13 08:35:18 --> Utf8 Class Initialized
INFO - 2018-02-13 08:35:18 --> URI Class Initialized
INFO - 2018-02-13 08:35:18 --> Router Class Initialized
INFO - 2018-02-13 08:35:18 --> Output Class Initialized
INFO - 2018-02-13 08:35:18 --> Security Class Initialized
DEBUG - 2018-02-13 08:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 08:35:18 --> Input Class Initialized
INFO - 2018-02-13 08:35:18 --> Language Class Initialized
INFO - 2018-02-13 08:35:18 --> Language Class Initialized
INFO - 2018-02-13 08:35:18 --> Config Class Initialized
INFO - 2018-02-13 08:35:18 --> Loader Class Initialized
INFO - 2018-02-13 14:05:18 --> Helper loaded: url_helper
INFO - 2018-02-13 14:05:18 --> Helper loaded: notification_helper
INFO - 2018-02-13 14:05:18 --> Helper loaded: settings_helper
INFO - 2018-02-13 14:05:18 --> Helper loaded: permission_helper
INFO - 2018-02-13 14:05:18 --> Helper loaded: users_helper
INFO - 2018-02-13 14:05:18 --> Database Driver Class Initialized
DEBUG - 2018-02-13 14:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 14:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 14:05:18 --> Helper loaded: form_helper
INFO - 2018-02-13 14:05:18 --> Form Validation Class Initialized
INFO - 2018-02-13 14:05:18 --> Controller Class Initialized
INFO - 2018-02-13 14:05:18 --> Model Class Initialized
INFO - 2018-02-13 14:05:18 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 14:05:18 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 14:05:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 14:05:18 --> Model Class Initialized
INFO - 2018-02-13 14:05:18 --> Model Class Initialized
INFO - 2018-02-13 14:05:18 --> Model Class Initialized
INFO - 2018-02-13 14:05:18 --> Model Class Initialized
INFO - 2018-02-13 14:05:18 --> Model Class Initialized
INFO - 2018-02-13 14:05:18 --> Model Class Initialized
INFO - 2018-02-13 14:05:18 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 14:05:18 --> Final output sent to browser
DEBUG - 2018-02-13 14:05:18 --> Total execution time: 0.1174
INFO - 2018-02-13 13:01:45 --> Config Class Initialized
INFO - 2018-02-13 13:01:45 --> Config Class Initialized
INFO - 2018-02-13 13:01:45 --> Config Class Initialized
INFO - 2018-02-13 13:01:45 --> Hooks Class Initialized
INFO - 2018-02-13 13:01:45 --> Hooks Class Initialized
INFO - 2018-02-13 13:01:45 --> Hooks Class Initialized
DEBUG - 2018-02-13 13:01:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 13:01:45 --> Utf8 Class Initialized
DEBUG - 2018-02-13 13:01:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 13:01:45 --> Utf8 Class Initialized
DEBUG - 2018-02-13 13:01:45 --> UTF-8 Support Enabled
INFO - 2018-02-13 13:01:45 --> Utf8 Class Initialized
INFO - 2018-02-13 13:01:45 --> URI Class Initialized
INFO - 2018-02-13 13:01:45 --> URI Class Initialized
INFO - 2018-02-13 13:01:45 --> URI Class Initialized
INFO - 2018-02-13 13:01:45 --> Router Class Initialized
INFO - 2018-02-13 13:01:45 --> Router Class Initialized
INFO - 2018-02-13 13:01:45 --> Router Class Initialized
INFO - 2018-02-13 13:01:45 --> Output Class Initialized
INFO - 2018-02-13 13:01:45 --> Output Class Initialized
INFO - 2018-02-13 13:01:45 --> Output Class Initialized
INFO - 2018-02-13 13:01:45 --> Security Class Initialized
INFO - 2018-02-13 13:01:45 --> Security Class Initialized
DEBUG - 2018-02-13 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 13:01:45 --> Input Class Initialized
INFO - 2018-02-13 13:01:45 --> Security Class Initialized
DEBUG - 2018-02-13 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 13:01:45 --> Input Class Initialized
DEBUG - 2018-02-13 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 13:01:45 --> Input Class Initialized
INFO - 2018-02-13 13:01:45 --> Language Class Initialized
INFO - 2018-02-13 13:01:45 --> Language Class Initialized
INFO - 2018-02-13 13:01:45 --> Language Class Initialized
INFO - 2018-02-13 13:01:45 --> Language Class Initialized
INFO - 2018-02-13 13:01:45 --> Config Class Initialized
INFO - 2018-02-13 13:01:45 --> Loader Class Initialized
INFO - 2018-02-13 13:01:45 --> Language Class Initialized
INFO - 2018-02-13 13:01:45 --> Config Class Initialized
INFO - 2018-02-13 13:01:45 --> Loader Class Initialized
INFO - 2018-02-13 13:01:45 --> Language Class Initialized
INFO - 2018-02-13 13:01:45 --> Config Class Initialized
INFO - 2018-02-13 13:01:45 --> Loader Class Initialized
INFO - 2018-02-13 18:31:45 --> Helper loaded: url_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: url_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: url_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: notification_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: notification_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: notification_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: settings_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: settings_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: permission_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: settings_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: permission_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: permission_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: users_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: users_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: users_helper
INFO - 2018-02-13 18:31:45 --> Database Driver Class Initialized
INFO - 2018-02-13 18:31:45 --> Database Driver Class Initialized
INFO - 2018-02-13 18:31:45 --> Database Driver Class Initialized
DEBUG - 2018-02-13 18:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 18:31:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-02-13 18:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-02-13 18:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 18:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 18:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 18:31:45 --> Helper loaded: form_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: form_helper
INFO - 2018-02-13 18:31:45 --> Form Validation Class Initialized
INFO - 2018-02-13 18:31:45 --> Form Validation Class Initialized
INFO - 2018-02-13 18:31:45 --> Helper loaded: form_helper
INFO - 2018-02-13 18:31:45 --> Controller Class Initialized
INFO - 2018-02-13 18:31:45 --> Form Validation Class Initialized
INFO - 2018-02-13 18:31:45 --> Controller Class Initialized
INFO - 2018-02-13 18:31:45 --> Controller Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Helper loaded: inflector_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: inflector_helper
INFO - 2018-02-13 18:31:45 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 18:31:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-13 18:31:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
DEBUG - 2018-02-13 18:31:45 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 18:31:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 18:31:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 18:31:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 18:31:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Final output sent to browser
DEBUG - 2018-02-13 18:31:45 --> Total execution time: 0.4565
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Final output sent to browser
DEBUG - 2018-02-13 18:31:45 --> Total execution time: 0.4637
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 18:31:45 --> Model Class Initialized
INFO - 2018-02-13 18:31:45 --> Final output sent to browser
DEBUG - 2018-02-13 18:31:45 --> Total execution time: 0.5193
INFO - 2018-02-13 13:01:47 --> Config Class Initialized
INFO - 2018-02-13 13:01:47 --> Hooks Class Initialized
DEBUG - 2018-02-13 13:01:47 --> UTF-8 Support Enabled
INFO - 2018-02-13 13:01:47 --> Utf8 Class Initialized
INFO - 2018-02-13 13:01:47 --> URI Class Initialized
INFO - 2018-02-13 13:01:47 --> Router Class Initialized
INFO - 2018-02-13 13:01:47 --> Output Class Initialized
INFO - 2018-02-13 13:01:48 --> Security Class Initialized
DEBUG - 2018-02-13 13:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 13:01:48 --> Input Class Initialized
INFO - 2018-02-13 13:01:48 --> Language Class Initialized
INFO - 2018-02-13 13:01:48 --> Language Class Initialized
INFO - 2018-02-13 13:01:48 --> Config Class Initialized
INFO - 2018-02-13 13:01:48 --> Loader Class Initialized
INFO - 2018-02-13 18:31:48 --> Helper loaded: url_helper
INFO - 2018-02-13 18:31:48 --> Helper loaded: notification_helper
INFO - 2018-02-13 18:31:48 --> Helper loaded: settings_helper
INFO - 2018-02-13 18:31:48 --> Helper loaded: permission_helper
INFO - 2018-02-13 18:31:48 --> Helper loaded: users_helper
INFO - 2018-02-13 18:31:48 --> Database Driver Class Initialized
DEBUG - 2018-02-13 18:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 18:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 18:31:48 --> Helper loaded: form_helper
INFO - 2018-02-13 18:31:48 --> Form Validation Class Initialized
INFO - 2018-02-13 18:31:48 --> Controller Class Initialized
INFO - 2018-02-13 18:31:48 --> Model Class Initialized
INFO - 2018-02-13 18:31:48 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 18:31:48 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 18:31:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 18:31:48 --> Model Class Initialized
INFO - 2018-02-13 18:31:48 --> Model Class Initialized
INFO - 2018-02-13 18:31:48 --> Model Class Initialized
INFO - 2018-02-13 18:31:48 --> Model Class Initialized
INFO - 2018-02-13 18:31:48 --> Final output sent to browser
DEBUG - 2018-02-13 18:31:48 --> Total execution time: 0.2699
INFO - 2018-02-13 13:01:49 --> Config Class Initialized
INFO - 2018-02-13 13:01:49 --> Hooks Class Initialized
DEBUG - 2018-02-13 13:01:49 --> UTF-8 Support Enabled
INFO - 2018-02-13 13:01:49 --> Utf8 Class Initialized
INFO - 2018-02-13 13:01:49 --> URI Class Initialized
INFO - 2018-02-13 13:01:49 --> Router Class Initialized
INFO - 2018-02-13 13:01:49 --> Output Class Initialized
INFO - 2018-02-13 13:01:49 --> Security Class Initialized
DEBUG - 2018-02-13 13:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 13:01:49 --> Input Class Initialized
INFO - 2018-02-13 13:01:49 --> Language Class Initialized
INFO - 2018-02-13 13:01:49 --> Language Class Initialized
INFO - 2018-02-13 13:01:49 --> Config Class Initialized
INFO - 2018-02-13 13:01:49 --> Loader Class Initialized
INFO - 2018-02-13 18:31:49 --> Helper loaded: url_helper
INFO - 2018-02-13 18:31:49 --> Helper loaded: notification_helper
INFO - 2018-02-13 18:31:49 --> Helper loaded: settings_helper
INFO - 2018-02-13 18:31:49 --> Helper loaded: permission_helper
INFO - 2018-02-13 18:31:49 --> Helper loaded: users_helper
INFO - 2018-02-13 18:31:49 --> Database Driver Class Initialized
DEBUG - 2018-02-13 18:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 18:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 18:31:49 --> Helper loaded: form_helper
INFO - 2018-02-13 18:31:49 --> Form Validation Class Initialized
INFO - 2018-02-13 18:31:49 --> Controller Class Initialized
INFO - 2018-02-13 18:31:49 --> Model Class Initialized
INFO - 2018-02-13 18:31:49 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 18:31:49 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 18:31:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 18:31:49 --> Model Class Initialized
INFO - 2018-02-13 18:31:49 --> Model Class Initialized
INFO - 2018-02-13 18:31:49 --> Final output sent to browser
DEBUG - 2018-02-13 18:31:49 --> Total execution time: 0.1103
INFO - 2018-02-13 13:04:47 --> Config Class Initialized
INFO - 2018-02-13 13:04:47 --> Hooks Class Initialized
DEBUG - 2018-02-13 13:04:47 --> UTF-8 Support Enabled
INFO - 2018-02-13 13:04:47 --> Utf8 Class Initialized
INFO - 2018-02-13 13:04:47 --> URI Class Initialized
INFO - 2018-02-13 13:04:47 --> Router Class Initialized
INFO - 2018-02-13 13:04:47 --> Output Class Initialized
INFO - 2018-02-13 13:04:47 --> Security Class Initialized
DEBUG - 2018-02-13 13:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 13:04:47 --> Input Class Initialized
INFO - 2018-02-13 13:04:47 --> Language Class Initialized
INFO - 2018-02-13 13:04:47 --> Language Class Initialized
INFO - 2018-02-13 13:04:47 --> Config Class Initialized
INFO - 2018-02-13 13:04:47 --> Loader Class Initialized
INFO - 2018-02-13 18:34:47 --> Helper loaded: url_helper
INFO - 2018-02-13 18:34:47 --> Helper loaded: notification_helper
INFO - 2018-02-13 18:34:47 --> Helper loaded: settings_helper
INFO - 2018-02-13 18:34:47 --> Helper loaded: permission_helper
INFO - 2018-02-13 18:34:47 --> Helper loaded: users_helper
INFO - 2018-02-13 18:34:47 --> Database Driver Class Initialized
DEBUG - 2018-02-13 18:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 18:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 18:34:47 --> Helper loaded: form_helper
INFO - 2018-02-13 18:34:47 --> Form Validation Class Initialized
INFO - 2018-02-13 18:34:47 --> Controller Class Initialized
INFO - 2018-02-13 18:34:47 --> Model Class Initialized
INFO - 2018-02-13 18:34:47 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 18:34:47 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 18:34:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 18:34:47 --> Model Class Initialized
INFO - 2018-02-13 18:34:47 --> Model Class Initialized
INFO - 2018-02-13 18:34:47 --> Model Class Initialized
INFO - 2018-02-13 18:34:47 --> Model Class Initialized
INFO - 2018-02-13 18:34:47 --> Model Class Initialized
INFO - 2018-02-13 18:34:47 --> Model Class Initialized
INFO - 2018-02-13 18:34:47 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 18:34:47 --> Final output sent to browser
DEBUG - 2018-02-13 18:34:47 --> Total execution time: 0.1111
INFO - 2018-02-13 13:04:51 --> Config Class Initialized
INFO - 2018-02-13 13:04:51 --> Hooks Class Initialized
DEBUG - 2018-02-13 13:04:51 --> UTF-8 Support Enabled
INFO - 2018-02-13 13:04:51 --> Utf8 Class Initialized
INFO - 2018-02-13 13:04:51 --> URI Class Initialized
INFO - 2018-02-13 13:04:51 --> Router Class Initialized
INFO - 2018-02-13 13:04:51 --> Output Class Initialized
INFO - 2018-02-13 13:04:51 --> Security Class Initialized
DEBUG - 2018-02-13 13:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-02-13 13:04:51 --> Input Class Initialized
INFO - 2018-02-13 13:04:51 --> Language Class Initialized
INFO - 2018-02-13 13:04:51 --> Language Class Initialized
INFO - 2018-02-13 13:04:51 --> Config Class Initialized
INFO - 2018-02-13 13:04:51 --> Loader Class Initialized
INFO - 2018-02-13 18:34:51 --> Helper loaded: url_helper
INFO - 2018-02-13 18:34:51 --> Helper loaded: notification_helper
INFO - 2018-02-13 18:34:51 --> Helper loaded: settings_helper
INFO - 2018-02-13 18:34:51 --> Helper loaded: permission_helper
INFO - 2018-02-13 18:34:51 --> Helper loaded: users_helper
INFO - 2018-02-13 18:34:51 --> Database Driver Class Initialized
DEBUG - 2018-02-13 18:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-02-13 18:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-02-13 18:34:51 --> Helper loaded: form_helper
INFO - 2018-02-13 18:34:51 --> Form Validation Class Initialized
INFO - 2018-02-13 18:34:51 --> Controller Class Initialized
INFO - 2018-02-13 18:34:51 --> Model Class Initialized
INFO - 2018-02-13 18:34:51 --> Helper loaded: inflector_helper
DEBUG - 2018-02-13 18:34:51 --> Config file loaded: /home/pr01004/public_html/application/config/rest.php
INFO - 2018-02-13 18:34:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2018-02-13 18:34:51 --> Model Class Initialized
INFO - 2018-02-13 18:34:51 --> Model Class Initialized
INFO - 2018-02-13 18:34:51 --> Model Class Initialized
INFO - 2018-02-13 18:34:51 --> Model Class Initialized
INFO - 2018-02-13 18:34:51 --> Model Class Initialized
INFO - 2018-02-13 18:34:51 --> Model Class Initialized
INFO - 2018-02-13 18:34:51 --> Language file loaded: language/english/message_lang.php
INFO - 2018-02-13 18:34:51 --> Final output sent to browser
DEBUG - 2018-02-13 18:34:51 --> Total execution time: 0.1055
