<?php

$create = check_methods_modules($moduleName,"perm_create");
$read = check_methods_modules($moduleName,"perm_read");
$update = check_methods_modules($moduleName,"perm_update");
$delete  = check_methods_modules($moduleName,"perm_delete");
$perm_update = check_methods_modules($moduleName2,"perm_update");
$perm_create = check_methods_modules($moduleName2,"perm_create");
$perm_read = check_methods_modules($moduleName2,"perm_read");

 ?>


     <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <!-- <h2>
                    JQUERY DATATABLES
                    <small>Taken from <a href="https://datatables.net/" target="_blank">datatables.net</a></small>
                </h2> -->
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                    <?php echo print_notification(); ?>
                        <div class="header">
                            <h2>
                                Admin List
                                <?php if($create){ ?>
                                <span class="right">
                                    <a href="<?php echo base_url(); ?>snackadmin/admin/create" class="btn btn-primary waves-effect">Add New</a><br><br>
                                </span>
                                <?php } ?>
                            </h2>
                            <!-- <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul> -->
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Photo</th>
                                           <?php if($update || $delete || $perm_read || $perm_update || $perm_create){ ?>
                                            <th>Action</th>
                                            <?php } ?>
                                        </tr>
                                    </thead>
                                    <!-- <tfoot>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Photo</th>
                                        </tr>
                                    </tfoot> -->
                                    <tbody>
                                <?php  
                               

                                if(count($adminList) > 0 && !empty($adminList)){ ?>
                                      <?php foreach (@$adminList as $row) { ?>
                                          <tr>
                                            <td><?php echo $row->admin_name; ?></td>
                                            <td><?php echo $row->admin_email; ?></td>
                                            <td><?php echo $row->admin_mobile; ?></td>
                                            <td><?php if($row->admin_photo!=""){ ?><img src="<?php echo base_url(); ?>uploads/admin/<?php echo $row->admin_photo; ?>" height="50" width="50"><?php } ?> </td>
                                            <?php if($update || $delete || $perm_read || $perm_update || $perm_create){ ?>
                                            <td>
                                            <?php if($update && ($row->admin_type!='2' || $this->session->userdata('admin_type')=="2")){ ?>
                                            <a href="<?php echo base_url(); ?>snackadmin/admin/manageadmin/edit/<?php echo $row->admin_id; ?>">
                                            <i class="material-icons">create</i></a>
                                            <?php } ?>
                                            <?php if($delete){ ?>
                                            <a href="#" 
                                       data-url="<?php echo base_url(); ?>snackadmin/admin/delete/<?php echo $row->admin_id; ?>/"
                                       data-title="<?php  echo $row->admin_name; ?>"
                                       class="js-sweetalert" data-type="confirm">
                                            <i class="material-icons">delete</i></a>
                                            <?php } ?>

                                            <?php if($perm_read || $perm_update || $perm_create){ ?>

                                            <?php
                                           
                                             if($row->admin_type!='2' || $this->session->userdata('admin_type')=="2"){ ?>
                                             <a href="<?php echo base_url(); ?>snackadmin/admin/permission/<?php echo $row->admin_id; ?>/"><i class="material-icons">settings_applications</i></a>
                                             <?php } ?>
                                             <?php } ?>
                                            </td>
                                            <?php } ?>
                                        </tr>
                                      <?php } } ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
            
        </div>
    </section>


