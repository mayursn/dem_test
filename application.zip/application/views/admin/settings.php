<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2> Settings</h2>
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                    <div class="card">
                    <?php echo print_notification(); ?>
                        <div class="header">
                        <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" class="active"><a href="#home" data-toggle="tab"> General Settings</a></li>
                                <li role="presentation"><a href="#smtpsetting" data-toggle="tab">SMTP Settings</a></li>
                                
                            </ul>
                            
                            
                        </div>
                        <div class="body">
                        <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="home">
                            <form action="<?php echo base_url(); ?>snackadmin/admin/settings" method="post" enctype="multipart/form-data" id="generalsetting">
                           
                            <input type="hidden" name="setting_type" value="general">
                            <label for="site_name">Website Name </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="site_name" id="txtsitename" class="form-control" value="<?php echo $profile->site_name; ?>" placeholder="Name">
                                    </div>
                                </div>
                                <label for="site_email">Website Email</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="site_email" name="site_email" class="form-control"  value="<?php echo $profile->site_email; ?>" placeholder="Enter your email address">
                                    </div>
                                </div>
                                 <label for="feedback_email">Feedback Email</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="feedback_email" name="feedback_email" class="form-control"  value="<?php echo $profile->feedback_email; ?>" placeholder="Enter your feedback email email address">
                                    </div>
                                </div>
                                <label for="site_phone">Website Phone</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="site_phone" name="site_phone" class="form-control" value="<?php echo $profile->site_phone; ?>" placeholder="Enter your phone number">
                                    </div>
                                </div>

                                <label for="site_logo">Logo </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="file" name="site_logo" id="site_logo" class="form-control" >
                                        <?php
                                        if($profile->site_logo!="")
                                        { ?>
                                        <img src="<?php echo base_url(); ?>uploads/admin/logo/<?php  echo $profile->site_logo; ?>" >
                                        <?php } ?>                                       
                                    </div>
                                </div>
                                	
                                <!-- <label for="password">Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="password" class="form-control" placeholder="Enter your password">
                                    </div>
                                </div> -->
                                
                                <br>
                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">Save</button>
                            </form>
                            </div>
                            <div role="tabpanel" class="tab-pane fade " id="smtpsetting">
                             <form action="<?php echo base_url(); ?>snackadmin/admin/smtpSettings" method="post" enctype="multipart/form-data" id="smtpsettings">
                           
                            
                            <label for="protocol">Protocol </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="protocol" id="protocol" class="form-control" value="<?php echo $smtp[0]->value; ?>" >
                                    </div>
                                </div>
                                <label for="smtp_host">SMTP Host</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="smtp_host" name="smtp_host" class="form-control"  value="<?php echo $smtp[1]->value; ?>" >
                                    </div>
                                </div>
                                <label for="smtp_port">SMTP Port</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="smtp_port" name="smtp_port" class="form-control" value="<?php echo $smtp[3]->value; ?>" >
                                    </div>
                                </div>
                                <label for="smtp_user">Email</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="smtp_user" name="smtp_user" class="form-control" value="<?php echo $smtp[4]->value; ?>" >
                                    </div>
                                </div>
                                <label for="smtp_pass"> Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="smtp_pass" name="smtp_pass" class="form-control" value="<?php echo $smtp[2]->value; ?>" >
                                    </div>
                                </div>
                                
                                
                                <br>
                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">Save</button>
                            </form>
                            </div>
                            </div>
                        </div> <!--  Body -->
                    </div>
                </div>
            </div>           
           
        </div>
    </section>
    <script type="text/javascript">
    	
    </script>