<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                     <?php echo print_notification(); ?>
                        <div class="header">
                            <!-- <h2><?php echo $title; ?></h2> -->
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" class="active"><a href="#home" data-toggle="tab"> <?php echo $title; ?></a></li>
                                <?php if(isset($profile)){ ?>
                                <li role="presentation"><a href="#changepassword" data-toggle="tab">Change password</a></li>
                                <?php } ?>
                                
                            </ul>

                        </div>
                        <div class="body">
                          <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="home">
                            <form action="<?php echo base_url(); ?>snackadmin/admin/manageadmin/edit/<?php if(isset($profile)){ echo $profile->admin_id; } ?>" method="post" enctype="multipart/form-data" id="manageadmin">

                            <input type="hidden" name="action" value="<?php echo $title; ?>">

                            <input type="hidden" name="id" value="<?php if(isset($profile)){ echo $profile->admin_id; } ?>">
                            <label for="email_address">Name </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="txtname" id="admin_name" class="form-control" value="<?php if(isset($profile)){ echo $profile->admin_name; } ?>" placeholder="Name">
                                    </div>
                                </div>
                                <label for="email_address">Email Address</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="email_address" name="txtemail" class="form-control" value="<?php if(isset($profile)){  echo $profile->admin_email; } ?>" placeholder="Enter your email address">
                                    </div>
                                </div>
                                <?php if(!isset($profile)){ ?>
                                <label for="newpass">Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="newpass" name="newpass" class="form-control" value="" placeholder="Enter password">
                                    </div>
                                </div>
                                <label for="confpass">Confirm Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="confpass" name="confpass" class="form-control" value="" placeholder="Enter confirm password">
                                    </div>
                                </div>
                                <?php } ?>
                                <label for="phone">Phone</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="phone" name="txtphone" class="form-control" value="<?php if(isset($profile)){  echo $profile->admin_mobile; } ?>" placeholder="Enter your phone number">
                                    </div>
                                </div>
                                <label for="admin_type" style="display: none;">Type</label>
                                <div class="form-group" style="display: none;">
                                    <div class="form-line">
                                    <select name="admin_type" class="form-control show-tick" id="admin_type">
                                        <option value="1" <?php if(isset($profile)){ if($profile->admin_type=="1") { echo "selected='selected'";}  } ?> >Admin</option>
                                        <option value="2" <?php if(isset($profile)){ if($profile->admin_type=="2") { echo "selected='selected'";}  } ?> >Super admin</option>
                                    </select>                           
                                    </div>
                                </div>
                                
                                <div class="form-group form-float">
                               Status
                                <div class="demo-switch">
                                    <div class="switch">
                                        
                                        <label>Inactive<input type="checkbox" name="admin_status" <?php if(isset($profile)){
                                            if($profile->admin_status==1) { echo 'checked';}  } ?> ><span class="lever"></span>Active</label>
                                    </div>
                                </div>
                               </div>
                             
                                 <!-- <label for="admin_status">Status</label>
                                <div class="form-group">
                                    <div class="form-line">
                                    <select name="admin_status" class="form-control show-tick" id="admin_status">
                                        <option value="1" <?php if(isset($profile)){ if($profile->admin_status=="1") { echo "selected='selected'";}  } ?> >Active</option>
                                        <option value="0" <?php if(isset($profile)){ if($profile->admin_status=="0") { echo "selected='selected'";}  } ?> >Inactive</option>
                                    </select>                           
                                    </div>
                                </div>  -->
                                <label for="photo">Photo </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="file" name="photo" id="photo" class="form-control" >
                                        <?php if(isset($profile)){  if($profile->admin_photo!=""){ ?>
                                        <div class="image">
                                        <img src="<?php echo base_url(); ?>uploads/admin/<?php echo $profile->admin_photo; ?>" height="48" width="48">
                                        </div>

                                        <?php } }?>
                                    </div>
                                </div>
                                	
                                <!-- <label for="password">Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="password" class="form-control" placeholder="Enter your password">
                                    </div>
                                </div> -->
                                
                                <br>
                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">Save</button>
                            </form>
                            </div>
                            <?php if(isset($profile)){ ?>
                             <div role="tabpanel" class="tab-pane fade " id="changepassword">
                        <form action="<?php echo base_url(); ?>snackadmin/admin/changepassword" method="post" enctype="multipart/form-data" id="changepass">
                       <input type="hidden" name="id" value="<?php echo $profile->admin_id; ?>">
                                 <label for="newpass">New Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="newpass" name="newpass" class="form-control" value="" placeholder="Enter new password">
                                    </div>
                                </div>
                                <label for="confpass">Confirm Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="confpass" name="confpass" class="form-control" value="" placeholder="Enter confirm password">
                                    </div>
                                </div>
                                 <br>
                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">Save</button>
                        </form>
                                </div> 
                                <?php } ?>
                        </div> <!-- vbv >
                    </div>
                </div>
            </div>           
           
        </div>
    </section>
    <script type="text/javascript">
    	
    </script>