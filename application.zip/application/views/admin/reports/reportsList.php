
<?php

$create = check_methods_modules($moduleName,"perm_create");
$read = check_methods_modules($moduleName,"perm_read");
$update = check_methods_modules($moduleName,"perm_update");
$delete  = check_methods_modules($moduleName,"perm_delete");
if(!$read){
    redirect(base_url());
}

 ?>


     <section class="content">
        <div class="container-fluid">
            <div class="block-header">
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <?php echo $page_title; ?>
                                <span class="right">
                                </span>
                            </h2>
                           
                        </div>
                        <?php echo print_notification(); ?>
                    
                        <div class="body">
                        <form action="<?php echo base_url(); ?>snackadmin/reports/generate" method="POST" id="report-admin">
                        <div class="row clearfix">
                        <div class="col-md-3">
                                    <p>
                                        <b>Basic</b>
                                    </p>
                                    <select class="form-control show-tick" id="type"  name="type">
                                        <?php
                                        $sel = "";
                                         if(set_value('type')=="In-app Purchase made"){
                                            $sel = "selected='selected'";
                                            } ?>

                                        <option value="In-app Purchase made" <?php echo $sel; ?>>In-app Purchase made</option>  
                                         <?php if(set_value('type')=="Credits bought"){
                                            $sel = "selected='selected'";
                                            } ?> 
                                        <option value="Credits bought"  <?php echo $sel; ?>>Credits bought</option>
                                    </select>

                                </div>
                                </div>
                                
                            <div class="row clearfix">
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" readonly="" name="from_date" id="from_date" class="datepicker form-control" value="<?php echo set_value('from_date'); ?>" placeholder="From date">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" id="to_date" readonly=""  name="to_date"  value="<?php echo set_value('to_date'); ?>" class="datepicker2 form-control" placeholder="To date">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">

                                    <p><b>Age Range</b></p>
                                    <div id="nouislider_range_example"></div>
                                    <div class="m-t-20 font-12"><b>Value: </b>
                                    <span class="js-nouislider-value"></span></div>
                                    <input type="hidden"  required="" value="<?php echo set_value('age_range'); ?>" name="age_range" class="js-nouislider-value2" id="age_range"  value="" >
                                </div>
                                </div>
                                 <div class="row clearfix">
                                <div class="col-md-12">                                
                                
                                <label class="col-sm-2 control-label">Location:</label>
                                
                                <div class="col-sm-10">
                                <div class="form-group">
                                <div class="form-line">
                                        <input type="text" class="form-control" id="us3-address" value="<?php echo set_value('location'); ?>" required="" name="location" placeholder="Enter a location" autocomplete="off">
                                </div>
                                </div>
                                </div>
                                     <label class="p-r-small col-sm-2 control-label">Radius (in Meters) </label>
                                     <div class="col-sm-3">
                                        <div class="form-group">      
                                            <div class="form-line">
                                                <input type="text" value="<?php echo set_value('radius'); ?>"   name="radius" class="form-control" id="us3-radius" />
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-sm-3">
                                                <div class="form-group">      
                                                    <div class="form-line">
                                                        <input type="text"  name="latitude" value="<?php echo set_value('latitude'); ?>" placeholder="Latitude"  class="form-control" style="width: 110px" id="us3-lat" />             
                                                    </div>
                                                </div>
                                        </div>
                                        <div class="col-sm-3">
                                               <div class="form-group">       
                                                <div class="form-line">
                                                    <input type="text"  name="longitude" value="<?php echo set_value('longitude'); ?>" class="form-control" placeholder="Longitude" style="width: 110px" id="us3-lon" />
                                                </div>
                                            </div>
                                        </div>
                                        
                                 </div>
                                 </div>
                                <div class="row clearfix">
                               
                                          <div class="col-md-9">
                                        <div id="us3" style="width: 500px; height: 300px;"></div>
                                        </div>
                                         <div class="col-md-3">
                                <span class="pull-right">
                                          <button class="btn btn-primary btn-lg m-l-50 waves-effect" id="reports-export" type="submit">Generate Report</button>
                                          </span>
                                          </div>
                                </div>
                            </form>
                           
                           
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
            
        </div>
    </section>

        <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyAR818XDiLAcbiyc8otS8-a8WPsRnyrOS8&libraries=places"></script>
        
<script type="text/javascript">
    function splitArray(){
        var myStr = "quick brown fox";
        var strArray = myStr.split(" ");
        
        // Display array values on page
        for(var i = 0; i < strArray.length; i++){
            alert(strArray[i]);
        }
    }
</script>