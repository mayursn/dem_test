<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                     <?php echo print_notification(); ?>
                        <div class="header">
                            <!-- <h2><?php echo $title; ?></h2> -->
                            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                <li role="presentation" class="active"><a href="#home" data-toggle="tab"> <?php echo $title; ?></a></li>                            
                            </ul>

                        </div>
                        <div class="body">
                          <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="home">
                             
                            <form action="<?php echo base_url(); ?>snackadmin/admin/create" method="post" enctype="multipart/form-data" id="manageadmin">
                            <label for="email_address">Name </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="txtname" id="admin_name" class="form-control" value="<?php echo set_value('txtname'); ?>" placeholder="Name">
                                    </div>
                                </div>
                                <label for="email_address">Email Address</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="email_address" name="txtemail" class="form-control" value="<?php echo set_value('txtemail'); ?>" placeholder="Enter your email address">
                                    </div>
                                </div>
                               
                                <label for="newpass">Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="newpass" name="newpass" class="form-control" value="" placeholder="Enter password">
                                    </div>
                                </div>
                                <label for="confpass">Confirm Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="confpass" name="confpass" class="form-control" value="" placeholder="Enter confirm password">
                                    </div>
                                </div>
                                
                                <label for="phone">Phone</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="phone" name="txtphone" class="form-control" value="<?php echo set_value('txtphone'); ?>" placeholder="Enter your phone number">
                                    </div>
                                </div>
                              
                                    <div class="form-group form-float">
                               Status
                                <div class="demo-switch">
                                    <div class="switch">
                                        <label>Inactive<input type="checkbox" name="admin_status" checked=""><span class="lever"></span>Active</label>
                                    </div>
                                </div>
                               </div>
                               <!--   <label for="admin_status">Status</label>
                                <div class="form-group">
                                    <div class="form-line">
                                    <select name="admin_status" class="form-control show-tick" id="admin_status">
                                    <?php $setval = (set_value('txtphone')) ? set_value('txtphone') : '' ?>
                                        <option value="1" <?php ($setval=="1")? "selected='selected'" : ''; ?> >Active</option>
                                        <option value="0" <?php ($setval=="0")? "selected='selected'" : ''; ?> >Inactive</option>
                                    </select>                           
                                    </div>
                                </div>  -->
                                <label for="photo">Photo </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="file" name="photo" id="photo" class="form-control" >
                                       
                                    </div>
                                </div>
                                    
                                <!-- <label for="password">Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="password" class="form-control" placeholder="Enter your password">
                                    </div>
                                </div> -->
                                
                                <br>
                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">Save</button>
                            </form>
                            </div>
                           
                        </div> <!-- vbv -->
                    </div>
                </div>
            </div>           
           
        </div>
    </section>
    <script type="text/javascript">
        
    </script>