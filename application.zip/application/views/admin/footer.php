<script type="text/javascript"> var base_url = "<?php echo base_url(); ?>";</script>
    <!-- Jquery Core Js -->
    <script src="<?php echo base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.js"></script>
<?php foreach ($script as $rowscript) { ?>
    <script src="<?php echo base_url(); ?>assets/<?php echo $rowscript; ?>"></script>
    <?php } ?> 
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-101891651-2', 'auto');
  ga('send', 'pageview');

</script>
</body>

</html>