<?php 
$create = check_methods_modules($moduleName,"perm_create");
$read = check_methods_modules($moduleName,"perm_read");
$update = check_methods_modules($moduleName,"perm_update");
$delete  = check_methods_modules($moduleName,"perm_delete");

?>
<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                     <?php echo print_notification(); ?>
                        <div class="header">
                             <h2><?php echo $title; ?></h2> 
                            

                        </div>
            <div class="body">
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade in active" id="home">
                        <form action="<?php echo base_url(); ?>snackadmin/notification/sendnotification" method="POST" enctype="multipart/form-data" id="sendnotification">

                            <div class="row clearfix">
                                <div class="col-md-3"  >
                                    <p>
                                        <b>Send To</b>
                                    </p>
                                    <select class="form-control show-tick" data-live-search="true" name="send_type" id="send_type">
                                        <option value="All">All</option>
                                        <option value="Individual">Individual</option>
                                    </select>

                                </div>
                            </div>
                            <div class="individual_send">
                            <div class="row clearfix">
                                <div class="col-md-3">
                                    <p>
                                        <b>Country</b>
                                    </p>
                                    <select class="form-control show-tick" data-live-search="true" name="country" required="" id="country">
                                       <!--  <option></option>
                                        <?php foreach ($country as $rows) { ?>
                                            <option value="<?php echo $rows->location_id; ?>"><?php echo $rows->name; ?></option>
                                        <?php } ?> -->
                                    </select>
                                    <label  class="country-error"></label>
                                </div>
                                </div>
                                <div class="row clearfix">
                                <div class="col-md-3">
                                    <p>
                                        <b>City</b>
                                    </p>
                                    <select class="form-control show-tick" data-live-search="true" name="city"  required="" id="cities">
                                    
                                    </select>
                                    <label  class="cities-error"></label>
                                </div>
                                </div>

                                <div class="row clearfix useroption">
                                <div class="col-md-6">
                                  <p>
                                        <b>Users </b>
                                          
                                    </p>
                                 <div class="form-group">
                                    <input type="radio" name="user_type" id="user_all" class="with-gap" value="All" checked="" >
                                    <label for="user_all">All</label>

                                    <input type="radio" name="user_type" id="individual_user" class="with-gap" value="individual_user">
                                    <label for="individual_user"  class="m-l-20">Individual</label>
                                </div>
                                </div>
                                </div>

                                <div class="row clearfix users" >
                                <div class="col-md-3">
                               
                                  
                                    <select class="form-control show-tick" name="users[]" id="users" multiple>
                                        
                                    </select>
                                    <label  class="users-error"></label>
                                    
                                </div>
                                </div>
                                </div>

                                <div class="row clearfix">
                               
                                <div id="TextBoxesGroup">
                                <div class="col-md-6" >
                                    <div class="input-group">               
                                        <div class="form-line" id="TextBoxDiv1">
                                        <textarea class="form-control" id="notification" name="notification" required="" placeholder="Notification" ></textarea>
                                        </div>
                                            <label  class="notification-error"></label>
                                    </div>
                                </div>

                                </div>

                        <div class="col-md-12">
                          <button class="btn btn-primary btn-lg m-l-15 waves-effect" type="submit">Send</button>
                          
                          <a href="<?php echo base_url(); ?>snackadmin/notification" class="btn btn-default  btn-lg m-l-15 waves-effect">Cancel</a>
                          </div>
                           </div>
                            
                            </form>
                            
                            </div>
                          
                        </div> <!-- vbv -->
                    </div>
                   
                    


                </div>
            </div>           
           
        </div>
    </section>
    <script type="text/javascript"> var base_url = "<?php echo base_url(); ?>snackadmin/";</script>