

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>DASHBOARD</h2>
                <?php echo print_notification(); ?>
            </div>

            <!-- Widgets -->
            <div class="row clearfix">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box hover-expand-effect">
                        <div class="icon bg-light-blue">
                            <i class="material-icons">person_outline</i>
                        </div>
                        <div class="content">
                            <div class="text">SUB ADMIN</div>
                            <div class="number count-to" data-from="0" data-to="<?php echo $subadmin; ?>" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box hover-expand-effect">
                        <div class="icon bg-indigo">
                            <i class="material-icons">face</i>
                        </div>
                        <div class="content">
                            <div class="text">USERS</div>
                            <div class="number count-to" data-from="0" data-to="<?php echo $weeklyUsers; ?>" data-speed="1000" data-fresh-interval="20">257</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box hover-expand-effect">
                        <div class="icon bg-cyan">
                            <i class="material-icons">person_outline</i>
                        </div>
                        <div class="content">
                            <div class="text">ONLINE USERS</div>
                            <div class="number count-to" data-from="0" data-to="<?php echo $onlineuser; ?>" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box  hover-expand-effect">
                        <div class="icon bg-orange">
                            <i class="material-icons">report</i>
                        </div>
                        <div class="content">
                            <div class="text">REPORTED USERS</div>
                            <div class="number count-to" data-from="0" data-to="<?php echo $reporteduser; ?>" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Widgets -->
            
           

            <div class="row clearfix">
                <!-- Task Info -->
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                    <div class="card">
                        <div class="header">
                            <h2>SUB ADMIN</h2>
                            
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Photo</th>
                                            <th>Created Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                    $count = 1;
                                    foreach ($subadminList as $rows) : ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $rows->admin_name; ?></td>
                                            
                                            <td><?php echo $rows->admin_email; ?></td>
                                            <td>
                                            <img src="<?php echo base_url().'uploads/admin/'.$rows->admin_photo; ?>" width="50">
                                            </td>
                                            <td><?php echo date("M, d Y h:i A",strtotime($rows->created_date)); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- #END# Task Info -->
                <!-- Browser Usage -->
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="card">
                        <div class="header">
                            <h2>Registered Users</h2>
                        </div>
                        <div class="body">
                           <ul class="list-group">                                
                                <li class="list-group-item">
                                    YESTERDAY
                                    <span class="pull-right"><b><?php echo $yesterdays; ?></b> <small>users</small></span>
                                </li>
                                <li class="list-group-item">
                                    THIS WEEK
                                    <span class="pull-right"><b><?php echo $thisweek; ?></b> <small>users</small></span>
                                </li>
                                <li class="list-group-item">
                                    LAST MONTH
                                    <span class="pull-right"><b><?php echo $thismonth; ?></b> <small>users</small></span>
                                </li>
                                <li class="list-group-item">
                                    LAST YEAR
                                    <span class="pull-right"><b><?php echo $thisyear; ?></b> <small>users</small></span>
                                </li>
                                <li class="list-group-item">
                                    ALL
                                    <span class="pull-right"><b><?php echo $allusers; ?></b> <small>users</small></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- #END#  special call karte hai log 96.7 me aise gaane ke liye Browser Usage -->
            </div>
        </div>
    </section>