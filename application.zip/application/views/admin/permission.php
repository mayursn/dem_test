<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2><?php echo $title; ?></h2>
            </div>
<?php 


$create = check_methods_modules($moduleName,"perm_create");
$read = check_methods_modules($moduleName,"perm_read");
$update = check_methods_modules($moduleName,"perm_update");
$delete  = check_methods_modules($moduleName,"perm_delete");



$createcheckall=0;
$readcheckall=0;
$updatecheckall=0;
$deletecheckall=0;
foreach (@$modulelist as $row) {
$user_role_permission = ['0', '0', '0', '0']; 
     
    foreach(@$user_permission as $permission) {
        if($permission->module_id == $row->module_id) {
            
            if($permission->perm_create==1)
            {
                $createcheckall++;
            }
            if($permission->perm_read==1)
            {
                $readcheckall++;
            }
            if($permission->perm_update==1)
            {
                $updatecheckall++;
            }
            if($permission->perm_delete==1)
            {
                $deletecheckall++;
            }
        }
    }
}
          ?>
           
            <!-- #END# Striped Rows -->
            <!-- Bordered Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">

                        <div class="header">
                        <?php  echo print_notification();?>
                            <h2>
                              PERMISSIONS
                                <small>Add Permission to individual Admin</small>
                            </h2>
<!--                             <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);" class=" waves-effect waves-block">Action</a></li>
                                        <li><a href="javascript:void(0);" class=" waves-effect waves-block">Another action</a></li>
                                        <li><a href="javascript:void(0);" class=" waves-effect waves-block">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul> -->
                        </div>
                        <div class="body table-responsive">
                        <?php if($update || $create){ ?>
                        <form action="" method="post" >
                        <?php } ?>
                        <input type="hidden" name="admin_id" value="<?php echo $id; ?>">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Module Name</th>
                                        <th>Create</th>
                                        <th>Read</th>
                                        <th>Update</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>

                                

                                <td>
                                    <input type="checkbox" id="createall"  <?php if($createcheckall==count($modulelist)){echo "checked"; } ?>  onclick="create_uncheck(); readcheckall();" class="all-create filled-in chk-col-indigo"  />
                                      <label for="createall"></label>
                                </td>
                                <td>
                                    <input type="checkbox" id="readall" <?php if($readcheckall==count($modulelist)){echo "checked"; } ?> onclick="read_uncheck();" class="all-read filled-in chk-col-indigo"  />
                                      <label for="readall"></label>
                                </td>
                                <td>
                                    <input type="checkbox" id="updateall" <?php if($updatecheckall==count($modulelist)){echo "checked"; } ?> onclick="update_uncheck();readcheckall();" class="all-update filled-in chk-col-indigo"  />
                                      <label for="updateall"></label>
                                </td>
                                <td>
                                    <input type="checkbox" id="deleteall"  <?php if($deletecheckall==count($modulelist)){echo "checked"; } ?> onclick="delete_uncheck();readcheckall();" class="all-delete filled-in chk-col-indigo" />
                                      <label for="deleteall"></label>
                                </td>

                            </tr>
                                <?php $i = 1; 
                                foreach (@$modulelist as $rows) { ?>

                                 <?php $user_role_permission = ['0', '0', '0', '0']; ?>
                            
                                <?php
                            if(count($user_permission))
                                foreach(@$user_permission as $permission) {
                                    if($permission->module_id == $rows->module_id) {
                                       /* $user_role_permission = str_split($permission->user_permission);*/ 
                                        $user_role_permission = $permission;
                                        break;
                                    }
                                }
                                ?>
                                 <tr>
                                         <th scope="row"><?php echo $i; ?></th>
                                        <th ><?php echo ucfirst($rows->module_name); ?></th>
                                        <td><input type="checkbox" name="create_<?php echo $rows->module_id; ?>" id="create_<?php echo $rows->module_id; ?>" 
                                               <?php if(@$user_role_permission->perm_create == 1) echo 'checked'; ?>  class="filled-in chk-col-blue create-permission" onclick="readpermission(<?php echo $rows->module_id; ?>);create_check()" >
                                        <label for="create_<?php echo $rows->module_id; ?>"></label>
                                        </td>
                                        <td><input type="checkbox" name="read_<?php echo $rows->module_id; ?>" id="read_<?php echo $rows->module_id; ?>"  <?php if(@$user_role_permission->perm_read == 1) echo 'checked'; ?> onclick="readpermission(<?php echo $rows->module_id; ?>);" class="filled-in chk-col-blue read-permission" >
                                        <label for="read_<?php echo $rows->module_id; ?>"></label>
                                        </td>
                                         <td><input type="checkbox" name="update_<?php echo $rows->module_id; ?>" id="update_<?php echo $rows->module_id; ?>"  class="filled-in chk-col-blue update-permission"  <?php if(@$user_role_permission->perm_update == 1) echo 'checked'; ?> onclick="readpermission(<?php echo $rows->module_id; ?>); update_check()">
                                        <label for="update_<?php echo $rows->module_id; ?>"></label>
                                        </td>
                                        <td><input type="checkbox" name="delete_<?php echo $rows->module_id; ?>" id="delete_<?php echo $rows->module_id; ?>" class="filled-in chk-col-blue delete-permission"  <?php if(@$user_role_permission->perm_delete == 1) echo 'checked'; ?> onclick="readpermission(<?php echo $rows->module_id; ?>); delete_check()">
                                        <label for="delete_<?php echo $rows->module_id; ?>"></label>
                                        </td>
                                    </tr>
                                 <?php    $i++; } ?>
                                </tbody>
                            </table>
                             <?php if($update || $create){ ?>
                            <div class="col-xs-6 col-sm-3 col-md-2 col-lg-2">
                                   
                                    <button type="submit" class="btn bg-blue btn-block waves-effect">Save</button>
                                </div>
                               
                            </form>
                             <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
           
            <!-- #END# With Material Design Colors -->
        </div>
    </section>