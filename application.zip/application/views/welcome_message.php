<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	
</head>
<body>

<div id="container">
<div style="text-align: center;">
	<img src="<?php echo base_url() ?>assets/images/under.jpg" height="500">
</div>
</body>
</html>