<section class="content">
   <div class="container-fluid">
      <div class="block-header">
      </div>
      <!-- Vertical Layout -->
      <div class="row clearfix">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
               <div id="message"></div>
               <div class="header">
                  <h2><?php echo $page_title; ?></h2>
               </div>
               <div class="body">
                  <form action="<?php echo base_url(); ?>snackadmin/questions/edit/<?php echo $question->question_id; ?>" method="POST" enctype="multipart/form-data" id="editquestions">
                  <div class="row clearfix">
                     <div class="col-md-12">
                        <div class="form-group form-float">
                           <div class="form-line">
                              <input type="text" class="form-control" name="txtname" id="txtname" value="<?php echo $question->question_title; ?>"  autofocus=""  aria-invalid="false">
                              <label class="form-label">Title</label>
                           </div>
                           <br>
                           <button type="button" id="addQueButton" class="btn bg-blue waves-effect">
                                    <i class="material-icons" >add</i>
                           </button>
                        </div>
                     </div>
                     <div id="TextBoxesGroup">
                        <?php
                           $counter = 3;
                           if($answerOptions){
                            foreach (@$answerOptions as $options) { ?>
                        <div class="col-md-4" id="remove<?php echo $counter; ?>" >
                           <div class="input-group">
                              <div class="form-line" id="TextBoxDiv<?php echo $counter; ?>">
                                 <input type="text" class="form-control" name="opt[options_<?php echo $options->answer_id; ?>]" id="option1" placeholder="answer" value="<?php echo $options->answer_title; ?>"  required=""  autofocus=""  aria-invalid="false">
                              </div>
                              <span class="input-group-addon pointerclass" onclick="removeDivEditQuestion('<?php echo $counter; ?>','<?php echo $options->answer_id; ?>')">
                              <i class="material-icons">remove_circle</i>
                              </span>
                           </div>
                        </div>
                        <?php
                           $counter++;
                            }
                            } ?>
                        <script type="text/javascript">
                           var qcounteredit = '<?php echo $counter; ?>';
                        </script>
                     </div>
                     <div class="col-md-12">
                          <button class="btn btn-primary btn-lg m-l-15 waves-effect" type="submit">Save</button>
                          
                          <a href="<?php echo base_url(); ?>snackadmin/questions" class="btn btn-default  btn-lg m-l-15 waves-effect">Cancel</a>
                          </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script type="text/javascript"></script>