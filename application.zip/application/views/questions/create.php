<section class="content">
   <div class="container-fluid">
   <div class="block-header">
   </div>
   <!-- Vertical Layout -->
   <div class="row clearfix">
   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="card">
         <div id="message"></div>
          <?php   echo print_notification(); ?>
         <div class="header">
            <h2><?php echo $page_title; ?></h2>
         </div>
         <div class="body">
            <div class="tab-content">
               <div role="tabpanel" class="tab-pane fade in active" id="home">
                  <form action="<?php echo base_url(); ?>snackadmin/questions/create_data" method="POST" enctype="multipart/form-data" id="createquestions">
                     <div class="row clearfix">
                        <div class="col-md-12">
                           <div class="form-group form-float">
                              <div class="form-line">
                                 <input type="text" class="form-control" name="txtname" id="txtname" value="<?php echo set_value('txtname'); ?>"  autofocus=""  aria-invalid="false">
                                 <label class="form-label">Title</label>
                              </div>
                              <label id="txtname-error" class="error" for="txtname"></label>
                           </div>
                           <br>
                           <button type="button" id="addQueButton" class="btn bg-blue waves-effect">
                           <i class="material-icons" >add</i>
                           </button>
                        </div>
                        <div id="TextBoxesGroup">
                           <div class="col-md-4" >
                              <div class="input-group">
                                 <div class="form-line" id="TextBoxDiv1">
                                    <input type="text" class="form-control" name="options[]" id="option1"  value="" placeholder="answer"  required=""  autofocus=""  aria-invalid="false">
                                 </div>
                              </div>
                           </div>
                           <div class="col-md-4" >
                              <div class="input-group">
                                 <div class="form-line" id="TextBoxDiv2">
                                    <input type="text" class="form-control" name="options[]" id="option2"  value="" placeholder="answer"  required=""  autofocus=""  aria-invalid="false">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-12">
                          <button class="btn btn-primary btn-lg m-l-15 waves-effect" type="submit">Save</button>
                          
                          <a href="<?php echo base_url(); ?>snackadmin/questions" class="btn btn-default  btn-lg m-l-15 waves-effect">Cancel</a>
                          </div>
                           <script type="text/javascript">
                        var createquestion = true;
                    </script>
                  </form>
                  </div>
               </div>
               <!-- vbv -->
            </div>
            
         </div>
      </div>
   </div>
</section>
<script type="text/javascript"></script>