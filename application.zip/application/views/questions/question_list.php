<?php


$create = check_methods_modules($moduleName,"perm_create");
$read = check_methods_modules($moduleName,"perm_read");
$update = check_methods_modules($moduleName,"perm_update");
$delete  = check_methods_modules($moduleName,"perm_delete");



 ?>


     <section class="content">
        <div class="container-fluid">
            <div class="block-header">
            <?php  echo print_notification(); ?>
                <!-- <h2>
                    JQUERY DATATABLES
                    <small>Taken from <a href="https://datatables.net/" target="_blank">datatables.net</a></small>
                </h2> -->
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <?php echo $page_title; ?>
                                <?php if($create){ ?>
                                <span class="right">
                                    <a href="<?php echo base_url(); ?>snackadmin/questions/create" class="btn btn-primary waves-effect">Add New</a><br><br>
                                </span>
                                <?php } ?>
                            </h2>
                           
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable" id="questionList">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                                                                              
                                            <?php if($update || $delete){ ?>         
                                            <th>Action</th>
                                            <?php } ?>
                                        </tr>
                                    </thead>

                                    <tbody>
                                    <?php  if(count($questions) > 0 && !empty($questions)){ ?> 
                                    <?php foreach ($questions as $questionsrow) { ?>
                                    <tr>
                                    	<td>
                                            <?php echo $questionsrow->question_title; ?>
                                                
                                        </td>
                                      
                                    	
                                        <?php if($update || $delete){ ?>
                                    	<td>
                                        <?php if($update){ ?>
                                        <a href="<?php echo base_url(); ?>snackadmin/questions/edit/<?php echo $questionsrow->question_id; ?>"><i class="material-icons">create</i></a>
                                        <?php } ?>
                                        <?php if($delete){ ?>
                                            <a href="#" data-url="<?php echo base_url(); ?>snackadmin/questions/delete/<?php echo $questionsrow->question_id; ?>/"
                                       data-title="<?php  echo $questionsrow->question_title; ?>" class="js-sweetalert" data-type="confirm"> <i class="material-icons">delete</i></a>
                                       <?php } ?>
                                       </td>
                                       <?php } ?>
                                    </tr>
                                    <?php } } ?>
                                    </tbody>
                                    <!-- <tfoot>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Photo</th>
                                        </tr>
                                    </tfoot> -->
                                    <tbody>   
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
            
        </div>
    </section>
