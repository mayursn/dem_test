<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                     <?php   echo print_notification(); ?>
                        <div class="header">
                             <h2><?php echo $page_title; ?></h2> 
                            

                        </div>
                        <div class="body">
                          <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="home">
                            <form action="<?php echo base_url(); ?>snackadmin/users/create" method="post" enctype="multipart/form-data" id="createuser">
                            <div class="row">
                            <div class="col-md-6">
                             <label for="firstname">First Name </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="firstname" id="firstname" class="form-control" value="<?php echo set_value('firstname'); ?>" placeholder="First Name">
                                    </div>

                                </div> 
                                </div>
                                <div class="col-md-6">
                                <label for="lastname">Last Name </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="lastname" id="lastname" class="form-control" value="<?php echo set_value('lastname'); ?>" placeholder="Last Name">
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="row">
                            <div class="col-md-6">
                            <label for="username">Username </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="txtname" id="admin_name" class="form-control" value="<?php echo set_value('txtname'); ?>" placeholder="Username">
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <label for="txtemail">Email Address</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="txtemail" name="txtemail" class="form-control" value="<?php echo set_value('txtemail'); ?>" placeholder="Email address">
                                    </div>
                                </div>
                                </div>
                                </div>

                                <div class="row">
                                <div class="col-md-6">
                                <label for="newpass">Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="newpass" name="newpass" class="form-control" value="" placeholder="Password">
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <label for="confpass">Confirm Password</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="password" id="confpass" name="confpass" class="form-control" value="" placeholder="Confirm password">
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="row">
                                <div class="col-md-6">
                                <label for="txtphone">Phone</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="txtphone" name="txtphone" class="form-control" value="<?php echo set_value('txtphone'); ?>" placeholder="Phone number">
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <label for="users_dob">Date Of Birth</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="users_dob" name="users_dob" class="form-control customdatepicker" value="<?php echo set_value('users_dob'); ?>" placeholder="Date Of Birth">
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="row">
                                <div class="col-md-6">
                                <label for="users_address">Address </label>
                                 <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="users_address" name="users_address" class="form-control" value="<?php echo set_value('users_address'); ?>" placeholder="Address">
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <label for="users_zip">Zip code</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="number" id="users_zip" name="users_zip" maxlength="6" minlength="4" min="0" class="form-control" value="<?php echo set_value('users_zip'); ?>" placeholder="Zipcode">
                                    </div>
                                </div>
                                </div>
                                </div>
                                <div class="row">
                                <div class="col-md-6">
                                <label for="users_latitude">Latitude</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="users_latitude" name="users_latitude" class="form-control" value="<?php echo set_value('users_latitude'); ?>" placeholder="Latitude">
                                    </div>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <label for="users_longitude">Longitude</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="users_longitude" name="users_longitude" class="form-control" value="<?php echo set_value('users_longitude'); ?>" placeholder="Longitude">
                                    </div>
                                </div>
                                </div>
                                </div>
                               
                               <div class="row">
                                <div class="col-md-6">
                                 <label for="user_status">Status</label>

	                                    <div class="form-group">    
	                                        <div class="switch">
	                                        <?php  $sel = ("on" == set_value('user_status')) ? 'checked=""' : ''; ?>
	                                            <label> Inactive <input type="checkbox" name="user_status" <?php  echo $sel; ?> ><span class="lever switch-col-green"></span> Active </label>
	                                        </div>
	                                    </div>
	                                    </div>
                                <div class="col-md-6">
                                <label for="photo">Photo </label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="file" name="photo" id="photo" class="form-control" > 
                                    </div>
                                </div>
                                </div>
                                </div>
                             
                                <br>
                                <div class="button-demo">
                                <button type="submit" class="btn btn-primary waves-effect">Save</button>
                                </div>
                            </form>
                            </div>
                          
                        </div> <!-- vbv >
                    </div>
                </div>
            </div>           
           
        </div>
    </section>
    <script type="text/javascript">
    	
    </script>