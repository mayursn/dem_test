<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>
            <div class="row clearfix">
               
              <!--  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                    
                        </div>
                        
                    </div>
                </div> -->

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               User Details
                                <small><?php echo  date("F d, Y h:i A", strtotime($user->created_date)); ?></small>
                            </h2>
                        </div>
                        <div class="clearfix row">
                        	<?php// echo "<prE>"; print_r($user->logs);echo "</pre>"; ?>
	                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
		                        <div class="body">
		                        
		                            <ul class="list-group">
		                                <li class="list-group-item">Name : <?php echo $user->users_fname.' '.$user->users_lname; ?></li>

		                                <li class="list-group-item">Email : <?php echo $user->users_email; ?></li>
		                                <li class="list-group-item"> Status : 
		                                    <?php echo ($user->users_status=='0') ? '<span class="bg-red btn">Inactive</span>' : "";
		                                    echo ($user->users_status=='1') ? '<span class="bg-green btn">Active</span>' : "";
		                                    echo ($user->users_status=='2') ? '<span class="bg-black btn">Blocked</span>' : ""; ?>
		                                </li>
		                                </ul>
		                        
		                        </div> <!-- body -->
	                        </div> <!-- col-lg-6 -->
                        </div> <!-- clearfix -->
                    </div> <!-- card -->
                        
                </div> <!-- col-lg-12 -->

                  <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <?php echo $page_title; ?>
                                <span class="right">
                                   <!--  <a href="<?php echo base_url(); ?>users/create" class="btn btn-primary waves-effect">Add New</a><br><br> -->
                                </span>
                            </h2>
                           
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable" id="activityList">
                                    <thead>
                                        <tr>
                                            <th>URL</th> 
                                            <th>Message</th>        
                                            <th>Parameters</th>        
                                            <th>IP Address</th>        
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                   
                                    <tbody>   
                                    </tbody>
                                </table>
                            <input type="hidden" name="users_id" id="users_id" value="<?php echo $users_id; ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                 <!-- <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo $page_title; ?></h2>
                        </div>
                        <div class="clearfix row">

                        	<?php
                        	
                        	 foreach ($logs as $rows) : ?>
                        		
                        	
	                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
		                        <div class="body">
		                        
		                            <ul class="list-group">
		                                <li class="list-group-item">URL : <span class="label bg-default" style="color: black;"><?php echo $rows->uri; ?></span></li>
		                                <li class="list-group-item">Parameter <br /> <?php
		                                $serialize = unserialize($rows->params);
		                                foreach ($serialize as $key => $value){
		                                	echo '<p>'.$key .' : ' .$value."</p>";
		                                }
		                                  ?></li>

		                                  
		                                  <li class="list-group-item">User IP : <?php echo $rows->ip_address; ?></li>

		                                  <li class="list-group-item">Response : <?php echo $rows->message; ?></li>

		                                  <li class="list-group-item">Date Time : <?php echo date("F d, Y h:i A", strtotime($rows->logged));; ?></li>
		                            
		                            </ul>
		                        
		                        </div>
	                        </div> 
	                        <?php endforeach; // endforeach ?>
                        </div>
                    </div> 
                        
                </div> --> 
            </div>
                






            <!-- #END# Contextual Classes With Linked Items -->
        </div>
    </section>