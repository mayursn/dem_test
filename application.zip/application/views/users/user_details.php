<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>LIST GROUPS</h2>
            </div>
            <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <!-- Basic Examples -->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                            User basic details
                            </h2>
                            
                            
                        </div>
                        <div class="clearfix row">
                            
                        </div>
                        <div class="body">
                      
                            <ul class="list-group">
                                <li class="list-group-item">Name <span class="pull-right"><?php echo $user->users_fname.' '.$user->users_lname; ?></span></li>

                                <li class="list-group-item">Email <span class="pull-right"><?php echo $user->users_email; ?></span></li>
                                <li class="list-group-item">Status
                                    <?php echo ($user->users_status=='0') ? '<span class="badge bg-orange btn">Inactive</span>' : "";
                                    echo ($user->users_status=='1') ? '<span class="badge bg-green btn">Active</span>' : "";
                                    echo ($user->users_status=='2') ? '<span class="badge bg-red btn">Blocked</span>' : ""; ?>
                                </li>

                                <li class="list-group-item">Gender <span class="pull-right"><?php echo $user->users_gender; ?></span></li>
                                <li class="list-group-item">Location <span class="pull-right"><?php echo $user->users_location; ?></span></li>
                                <li class="list-group-item">Country <span class="pull-right"><?php echo $user->country; ?></span></li>
                              
                                <li class="list-group-item">Lat/Long <span class="pull-right"><?php  if($user->users_latitude!="") echo $user->users_latitude.','.$user->users_longitude; ?></span></li>
                                <li class="list-group-item">Date Of Birth <span class="pull-right"><?php echo $user->users_dob; ?></span></li>
                                <li class="list-group-item">Age <span class="pull-right"><?php echo $user->users_age; ?></span></li>

                                <li class="list-group-item">User IP <span class="badge "><?php echo $user->user_ip; ?></span></li>
                                <li class="list-group-item">Registration Date <span class="pull-right"><?php echo $user->created_date; ?></span></li>

                                <li class="list-group-item">Updated Date <span class="pull-right"><?php echo $user->updated_date; ?></span></li>
                                
                            </ul>
                            <?php if($user->users_status=='1'){ ?>
                            <a href="<?php echo base_url(); ?>snackadmin/users/changestatus/block/<?php echo $user->users_id; ?>" class="btn bg-red waves-effect">Block This User</a>
                            <?php } ?>
                            <?php if($user->users_status=='2'){ ?>
                            <a href="<?php echo base_url(); ?>snackadmin/users/changestatus/unblock/<?php echo $user->users_id; ?>" class="btn bg-green waves-effect">Unblock This User</a>
                            <?php } ?>
                        </div>


                    </div>
                </div>
                <!-- #END# Basic Examples -->
                <!-- Badges -->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                            
                                Preference

                                <small>User Match Preferences</small>

                            </h2>
                            
                        </div>

                        <div class="body">

                            <ul class="list-group">
                            <?php foreach ($preferences as $rows) { ?>
                                
                                <li class="list-group-item"><?php echo $rows->preference_name; ?>  <span class="pull-right"><?php echo $rows->option_title; ?></span></li>

                            <?php } ?>
                            <?php if($user->users_height!=""){ ?>
                            <li class="list-group-item">User Height  <span class="pull-right"><?php echo $user->users_height; ?></span></li>
                            <?php } ?>
                            <?php if($user->from_age!="" && $user->to_age!=""){ ?>

                            <li class="list-group-item">Age Range  <span class="pull-right"><?php echo $user->from_age." To ".$user->to_age; ?></span></li>
                            <?php } ?>
                            <?php if($user->looking_for!=""){ ?>
                            <li class="list-group-item">Looking for  <span class="pull-right"><?php echo $user->looking_for; ?></span></li>
                            <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- #END# Badges -->
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>Membership details</h2>
                        </div>
                        <div class="body">
                            <ul class="list-group">
                         
                        <?php  $premium_status = $user->premium_status;    
                                if($premium_status=='1'){

                                $freetrial_start_date = date('Y-m-d',strtotime($user->freetrial_start_date));        
                                $freetrial_end_date = date('Y-m-d',strtotime($user->freetrial_end_date));        
                                $date = date('Y-m-d');
                                $is_trial = '0';
                                    if (($date >= $freetrial_start_date) && ($date <= $freetrial_end_date)){
                                        $is_trial = '1';
                                    }
                                }else{
                                    $is_trial = '0';
                                    $freetrial_start_date = "";
                                    $freetrial_end_date = "";
                                }

                                if($user->premium_trial_used==""){
                                    $is_trial_used = "0";
                                }else{
                                    $is_trial_used = $user->premium_trial_used;
                                }

                                $credits = ($user->total_credits + $user->weekly_credits);   
                                if($is_trial=='1' && $premium_status=="1"){
                                    $membership = "Free Trial";
                                }elseif($is_trial=='0' && $premium_status=="1"){
                                    $membership = "Premium";
                                }else{
                                    $membership = "Free";
                                }

                                ?>
                                
                                <li class="list-group-item">Membership Status  <span class="pull-right"><?php echo $membership; ?></span></li>
                                <li class="list-group-item"> Free Trial Period
                                    <span class="pull-right"><?php if($freetrial_start_date!="" && $freetrial_end_date!="" &&  ($freetrial_start_date!="0000-00-00")){
                                     echo $freetrial_start_date." To ".$freetrial_end_date; } ?></span> 
                                </li>
                                 <li class="list-group-item">Credits  <span class="pull-right"><?php echo $credits; ?></span></li>

                            
                            </ul>
                        </div>
                    </div>
                </div>
                <?php if(!empty($images)){ ?>
                <!-- Corusol slider -->
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>User Images</h2>
                        </div>
                        <div class="body">
                            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                                <!-- Indicators -->
                                <ol class="carousel-indicators">
                                <?php $j = 0; foreach ($images as $count) { ?>
                                    <li data-target="#carousel-example-generic" data-slide-to="<?php echo $j; ?>" class=""></li>
                                    <?php $j++; } ?>
                                </ol>

                                <!-- Wrapper for slides -->
                                <div class="carousel-inner" role="listbox">
                                <?php $i = 1; foreach ($images as $row) { ?>
                                    <div class="item <?php if($i==1) { ?> active <?php }  ?>">
                                    <?php $i=0; ?>
                                       <img src="<?php echo base_url(); ?>uploads/users/<?php echo $row->user_img; ?>" height="249" width="249">
                                    </div>
                                       <?php } ?>
                                </div>

                                <!-- Controls -->
                                <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>

               

                </div>
                <!-- End Corusol slider -->



            </div>

            <!-- #END# Contextual Classes With Linked Items -->
        </div>
    </section>