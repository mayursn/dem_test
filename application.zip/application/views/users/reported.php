<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>
            <div class="row clearfix">
               
              <!--  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                    
                        </div>
                        
                    </div>
                </div> -->

                <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <?php echo $page_title; ?>   
                            </h2>
                           
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable" id="reported">
                                    <thead>
                                        <tr>
                                            <th>User Name</th> 
                                            <th>Report by User</th>        
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                   
                                    
                                </table>
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            </div>
                






            <!-- #END# Contextual Classes With Linked Items -->
        </div>
    </section>