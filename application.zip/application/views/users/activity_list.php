


     <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <!-- <h2>
                    JQUERY DATATABLES
                    <small>Taken from <a href="https://datatables.net/" target="_blank">datatables.net</a></small>
                </h2> -->
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <?php echo $page_title; ?>
                                <span class="right">
                                   <!--  <a href="<?php echo base_url(); ?>users/create" class="btn btn-primary waves-effect">Add New</a><br><br> -->
                                </span>
                            </h2>
                           
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable" id="activityList">
                                    <thead>
                                        <tr>
                                            <th>User</th>         
                                            <th>URL</th> 
                                            <th>Message</th>        
                                            <th>IP Address</th>        
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <!-- <tfoot>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Photo</th>
                                        </tr>
                                    </tfoot> -->
                                    <tbody>   
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
            
        </div>
    </section>
