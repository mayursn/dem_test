<?php


$create = check_methods_modules($moduleName,"perm_create");
$read = check_methods_modules($moduleName,"perm_read");
$update = check_methods_modules($moduleName,"perm_update");
$delete  = check_methods_modules($moduleName,"perm_delete");



 ?>


     <section class="content">
        <div class="container-fluid">
            <div class="block-header">
            <?php  echo print_notification(); ?>
                <!-- <h2>
                    JQUERY DATATABLES
                    <small>Taken from <a href="https://datatables.net/" target="_blank">datatables.net</a></small>
                </h2> -->
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <?php echo $page_title; ?>
                                <?php if($create){ ?>
                                <span class="right">
                                    <a href="<?php echo base_url(); ?>snackadmin/preference/create" class="btn btn-primary waves-effect">Add New</a><br><br>
                                </span>
                                <?php } ?>
                            </h2>
                           
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable" id="questionList">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                           
                                            <th>Created Date</th>
                                            <?php if($update || $delete){ ?>         
                                            <th>Action</th>
                                            <?php } ?>
                                        </tr>
                                    </thead>

                                    <tbody>
                                    <?php  if(count($preferences) > 0 && !empty($preferences)){ ?> 
                                    <?php foreach ($preferences as $preferencesrow) { ?>
                                    <tr>
                                    	<td>
                                            <?php echo $preferencesrow->preference_name; ?>
                                                
                                        </td>
                                        
                                       <td>
                                            <?php echo $preferencesrow->created_date; ?>
                                                
                                        </td>
                                    	
                                        <?php if($update || $delete){ ?>
                                    	<td>
                                        <?php if($update  && $preferencesrow->preference_id!="1" && $preferencesrow->preference_id!="2"){ ?>
                                        <a href="<?php echo base_url(); ?>snackadmin/preference/edit/<?php echo $preferencesrow->preference_id; ?>"><i class="material-icons">create</i></a>
                                        <?php } ?>
                                        <?php
                                        
                                         if($delete && $preferencesrow->is_static=='0'){ ?>
                                            <a href="#" data-url="<?php echo base_url(); ?>snackadmin/preference/delete/<?php echo $preferencesrow->preference_id; ?>/"
                                       data-title="<?php  echo $preferencesrow->preference_name; ?>" class="js-sweetalert" data-type="confirm"> <i class="material-icons">delete</i></a>
                                       <?php } ?>
                                       </td>
                                       <?php } ?>
                                    </tr>
                                    <?php } } ?>
                                    </tbody>
                                   
                                    <tbody>   
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
        
        </div>
    </section>
