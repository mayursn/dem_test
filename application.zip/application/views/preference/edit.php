<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                     <div id="message"></div>
                        <div class="header">
                             <h2><?php echo $page_title; ?></h2> 
                            

                        </div>
            <div class="body">
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade in active" id="home">
                        <form action="<?php echo base_url(); ?>snackadmin/preference/update/<?php echo $preference->preference_id; ?>" method="POST" enctype="multipart/form-data" id="createprefences">
                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="form-group form-float">
                            	       <div class="form-line">
                                       <?php $value  = (set_value('txtname')!="") ? set_value('txtname') : $preference->preference_name; ?>
                           			      <input type="text" class="form-control" name="txtname" id="txtname" value="<?php echo $value; ?>"  autofocus=""  aria-invalid="false">
                           			      <label class="form-label">Title</label>
                                
	                        	        </div>
                                        <label id="txtname-error" class="error" for="txtname"></label>
	                     	        </div>
                                    <button type="button" id="addButton" class="btn bg-blue waves-effect">
                                    <i class="material-icons" >add</i>
                                    </button>
                                     
                                </div>
                               
                                <div id="TextBoxesGroup">
                               <?php
                               $counter = 2;
                                foreach ($preferenceOptions as $options) { ?>
                                   
                                
                                <div class="col-md-4" id="remove<?php echo $counter; ?>" >
                                    <div class="input-group">               
                                        <div class="form-line" id="TextBoxDiv<?php echo $counter; ?>">
                                           <input type="text" class="form-control" name="opt[options_<?php echo $options->preferences_option_id; ?>]" id="option1" placeholder="option" value="<?php echo $options->option_title; ?>"  required=""  autofocus=""  aria-invalid="false">
                                        </div>
                                        <span class="input-group-addon pointerclass" onclick="removeDivEdit('<?php echo $counter; ?>','<?php echo $options->preferences_option_id; ?>')">
                                            <i class="material-icons">remove_circle</i>
                                        </span>
                                    </div>
                                </div>
                                <?php
                                $counter++;
                                 } ?>
                                 <script type="text/javascript">
                                     var counteredit = '<?php echo $counter; ?>';
                                 </script>
                                </div>
                                <div class="col-md-12">
                                 <button class="btn btn-primary btn-lg m-l-15 waves-effect" type="submit">Save</button>
                                 <a href="<?php echo base_url(); ?>snackadmin/preference" class="btn btn-default  btn-lg m-l-15 waves-effect">Cancel</a>
                                </div>
                            </form>
                            
                            </div>
                          
                        </div> <!-- vbv -->
                    </div>

                    


                </div>
            </div>           
           
        </div>
    </section>
