<?php


$create = check_methods_modules($moduleName,"perm_create");
$read = check_methods_modules($moduleName,"perm_read");
$update = check_methods_modules($moduleName,"perm_update");
$delete  = check_methods_modules($moduleName,"perm_delete");



 ?>


     <section class="content">
        <div class="container-fluid">
            <div class="block-header">
            <?php  echo print_notification(); ?>
                <!-- <h2>
                    JQUERY DATATABLES
                    <small>Taken from <a href="https://datatables.net/" target="_blank">datatables.net</a></small>
                </h2> -->
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <?php echo $page_title; ?>
                                <?php if($create){ ?>
                                <span class="right">
                                    <a href="<?php echo base_url(); ?>snackadmin/credits/create" class="btn btn-primary waves-effect">Add New</a><br><br>
                                </span>
                                <?php } ?>
                            </h2>
                           
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable" id="questionList">
                                    <thead>
                                        <tr>
                                             <th>Credits</th>
                                           
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <?php if($update || $delete){ ?>
                                            <th>Action</th>
                                            <?php } ?>
                                        </tr>
                                    </thead>

                                    <tbody>
                                    <?php  if(count($credits) > 0 && !empty($credits)){ ?> 
                                    <?php foreach ($credits as $creditsrow) { ?>
                                    <tr>
                                    	<td>
                                            <?php echo $creditsrow->credits; ?>
                                                
                                        </td>
                                        
                                       <td>
                                            <?php echo $creditsrow->currency.$creditsrow->amount; ?>
                                                
                                        </td>
                                        <td>
                                            <?php if($creditsrow->status=="1"){ ?>
                                                <span class="label label-success">Active</span>
                                            <?php }else{ ?>
                                                <span class="label label-warning">Inactive</span>
                                            <?php } ?>
                                        </td>
                                    	
                                        <?php if($update || $delete){ ?>
                                    	<td>
                                        <?php if($update){ ?>
                                        <a href="<?php echo base_url(); ?>snackadmin/credits/edit/<?php echo $creditsrow->id; ?>"><i class="material-icons">create</i></a>
                                        <?php } ?>
                                        <?php
                                        
                                         if($delete){ ?>
                                            <a href="#" data-url="<?php echo base_url(); ?>snackadmin/credits/delete/<?php echo $creditsrow->id; ?>/"
                                       data-title="<?php  echo $creditsrow->credits; ?> Credits" class="js-sweetalert" data-type="confirm"> <i class="material-icons">delete</i></a>
                                       <?php } ?>
                                       </td>
                                       <?php } ?>
                                    </tr>
                                    <?php } } ?>
                                    </tbody>
                                   
                                    <tbody>   
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
        
        </div>
    </section>
