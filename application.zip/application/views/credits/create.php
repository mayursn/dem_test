<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                     <div id="message"></div>
                      <?php   echo print_notification(); ?>
                        <div class="header">
                             <h2><?php echo $page_title; ?></h2> 
                            

                        </div>
            <div class="body">
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade in active" id="home">
                        <form action="<?php echo base_url(); ?>snackadmin/credits/create" method="POST" enctype="multipart/form-data" id="credits">
                            <div class="row clearfix">
                               <div class="col-md-6">
                             
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="number" name="credits"  required="" id="credits" class="form-control" value="<?php echo set_value('credits'); ?>" placeholder="Credits">
                                    </div>

                                </div> 
                                </div>
                                     
                                </div>
								<div class="row clearfix">
                                 <div class="col-md-6">       
                                <div class="form-group">

                                    <div class="form-line">
                                        <input type="number" required="" name="amount" id="amount" class="form-control" value="<?php echo set_value('amount'); ?>" placeholder="Amount">                   
                                    </div>

                                </div> 
                                </div>

                                </div>
                                <div class="clearfix">
                                   <div class="col-md-6">
                                 <label for="user_status">Status</label>

	                                    <div class="form-group">    
	                                        <div class="switch">
	                                        <?php  $sel = ("on" == set_value('status')) ? 'checked=""' : ''; ?>
	                                            <label> Inactive <input type="checkbox" name="status" <?php  echo $sel; ?> ><span class="lever switch-col-green"></span> Active </label>
	                                        </div>
	                                    </div>
	                                    </div>
                                </div>
                                <div class="row clearfix">
                                	<div class="col-md-12">
                          <button class="btn btn-primary btn-lg m-l-15 waves-effect" type="submit">Save</button>
                          
                          <a href="<?php echo base_url(); ?>snackadmin/credits" class="btn btn-default  btn-lg m-l-15 waves-effect">Cancel</a>
                          </div>
                                </div>
                               
                                
                        
                            
                            </form>
                            
                            </div>
                          
                        </div> <!-- vbv -->
                    </div>
                   
                    


                </div>
            </div>           
           
        </div>
    </section>
