<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                     <?php   echo print_notification(); ?>
                        <div class="header">
                             <h2><?php echo $page_title; ?></h2> 
                            

                        </div>
                        <div class="body">
                          <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="home">
                            <form action="<?php echo base_url(); ?>snackadmin/cmspages/create" method="POST" enctype="multipart/form-data" id="createcms">
                            <div class="form-group form-float">
                                             <div class="form-line">
                           <input type="text" class="form-control" name="txtname" value="<?php echo set_value('txtname'); ?>" required="" autofocus="" aria-required="true" aria-invalid="false">
                           <label class="form-label">Title</label>
                        </div>
                     </div>
                     <p>Content </p>
                      <div class="form-group form-float">
                                             <div class="form-line">
                            <textarea id="editor" name="cms_content"><?php echo set_value('cms_content'); ?></textarea>
                            </div>
                            </div>

                            <div class="form-group form-float">
                                <label for="cms_date">Date</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="cms_date" name="cms_date" class="form-control customdatepicker" value="<?php echo set_value('cms_date'); ?>" placeholder="Date" >
                                    </div>
                                </div>
                            </div>
                            <div class="form-group form-float">
                                <label for="status">Status</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <select name="status" class="form-control show-tick" id="status">
                                    <?php $setval = (set_value('status')) ? set_value('status') : '' ?>
                                        <option value="1" <?php ($setval=="1")? "selected='selected'" : ''; ?> >Active</option>
                                        <option value="0" <?php ($setval=="0")? "selected='selected'" : ''; ?> >Inactive</option>
                                    </select>  
                                    </div>
                                </div>
                            </div>
                            <div class="form-group form-float">
                                <label class="form-label">Photo</label>
                                 <div class="form-line">
                                    <input type="file" name="cms_img"  class="form-control" autofocus=""  aria-required="true" aria-invalid="false">
                            
                                 </div>
                            </div>

                            
                                <br>
                                <div class="button-demo">
                                <button type="submit" class="btn btn-primary waves-effect">Save</button>
                                </div>
                            </form>
                            </div>
                          
                        </div> <!-- vbv >
                    </div>
                </div>
            </div>           
           
        </div>
    </section>
    <script type="text/javascript">
    	
    </script>