<?php


$create = check_methods_modules($moduleName,"perm_create");
$read = check_methods_modules($moduleName,"perm_read");
$update = check_methods_modules($moduleName,"perm_update");
$delete  = check_methods_modules($moduleName,"perm_delete");



 ?>


     <section class="content">
        <div class="container-fluid">
            <div class="block-header">
            <?php  echo print_notification(); ?>
                <!-- <h2>
                    JQUERY DATATABLES
                    <small>Taken from <a href="https://datatables.net/" target="_blank">datatables.net</a></small>
                </h2> -->
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <?php echo $page_title; ?>
                                <?php if($create){ ?>
                                <span class="right">
                                    <a href="<?php echo base_url(); ?>snackadmin/cmspages/create" class="btn btn-primary waves-effect">Add New</a><br><br>
                                </span>
                                <?php } ?>
                            </h2>
                           
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable" id="cmsPages">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <?php if($update || $delete){ ?>         
                                            <th>Action</th>
                                            <?php } ?>
                                        </tr>
                                    </thead>

                                    <tbody>
                                    <?php  if(count($cmspage) > 0 && !empty($cmspage)){ ?> 
                                    <?php foreach ($cmspage as $cmsrow) { ?>
                                    <tr>
                                    	<td>
                                            <?php echo $cmsrow->cms_title; ?>
                                                
                                        </td>
                                    	<td><?php echo $cmsrow->cms_date; ?></td>
                                    	<td><?php  echo status_active($cmsrow->cms_status); ?>
                                            
                                        </td>
                                        <?php if($update || $delete){ ?>
                                    	<td>
                                        <?php if($update){ ?>
                                        <a href="<?php echo base_url(); ?>snackadmin/cmspages/edit/<?php echo $cmsrow->cms_id; ?>"><i class="material-icons">create</i></a>
                                        <?php } ?>
                                        <?php if($delete){ ?>
                                           <!--  <a href="#" data-url="<?php echo base_url(); ?>cmspages/delete/<?php echo $cmsrow->cms_id; ?>/"
                                       data-title="<?php  echo $cmsrow->cms_title; ?>" class="js-sweetalert" data-type="confirm"> <i class="material-icons">delete</i></a> -->
                                       <?php } ?>
                                       </td>
                                       <?php } ?>
                                    </tr>
                                    <?php } } ?>
                                    </tbody>
                                    <!-- <tfoot>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Photo</th>
                                        </tr>
                                    </tfoot> -->
                                    <tbody>   
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
            
        </div>
    </section>
